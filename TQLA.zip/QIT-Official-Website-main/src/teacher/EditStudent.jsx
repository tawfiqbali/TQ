import { lockScroll } from '../lib/scrollLock';
import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { CalendarClock, Plus, Save, Shuffle, Trash2, X } from 'lucide-react';
import { useTeacher } from './TeacherContext';
import ScheduleEditor from './ScheduleEditor';
import { addMyStudent, isFlexible, requestStudentDelete, updateMyStudent } from '../lib/teacherData';
import { useConfirm } from '../components/ui/Confirm';
import { useToast } from '../components/ui/Toast';
import { useT } from './i18n';
import { useRequired } from './dashConfig';

const COURSES = ['Quran & Tajweed', 'Noorani Qaida', 'Nazera', 'Hifz', 'Arabic Language', 'Islamic Studies'];
const splitPhones = (text) => String(text || '').split(/\s*[,;\n|]\s*/).map((p) => p.trim()).filter((p) => p && p.toUpperCase() !== 'N/A');

/**
 * Teachers edit their own student: name, WhatsApp numbers, course, and the
 * schedule — fixed (weekly days and times) or flexible (log each class).
 * Saved to the student's record in the Management Portal as well.
 */
export default function EditStudent({ student: given, onClose }) {
  // No student given = add a new one
  const isNew = !given;
  const student = given || { id: '', name: '', phone: '', course: 'Quran & Tajweed', classTime: '', scheduleType: 'fixed' };
  const { reload, adminTeacherId } = useTeacher();
  const { t, err } = useT();
  const [sameAsk, setSameAsk] = useState(false);
  const [sameOk, setSameOk] = useState(false);
  const toast = useToast();
  const confirm = useConfirm();
  const [v, setV] = useState(() => ({
    name: student.name || '',
    phones: splitPhones(student.phone).length ? splitPhones(student.phone) : [''],
    course: student.course || '',
    classTime: student.classTime || '',
    scheduleType: isFlexible(student) ? 'flexible' : 'fixed',
    status: ['Hold', 'Inactive'].includes(student.status) ? student.status : 'Active',
    medium: ['Bangla Medium', 'English Medium'].includes(student.medium) ? student.medium : '',
    statusDate: new Date(Date.now() + 6 * 3600 * 1000).toISOString().slice(0, 10),
    assignDate: student.assignDate || '',
  }));
  const oldStatus = ['Hold', 'Inactive'].includes(student.status) ? student.status : 'Active';
  const statusChanged = !isNew && v.status !== oldStatus;
  const [delOpen, setDelOpen] = useState(false);
  const [delReason, setDelReason] = useState('');
  const [touched, setTouched] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const panel = useRef(null);
  // class days picked in the weekly editor but not added yet
  const pending = useRef(null);
  const req = useRequired();
  const nameOk = v.name.trim().length >= 2;
  // Fields the Executives made required (Dashboard Editor)
  const missing = {
    phone: req('stu.phone') && !v.phones.some((p) => p.trim()),
    course: req('stu.course') && !v.course.trim(),
    classTime: req('stu.classTime') && v.scheduleType === 'fixed' && !v.classTime.trim(),
    medium: !v.medium, // v156: Bangla / English Medium is always required
  };
  const Star = ({ k }) => (req(k) ? <span className="text-red-700" aria-hidden="true"> *</span> : null);
  const Miss = ({ k }) => (touched && missing[k] ? <p className="mt-1 text-xs text-red-700" role="alert">{t('common.required')}</p> : null);

  // Esc closes; focus the first field once when the dialog opens
  const closeRef = useRef(onClose);
  closeRef.current = busy ? () => {} : onClose;
  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && closeRef.current();
    document.addEventListener('keydown', onKey);
    const prev = lockScroll();
    setTimeout(() => panel.current?.querySelector('input')?.focus(), 30);
    return () => {
      document.removeEventListener('keydown', onKey);
      prev();
    };
  }, []);

  const setPhone = (i, val) => setV((x) => ({ ...x, phones: x.phones.map((p, j) => (j === i ? val : p)) }));

  const save = async (e) => {
    e.preventDefault();
    setTouched(true);
    if (!nameOk || Object.values(missing).some(Boolean) || busy) return;
    const toFlex = !isNew && v.scheduleType === 'flexible' && !isFlexible(student);
    if (toFlex && !(await confirm({ title: t('stu.toFlexQ'), message: t('stu.toFlexMsg', { name: v.name.trim() }), confirmText: t('stu.toFlexYes'), cancelText: t('stu.cancel') }))) return;
    setBusy(true);
    setError('');
    try {
      // Save changes also saves the class days and time chosen below
      const saveTimes = async () => (!isNew && v.scheduleType === 'fixed' && pending.current ? pending.current() : true);
      // (a student who was Flexible becomes Fixed first, then gets the class times)
      const wasFlex = !isNew && isFlexible(student);
      if (!wasFlex && !(await saveTimes())) {
        setBusy(false);
        return;
      }
      const row = {
        name: v.name.trim(),
        phone: v.phones.map((p) => p.trim()).filter(Boolean).join(', '),
        course: v.course.trim(),
        classTime: v.scheduleType === 'flexible' ? '' : v.classTime.trim(),
        scheduleType: v.scheduleType,
        medium: v.medium,
        // v151: the same child in a second class (same number + same name)
        ...(isNew && sameOk ? { sameStudent: true } : {}),
        // a new student is always Active
        ...(isNew ? (v.assignDate ? { assignDate: v.assignDate } : {}) : { status: v.status, ...(statusChanged ? { statusDate: v.statusDate } : {}) }),
      };
      if (isNew) await addMyStudent(row, adminTeacherId);
      else await updateMyStudent(student.id, row, adminTeacherId);
      if (wasFlex && !(await saveTimes())) {
        await reload();
        setBusy(false);
        return;
      }
      await reload();
      toast(isNew ? t('stu.added') : v.status !== 'Active' && v.status !== (student.status || 'Active') ? t('stu.movedToHistory') : t('stu.saved'));
      onClose();
    } catch (e2) {
      // v151: same number + same name: ask whether it is the same student's second class
      if (/same_student/.test(e2.message)) { setSameAsk(true); setError(''); setBusy(false); return; }
      setError(e2.message);
      setBusy(false);
    }
  };

  // Rendered at the page root, so the student card's hover lift and clipping don't affect it
  return createPortal(
    <div className="teacher-app fixed inset-0 z-50 flex items-end justify-center sm:items-center sm:p-6">
      <div className="absolute inset-0 bg-pine-950/60" onClick={() => !busy && onClose()} aria-hidden="true" />
      <form
        ref={panel}
        onSubmit={save}
        noValidate
        role="dialog"
        aria-modal="true"
        aria-labelledby="es-title"
        className="relative max-h-[92vh] w-full overflow-y-auto rounded-t-3xl bg-surface p-6 shadow-2xl sm:max-w-xl sm:rounded-3xl sm:p-7"
      >
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            <h2 id="es-title" className="text-xl text-heading">{isNew ? t('stu.addTitle') : t('stu.editTitle')}</h2>
            <p className="mt-1 text-sm text-ink/70">{isNew ? t('stu.addSub') : `${student.id} · ${t('stu.editSub')}`}</p>
          </div>
          <button type="button" className="icon-btn -mr-2 -mt-1" onClick={onClose} disabled={busy} aria-label={t('stu.close')}><X className="h-5 w-5" /></button>
        </div>

        <div className="space-y-4">
          {!isNew && (
            <div>
              <span className="label">{t('stu.status')}</span>
              <div className="grid grid-cols-3 gap-2" role="radiogroup" aria-label={t('stu.status')} data-testid="es-status">
                {[['Active', 'stu.statusActive', 'border-emerald-600 bg-emerald-50 text-emerald-900 dark:bg-emerald-900/30 dark:text-emerald-100'],
                  ['Hold', 'hist.hold', 'border-amber-500 bg-amber-50 text-amber-900 dark:bg-amber-900/30 dark:text-amber-100'],
                  ['Inactive', 'hist.inactive', 'border-slate-500 bg-slate-100 text-slate-800 dark:bg-white/10 dark:text-ink']].map(([k, label, on]) => (
                  <button key={k} type="button" role="radio" aria-checked={v.status === k} onClick={() => setV((x) => ({ ...x, status: k }))} data-testid={`es-status-${k}`}
                    className={`rounded-xl border-2 px-2 py-2.5 text-sm font-bold transition ${v.status === k ? on : 'border-ink/15 bg-surface text-ink/70 hover:border-ink/30'}`}>
                    {t(label)}
                  </button>
                ))}
              </div>
              <p className="mt-1 text-xs text-ink/65">{t(v.status === 'Active' ? 'stu.statusActiveHint' : 'stu.statusOffHint')}</p>
              {statusChanged && (
                <div className="mt-2 rounded-xl border border-amber-300 bg-amber-50 p-3 dark:bg-amber-900/20">
                  <label className="label" htmlFor="es-sdate">{t('stu.statusDate')}</label>
                  <input id="es-sdate" type="date" className="input" value={v.statusDate} onChange={(e) => setV({ ...v, statusDate: e.target.value })} data-testid="es-status-date" required />
                </div>
              )}
            </div>
          )}
          <div>
            <span className="label">{t('stu.medium')} <span className="text-red-700" aria-hidden="true">*</span></span>
            <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label={t('stu.medium')} data-testid="es-medium">
              {['Bangla Medium', 'English Medium'].map((m) => (
                <button key={m} type="button" role="radio" aria-checked={v.medium === m} onClick={() => setV((x) => ({ ...x, medium: m }))} data-testid={`es-medium-${m.split(' ')[0]}`}
                  className={`rounded-xl border-2 px-2 py-2.5 text-sm font-bold transition ${v.medium === m ? 'border-[#034751] bg-[#034751] text-white' : 'border-ink/15 bg-surface text-ink/70 hover:border-ink/30'}`}>
                  {t(m === 'Bangla Medium' ? 'stu.bangla' : 'stu.english')}
                </button>
              ))}
            </div>
            <Miss k="medium" />
          </div>
          {isNew && (
            <div>
              <label className="label" htmlFor="es-assign">{t('stu.assignDate')}</label>
              <input id="es-assign" type="date" className="input" value={v.assignDate} onChange={(e) => setV({ ...v, assignDate: e.target.value })} />
            </div>
          )}
          <div>
            <label className="label" htmlFor="es-name">{t('stu.name')} <span className="text-red-700" aria-hidden="true">*</span></label>
            <input id="es-name" className="input" maxLength={120} value={v.name} onChange={(e) => setV({ ...v, name: e.target.value })} aria-invalid={touched && !nameOk} />
            {touched && !nameOk && <p className="mt-1 text-xs text-red-700" role="alert">{t('stu.nameErr')}</p>}
          </div>

          <div>
            <span className="label">{t('stu.phones')}<Star k="stu.phone" /></span>
            <div className="space-y-2">
              {v.phones.map((p, i) => (
                <div key={i} className="flex gap-2">
                  <input className="input" type="tel" inputMode="tel" placeholder="+880 1XXX-XXXXXX" value={p} onChange={(e) => setPhone(i, e.target.value)} aria-label={`${t('stu.phones')} ${i + 1}`} />
                  {v.phones.length > 1 && (
                    <button type="button" className="icon-btn shrink-0 text-red-700" onClick={() => setV((x) => ({ ...x, phones: x.phones.filter((_, j) => j !== i) }))} aria-label={t('stu.removePhone')}>
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
            <Miss k="phone" />
            {v.phones.length < 4 && (
              <button type="button" className="btn-ghost btn-sm mt-2" onClick={() => setV((x) => ({ ...x, phones: [...x.phones, ''] }))}>
                <Plus className="h-4 w-4" /> {t('stu.addPhone')}
              </button>
            )}
          </div>

          <div>
            <label className="label" htmlFor="es-course">{t('stu.course')}<Star k="stu.course" /></label>
            <input id="es-course" className="input" list="es-courses" maxLength={120} placeholder={t('stu.coursePh')} value={v.course} onChange={(e) => setV({ ...v, course: e.target.value })} />
            <datalist id="es-courses">{COURSES.map((c) => <option key={c} value={c} />)}</datalist>
            <Miss k="course" />
          </div>

          <fieldset>
            <legend className="label">{t('stu.schedule')}</legend>
            <div className="grid grid-cols-2 gap-2" role="radiogroup">
              {[['fixed', CalendarClock], ['flexible', Shuffle]].map(([k, Icon]) => (
                <label key={k} className={`flex cursor-pointer items-center justify-center gap-2 rounded-xl border px-3 py-2.5 text-sm font-semibold transition ${v.scheduleType === k ? 'border-[#034751] bg-[#034751] text-white' : 'border-ink/15 text-ink/75 hover:border-[#005359]'}`}>
                  <input type="radio" name="es-sched" value={k} checked={v.scheduleType === k} onChange={() => setV({ ...v, scheduleType: k })} className="sr-only" />
                  <Icon className="h-4 w-4" aria-hidden="true" /> {t(`stu.${k}`)}
                </label>
              ))}
            </div>
            <p className="mt-1.5 text-xs text-ink/70">{v.scheduleType === 'flexible' ? t('stu.flexHint') : t('stu.fixedHint')}</p>
          </fieldset>

          {v.scheduleType === 'fixed' && (
            <>
              <div>
                <label className="label" htmlFor="es-time">{t('stu.classTime')}<Star k="stu.classTime" /></label>
                <input id="es-time" className="input" maxLength={120} placeholder={t('stu.classTimePh')} value={v.classTime} onChange={(e) => setV({ ...v, classTime: e.target.value })} aria-required={req('stu.classTime')} />
                <Miss k="classTime" />
              </div>
              {isNew ? <p className="text-xs text-ink/70">{t('stu.addSchedHint')}</p> : (
                <div className="rounded-2xl border border-ink/10 bg-paper/50 p-3.5">
                  <ScheduleEditor student={student} pendingRef={pending} />
                </div>
              )}
            </>
          )}
        </div>

        {!isNew && (
          <div className="mt-5 border-t border-ink/10 pt-4">
            {!delOpen ? (
              <button type="button" className="inline-flex items-center gap-1.5 text-sm font-semibold text-red-700 hover:underline" onClick={() => setDelOpen(true)} data-testid="es-delete">
                <Trash2 className="h-4 w-4" aria-hidden="true" /> {t('stu.delete')}
              </button>
            ) : (
              <div className="rounded-xl border border-red-200 bg-red-50 p-3 dark:bg-red-900/20">
                <p className="text-sm font-semibold text-red-900 dark:text-red-100">{t('stu.deleteHint')}</p>
                <textarea className="input mt-2" rows={2} maxLength={300} placeholder={t('stu.deleteReason')} value={delReason} onChange={(e) => setDelReason(e.target.value)} data-testid="es-delete-reason" />
                <div className="mt-2 flex justify-end gap-2">
                  <button type="button" className="btn-ghost btn-sm" onClick={() => setDelOpen(false)} disabled={busy}>{t('stu.cancel')}</button>
                  <button type="button" className="btn-sm rounded-xl bg-red-700 px-3 py-2 text-sm font-semibold text-white hover:bg-red-800" disabled={busy} data-testid="es-delete-send"
                    onClick={async () => {
                      setBusy(true);
                      try {
                        await requestStudentDelete(student.id, delReason.trim(), adminTeacherId);
                        await reload();
                        toast(t('stu.deleteSent'));
                        onClose();
                      } catch (e3) {
                        setError(e3.message);
                        setBusy(false);
                      }
                    }}>{t('stu.deleteSend')}</button>
                </div>
              </div>
            )}
          </div>
        )}
        {sameAsk && (
          <div className="t-same mt-4" role="alert" data-testid="same-student">
            <strong>{t('stu.sameTitle')}</strong>
            <p>{t('stu.sameText')}</p>
            <label><input type="checkbox" checked={sameOk} onChange={(e) => setSameOk(e.target.checked)} data-testid="same-ok" /> {t('stu.sameOk')}</label>
          </div>
        )}
        {error && <p className="mt-4 rounded-xl bg-red-50 px-3 py-2 text-sm text-red-800" role="alert">{err(error)}</p>}
        <div className="mt-5 flex justify-end gap-2">
          <button type="button" className="btn-ghost" onClick={onClose} disabled={busy}>{t('stu.cancel')}</button>
          <button type="submit" className="btn-primary" disabled={busy} data-testid="es-save"><Save className="h-4 w-4" /> {busy ? (isNew ? t('stu.adding') : t('stu.saving')) : isNew ? t('stu.addBtn') : t('stu.save')}</button>
        </div>
      </form>
    </div>,
    document.body,
  );
}
