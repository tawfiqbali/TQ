import { MONTHS, attendanceTotals, isoDay, listAttendance, listMyReports, salaryHistory, teacherSalary } from '../lib/teacherData';
import { esc, printDocument } from '../lib/printDoc';

/**
 * Teacher summary for one month as a printable PDF: progress, points,
 * each student's attendance and report, and the month's salary status.
 * Used by the teacher (My Progress) and by Executives (admin view).
 */
export async function downloadTeacherSummary({ tr, teacher, students, stats, month, year, adminTeacherId }) {
  const { t, n, lang, money, month: monthName, date } = tr;
  const m = MONTHS.indexOf(month);
  const from = isoDay(new Date(year, m, 1));
  const to = isoDay(new Date(year, m + 1, 0));
  const [att, reports, salary] = await Promise.all([
    listAttendance(from, to, adminTeacherId).catch(() => []),
    listMyReports(adminTeacherId).catch(() => []),
    teacherSalary(adminTeacherId).catch(() => null),
  ]);
  const rows = students.map((s) => {
    const x = attendanceTotals(att.filter((a) => a.student_id === s.id));
    const rep = reports.find((r) => r.student_id === s.id && r.month === month && r.year === Number(year));
    return { s, p: x.present, a: x.absent, r: x.recovery, c: x.conducted, rate: x.rate, rep };
  });
  const sal = salaryHistory(salary).find((r) => r.month === month && r.year === Number(year));
  const pts = stats?.points?.month || {};
  const lvl = stats?.level ? (lang === 'bn' ? stats.level.bn : stats.level.en) : '—';
  const badge = (status) => {
    const cls = { reviewed: 'ok', submitted: 'warn', needs_changes: 'bad', Paid: 'ok', Pending: 'warn', Unpaid: 'bad' }[status] || 'warn';
    return `<span class="badge ${cls}">${esc(t(`badge.${status}`))}</span>`;
  };
  const title = `${teacher?.fullName || teacher?.name || ''} (${teacher?.id}) — ${monthName(month)} ${n(year)}`;

  const body = `
<h1>${esc(t('pdf.title'))}</h1>
<p class="muted">${esc(teacher?.fullName || teacher?.name || '')} · ${esc(t('brand.id'))} <b>${esc(teacher?.id)}</b> · ${esc(monthName(month))} ${esc(n(year))}</p>
<div class="tiles">
  <div class="tile"><small>${esc(t('pg.attRate'))}</small><b>${stats?.attendance?.rate == null ? '—' : esc(n(stats.attendance.rate)) + '%'}</b></div>
  <div class="tile"><small>${esc(t('pg.monthPoints'))}</small><b>${esc(n(pts.total ?? 0))}</b></div>
  <div class="tile"><small>${esc(t('pg.level'))}</small><b>${esc(lvl)}</b></div>
  <div class="tile"><small>${esc(t('pg.rank'))}</small><b>${stats?.rank ? `#${esc(n(stats.rank.position))} / ${esc(n(stats.rank.of))}` : '—'}</b></div>
</div>
<h2>${esc(t('pdf.students'))}</h2>
<table><thead><tr><th>${esc(t('rp.student'))}</th><th class="num">${esc(t('att.present'))}</th><th class="num">${esc(t('att.absent'))}</th><th class="num">${esc(t('att.recoveryShort'))}</th><th class="num">${esc(t('att.conducted'))}</th><th class="num">%</th><th>${esc(t('pdf.report'))}</th><th>${esc(t('rp.lesson'))}</th></tr></thead><tbody>
${rows.map((r) => `<tr><td>${esc(r.s.name)}<br><span class="muted">${esc(r.s.id)}</span></td><td class="num">${esc(n(r.p))}</td><td class="num">${esc(n(r.a))}</td><td class="num">${esc(n(r.r))}</td><td class="num">${esc(n(r.c))}</td><td class="num">${r.rate == null ? '—' : esc(n(r.rate))}</td><td>${r.rep ? badge(r.rep.review_status) : `<span class="badge bad">${esc(t('badge.missing'))}</span>`}</td><td>${esc(r.rep?.current_lesson || '')}</td></tr>`).join('') || `<tr><td colspan="8" class="muted">${esc(t('home.noneTitle'))}</td></tr>`}
</tbody></table>
<h2>${esc(t('pdf.points'))}</h2>
<table><tbody>
${['present', 'daysLogged', 'reports', 'onTime', 'reviewed', 'perfectAttendance', 'studentLevels', 'adjustments'].map((k) => `<tr><td>${esc(t(`pg.pt.${k}`))}</td><td class="num">${esc(n(pts[k] ?? 0))}</td></tr>`).join('')}
<tr><td><b>${esc(t('pg.total'))}</b></td><td class="num"><b>${esc(n(pts.total ?? 0))}</b></td></tr>
</tbody></table>
<h2>${esc(t('sal.title'))}</h2>
<table><tbody>
<tr><td>${esc(t('sal.monthly'))}</td><td class="num">${esc(money(salary?.monthlySalary || 0))}</td></tr>
<tr><td>${esc(t('sal.paid'))} (${esc(monthName(month))})</td><td class="num">${esc(money(sal?.paid || 0))}</td></tr>
<tr><td>${esc(t('sal.status'))}</td><td>${sal ? badge(sal.status) : '—'}${sal?.dates?.length ? ` <span class="muted">${esc(sal.dates.map((d) => date(String(d).slice(0, 10))).join(', '))}</span>` : ''}</td></tr>
</tbody></table>
<p class="muted" style="margin-top:14px">${esc(t('pdf.note'))}</p>`;

  return printDocument({ title, body, lang });
}
