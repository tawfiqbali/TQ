import { lazy, Suspense, useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Save, ShieldCheck, SlidersHorizontal, Star, Trash2, UserCheck, UserCog, UserX } from 'lucide-react';
import { useTeacher } from './TeacherContext';
import { useToast } from '../components/ui/Toast';
import { useConfirm } from '../components/ui/Confirm';
import { isGmail } from '../lib/auth';
import { MONTHS, addAdjustment, adminUpdateTeacherRecord, deleteAdjustment, listAdjustments, updateTeacherProfile } from '../lib/teacherData';

/**
 * Executive-only panel on a teacher's dashboard (admin mode): edit the
 * teacher's name, WhatsApp and Gmail everywhere at once, and give bonus or
 * deduction points. Everything else on the dashboard is edited in place.
 */
const AdminOfficePanel = lazy(() => import('./AdminOfficePanel'));

export default function AdminTeacherTools() {
  const { teacher, adminTeacherId, access, reload } = useTeacher();
  const toast = useToast();
  const confirm = useConfirm();
  const [form, setForm] = useState({ name: teacher?.fullName || teacher?.name || '', whatsapp: teacher?.whatsapp || '', email: teacher?.email || '' });
  const [busy, setBusy] = useState(false);
  const now = new Date();
  const [adj, setAdj] = useState({ month: MONTHS[now.getMonth()], year: now.getFullYear(), points: '', reason: '' });
  const [list, setList] = useState([]);

  const loadAdj = useCallback(() => listAdjustments(adminTeacherId).then(setList).catch(() => setList([])), [adminTeacherId]);
  useEffect(() => {
    loadAdj();
  }, [loadAdj]);

  const gmail = form.email.trim().toLowerCase();
  const saveProfile = async (e) => {
    e.preventDefault();
    if (form.name.trim().length < 2) return toast('Enter the teacher’s full name.', 'error');
    if (gmail && !isGmail(gmail)) return toast('Enter a Gmail address (…@gmail.com).', 'error');
    setBusy(true);
    try {
      await adminUpdateTeacherRecord(adminTeacherId, { name: form.name.trim(), whatsapp: form.whatsapp.trim() || 'N/A', email: gmail || null });
      if (teacher?.userId) await updateTeacherProfile(teacher.userId, { full_name: form.name.trim(), whatsapp: form.whatsapp.trim() || teacher.whatsapp, email: gmail || teacher.email });
      toast('Teacher details saved everywhere.');
      reload();
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setBusy(false);
    }
  };

  const addPoints = async (e) => {
    e.preventDefault();
    const pts = Number(adj.points);
    if (!Number.isInteger(pts) || pts === 0) return toast('Enter a whole number of points (use a minus sign for a deduction).', 'error');
    try {
      await addAdjustment({ teacher_id: adminTeacherId, month: adj.month, year: Number(adj.year), points: pts, reason: adj.reason.trim() || null, created_by: access?.adminEmail || null });
      toast(pts > 0 ? `${pts} bonus points added.` : `${Math.abs(pts)} points deducted.`);
      setAdj((a) => ({ ...a, points: '', reason: '' }));
      loadAdj();
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  const removeAdj = async (row) => {
    if (!(await confirm({ title: 'Remove this adjustment?', message: `${row.points > 0 ? '+' : ''}${row.points} points for ${row.month} ${row.year}${row.reason ? ` — ${row.reason}` : ''}.`, confirmText: 'Remove', tone: 'danger' }))) return;
    try {
      await deleteAdjustment(row.id);
      toast('Adjustment removed.');
      loadAdj();
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  return (
    <>
    <section className="t-exec mb-6" lang="en" aria-labelledby="exec-title">
      <div className="t-exec-head">
        <div className="min-w-0">
          <h2 id="exec-title" className="flex items-center gap-2 text-lg font-extrabold text-heading">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gold-500 text-white"><ShieldCheck className="h-4 w-4" aria-hidden="true" /></span>
            Executive tools
            <span className="rounded-full bg-white/70 px-2 py-0.5 text-[11px] font-bold uppercase tracking-wider text-gold-800 ring-1 ring-gold-300 dark:bg-black/20 dark:text-gold-200">Only Executives see this</span>
          </h2>
          <p className="mt-1 text-sm text-ink/70">Changes here update the Teachers List / Salary Directory and the teacher’s account together.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
        <Link to="/admin/portal?tab=dashEditor" className="inline-flex items-center gap-1.5 rounded-full bg-white/80 px-3 py-1 text-xs font-bold text-[#034751] ring-1 ring-[#034751]/25 hover:bg-white dark:bg-black/20 dark:text-gold-100" data-testid="open-dash-editor">
          <SlidersHorizontal className="h-3.5 w-3.5" aria-hidden="true" /> Edit texts &amp; required fields (all teachers)
        </Link>
        <span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold ${teacher?.hasAccount ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200' : 'bg-slate-200 text-slate-700 dark:bg-white/10 dark:text-slate-200'}`}>
          {teacher?.hasAccount ? <UserCheck className="h-3.5 w-3.5" aria-hidden="true" /> : <UserX className="h-3.5 w-3.5" aria-hidden="true" />}
          {teacher?.hasAccount ? 'Has signed in' : 'Has not signed in yet'}
        </span>
        </div>
      </div>
      <div className="grid gap-4 p-4 sm:p-5 lg:grid-cols-2">
        <form onSubmit={saveProfile} className="t-sub t-k-teal space-y-3">
          <p className="t-sub-title"><UserCog className="h-4 w-4" aria-hidden="true" /> Teacher details</p>
          <div>
            <label className="label" htmlFor="at-name">Full name</label>
            <input id="at-name" className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <label className="label" htmlFor="at-wa">WhatsApp</label>
              <input id="at-wa" className="input" placeholder="+880 1…" value={form.whatsapp} onChange={(e) => setForm({ ...form, whatsapp: e.target.value })} />
            </div>
            <div>
              <label className="label" htmlFor="at-gmail">Gmail (sign-in)</label>
              <input id="at-gmail" type="email" className="input" placeholder="name@gmail.com" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </div>
          </div>
          <button type="submit" className="btn-primary btn-sm" disabled={busy}><Save className="h-4 w-4" /> {busy ? 'Saving…' : 'Save details'}</button>
        </form>

        <div className="t-sub t-k-gold">
          <p className="t-sub-title"><Star className="h-4 w-4" aria-hidden="true" /> Bonus / deduction points</p>
          <form onSubmit={addPoints} className="grid gap-2 sm:grid-cols-[1fr_5.5rem_5.5rem]">
            <div>
              <label className="label" htmlFor="adj-month">Month</label>
              <select id="adj-month" className="input" value={adj.month} onChange={(e) => setAdj({ ...adj, month: e.target.value })}>
                {MONTHS.map((m) => <option key={m}>{m}</option>)}
              </select>
            </div>
            <div>
              <label className="label" htmlFor="adj-year">Year</label>
              <input id="adj-year" className="input" type="number" value={adj.year} onChange={(e) => setAdj({ ...adj, year: e.target.value })} />
            </div>
            <div>
              <label className="label" htmlFor="adj-pts">Points</label>
              <input id="adj-pts" className="input" type="number" placeholder="+20" value={adj.points} onChange={(e) => setAdj({ ...adj, points: e.target.value })} />
            </div>
            <div className="sm:col-span-2">
              <label className="label" htmlFor="adj-reason">Reason</label>
              <input id="adj-reason" className="input" maxLength={300} placeholder="e.g. extra classes during Ramadan" value={adj.reason} onChange={(e) => setAdj({ ...adj, reason: e.target.value })} />
            </div>
            <div className="flex items-end">
              <button type="submit" className="btn-outline btn-sm w-full justify-center"><Plus className="h-4 w-4" /> Add</button>
            </div>
          </form>
          <p className="t-stu-lbl mt-4">History</p>
          <ul className="mt-1.5 max-h-48 space-y-1.5 overflow-y-auto">
            {list.map((row) => (
              <li key={row.id} className="flex items-center justify-between gap-2 rounded-lg border border-ink/10 bg-surface px-3 py-1.5 text-sm">
                <span><b className={row.points < 0 ? 'text-red-700' : 'text-emerald-700'}>{row.points > 0 ? '+' : ''}{row.points}</b> · {row.month} {row.year}{row.reason ? ` · ${row.reason}` : ''}</span>
                <button type="button" className="icon-btn text-red-700" onClick={() => removeAdj(row)} aria-label="Remove adjustment"><Trash2 className="h-4 w-4" /></button>
              </li>
            ))}
            {!list.length && <li className="text-sm text-ink/70">No adjustments yet.</li>}
          </ul>
        </div>
      </div>
    </section>
    {/* admin mode is Executive-only */}
    <Suspense fallback={null}><AdminOfficePanel teacherId={adminTeacherId} /></Suspense>
    </>
  );
}
