import { useState } from 'react';
import { PortalProvider, usePortal } from '../admin/portal/PortalContext';
import { AssignStudentModal, EditStudentModal, statusOf } from '../admin/portal/panels/common';
import AttendanceLog from '../admin/portal/panels/AttendanceLog';
import { fmt, feeFor, currentMonthName } from '../admin/portal/lib/constants';
import '../admin/portal/portal.css';

// v156: Executives on a teacher's dashboard: every student detail (payments
// too), delete, Assign Students, and this teacher's attendance log (edit / delete)
function Office({ teacherId }) {
  const { db, status, isSuper, deleteStudent } = usePortal();
  const [editing, setEditing] = useState(null);
  const [assign, setAssign] = useState(false);
  const [showLog, setShowLog] = useState(false);
  if (status !== 'ready') return <div className="box-card text-sm">Loading office records…</div>;
  const teacher = db.teachers.find((t) => t.id === teacherId);
  const list = db.students.filter((s) => s.teacherId === teacherId);
  const m = currentMonthName();
  const y = String(new Date().getFullYear());
  return (
    <div className="box-card" data-testid="office-panel">
      <div className="card-header-bar">
        <h2 className="card-title">Office · students &amp; attendance</h2>
        <div className="flex flex-wrap gap-2">
          {teacher && <button type="button" className="btn-teal" onClick={() => setAssign(true)} data-testid="office-assign">+ Assign Students</button>}
          <button type="button" className={`btn-outline-sm ${showLog ? 'is-on' : ''}`} onClick={() => setShowLog((v) => !v)} data-testid="office-log">{showLog ? 'Hide attendance log' : 'Attendance log'}</button>
        </div>
      </div>
      <div className="table-wrap">
        <table className="salary-table row-cards" style={{ minWidth: 560 }}>
          <thead><tr><th>Student</th><th>Status</th><th>Payment ({m.slice(0, 3)})</th>{isSuper && <th>Teacher share</th>}<th style={{ textAlign: 'right' }}>Action</th></tr></thead>
          <tbody>
            {!list.length && <tr><td colSpan={5} style={{ textAlign: 'center', padding: 14 }}>No students.</td></tr>}
            {list.map((s) => (
              <tr key={s.id} className={`row-card st-${statusOf(s).toLowerCase()}`} onClick={(e) => { if (!e.target.closest('button')) setEditing(s); }}>
                <td><strong>{s.name}</strong> <span className="id-tag">{s.id}</span>{s.deleteRequest && <span className="st-badge no ml-1.5">Delete requested</span>}</td>
                <td>{statusOf(s)}</td>
                <td>{fmt(feeFor(s, m, y))} BDT</td>
                {isSuper && <td>{fmt(s.cut)} BDT</td>}
                <td style={{ textAlign: 'right' }} className="whitespace-nowrap">
                  <button type="button" className="btn-outline-sm mr-1" onClick={() => setEditing(s)} data-testid={`office-edit-${s.id}`}>Edit all</button>
                  {isSuper && <button type="button" className="btn-danger" style={{ padding: '6px 10px' }} onClick={() => { if (window.confirm(`Delete ${s.name} (${s.id})? This cannot be undone.`)) deleteStudent(s.id); }} data-testid={`office-del-${s.id}`}>Delete</button>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {showLog && <div className="mt-5"><AttendanceLog presetTeacher={teacherId} /></div>}
      {editing && <EditStudentModal student={editing} onClose={() => setEditing(null)} />}
      {assign && teacher && <AssignStudentModal teacher={teacher} onClose={() => setAssign(false)} />}
    </div>
  );
}

export default function AdminOfficePanel({ teacherId }) {
  return (
    <div className="qit-portal mb-6" style={{ padding: 0, background: 'transparent' }}>
      <PortalProvider>
        <Office teacherId={teacherId} />
      </PortalProvider>
    </div>
  );
}
