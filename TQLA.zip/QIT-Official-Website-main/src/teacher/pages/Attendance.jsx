import { lockScroll } from '../../lib/scrollLock';
import { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Check, CheckCircle2, ChevronLeft, ChevronRight, History, Lock, Plus, RotateCcw, Send, Shuffle, X } from 'lucide-react';
import { useTeacher } from '../TeacherContext';
import { Card, EmptyState, PageHeader, Stat } from '../ui';
import { addAttendance, attendanceTotals, isFlexible, isoDay, listAttendance } from '../../lib/teacherData';
import { useToast } from '../../components/ui/Toast';
import { useConfirm } from '../../components/ui/Confirm';
import { useT } from '../i18n';
import { useRequired } from '../dashConfig';

const addDays = (iso, n) => {
  const d = new Date(`${iso}T12:00:00`);
  d.setDate(d.getDate() + n);
  return isoDay(d);
};
const monthRange = (iso) => {
  const d = new Date(`${iso}T12:00:00`);
  return [isoDay(new Date(d.getFullYear(), d.getMonth(), 1)), isoDay(new Date(d.getFullYear(), d.getMonth() + 1, 0))];
};
const LESSON_MAX = 1000;
// lessonReq: whether the Executives made “Today’s lesson” required (Dashboard Editor)
// Absent: no lesson is asked for; the reason for the absence is required instead.
const ready = (v, lessonReq = true) => {
  if (!v?.status) return false;
  if (v.status === 'absent') return (v.note || '').trim().length >= 2;
  return !lessonReq || (v.lesson || '').trim().length >= 2;
};

function useStamp() {
  const { t, time, date } = useT();
  return (iso) => {
    if (!iso) return '';
    const d = new Date(iso);
    return t('att.submittedAt', { time: `${date(isoDay(d), { day: 'numeric', month: 'short' })}, ${time(`${d.getHours()}:${d.getMinutes()}`)}` });
  };
}

// A submitted entry: read-only
function EntryView({ row, recovery }) {
  const { t } = useT();
  const stamp = useStamp();
  const present = row.status === 'present';
  return (
    <div className={`rounded-xl border px-3.5 py-3 ${recovery ? 'border-gold-300/70 bg-tint-gold/60' : 'border-ink/10 bg-paper/60'}`} data-testid={recovery ? 'recovery-entry' : 'regular-entry'}>
      <div className="flex flex-wrap items-center gap-2 text-xs font-semibold">
        {recovery && <span className="inline-flex items-center gap-1 rounded-full bg-gold-500 px-2 py-0.5 text-white"><RotateCcw className="h-3 w-3" aria-hidden="true" />{t('att.recoveryShort')}</span>}
        <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 ${present ? 'bg-emerald-100 text-emerald-900 dark:bg-emerald-900/40 dark:text-emerald-100' : 'bg-red-100 text-red-900 dark:bg-red-900/40 dark:text-red-100'}`}>
          {present ? <Check className="h-3 w-3" aria-hidden="true" /> : <X className="h-3 w-3" aria-hidden="true" />}
          {present ? t('att.present') : t('att.absent')}
        </span>
        <span className="text-ink/60">{stamp(row.created_at)}</span>
        {row.edited_at && <span className="text-gold-700 dark:text-gold-300">· {t('att.editedByOffice')}</span>}
        {recovery && row.approval === 'pending' && <span className="rounded-full bg-amber-100 px-2 py-0.5 text-amber-900 dark:bg-amber-900/40 dark:text-amber-100" data-testid="rec-pending">{t('stu.recPending')}</span>}
        {recovery && row.approval === 'rejected' && <span className="rounded-full bg-red-100 px-2 py-0.5 text-red-900 dark:bg-red-900/40 dark:text-red-100">{t('stu.recRejected')}</span>}
      </div>
      {row.lesson && (
        <p className="mt-2 whitespace-pre-line text-sm text-ink/85"><span className="font-semibold text-heading">{t('att.lesson')}: </span>{row.lesson}</p>
      )}
      {row.note && <p className="mt-1 text-xs text-ink/65">{row.note}</p>}
    </div>
  );
}

// One student's regular class for the chosen day
const StudentRow = memo(function StudentRow({ student, slotsToday, entry, recoveries, value, open, busy, onChange, onSubmit, lessonReq = true }) {
  const { t, time } = useT();
  const status = value?.status || '';
  const lessonId = `lesson-${student.id}`;
  const done = Boolean(entry);
  return (
    <li
      data-student={student.id}
      className={`rounded-2xl border p-4 transition ${done ? 'border-ink/10 bg-surface' : status === 'present' ? 'border-emerald-300 bg-emerald-50/60 dark:border-emerald-800 dark:bg-emerald-900/20' : status === 'absent' ? 'border-red-300 bg-red-50/60 dark:border-red-900 dark:bg-red-900/20' : 'border-ink/10 bg-surface'}`}
    >
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="font-semibold text-heading">{student.name}</p>
          <p className="text-xs text-ink/70">
            {student.id}
            {slotsToday.length ? ` · ${t('att.classAt', { time: slotsToday.map((s) => time(s.start_time)).join(', ') })}` : ''}
          </p>
        </div>
        {done ? (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-[#034751] px-3 py-1.5 text-xs font-bold text-white" data-testid="completed">
            <CheckCircle2 className="h-4 w-4" aria-hidden="true" /> {t('att.completed')}
          </span>
        ) : !open ? (
          <span className="text-xs font-semibold text-ink/55">{t('att.notMarked')}</span>
        ) : (
          <div className="flex gap-2" role="radiogroup" aria-label={t('att.statusFor', { name: student.name })}>
            {[['present', Check, 'emerald'], ['absent', X, 'red']].map(([key, Icon, c]) => (
              <button
                key={key}
                type="button"
                role="radio"
                aria-checked={status === key}
                disabled={busy}
                onClick={() => onChange(student.id, { status: status === key ? '' : key })}
                className={`inline-flex min-w-[6.5rem] items-center justify-center gap-1.5 rounded-xl border px-3 py-2 text-sm font-semibold transition disabled:opacity-50 ${status === key ? (c === 'emerald' ? 'border-emerald-700 bg-emerald-700 text-white' : 'border-red-700 bg-red-700 text-white') : `border-ink/15 text-ink/75 ${c === 'emerald' ? 'hover:border-emerald-600' : 'hover:border-red-600'}`}`}
              >
                <Icon className="h-4 w-4" aria-hidden="true" /> {t(`att.${key}`)}
              </button>
            ))}
          </div>
        )}
      </div>

      {done && (
        <div className="mt-3 space-y-2">
          <EntryView row={entry} />
          <p className="flex items-center gap-1.5 text-[11px] font-semibold text-ink/55"><Lock className="h-3 w-3" aria-hidden="true" /> {t('att.lockedNote')}</p>
        </div>
      )}

      {!done && open && (
        <div className="mt-3 space-y-2.5">
          {status !== 'absent' && (
          <div>
            <label htmlFor={lessonId} className="mb-1 block text-xs font-bold text-heading">
              {t('att.lesson')} {lessonReq && <span className="text-red-700" aria-hidden="true">*</span>}
            </label>
            <textarea
              id={lessonId}
              rows={2}
              maxLength={LESSON_MAX}
              className="input min-h-[3.25rem] resize-y"
              placeholder={t('att.lessonPh')}
              aria-label={t('att.lessonFor', { name: student.name })}
              aria-required={lessonReq}
              disabled={busy}
              value={value?.lesson || ''}
              onChange={(e) => onChange(student.id, { lesson: e.target.value })}
            />
          </div>
          )}
          {status === 'absent' && (
            <div>
              <label htmlFor={`reason-${student.id}`} className="mb-1 block text-xs font-bold text-heading">
                {t('att.reasonLabel')} <span className="text-red-700" aria-hidden="true">*</span>
              </label>
              <input
                id={`reason-${student.id}`}
                className="input"
                maxLength={300}
                disabled={busy}
                placeholder={t('att.reasonPh')}
                aria-label={t('att.reasonFor', { name: student.name })}
                aria-required="true"
                value={value?.note || ''}
                onChange={(e) => onChange(student.id, { note: e.target.value })}
                data-testid="absent-reason"
              />
            </div>
          )}
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="text-[11px] font-semibold text-ink/55">
              {!status ? t('att.needStatus') : !ready(value, lessonReq) ? (status === 'absent' ? t('att.needReason') : t('att.needLesson')) : t('att.lockHint')}
            </p>
            <button type="button" className="btn-primary btn-sm" disabled={!ready(value, lessonReq) || busy} onClick={() => onSubmit([student.id])} data-testid="submit-one">
              <Send className="h-4 w-4" aria-hidden="true" /> {busy ? t('att.submitting') : t('att.submit')}
            </button>
          </div>
        </div>
      )}

      {recoveries.length > 0 && (
        <div className="mt-3 space-y-2">
          {recoveries.map((r) => <EntryView key={r.id} row={r} recovery />)}
        </div>
      )}
    </li>
  );
});

// "Log recovery class": a make-up class on any day, tagged is_recovery
function RecoveryDialog({ students, defaultDay, earliest, today, adminTeacherId, onClose, onSaved }) {
  const { t, date } = useT();
  const req = useRequired();
  const toast = useToast();
  const confirm = useConfirm();
  const [v, setV] = useState({ student: students.length === 1 ? students[0].id : '', day: defaultDay, status: 'present', lesson: '', note: '' });
  const [touched, setTouched] = useState(false);
  const [busy, setBusy] = useState(false);
  const panel = useRef(null);
  const set = (k) => (e) => setV((x) => ({ ...x, [k]: e.target.value }));
  const errors = {
    student: v.student ? '' : t('att.recChoose'),
    day: v.day && v.day <= today && v.day >= earliest ? '' : t('att.outOfRange'),
    lesson: v.status === 'absent' || !req('rec.lesson') || v.lesson.trim().length >= 2 ? '' : t('att.needLesson'),
    note: (v.status === 'absent' ? v.note.trim().length < 2 : req('rec.note') && !v.note.trim()) ? (v.status === 'absent' ? t('att.needReason') : t('common.required')) : '',
  };
  const valid = !errors.student && !errors.day && !errors.lesson && !errors.note;

  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && !busy && onClose();
    document.addEventListener('keydown', onKey);
    const prev = lockScroll();
    setTimeout(() => panel.current?.querySelector('select, textarea, input')?.focus(), 30);
    return () => {
      document.removeEventListener('keydown', onKey);
      prev();
    };
  }, [busy, onClose]);

  const submit = async (e) => {
    e.preventDefault();
    setTouched(true);
    if (!valid || busy) return;
    const name = students.find((s) => s.id === v.student)?.name || v.student;
    if (!(await confirm({ title: t('att.recTitle'), message: t('att.recConfirm', { name, date: date(v.day, { day: 'numeric', month: 'long' }) }), confirmText: t('att.confirmBtn'), cancelText: t('att.cancel') }))) return;
    setBusy(true);
    try {
      await addAttendance({
        student_id: v.student, day: v.day, status: v.status, lesson: v.status === 'absent' ? null : v.lesson.trim() || null, note: v.note.trim() || null, is_recovery: true,
        ...(adminTeacherId ? { teacher_id: adminTeacherId } : {}),
      });
      toast(t('att.recSaved'));
      onSaved(v.day);
    } catch (err) {
      toast(err.message, 'error');
      setBusy(false);
    }
  };

  const show = (k) => (touched ? errors[k] : '');
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center sm:p-6">
      <div className="absolute inset-0 bg-pine-950/60" onClick={() => !busy && onClose()} aria-hidden="true" />
      <form
        ref={panel}
        onSubmit={submit}
        noValidate
        role="dialog"
        aria-modal="true"
        aria-labelledby="rec-title"
        className="relative max-h-[92vh] w-full overflow-y-auto rounded-t-3xl bg-surface p-6 shadow-2xl sm:max-w-lg sm:rounded-3xl sm:p-7"
      >
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            <h2 id="rec-title" className="flex items-center gap-2 text-xl text-heading">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gold-500 text-white"><RotateCcw className="h-4 w-4" aria-hidden="true" /></span>
              {t('att.recTitle')}
            </h2>
            <p className="mt-1.5 text-sm text-ink/70">{t('att.recSub')}</p>
          </div>
          <button type="button" className="icon-btn -mr-2 -mt-1" onClick={onClose} disabled={busy} aria-label={t('att.close')}><X className="h-5 w-5" /></button>
        </div>
        <div className="space-y-4">
          <div>
            <label className="label" htmlFor="rec-student">{t('att.recStudent')} <span className="text-red-700" aria-hidden="true">*</span></label>
            <select id="rec-student" className="input" value={v.student} onChange={set('student')} aria-invalid={Boolean(show('student'))}>
              <option value="">{t('att.recChoose')}</option>
              {students.map((s) => <option key={s.id} value={s.id}>{s.name} ({s.id})</option>)}
            </select>
            {show('student') && <p className="mt-1 text-xs text-red-700" role="alert">{show('student')}</p>}
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="label" htmlFor="rec-day">{t('att.recDate')}</label>
              <input id="rec-day" type="date" className="input" min={earliest} max={today} value={v.day} onChange={set('day')} aria-invalid={Boolean(show('day'))} />
              {show('day') && <p className="mt-1 text-xs text-red-700" role="alert">{show('day')}</p>}
              {!adminTeacherId && v.day && v.day.slice(0, 7) < today.slice(0, 7) && <p className="mt-1 text-xs font-semibold text-amber-800 dark:text-amber-200" data-testid="rec-needs-approval">{t('stu.recPendingHint')}</p>}
            </div>
            <fieldset>
              <legend className="label">{t('att.recStatus')}</legend>
              <div className="flex gap-2">
                {['present', 'absent'].map((k) => (
                  <label key={k} className={`flex flex-1 cursor-pointer items-center justify-center gap-1.5 rounded-xl border px-3 py-2.5 text-sm font-semibold transition ${v.status === k ? (k === 'present' ? 'border-emerald-700 bg-emerald-700 text-white' : 'border-red-700 bg-red-700 text-white') : 'border-ink/15 text-ink/75'}`}>
                    <input type="radio" name="rec-status" value={k} checked={v.status === k} onChange={set('status')} className="sr-only" />
                    {t(`att.${k}`)}
                  </label>
                ))}
              </div>
            </fieldset>
          </div>
          {v.status !== 'absent' && (
          <div>
            <label className="label" htmlFor="rec-lesson">{t('att.lesson')} {req('rec.lesson') && <span className="text-red-700" aria-hidden="true">*</span>}</label>
            <textarea id="rec-lesson" rows={3} maxLength={LESSON_MAX} className="input" placeholder={t('att.lessonPh')} value={v.lesson} onChange={set('lesson')} aria-invalid={Boolean(show('lesson'))} aria-required={req('rec.lesson')} />
            {show('lesson') && <p className="mt-1 text-xs text-red-700" role="alert">{show('lesson')}</p>}
          </div>
          )}
          <div>
            <label className="label" htmlFor="rec-note">{v.status === 'absent' ? t('att.reasonLabel') : t('att.recFor')} {(v.status === 'absent' || req('rec.note')) && <span className="text-red-700" aria-hidden="true">*</span>}</label>
            <input id="rec-note" className="input" maxLength={300} placeholder={t('att.recForPh')} value={v.note} onChange={set('note')} aria-invalid={Boolean(show('note'))} aria-required={req('rec.note')} />
            {show('note') && <p className="mt-1 text-xs text-red-700" role="alert">{show('note')}</p>}
          </div>
        </div>
        <p className="mt-4 flex items-center gap-1.5 text-xs font-semibold text-ink/60"><Lock className="h-3.5 w-3.5" aria-hidden="true" /> {t('att.lockHint')}</p>
        <div className="mt-4 flex justify-end gap-2">
          <button type="button" className="btn-ghost" onClick={onClose} disabled={busy}>{t('att.cancel')}</button>
          <button type="submit" className="btn-gold" disabled={busy} data-testid="rec-submit">
            <Send className="h-4 w-4" aria-hidden="true" /> {busy ? t('att.submitting') : t('att.recSave')}
          </button>
        </div>
      </form>
    </div>
  );
}

// Flexible-schedule student: log each completed class (no fixed days, no absences)
function FlexDialog({ student, logged, monthLabel, earliest, today, adminTeacherId, onClose, onSaved }) {
  const { t, date } = useT();
  const toast = useToast();
  const confirm = useConfirm();
  const [v, setV] = useState({ day: today, lesson: '', note: '' });
  const req = useRequired();
  const [touched, setTouched] = useState(false);
  const [busy, setBusy] = useState(false);
  const panel = useRef(null);
  const errors = { day: v.day && v.day <= today && v.day >= earliest ? '' : t('att.outOfRange'), lesson: !req('flex.lesson') || v.lesson.trim().length >= 2 ? '' : t('att.needLesson'), note: req('flex.note') && !v.note.trim() ? t('common.required') : '' };
  const sameDay = logged.some((r) => r.day === v.day && !r.is_recovery);

  // Esc closes; focus the first field once when the dialog opens
  const closeRef = useRef(onClose);
  closeRef.current = busy ? () => {} : onClose;
  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && closeRef.current();
    document.addEventListener('keydown', onKey);
    const prev = lockScroll();
    setTimeout(() => panel.current?.querySelector('textarea')?.focus(), 30);
    return () => { document.removeEventListener('keydown', onKey); prev(); };
  }, []);

  const submit = async (e) => {
    e.preventDefault();
    setTouched(true);
    if (errors.day || errors.lesson || errors.note || busy) return;
    if (!(await confirm({ title: t('att.flexDialog'), message: t('att.flexConfirm', { name: student.name, date: date(v.day, { day: 'numeric', month: 'long' }) }), confirmText: t('att.confirmBtn'), cancelText: t('att.cancel') }))) return;
    setBusy(true);
    const row = { student_id: student.id, day: v.day, status: 'present', lesson: v.lesson.trim() || null, note: v.note.trim() || null, ...(adminTeacherId ? { teacher_id: adminTeacherId } : {}) };
    try {
      try {
        await addAttendance({ ...row, is_recovery: false });
      } catch (e1) {
        // A class is already logged that day: save this one as an extra class
        if (!/already submitted/i.test(e1.message)) throw e1;
        await addAttendance({ ...row, is_recovery: true });
      }
      toast(t('att.flexDone'));
      onSaved(v.day);
    } catch (e2) {
      toast(e2.message, 'error');
      setBusy(false);
    }
  };
  const show = (k) => (touched ? errors[k] : '');
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center sm:p-6">
      <div className="absolute inset-0 bg-pine-950/60" onClick={() => !busy && onClose()} aria-hidden="true" />
      <form ref={panel} onSubmit={submit} noValidate role="dialog" aria-modal="true" aria-labelledby="flex-title"
        className="relative max-h-[92vh] w-full overflow-y-auto rounded-t-3xl bg-surface p-6 shadow-2xl sm:max-w-lg sm:rounded-3xl sm:p-7">
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            <h2 id="flex-title" className="flex items-center gap-2 text-xl text-heading">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#034751] text-white"><Shuffle className="h-4 w-4" aria-hidden="true" /></span>
              {t('att.flexDialog')}
            </h2>
            <p className="mt-1.5 text-sm text-ink/70">{t('att.flexFor', { name: student.name })}</p>
          </div>
          <button type="button" className="icon-btn -mr-2 -mt-1" onClick={onClose} disabled={busy} aria-label={t('att.close')}><X className="h-5 w-5" /></button>
        </div>
        <div className="space-y-4">
          <div>
            <label className="label" htmlFor="flex-day">{t('att.recDate')}</label>
            <input id="flex-day" type="date" className="input" min={earliest} max={today} value={v.day} onChange={(e) => setV({ ...v, day: e.target.value })} />
            {show('day') && <p className="mt-1 text-xs text-red-700" role="alert">{show('day')}</p>}
            {sameDay && <p className="mt-1 text-xs text-gold-700 dark:text-gold-300">{t('att.flexExtra')}</p>}
          </div>
          <div>
            <label className="label" htmlFor="flex-lesson">{t('att.lesson')} {req('flex.lesson') && <span className="text-red-700" aria-hidden="true">*</span>}</label>
            <textarea id="flex-lesson" rows={3} maxLength={LESSON_MAX} className="input" placeholder={t('att.lessonPh')} value={v.lesson} onChange={(e) => setV({ ...v, lesson: e.target.value })} aria-required={req('flex.lesson')} />
            {show('lesson') && <p className="mt-1 text-xs text-red-700" role="alert">{show('lesson')}</p>}
          </div>
          <div>
            <label className="label" htmlFor="flex-note">{t('att.flexNote')} {req('flex.note') && <span className="text-red-700" aria-hidden="true">*</span>}</label>
            <input id="flex-note" className="input" maxLength={300} value={v.note} onChange={(e) => setV({ ...v, note: e.target.value })} aria-required={req('flex.note')} />
            {show('note') && <p className="mt-1 text-xs text-red-700" role="alert">{show('note')}</p>}
          </div>
          <div className="rounded-2xl border border-ink/10 bg-paper/50 p-3.5">
            <p className="text-xs font-bold uppercase tracking-wider text-ink/60">{t('att.flexLogged', { month: monthLabel })} · {logged.length}</p>
            {logged.length ? (
              <ul className="mt-2 max-h-40 space-y-1.5 overflow-y-auto text-sm">
                {logged.map((r) => <li key={r.id} className="flex gap-2"><span className="shrink-0 font-semibold text-heading">{date(r.day, { day: 'numeric', month: 'short' })}</span><span className="truncate text-ink/75">{r.lesson || '—'}</span></li>)}
              </ul>
            ) : <p className="mt-1 text-sm text-ink/60">{t('att.flexNone')}</p>}
          </div>
        </div>
        <p className="mt-4 flex items-center gap-1.5 text-xs font-semibold text-ink/60"><Lock className="h-3.5 w-3.5" aria-hidden="true" /> {t('att.lockHint')}</p>
        <div className="mt-4 flex justify-end gap-2">
          <button type="button" className="btn-ghost" onClick={onClose} disabled={busy}>{t('att.cancel')}</button>
          <button type="submit" className="btn-primary" disabled={busy} data-testid="flex-submit"><Send className="h-4 w-4" aria-hidden="true" /> {busy ? t('att.submitting') : t('att.submit')}</button>
        </div>
      </form>
    </div>
  );
}

/**
 * Daily attendance with "Today's lesson".
 *  - Regular class: one entry per student per day. After submitting it shows
 *    "Completed" and is locked (the database refuses edits and deletes by
 *    teachers; only Executives can change entries, in the Attendance log).
 *  - Recovery class: "Log recovery class" adds a make-up class on any day,
 *    tagged is_recovery. Present recovery classes count toward "classes conducted".
 */
export default function Attendance() {
  const { students, schedules, adminTeacherId, adminMode } = useTeacher();
  const { t, n, weekday, weekdayShort, date, month: monthName } = useT();
  const lessonReq = useRequired()('att.lesson');
  const toast = useToast();
  const confirm = useConfirm();
  const today = isoDay();
  const earliest = adminMode ? '2020-01-01' : addDays(today, -31);
  const [day, setDay] = useState(today);
  const [rows, setRows] = useState(null); // all entries of the shown month
  const [draft, setDraft] = useState({}); // { [studentId]: { status, lesson, note } } for the chosen day
  const [busy, setBusy] = useState(false);
  const [range, setRange] = useState(() => monthRange(today));
  const [recOpen, setRecOpen] = useState(false);
  const [flexFor, setFlexFor] = useState(null);

  const load = useCallback(async (r) => {
    try {
      setRows((await listAttendance(r[0], r[1], adminTeacherId)) || []);
    } catch (e) {
      toast(e.message, 'error');
      setRows([]);
    }
  }, [adminTeacherId, toast]);

  useEffect(() => {
    load(range);
  }, [range, load]);

  const pick = (next) => {
    if (next > today || next < earliest) return;
    setDraft({});
    setDay(next);
    const r = monthRange(next);
    if (r[0] !== range[0]) setRange(r);
  };

  // Regular entries by student|day; recovery entries by student|day (list)
  const { regular, recovery } = useMemo(() => {
    const reg = {};
    const rec = {};
    (rows || []).forEach((r) => {
      const k = `${r.student_id}|${r.day}`;
      if (r.is_recovery) (rec[k] = rec[k] || []).push(r);
      else reg[k] = r;
    });
    return { regular: reg, recovery: rec };
  }, [rows]);

  const dow = new Date(`${day}T12:00:00`).getDay();
  const slotsByStudent = useMemo(() => {
    const m = {};
    schedules.filter((s) => s.weekday === dow).forEach((s) => (m[s.student_id] = [...(m[s.student_id] || []), s]));
    return m;
  }, [schedules, dow]);
  // Students with a class that day first
  const ordered = useMemo(
    () => [...students].sort((a, b) => Number(Boolean(slotsByStudent[b.id])) - Number(Boolean(slotsByStudent[a.id])) || a.name.localeCompare(b.name)),
    [students, slotsByStudent],
  );

  // Flexible-schedule students are logged class by class, not day by day
  // v153: only students with a class on this day (or already marked for it) are listed
  const hasAnySlot = useMemo(() => new Set(schedules.map((x) => x.student_id)), [schedules]);
  const fixedList = useMemo(() => ordered.filter((s) => !isFlexible(s) && (slotsByStudent[s.id] || regular[`${s.id}|${day}`])), [ordered, slotsByStudent, regular, day]);
  const noTimes = useMemo(() => ordered.filter((s) => !isFlexible(s) && !hasAnySlot.has(s.id)).length, [ordered, hasAnySlot]);
  const flexList = useMemo(() => ordered.filter(isFlexible), [ordered]);
  const flexLogged = useCallback((sid) => (rows || []).filter((r) => r.student_id === sid && r.status === 'present').sort((a, b) => b.day.localeCompare(a.day)), [rows]);

  const open = day <= today && day >= earliest;
  const change = useCallback((sid, patch) => setDraft((d) => ({ ...d, [sid]: { ...d[sid], ...patch } })), []);
  const pending = fixedList.filter((s) => !regular[`${s.id}|${day}`]);
  const readyIds = pending.filter((s) => ready(draft[s.id], lessonReq)).map((s) => s.id);

  const markAllPresent = () => {
    const next = {};
    pending.forEach((s) => {
      if (!draft[s.id]?.status) next[s.id] = { ...draft[s.id], status: 'present' };
    });
    setDraft((d) => ({ ...d, ...next }));
  };

  const submit = async (ids) => {
    if (!ids.length || busy) return;
    const first = students.find((s) => s.id === ids[0]);
    const message = ids.length === 1
      ? t('att.confirmOne', { name: first?.name || ids[0], status: t(`att.${draft[ids[0]].status}`) })
      : t('att.confirmMany', { n: ids.length });
    if (!(await confirm({ title: t('att.confirmTitle'), message, confirmText: t('att.confirmBtn'), cancelText: t('att.cancel') }))) return;
    setBusy(true);
    const results = await Promise.allSettled(ids.map((sid) => {
      const v = draft[sid];
      return addAttendance({
        student_id: sid, day, status: v.status, lesson: v.status === 'absent' ? null : (v.lesson || '').trim() || null, is_recovery: false,
        note: v.status === 'absent' ? (v.note || '').trim() || null : null,
        ...(adminTeacherId ? { teacher_id: adminTeacherId } : {}),
      });
    }));
    const okIds = ids.filter((_, i) => results[i].status === 'fulfilled');
    const failed = results.find((r) => r.status === 'rejected');
    await load(range);
    setDraft((d) => {
      const next = { ...d };
      okIds.forEach((sid) => delete next[sid]);
      return next;
    });
    if (okIds.length) toast(t('att.submitted', { n: okIds.length }));
    if (failed) toast(failed.reason?.message || String(failed.reason), 'error');
    setBusy(false);
  };

  // Month totals and calendar marks
  const monthStats = useMemo(() => {
    const byDay = {};
    (rows || []).forEach((r) => {
      byDay[r.day] = byDay[r.day] || { p: 0, a: 0, r: 0 };
      if (r.is_recovery) byDay[r.day].r += 1;
      else byDay[r.day][r.status === 'present' ? 'p' : 'a'] += 1;
    });
    return { byDay, ...attendanceTotals(rows) };
  }, [rows]);

  const [mFrom, mTo] = range;
  const firstDow = new Date(`${mFrom}T12:00:00`).getDay(); // 0 = Sunday
  const lead = (firstDow + 1) % 7; // calendar starts on Saturday
  const daysInMonth = Number(mTo.slice(8, 10));
  const monthLabel = `${monthName(new Date(`${mFrom}T12:00:00`).toLocaleString('en-US', { month: 'long' }))} ${n(mFrom.slice(0, 4))}`;

  if (!students.length) {
    return (
      <>
        <PageHeader title={t('att.title')} />
        <EmptyState title={t('home.noneTitle')}>{t('att.noneBody')}</EmptyState>
      </>
    );
  }

  return (
    <>
      <PageHeader
        title={t('att.title')}
        subtitle={t('att.sub')}
        action={(
          <button type="button" className="btn-gold" onClick={() => setRecOpen(true)} data-testid="log-recovery">
            <History className="h-4 w-4" aria-hidden="true" /> {t('att.logRecovery')}
          </button>
        )}
      />

      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label={`${t('att.conducted')} · ${monthLabel}`} value={n(monthStats.conducted)} hint={t('att.conductedHint', { p: monthStats.present, r: monthStats.recovery })} />
        <Stat label={t('att.present')} value={n(monthStats.present)} hint={monthStats.rate == null ? undefined : t('att.presentHint', { pct: `${n(monthStats.rate)}%` })} tone={monthStats.rate != null && monthStats.rate < 75 ? 'gold' : 'pine'} />
        <Stat label={t('att.absent')} value={n(monthStats.absent)} tone={monthStats.absent ? 'red' : 'pine'} />
        <Stat label={t('att.recoveryCount')} value={n(monthStats.recovery + monthStats.recoveryAbsent)} tone="gold" />
      </div>

      {flexList.length > 0 && (
        <Card className="mb-6" data-testid="flex-card">
          <h2 className="flex items-center gap-2 text-lg text-heading"><Shuffle className="h-5 w-5 text-gold-600" aria-hidden="true" /> {t('att.flexTitle')}</h2>
          <p className="mt-1 text-sm text-ink/70">{t('att.flexSub')}</p>
          <ul className="mt-4 grid gap-3 sm:grid-cols-2">
            {flexList.map((s) => {
              const list = flexLogged(s.id);
              return (
                <li key={s.id} className="flex items-center justify-between gap-3 rounded-2xl border border-gold-300/70 bg-tint-gold/50 px-4 py-3 dark:border-gold-700/50" data-flex={s.id}>
                  <div className="min-w-0">
                    <p className="font-semibold text-heading">{s.name}</p>
                    <p className="text-xs text-ink/70">{s.id} · <b className="text-gold-800 dark:text-gold-200" data-testid="flex-count">{t('att.flexCount', { n: list.length, month: monthLabel })}</b></p>
                  </div>
                  <button type="button" className="btn-primary btn-sm shrink-0" onClick={() => setFlexFor(s)} data-testid="log-class"><Plus className="h-4 w-4" aria-hidden="true" /> {t('att.logClass')}</button>
                </li>
              );
            })}
          </ul>
        </Card>
      )}

      <div className="grid gap-6 lg:grid-cols-[1fr_20rem]">
        <Card>
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <button type="button" className="icon-btn" onClick={() => pick(addDays(day, -1))} disabled={addDays(day, -1) < earliest} aria-label={t('att.prevDay')}>
                <ChevronLeft className="h-5 w-5" />
              </button>
              <div>
                <label className="sr-only" htmlFor="att-day">{t('att.day')}</label>
                <input id="att-day" type="date" className="input py-2" value={day} min={earliest} max={today} onChange={(e) => e.target.value && pick(e.target.value)} />
              </div>
              <button type="button" className="icon-btn" onClick={() => pick(addDays(day, 1))} disabled={addDays(day, 1) > today} aria-label={t('att.nextDay')}>
                <ChevronRight className="h-5 w-5" />
              </button>
              {day !== today && (
                <button type="button" className="btn-ghost btn-sm" onClick={() => pick(today)}>{t('att.today')}</button>
              )}
            </div>
            <button type="button" className="btn-outline btn-sm" onClick={markAllPresent} disabled={!open || !pending.length || busy}>
              <Check className="h-4 w-4" /> {t('att.allPresent')}
            </button>
          </div>
          <p className="mb-4 text-sm font-semibold text-heading">
            {weekday(dow)}, {date(day, { day: 'numeric', month: 'long', year: 'numeric' })}
            <span className="ml-2 font-normal text-ink/70">· {t('att.classesThatDay', { n: Object.keys(slotsByStudent).length })}</span>
          </p>
          {adminMode && <p className="mb-3 rounded-xl bg-tint px-3 py-2 text-xs font-semibold text-heading">{t('att.adminEditHint')}</p>}
          {rows === null ? (
            <p className="text-sm text-ink/70">{t('loading.generic')}</p>
          ) : (
            <ul className="space-y-3">
              {!fixedList.length && <li className="rounded-xl bg-tint px-4 py-5 text-center text-sm font-semibold text-heading" data-testid="att-none-today">{t('att.noneThisDay')}</li>}
              {fixedList.map((s) => (
                <StudentRow
                  key={s.id}
                  lessonReq={lessonReq}
                  student={s}
                  slotsToday={slotsByStudent[s.id] || []}
                  entry={regular[`${s.id}|${day}`]}
                  recoveries={recovery[`${s.id}|${day}`] || []}
                  value={draft[s.id]}
                  open={open}
                  busy={busy}
                  onChange={change}
                  onSubmit={submit}
                />
              ))}
            </ul>
          )}
          {noTimes > 0 && <p className="mt-3 text-xs font-semibold text-ink/60" data-testid="att-no-times">{t('att.noTimesSet', { n: noTimes })}</p>}
          {readyIds.length > 1 && (
            <div className="sticky bottom-20 mt-5 flex items-center justify-end gap-3 rounded-2xl bg-paper/90 py-2 backdrop-blur">
              <span className="text-xs font-semibold text-ink/65">{t('att.lockHint')}</span>
              <button type="button" className="btn-primary px-5 py-2.5" onClick={() => submit(readyIds)} disabled={busy} data-testid="submit-all">
                <Send className="h-4 w-4" /> {busy ? t('att.submitting') : t('att.submitAll', { n: readyIds.length })}
              </button>
            </div>
          )}
        </Card>

        <Card className="h-fit">
          <h2 className="mb-3 text-base text-heading">{monthLabel}</h2>
          <div className="grid grid-cols-7 gap-1 text-center text-[11px] font-semibold text-ink/50" aria-hidden="true">
            {[6, 0, 1, 2, 3, 4, 5].map((d) => <span key={d}>{weekdayShort(d)}</span>)}
          </div>
          <div className="mt-1 grid grid-cols-7 gap-1">
            {Array.from({ length: lead }).map((_, i) => <span key={`b${i}`} />)}
            {Array.from({ length: daysInMonth }).map((_, i) => {
              const iso = `${mFrom.slice(0, 8)}${String(i + 1).padStart(2, '0')}`;
              const c = monthStats.byDay[iso];
              const reg = c && c.p + c.a > 0;
              const disabled = iso > today || iso < earliest;
              return (
                <button
                  key={iso}
                  type="button"
                  disabled={disabled}
                  onClick={() => pick(iso)}
                  aria-label={`${date(iso, { day: 'numeric', month: 'long' })}${c ? `: ${c.p} ${t('att.present')}, ${c.a} ${t('att.absent')}${c.r ? `, ${c.r} ${t('att.recoveryShort')}` : ''}` : ''}`}
                  aria-current={iso === day ? 'date' : undefined}
                  className={`relative flex aspect-square flex-col items-center justify-center rounded-lg text-xs transition disabled:opacity-30 ${iso === day ? 'bg-pine-800 font-bold text-white' : reg ? (c.a ? 'bg-amber-100 text-amber-900 dark:bg-amber-900/40 dark:text-amber-100' : 'bg-emerald-100 text-emerald-900 dark:bg-emerald-900/40 dark:text-emerald-100') : 'hover:bg-tint'}`}
                >
                  {n(i + 1)}
                  {reg && <span className="mt-0.5 h-1 w-1 rounded-full bg-current" aria-hidden="true" />}
                  {c?.r > 0 && <span className="absolute right-1 top-1 h-1.5 w-1.5 rounded-full bg-gold-500 ring-1 ring-surface" aria-hidden="true" />}
                </button>
              );
            })}
          </div>
          <p className="mt-3 text-xs text-ink/70">{t('att.calendarHint')}</p>
        </Card>
      </div>

      {flexFor && (
        <FlexDialog
          student={flexFor}
          logged={flexLogged(flexFor.id)}
          monthLabel={monthLabel}
          earliest={earliest}
          today={today}
          adminTeacherId={adminTeacherId}
          onClose={() => setFlexFor(null)}
          onSaved={(d) => {
            setFlexFor(null);
            const r = monthRange(d);
            if (r[0] !== range[0]) setRange(r); else load(range);
          }}
        />
      )}
      {recOpen && (
        <RecoveryDialog
          students={ordered}
          defaultDay={day}
          earliest={earliest}
          today={today}
          adminTeacherId={adminTeacherId}
          onClose={() => setRecOpen(false)}
          onSaved={(d) => {
            setRecOpen(false);
            if (d !== day) pick(d);
            if (monthRange(d)[0] === range[0]) load(range);
          }}
        />
      )}
    </>
  );
}
