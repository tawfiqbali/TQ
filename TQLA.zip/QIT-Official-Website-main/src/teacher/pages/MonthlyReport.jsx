import { useEffect, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ArrowRight, CheckCircle2, Lock, MessageCircle, Send } from 'lucide-react';
import { useTeacher } from '../TeacherContext';
import { bySlot } from '../ScheduleEditor';
import { Badge, Card, EmptyState, PageHeader } from '../ui';
import { MONTHS, STATUS_LEVELS, attendanceTotals, fromBaseline, isFlexible, isoDay, listAttendance, listMyReports, reportMonth, reportableMonths, submitReport, whatsappLinks } from '../../lib/teacherData';
import { useT } from '../i18n';
import { useRequired } from '../dashConfig';

const EMPTY = { total_classes: '', present: '', absence_reason: '', status_level: '', status_note: '', current_lesson: '', taught: '', next_target: '', remarks: '', medium: '', class_start: '' };
// v156: 1st–3rd = full month; from the 4th the days left of a 30-day month
const startDays = (iso, month, year) => {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || '');
  if (!m || Number(m[1]) !== Number(year) || MONTHS[Number(m[2]) - 1] !== month) return null;
  const d = Number(m[3]);
  return d <= 3 ? 30 : Math.max(0, 30 - d);
};
const monthKey = (m, y) => Number(y) * 12 + MONTHS.indexOf(m);

// How many times each scheduled weekday falls in that month
function classesFromSchedule(slots, month, year) {
  const m = MONTHS.indexOf(month);
  if (m < 0 || !slots.length) return 0;
  const days = new Date(year, m + 1, 0).getDate();
  let count = 0;
  for (let d = 1; d <= days; d += 1) {
    const wd = new Date(year, m, d).getDay();
    count += slots.filter((s) => s.weekday === wd).length;
  }
  return count;
}

function Field({ label, required, hint, error, children, htmlFor }) {
  return (
    <div>
      <label className="label" htmlFor={htmlFor}>
        {label} {required && <span className="text-red-700" aria-hidden="true">*</span>}
      </label>
      {children}
      {error ? <p className="mt-1 text-xs text-red-700" role="alert">{error}</p> : hint ? <p className="mt-1 text-xs text-ink/70">{hint}</p> : null}
    </div>
  );
}

/**
 * Monthly progress report (/teacher/report — shareable link; ?student=ID
 * opens one student directly). Choosing a student fills in their background
 * and last report; one report per student per month (sending again updates it
 * until the office marks it reviewed).
 */
export default function MonthlyReport() {
  const { students, schedules, base, adminTeacherId, adminMode, home } = useTeacher();
  const { t, n, lang, month: monthName, weekdayShort, time, date, err, status } = useT();
  const req = useRequired();
  const bn = lang === 'bn';
  const [params, setParams] = useSearchParams();
  const due = reportMonth();
  const [studentId, setStudentId] = useState(() => (students.some((s) => s.id === params.get('student')) ? params.get('student') : ''));
  const [month, setMonth] = useState(MONTHS.includes(params.get('month')) ? params.get('month') : due.month);
  const [year, setYear] = useState(Number(params.get('year')) || due.year);
  useEffect(() => {
    if (!adminMode && !fromBaseline(month, year)) { setMonth(due.month); setYear(due.year); }
  }, [adminMode, month, year, due.month, due.year]);
  const [reports, setReports] = useState(null);
  const [form, setForm] = useState(EMPTY);
  const [touched, setTouched] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [sent, setSent] = useState(null);

  // v169: read again when the dashboard refreshes (office review shows at once)
  useEffect(() => {
    listMyReports(adminTeacherId).then(setReports).catch((e) => { setError(e.message); setReports((r) => r || []); });
  }, [adminTeacherId, home]);

  // Daily attendance of the chosen month fills in the class counts
  const [daily, setDaily] = useState([]);
  useEffect(() => {
    const m = MONTHS.indexOf(month);
    if (m < 0) return;
    listAttendance(isoDay(new Date(year, m, 1)), isoDay(new Date(year, m + 1, 0)), adminTeacherId).then((r) => setDaily(r || [])).catch(() => setDaily([]));
  }, [month, year, adminTeacherId]);

  const student = students.find((s) => s.id === studentId);
  const slots = useMemo(() => schedules.filter((s) => s.student_id === studentId).sort(bySlot), [schedules, studentId]);
  const existing = useMemo(() => (reports || []).find((r) => r.student_id === studentId && r.month === month && r.year === Number(year)), [reports, studentId, month, year]);
  const previous = useMemo(
    () => (reports || []).filter((r) => r.student_id === studentId && monthKey(r.month, r.year) < monthKey(month, year)).sort((a, b) => monthKey(b.month, b.year) - monthKey(a.month, a.year))[0],
    [reports, studentId, month, year],
  );
  // Reviewed reports are locked for teachers; Executives can still edit them
  const locked = !adminMode && existing?.review_status === 'reviewed';
  const marks = useMemo(() => daily.filter((d) => d.student_id === studentId), [daily, studentId]);
  // Total classes conducted = regular classes marked + recovery classes held;
  // present = regular present + recovery present
  const flex = isFlexible(student);
  const marked = useMemo(() => {
    const x = attendanceTotals(marks);
    // Flexible schedule: every logged class counts, no fixed target and no absences
    if (flex) return { p: x.present, a: 0, r: x.recovery, total: x.present + x.recovery, present: x.present + x.recovery, reasons: '' };
    // the reasons written when marking a student absent
    const reasons = [...new Set(marks.filter((d) => !d.is_recovery && d.status !== 'present').map((d) => String(d.note || '').trim()).filter(Boolean))].join('; ').slice(0, 500);
    return { p: x.present, a: x.absent, r: x.recovery, total: x.regular + x.recovery, present: x.present + x.recovery, reasons };
  }, [marks, flex]);
  const suggested = marked.total || (flex ? 0 : classesFromSchedule(slots, month, Number(year)));
  const doneFor = useMemo(() => new Set((reports || []).filter((r) => r.month === month && r.year === Number(year)).map((r) => r.student_id)), [reports, month, year]);

  // A different student or month starts fresh (the "sent" banner stays after a save)
  useEffect(() => {
    setTouched(false);
    setSent(null);
    setError('');
  }, [studentId, month, year]);

  // Selecting a student (or month) loads that month's report, or a fresh form
  useEffect(() => {
    if (!studentId) return setForm(EMPTY);
    if (existing) {
      setForm({
        total_classes: existing.total_classes ?? '', present: existing.present ?? '', absence_reason: existing.absence_reason || '',
        status_level: existing.status_level || '', status_note: existing.status_note || '', current_lesson: existing.current_lesson || '',
        taught: existing.taught || '', next_target: existing.next_target || '', remarks: existing.remarks || '',
        medium: existing.medium || student?.medium || '', class_start: existing.class_start || '',
      });
    } else setForm({ ...EMPTY, total_classes: suggested || '', present: marked.total ? marked.present : '', absence_reason: marked.total ? marked.reasons : '', medium: student?.medium || '', class_start: student?.assignDate && startDays(student.assignDate, month, year) != null ? student.assignDate : '' });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [studentId, month, year, existing?.id, reports === null, `${marked.total}/${marked.present}`]);
  // Attendance already marked this month vs. what the form says
  const attDiffers = marked.total > 0 && (String(form.total_classes) !== String(marked.total) || String(form.present) !== String(marked.present));
  const useAttendance = () => setForm((f) => ({ ...f, total_classes: marked.total, present: marked.present, absence_reason: marked.total > marked.present ? f.absence_reason || marked.reasons : '' }));

  const choose = (id) => {
    setStudentId(id);
    const next = new URLSearchParams(params);
    if (id) next.set('student', id);
    else next.delete('student');
    setParams(next, { replace: true });
  };

  // Numbers typed with Bangla digits count too
  const num = (v) => (v === '' ? null : Number(String(v).trim().replace(/[০-৯]/g, (c) => '০১২৩৪৫৬৭৮৯'.indexOf(c))));
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));
  const total = num(String(form.total_classes));
  const present = num(String(form.present));
  const absent = total != null && present != null && Number.isFinite(total) && Number.isFinite(present) ? Math.max(total - present, 0) : null;
  const need = (k, v) => (req(`report.${k}`) && !String(v ?? '').trim() ? t('common.required') : '');
  const errors = {
    total_classes: total == null ? (req('report.total') ? t('rp.eTotal') : '') : !Number.isInteger(total) || total < 0 || total > 62 ? t('rp.eRange') : '',
    present: present == null ? (req('report.present') ? t('rp.ePresent') : '') : !Number.isInteger(present) || present < 0 ? t('rp.eWhole') : total != null && present > total ? t('rp.eMore') : '',
    absence_reason: absent ? need('reason', form.absence_reason) : '',
    status_level: req('report.level') && !form.status_level ? t('rp.eLevel') : '',
    status_note: need('notes', form.status_note),
    taught: need('taught', form.taught),
    current_lesson: need('lesson', form.current_lesson),
    next_target: need('target', form.next_target),
    remarks: req('report.remarks') && !form.remarks.trim() ? t('rp.eRemarks') : '',
    medium: form.medium ? '' : t('common.required'),
  };
  const days = startDays(form.class_start, month, year);
  const valid = !Object.values(errors).some(Boolean);

  const submit = async (e) => {
    e.preventDefault();
    setTouched(true);
    if (!valid || busy || locked) return;
    setBusy(true);
    setError('');
    try {
      const row = await submitReport(adminMode, {
        student_id: studentId, month, year: Number(year),
        total_classes: total, present, absent,
        absence_reason: absent ? form.absence_reason.trim() || null : null,
        status_level: form.status_level || null, status_note: form.status_note.trim() || null,
        current_lesson: form.current_lesson.trim() || null, taught: form.taught.trim() || null,
        next_target: form.next_target.trim() || null, remarks: form.remarks.trim() || null,
        medium: form.medium || null, class_start: form.class_start || null,
        ...(adminTeacherId ? { teacher_id: adminTeacherId } : {}),
      });
      setReports((list) => [row, ...(list || []).filter((r) => r.id !== row.id)]);
      setSent({ name: student.name, updated: Boolean(existing) });
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (e2) {
      setError(e2.message);
    } finally {
      setBusy(false);
    }
  };

  const nextMissing = students.find((s) => s.id !== studentId && !doneFor.has(s.id));
  // Teachers report from the progress baseline (September 2026) onwards; Executives can open any month
  const allowed = reportableMonths();
  const years = adminMode ? [due.year + 1, due.year, due.year - 1].filter((y) => y <= new Date().getFullYear()) : [...new Set(allowed.map((x) => x.year))];
  const monthOpts = adminMode ? MONTHS : allowed.filter((x) => x.year === Number(year)).map((x) => x.month);
  const show = (k) => (touched ? errors[k] : '');
  const levelText = (v) => {
    const l = STATUS_LEVELS.find((x) => x.value === v);
    return l ? (bn ? l.bn : l.en) : '—';
  };

  if (!students.length) {
    return (
      <>
        <PageHeader title={t('rp.title')} />
        <EmptyState title={t('home.noneTitle')}>{t('rp.noneBody')}</EmptyState>
      </>
    );
  }

  return (
    <>
      <PageHeader title={t('rp.title')} subtitle={t('rp.sub', { done: doneFor.size, total: students.length, month: monthName(month), year: n(year) })} />

      {sent && (
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-emerald-300 bg-emerald-50 px-5 py-4 text-emerald-900 dark:border-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-100" role="status">
          <p className="flex items-center gap-2 text-sm font-semibold">
            <CheckCircle2 className="h-5 w-5 shrink-0" /> {t(sent.updated ? 'rp.sentUpd' : 'rp.sentNew', { name: sent.name, month: monthName(month) })}
          </p>
          {nextMissing ? (
            <button type="button" className="btn-primary btn-sm" onClick={() => choose(nextMissing.id)}>{t('rp.next', { name: nextMissing.name })} <ArrowRight className="h-4 w-4" /></button>
          ) : (
            <Link to={base} className="btn-primary btn-sm">{t('rp.allDone')}</Link>
          )}
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-[1fr_20rem]">
        <form onSubmit={submit} noValidate className="order-2 space-y-6 lg:order-1">
          <Card>
            <div className="grid gap-4 sm:grid-cols-[2fr_1fr_1fr]">
              <Field label={t('rp.student')} required htmlFor="rp-student">
                <select id="rp-student" className="input" value={studentId} onChange={(e) => choose(e.target.value)}>
                  <option value="">{t('rp.choose')}</option>
                  {students.map((s) => <option key={s.id} value={s.id}>{doneFor.has(s.id) ? '✓ ' : ''}{s.name} ({s.id})</option>)}
                </select>
              </Field>
              <Field label={t('rp.month')} required htmlFor="rp-month">
                <select id="rp-month" className="input" value={month} onChange={(e) => setMonth(e.target.value)}>
                  {monthOpts.map((m) => <option key={m} value={m}>{monthName(m)}</option>)}
                </select>
              </Field>
              <Field label={t('rp.year')} required htmlFor="rp-year">
                <select id="rp-year" className="input" value={year} onChange={(e) => setYear(Number(e.target.value))}>
                  {years.map((y) => <option key={y} value={y}>{n(y)}</option>)}
                </select>
              </Field>
            </div>
            {existing && (
              <div className={`mt-4 flex flex-wrap items-center gap-2 rounded-xl px-3.5 py-2.5 text-sm ${locked ? 'bg-emerald-50 text-emerald-900 dark:bg-emerald-900/30 dark:text-emerald-100' : existing.review_status === 'needs_changes' ? 'bg-red-50 text-red-900 dark:bg-red-900/30 dark:text-red-100' : 'bg-tint'}`}>
                {locked ? <Lock className="h-4 w-4" /> : null}
                <Badge status={existing.review_status} />
                {locked
                  ? t('rp.locked')
                  : existing.review_status === 'needs_changes'
                    ? t('rp.askedChanges', { note: existing.review_note || '' })
                    : t('rp.alreadySent', { date: date(existing.submitted_at, { day: 'numeric', month: 'short' }) })}
              </div>
            )}
          </Card>

          {!student ? (
            <EmptyState title={t('rp.chooseTitle')}>{t('rp.chooseBody')}</EmptyState>
          ) : (
            <fieldset disabled={locked} className="space-y-6 disabled:opacity-70">
              <Card>
                <div className="mb-5 grid gap-4 sm:grid-cols-2" data-testid="rp-medium-box">
                  <Field label={t('stu.medium')} required htmlFor="rp-medium" error={show('medium')}>
                    <select id="rp-medium" className="input" value={form.medium} onChange={set('medium')} data-testid="rp-medium">
                      <option value="">—</option>
                      <option value="Bangla Medium">{t('stu.bangla')}</option>
                      <option value="English Medium">{t('stu.english')}</option>
                    </select>
                  </Field>
                  <Field label={t('rp.classStart')} htmlFor="rp-start" hint={form.class_start ? (days == null ? t('rp.startOther') : days === 30 ? t('rp.startFull') : t('rp.startDays', { n: days })) : t('rp.startHint')}>
                    <input id="rp-start" type="date" className="input" value={form.class_start} onChange={set('class_start')} data-testid="rp-start" />
                  </Field>
                </div>
                <h2 className="mb-4 text-lg text-heading">{t('rp.s1')}</h2>
                <div className="grid gap-4 sm:grid-cols-3">
                  <Field label={t('rp.total')} required={req('report.total')} htmlFor="rp-total" error={show('total_classes')} hint={flex ? t('att.flexTotal', { n: marked.total }) : marks.length ? t('att.fromDaily', { p: n(marked.p), a: n(marked.a), r: n(marked.r) }) : suggested ? t('rp.totalFromSch', { n: suggested, month: monthName(month) }) : t('rp.totalHint')}>
                    <input id="rp-total" className="input" type="text" inputMode="numeric" value={form.total_classes} onChange={set('total_classes')} aria-invalid={Boolean(show('total_classes'))} />
                  </Field>
                  <Field label={t('rp.present')} required={req('report.present')} htmlFor="rp-present" error={show('present')}>
                    <input id="rp-present" className="input" type="text" inputMode="numeric" value={form.present} onChange={set('present')} aria-invalid={Boolean(show('present'))} />
                  </Field>
                  <Field label={t('rp.absent')} htmlFor="rp-absent" hint={total ? t('rp.attendance', { pct: Math.round(((present || 0) / total) * 100) }) : t('rp.absentHint')}>
                    <input id="rp-absent" className="input" value={absent == null ? '' : n(absent)} readOnly tabIndex={-1} />
                  </Field>
                </div>
                {marked.total > 0 && !locked && (
                  <p className={`mt-3 flex flex-wrap items-center gap-2 rounded-xl px-3 py-2 text-xs ${attDiffers ? 'bg-amber-50 text-amber-900 dark:bg-amber-900/20 dark:text-amber-100' : 'bg-tint text-ink/75'}`} data-testid="att-auto">
                    {attDiffers ? (
                      <>
                        <span>{t('att.differs', { p: n(marked.present), t: n(marked.total) })}</span>
                        <button type="button" className="btn-outline btn-sm" onClick={useAttendance} data-testid="att-use">{t('att.use')}</button>
                      </>
                    ) : t('att.autoFilled')}
                  </p>
                )}
                {absent > 0 && (
                  <div className="mt-4">
                    <Field label={t('rp.reason')} required={req('report.reason')} error={show('absence_reason')} htmlFor="rp-reason" hint={t('rp.reasonHint')}>
                      <input id="rp-reason" className="input" maxLength={500} value={form.absence_reason} onChange={set('absence_reason')} aria-invalid={Boolean(show('absence_reason'))} />
                    </Field>
                  </div>
                )}
              </Card>

              <Card>
                <h2 className="mb-4 text-lg text-heading">{t('rp.s2')} {req('report.level') && <span className="text-red-700" aria-hidden="true">*</span>}</h2>
                <div className="flex flex-wrap gap-2" role="radiogroup" aria-label={t('rp.level')} aria-invalid={Boolean(show('status_level'))}>
                  {STATUS_LEVELS.map((l) => (
                    <button
                      key={l.value}
                      type="button"
                      role="radio"
                      aria-checked={form.status_level === l.value}
                      onClick={() => setForm((f) => ({ ...f, status_level: l.value }))}
                      className={`rounded-xl border px-3.5 py-2 text-sm font-semibold transition ${form.status_level === l.value ? 'border-[#034751] bg-[#034751] text-white shadow' : 'border-ink/15 text-ink/80 hover:border-pine-500'}`}
                    >
                      {bn ? l.bn : l.en} <span className="font-normal opacity-75">· {bn ? l.en : l.bn}</span>
                    </button>
                  ))}
                </div>
                {show('status_level') && <p className="mt-2 text-xs text-red-700" role="alert">{errors.status_level}</p>}
                <div className="mt-4">
                  <Field label={t('rp.notes')} required={req('report.notes')} error={show('status_note')} htmlFor="rp-note" hint={t('rp.notesHint')}>
                    <textarea id="rp-note" className="input" rows={2} maxLength={1000} value={form.status_note} onChange={set('status_note')} aria-invalid={Boolean(show('status_note'))} />
                  </Field>
                </div>
              </Card>

              <Card>
                <h2 className="mb-4 text-lg text-heading">{t('rp.s3')}</h2>
                <div className="space-y-4">
                  <Field label={t('rp.taught')} required={req('report.taught')} error={show('taught')} htmlFor="rp-taught" hint={t('rp.taughtHint')}>
                    <textarea id="rp-taught" className="input" rows={3} maxLength={2000} value={form.taught} onChange={set('taught')} aria-invalid={Boolean(show('taught'))} />
                  </Field>
                  <Field label={t('rp.lesson')} required={req('report.lesson')} error={show('current_lesson')} htmlFor="rp-lesson" hint={t('rp.lessonHint')}>
                    <input id="rp-lesson" className="input" maxLength={1000} value={form.current_lesson} onChange={set('current_lesson')} aria-invalid={Boolean(show('current_lesson'))} />
                  </Field>
                </div>
              </Card>

              <Card>
                <h2 className="mb-4 text-lg text-heading">{t('rp.s4')}</h2>
                <div className="space-y-4">
                  <Field label={t('rp.target')} required={req('report.target')} error={show('next_target')} htmlFor="rp-next" hint={previous?.next_target ? t('rp.lastTarget', { t: previous.next_target }) : t('rp.targetHint')}>
                    <textarea id="rp-next" className="input" rows={2} maxLength={1000} value={form.next_target} onChange={set('next_target')} aria-invalid={Boolean(show('next_target'))} />
                  </Field>
                  <Field label={t('rp.remarks')} required={req('report.remarks')} htmlFor="rp-remarks" error={show('remarks')} hint={t('rp.remarksHint')}>
                    <textarea id="rp-remarks" className="input" rows={3} maxLength={2000} value={form.remarks} onChange={set('remarks')} aria-invalid={Boolean(show('remarks'))} aria-required={req('report.remarks')} />
                  </Field>
                </div>
              </Card>

              {error && <p role="alert" className="rounded-xl bg-red-50 px-4 py-3 text-sm text-red-800">{err(error)}</p>}
              {touched && !valid && <p role="alert" className="text-sm text-red-700">{t('rp.fix')}</p>}
              {!locked && (
                <div className="flex justify-end">
                  <button type="submit" className="btn-primary px-6 py-3" disabled={busy}>
                    <Send className="h-4 w-4" /> {busy ? t('rp.sending') : existing ? t('rp.update') : t('rp.submit')}
                  </button>
                </div>
              )}
            </fieldset>
          )}
        </form>

        {/* Background of the chosen student, filled in automatically */}
        <aside className="order-1 lg:order-2" aria-label={t('rp.bg')}>
          <Card className="lg:sticky lg:top-36">
            {!student ? (
              <p className="text-sm text-ink/70">{t('rp.bgEmpty')}</p>
            ) : (
              <>
                <p className="label-caps">{t('rp.bg')}</p>
                <h2 className="text-xl text-heading">{student.name}</h2>
                <dl className="mt-3 space-y-2 text-sm">
                  <div className="flex justify-between gap-3"><dt className="text-ink/70">{t('rp.sid')}</dt><dd className="font-semibold">{student.id}</dd></div>
                  {student.course && <div className="flex justify-between gap-3"><dt className="text-ink/70">{t('rp.course')}</dt><dd className="text-right">{student.course}</dd></div>}
                  {whatsappLinks(student.phone).length > 0 && (
                    <div className="flex justify-between gap-3">
                      <dt className="text-ink/70">{t('home.whatsapp')}</dt>
                      <dd className="space-y-0.5 text-right">
                        {whatsappLinks(student.phone).map((ph) => (
                          <a key={ph.label} href={ph.href || undefined} target="_blank" rel="noreferrer" className="flex items-center justify-end gap-1.5 text-brand hover:underline">
                            <MessageCircle className="h-4 w-4 shrink-0" aria-hidden="true" />{ph.label}
                          </a>
                        ))}
                      </dd>
                    </div>
                  )}
                  {student.status && <div className="flex justify-between gap-3"><dt className="text-ink/70">{t('rp.status')}</dt><dd>{status(student.status)}</dd></div>}
                  <div>
                    <dt className="text-ink/70">{t('rp.times')}</dt>
                    <dd className="mt-1 flex flex-wrap gap-1.5">
                      {slots.length ? slots.map((s) => <span key={s.id} className="rounded-md bg-tint px-2 py-0.5 text-xs font-semibold">{weekdayShort(s.weekday)} {time(s.start_time)}</span>) : <span className="text-ink/70">{student.classTime || t('rp.notSet')}</span>}
                    </dd>
                  </div>
                </dl>
                <div className="mt-4 border-t border-ink/10 pt-4">
                  <p className="label-caps">{t('rp.last')}</p>
                  {previous ? (
                    <dl className="space-y-1.5 text-sm">
                      <div className="flex justify-between gap-3"><dt className="text-ink/70">{t('rp.month')}</dt><dd>{monthName(previous.month)} {n(previous.year)}</dd></div>
                      <div className="flex justify-between gap-3"><dt className="text-ink/70">{t('rp.present')}</dt><dd>{n(`${previous.present ?? '—'} / ${previous.total_classes ?? '—'}`)}</dd></div>
                      <div className="flex justify-between gap-3"><dt className="text-ink/70">{t('rp.lvl')}</dt><dd>{levelText(previous.status_level)}</dd></div>
                      {previous.current_lesson && <div><dt className="text-ink/70">{t('rp.lessonThen')}</dt><dd>{previous.current_lesson}</dd></div>}
                      {previous.next_target && <div><dt className="text-ink/70">{t('rp.targetSet')}</dt><dd>{previous.next_target}</dd></div>}
                    </dl>
                  ) : (
                    <p className="text-sm text-ink/70">{reports === null ? t('loading.generic') : t('rp.firstReport')}</p>
                  )}
                </div>
              </>
            )}
          </Card>
        </aside>
      </div>
    </>
  );
}
