import { useEffect, useState } from 'react';
import { Send } from 'lucide-react';
import { Badge, Card, EmptyState, PageHeader } from '../ui';
import { listMyInquiries, sendInquiry, updateTeacherInquiry } from '../../lib/teacherData';
import { useTeacher } from '../TeacherContext';
import { useToast } from '../../components/ui/Toast';
import { useT } from '../i18n';
import { useRequired } from '../dashConfig';

// Admin mode: answer a request right here
function AdminReply({ item, onSaved }) {
  const toast = useToast();
  const [reply, setReply] = useState(item.admin_reply || '');
  const [status, setStatus] = useState(item.status);
  const [busy, setBusy] = useState(false);
  const save = async () => {
    setBusy(true);
    try {
      const row = await updateTeacherInquiry(item.id, { admin_reply: reply.trim() || null, status });
      onSaved(row);
      toast('Reply saved.');
    } catch (e) {
      toast(e.message, 'error');
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="mt-3 space-y-2 rounded-xl border border-gold-300 p-3 dark:border-gold-700" lang="en">
      <label className="label-caps" htmlFor={`rep-${item.id}`}>Reply as the office</label>
      <textarea id={`rep-${item.id}`} className="input" rows={2} value={reply} onChange={(e) => setReply(e.target.value)} />
      <div className="flex flex-wrap gap-2">
        <select className="input w-40" value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Status">
          <option value="open">Open</option><option value="in_progress">In progress</option><option value="resolved">Resolved</option>
        </select>
        <button type="button" className="btn-primary btn-sm" onClick={save} disabled={busy}>{busy ? 'Saving…' : 'Save reply'}</button>
      </div>
    </div>
  );
}
const CATEGORIES = ['general', 'issue', 'leave', 'salary', 'other'];
const today = () => new Date().toISOString().slice(0, 10);

// Questions, problems and leave requests straight to the QIT office
export default function Support() {
  const { t, date, err } = useT();
  const { adminTeacherId, adminMode } = useTeacher();
  const toast = useToast();
  const [items, setItems] = useState(null);
  const [form, setForm] = useState({ category: 'general', subject: '', message: '', leave_from: '', leave_to: '' });
  const [touched, setTouched] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [sent, setSent] = useState(false);

  useEffect(() => {
    listMyInquiries(adminTeacherId).then(setItems).catch((e) => { setError(e.message); setItems([]); });
  }, [adminTeacherId]);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));
  const leave = form.category === 'leave';
  const req = useRequired();
  const errors = {
    subject: !req('sup.subject') && !form.subject.trim() ? '' : form.subject.trim().length >= 3 ? '' : t('sup.eSubject'),
    message: form.message.trim().length >= 5 ? '' : t('sup.eMessage'),
    leave_from: leave && !form.leave_from ? t('sup.eFirst') : '',
    leave_to: leave && req('sup.leaveTo') && !form.leave_to ? t('common.required') : leave && form.leave_to && form.leave_from && form.leave_to < form.leave_from ? t('sup.eLast') : '',
  };
  const valid = !Object.values(errors).some(Boolean);
  const show = (k) => (touched ? errors[k] : '');

  const submit = async (e) => {
    e.preventDefault();
    setTouched(true);
    if (!valid || busy) return;
    setBusy(true);
    setError('');
    try {
      const row = await sendInquiry({
        category: form.category,
        // No subject typed (when optional): use the request type as the subject
        subject: form.subject.trim() || t(`sup.${form.category}`),
        message: form.message.trim(),
        leave_from: leave ? form.leave_from : null,
        leave_to: leave ? form.leave_to || form.leave_from : null,
      });
      setItems((list) => [row, ...(list || [])]);
      setForm({ category: 'general', subject: '', message: '', leave_from: '', leave_to: '' });
      setTouched(false);
      setSent(true);
      toast(t('sup.sentOk'));
      setTimeout(() => setSent(false), 5000);
    } catch (e2) {
      setError(e2.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <PageHeader title={t('sup.title')} subtitle={t('sup.sub')} />
      <div className={`grid gap-6 ${adminMode ? '' : 'lg:grid-cols-[1fr_1.1fr]'}`}>
        {!adminMode && (
        <Card>
          <h2 className="mb-4 text-lg text-heading">{t('sup.new')}</h2>
          <form onSubmit={submit} noValidate className="space-y-4">
            <div>
              <span className="label">{t('sup.type')}</span>
              <div className="flex flex-wrap gap-2" role="radiogroup" aria-label={t('sup.type')}>
                {CATEGORIES.map((c) => (
                  <button key={c} type="button" role="radio" aria-checked={form.category === c} onClick={() => setForm((f) => ({ ...f, category: c }))}
                    className={`rounded-xl border px-3 py-1.5 text-sm font-semibold transition ${form.category === c ? 'border-[#034751] bg-[#034751] text-white' : 'border-ink/15 text-ink/75 hover:border-pine-500'}`}>
                    {t(`sup.${c}`)}
                  </button>
                ))}
              </div>
            </div>
            {leave && (
              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <label className="label" htmlFor="sp-from">{t('sup.first')} <span className="text-red-700">*</span></label>
                  <input id="sp-from" type="date" className="input" min={today()} value={form.leave_from} onChange={set('leave_from')} aria-invalid={Boolean(show('leave_from'))} />
                  {show('leave_from') && <p className="mt-1 text-xs text-red-700">{errors.leave_from}</p>}
                </div>
                <div>
                  <label className="label" htmlFor="sp-to">{t('sup.last')} {req('sup.leaveTo') && <span className="text-red-700">*</span>}</label>
                  <input id="sp-to" type="date" className="input" min={form.leave_from || today()} value={form.leave_to} onChange={set('leave_to')} aria-invalid={Boolean(show('leave_to'))} />
                  {show('leave_to') && <p className="mt-1 text-xs text-red-700">{errors.leave_to}</p>}
                </div>
              </div>
            )}
            <div>
              <label className="label" htmlFor="sp-subject">{t('sup.subject')} {req('sup.subject') && <span className="text-red-700">*</span>}</label>
              <input id="sp-subject" className="input" maxLength={150} placeholder={leave ? t('sup.subjectPhLeave') : t('sup.subjectPh')} value={form.subject} onChange={set('subject')} aria-invalid={Boolean(show('subject'))} />
              {show('subject') && <p className="mt-1 text-xs text-red-700">{errors.subject}</p>}
            </div>
            <div>
              <label className="label" htmlFor="sp-message">{t('sup.message')} <span className="text-red-700">*</span></label>
              <textarea id="sp-message" className="input" rows={5} maxLength={3000} placeholder={leave ? t('sup.messagePhLeave') : t('sup.messagePh')} value={form.message} onChange={set('message')} aria-invalid={Boolean(show('message'))} />
              {show('message') && <p className="mt-1 text-xs text-red-700">{errors.message}</p>}
            </div>
            {error && <p role="alert" className="rounded-xl bg-red-50 px-3.5 py-2.5 text-sm text-red-800">{err(error)}</p>}
            {sent && <p role="status" className="rounded-xl bg-emerald-50 px-3.5 py-2.5 text-sm text-emerald-900">{t('sup.sentOk')}</p>}
            <button type="submit" className="btn-primary w-full py-3" disabled={busy}><Send className="h-4 w-4" /> {busy ? t('sup.sending') : t('sup.send')}</button>
          </form>
        </Card>
        )}

        <div>
          <h2 className="mb-3 text-lg text-heading">{t('sup.yours')}</h2>
          {items === null ? (
            <p className="text-sm text-ink/70">{t('loading.generic')}</p>
          ) : !items.length ? (
            <EmptyState title={t('sup.noneTitle')}>{t('sup.noneBody')}</EmptyState>
          ) : (
            <ul className="space-y-3">
              {items.map((i) => (
                <li key={i.id}>
                  <Card className="p-4 sm:p-5">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="font-semibold text-heading">{i.subject}</p>
                        <p className="text-xs text-ink/70">
                          {t(`sup.${i.category}`)} · {date(i.created_at)}
                          {i.category === 'leave' && i.leave_from ? ` · ${date(i.leave_from)}${i.leave_to && i.leave_to !== i.leave_from ? ` → ${date(i.leave_to)}` : ''}` : ''}
                        </p>
                      </div>
                      <Badge status={i.status} />
                    </div>
                    <p className="mt-2 whitespace-pre-wrap text-sm text-ink/80">{i.message}</p>
                    {adminMode && <AdminReply item={i} onSaved={(row) => setItems((list) => list.map((x) => (x.id === row.id ? row : x)))} />}
                    {!adminMode && i.admin_reply && (
                      <div className="mt-3 rounded-xl bg-tint px-3.5 py-2.5 text-sm">
                        <span className="label-caps mb-0.5">{t('sup.reply')}</span>
                        <p className="whitespace-pre-wrap">{i.admin_reply}</p>
                      </div>
                    )}
                  </Card>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </>
  );
}
