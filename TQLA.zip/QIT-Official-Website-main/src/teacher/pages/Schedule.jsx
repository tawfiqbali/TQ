import { useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { CalendarClock, Shuffle } from 'lucide-react';
import { useTeacher } from '../TeacherContext';
import { isFlexible, updateMyStudent } from '../../lib/teacherData';
import { useConfirm } from '../../components/ui/Confirm';
import { useToast } from '../../components/ui/Toast';
import ScheduleEditor, { WEEK_ORDER } from '../ScheduleEditor';
import { Card, EmptyState, PageHeader } from '../ui';
import { useT } from '../i18n';

const endTime = (start, minutes) => {
  const [h, m] = String(start).split(':').map(Number);
  const total = h * 60 + m + Number(minutes || 0);
  return `${String(Math.floor(total / 60) % 24).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`;
};

// Fixed (weekly days and times) or Flexible (log each class) for one student
function ScheduleType({ student }) {
  const { reload, adminTeacherId } = useTeacher();
  const { t, err } = useT();
  const confirm = useConfirm();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const cur = isFlexible(student) ? 'flexible' : 'fixed';
  const change = async (k) => {
    if (k === cur || busy) return;
    if (k === 'flexible' && !(await confirm({ title: t('stu.toFlexQ'), message: t('stu.toFlexMsg', { name: student.name }), confirmText: t('stu.toFlexYes'), cancelText: t('stu.cancel') }))) return;
    setBusy(true);
    try {
      await updateMyStudent(student.id, { scheduleType: k }, adminTeacherId);
      await reload();
      toast(t('stu.saved'));
    } catch (e) {
      toast(err(e.message), 'error');
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="mb-4">
      <div className="grid max-w-md grid-cols-2 gap-2" role="radiogroup" aria-label={t('stu.schedule')}>
        {[['fixed', CalendarClock], ['flexible', Shuffle]].map(([k, Icon]) => (
          <button key={k} type="button" role="radio" aria-checked={cur === k} disabled={busy} onClick={() => change(k)}
            className={`flex items-center justify-center gap-2 rounded-xl border px-3 py-2.5 text-sm font-semibold transition disabled:opacity-60 ${cur === k ? 'border-[#034751] bg-[#034751] text-white' : 'border-ink/15 text-ink/75 hover:border-[#005359]'}`}>
            <Icon className="h-4 w-4" aria-hidden="true" /> {t(`stu.${k}`)}
          </button>
        ))}
      </div>
      <p className="mt-1.5 text-xs text-ink/70">{cur === 'flexible' ? t('stu.flexHint') : t('stu.fixedHint')}</p>
    </div>
  );
}

/**
 * The teacher's week at a glance (Saturday → Friday) and the editor for
 * each student's class times.
 */
export default function Schedule() {
  const { students, schedules } = useTeacher();
  const { t, weekday, time } = useT();
  const [params, setParams] = useSearchParams();
  const [studentId, setStudentId] = useState(params.get('student') || students[0]?.id || '');
  const names = useMemo(() => Object.fromEntries(students.map((s) => [s.id, s.name])), [students]);
  const today = new Date().getDay();
  const student = students.find((s) => s.id === studentId);

  const byDay = useMemo(() => {
    const m = Object.fromEntries(WEEK_ORDER.map((d) => [d, []]));
    schedules.filter((s) => names[s.student_id]).forEach((s) => m[s.weekday]?.push(s));
    Object.values(m).forEach((list) => list.sort((a, b) => String(a.start_time).localeCompare(String(b.start_time))));
    return m;
  }, [schedules, names]);
  const total = Object.values(byDay).reduce((a, l) => a + l.length, 0);
  const flexible = students.filter(isFlexible);

  const pick = (id) => {
    setStudentId(id);
    setParams(id ? { student: id } : {}, { replace: true });
  };

  return (
    <>
      <PageHeader title={t('sch.title')} subtitle={t('sch.sub', { classes: total, students: students.length })} />

      {!students.length ? (
        <EmptyState title={t('home.noneTitle')}>{t('sch.noneBody')}</EmptyState>
      ) : (
        <>
          <Card className="mb-6 p-4 sm:p-5">
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-7">
              {WEEK_ORDER.map((d) => (
                <div key={d} className={`rounded-xl p-2.5 ${d === today ? 'bg-pine-50 ring-2 ring-pine-500/40 dark:bg-pine-900/40' : 'bg-tint'}`}>
                  <div className="mb-2 flex items-center justify-between text-xs font-semibold uppercase tracking-wider text-ink/70">
                    {weekday(d)}
                    {d === today && <span className="rounded bg-pine-800 px-1.5 py-0.5 text-[10px] text-white">{t('sch.today')}</span>}
                  </div>
                  {byDay[d].length ? (
                    <ul className="space-y-1.5">
                      {byDay[d].map((s) => (
                        <li key={s.id}>
                          <button type="button" onClick={() => pick(s.student_id)} className="w-full rounded-lg bg-surface px-2.5 py-2 text-left shadow-sm transition hover:ring-2 hover:ring-pine-500/40">
                            <span className="block text-xs font-semibold text-brand">{time(s.start_time)} – {time(endTime(s.start_time, s.duration_min))}</span>
                            <span className="block truncate text-sm text-heading">{names[s.student_id]}</span>
                          </button>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="py-2 text-center text-xs text-ink/40">{t('sch.noClasses')}</p>
                  )}
                </div>
              ))}
            </div>
          </Card>

          {flexible.length > 0 && (
            <Card className="mb-6 p-4 sm:p-5">
              <h2 className="flex items-center gap-2 text-base text-heading"><Shuffle className="h-4 w-4" aria-hidden="true" /> {t('att.flexTitle')}</h2>
              <p className="mt-1 text-sm text-ink/70">{t('stu.flexHint')}</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {flexible.map((s) => (
                  <button key={s.id} type="button" onClick={() => pick(s.id)} className="rounded-full border border-gold-300 bg-gold-50 px-3 py-1.5 text-sm font-semibold text-gold-800 dark:border-gold-700 dark:bg-gold-700/20 dark:text-gold-100">
                    {s.name} · {t('stu.flexible')}
                  </button>
                ))}
              </div>
            </Card>
          )}

          <Card>
            <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
              <div>
                <h2 className="text-lg text-heading">{t('sch.manage')}</h2>
                <p className="text-sm text-ink/70">{t('sch.manageSub')}</p>
              </div>
              <div className="w-full sm:w-72">
                <label className="label" htmlFor="sch-student">{t('sch.student')}</label>
                <select id="sch-student" className="input" value={studentId} onChange={(e) => pick(e.target.value)}>
                  {students.map((s) => <option key={s.id} value={s.id}>{s.name} ({s.id})</option>)}
                </select>
              </div>
            </div>
            {student && <ScheduleType key={`t-${student.id}`} student={student} />}
            {student && !isFlexible(student) && <ScheduleEditor key={student.id} student={student} />}
          </Card>
        </>
      )}
    </>
  );
}
