import { matchSearch } from '../../lib/search';
import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { AlertCircle, AlertTriangle, CalendarClock, CalendarDays, CheckCircle2, ChevronDown, ClipboardList, Clock, FileText, History, MessageCircle, Pencil, Plus, Search, Send, Shuffle, Users } from 'lucide-react';
import { useTeacher } from '../TeacherContext';
import ScheduleEditor, { bySlot } from '../ScheduleEditor';
import { EmptyState, PageHeader, Stat } from '../ui';
import { cancelStudentDelete, isFlexible, listMyReports, reportMonth, whatsappLinks } from '../../lib/teacherData';
import { useToast } from '../../components/ui/Toast';
import EditStudent from '../EditStudent';
import { useT } from '../i18n';
import { lazy, Suspense } from 'react';
import LoginCard from '../LoginCard';
// Executive-only tools (profile, points), loaded only in admin mode
const AdminTeacherTools = lazy(() => import('../AdminTeacherTools'));

const TONES = ['teal', 'gold', 'slate'];
const initials = (name) => {
  const w = String(name || '').replace(/\(.*?\)/g, ' ').split(/[\s/]+/).filter((x) => /[\p{L}]/u.test(x));
  return ((w[0]?.[0] || '?') + (w.length > 1 ? w[w.length - 1][0] : w[0]?.[1] || '')).toUpperCase();
};

function StudentCard({ student, slots, report, due, base, tone }) {
  const { t, month, weekdayShort, time } = useT();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(false);
  const flex = isFlexible(student);
  const phones = whatsappLinks(student.phone);
  const status = report ? report.review_status : 'missing';
  const RepIcon = { missing: AlertCircle, submitted: Send, reviewed: CheckCircle2, needs_changes: AlertTriangle }[status] || AlertCircle;
  return (
    <article className={`t-stu t-k-${status === 'needs_changes' ? 'red' : tone}`} data-student={student.id}>
      <header className="t-stu-head">
        <span className="t-avatar" aria-hidden="true">{initials(student.name)}</span>
        <div className="min-w-0 flex-1">
          <h2 className="t-stu-name">{student.name}</h2>
          <span className="t-stu-id">{student.id}</span>
          {student.course && <span className="t-stu-id ml-1.5">{student.course}</span>}
          {student.medium && <span className={`t-medium ${student.medium === 'English Medium' ? 'en' : 'bn'}`} data-testid={`medium-${student.id}`}>{t(student.medium === 'English Medium' ? 'stu.english' : 'stu.bangla')}</span>}
        </div>
        <button type="button" className="t-stu-edit" onClick={() => setEditing(true)} aria-label={t('stu.editFor', { name: student.name })} title={t('stu.edit')} data-testid="edit-student">
          <Pencil className="h-4 w-4" aria-hidden="true" />
        </button>
      </header>

      <div className="t-stu-body text-sm">
        <div className="t-stu-row">
          <span className="t-stu-ico"><Clock className="h-4 w-4" aria-hidden="true" /></span>
          <div className="min-w-0">
            <div className="t-stu-lbl">{t('home.classes')}</div>
            <div className="mt-1 flex flex-wrap gap-1.5">
              {flex ? <span className="t-time-chip t-flex-chip"><Shuffle className="h-3.5 w-3.5" aria-hidden="true" /> {t('stu.flexible')}</span> : slots.length ? slots.map((s) => (
                <span key={s.id} className="t-time-chip">{weekdayShort(s.weekday)} · {time(s.start_time)}</span>
              )) : student.classTime ? <span className="t-time-chip">{student.classTime}</span> : <span className="text-ink/60">{t('home.notSet')}</span>}
            </div>
          </div>
        </div>
        {phones.length > 0 && (
          <div className="t-stu-row">
            <span className="t-stu-ico"><MessageCircle className="h-4 w-4" aria-hidden="true" /></span>
            <div className="min-w-0">
              <div className="t-stu-lbl">{t('home.whatsapp')}</div>
              <div className="mt-0.5 space-y-0.5">
                {phones.map((ph) => (
                  <div key={ph.label}>
                    {ph.href ? (
                      <a href={ph.href} target="_blank" rel="noreferrer" className="font-semibold text-brand hover:underline">{ph.label}</a>
                    ) : ph.label}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
        <div className="t-stu-row">
          <span className="t-stu-ico"><FileText className="h-4 w-4" aria-hidden="true" /></span>
          <div className="min-w-0">
            <div className="t-stu-lbl">{t('home.reportLbl', { month: month(due.month) })}</div>
            <span className={`t-rep ${status} mt-1`}>
              <RepIcon className="h-3.5 w-3.5" aria-hidden="true" />
              {report ? t(`badge.${status}`) : t('home.notSent')}
            </span>
          </div>
        </div>
        {report?.review_status === 'needs_changes' && report.review_note && (
          <div className="rounded-lg bg-red-50 px-3 py-2 text-xs text-red-800 dark:bg-red-900/40 dark:text-red-100">{t('home.officeNote', { note: report.review_note })}</div>
        )}
      </div>

      <div className="t-stu-foot">
        {!flex && (
          <button type="button" className="btn-outline btn-sm" onClick={() => setOpen((o) => !o)} aria-expanded={open}>
            <CalendarClock className="h-4 w-4" /> {t('home.schedule')} <ChevronDown className={`h-4 w-4 transition ${open ? 'rotate-180' : ''}`} />
          </button>
        )}
        <Link to={`${base}/report?student=${encodeURIComponent(student.id)}`} className="btn-primary btn-sm">
          <ClipboardList className="h-4 w-4" /> {report ? t('home.editReport') : t('home.writeReport')}
        </Link>
      </div>
      {open && !flex && <div className="border-t border-ink/10 p-4"><ScheduleEditor student={student} /></div>}
      {editing && <EditStudent student={student} onClose={() => setEditing(false)} />}
    </article>
  );
}

export default function MyStudents() {
  const { teacher, students, schedules, base, adminTeacherId, adminMode, access, stats, home } = useTeacher();
  // Teachers who came in through Google see their Teacher ID + password once
  const seenKey = `qit:login-card-seen:${access?.teacherId || ''}`;
  const [cardSeen, setCardSeen] = useState(() => {
    try {
      return localStorage.getItem(seenKey) === '1';
    } catch {
      return true;
    }
  });
  const hideCard = () => {
    try {
      localStorage.setItem(seenKey, '1');
    } catch {
      /* hidden for this visit */
    }
    setCardSeen(true);
  };
  const { t, n, month } = useT();
  const due = reportMonth();
  const [reports, setReports] = useState([]);
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState('all');
  const [adding, setAdding] = useState(false);

  // v169: the reports are read again whenever the dashboard refreshes (every
  // minute and when the phone/tab comes back), so "Needs changes" from the
  // office shows up without reopening the page
  useEffect(() => {
    listMyReports(adminTeacherId).then(setReports).catch(() => {});
  }, [adminTeacherId, home]);

  const dueReports = useMemo(() => {
    const m = {};
    reports.filter((r) => r.month === due.month && r.year === due.year).forEach((r) => (m[r.student_id] = r));
    return m;
  }, [reports, due.month, due.year]);
  const missing = students.filter((s) => !dueReports[s.id]).length;
  const weekly = schedules.filter((s) => students.some((x) => x.id === s.student_id)).length;
  // v188: a sent-back report counts only until it is sent again — also when it was
  // written for a double entry of the same student (same name and month)
  const fixList = useMemo(() => {
    const k = (r) => `${String(r.student_name || r.student_id).trim().toLowerCase().replace(/\s+/g, ' ')}|${r.month}|${r.year}`;
    return reports.filter((r) => r.review_status === 'needs_changes'
      && !reports.some((o) => o.id !== r.id && k(o) === k(r) && o.review_status !== 'needs_changes' && String(o.submitted_at || '') >= String(r.submitted_at || '')));
  }, [reports]);
  const needs = fixList.length;
  const term = q.trim().toLowerCase();
  const stateOf = (s) => (dueReports[s.id] ? (dueReports[s.id].review_status === 'needs_changes' ? 'fix' : 'sent') : 'due');
  const counts = { all: students.length, due: 0, sent: 0, fix: 0 };
  students.forEach((s) => (counts[stateOf(s)] += 1));
  const sorted = useMemo(() => [...students].sort((a, b) => a.name.localeCompare(b.name)), [students]);
  const shown = sorted.filter((s) => (filter === 'all' || stateOf(s) === filter)
    && (!term || matchSearch([s.name, s.id, s.phone, s.classTime].join(' '), term)));

  return (
    <>
      <PageHeader
        title={t('home.hello', { name: teacher?.fullName?.trim() || 'Ustad' })}
        subtitle={t('home.sub', { id: teacher?.id, dept: teacher?.department ? ` · ${teacher.department}` : '' })}
        action={<button type="button" className="btn-primary" onClick={() => setAdding(true)} data-testid="add-student"><Plus className="h-4 w-4" aria-hidden="true" /> {t('stu.add')}</button>}
      />
      {adding && <EditStudent student={null} onClose={() => setAdding(false)} />}

      {!adminMode && access?.via === 'google' && !cardSeen && <LoginCard className="mb-6" onDismiss={hideCard} />}

      {adminMode && (
        <Suspense fallback={null}>
          <AdminTeacherTools />
        </Suspense>
      )}

      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-5">
        <Stat accent="teal" icon={Users} label={t('hist.active')} value={n(students.length)}
          hint={stats && (stats.hold || stats.inactive) ? `${t('hist.holdN')} ${n(stats.hold)} · ${t('hist.inactiveN')} ${n(stats.inactive)}` : undefined} />
        <Stat accent="slate" icon={History} label={t('hist.allTime')} value={n(stats?.allTime ?? students.length)} hint={t('hist.allHint')} />
        <Stat accent="slate" icon={CalendarDays} label={t('home.perWeek')} value={n(weekly)} hint={weekly ? t('home.fromSchedule') : t('home.addUnder')} />
        <Stat
          accent="gold"
          icon={FileText}
          label={t('home.reports', { month: month(due.month) })}
          value={n(`${students.length - missing} / ${students.length}`)}
          hint={missing ? t('home.toSend', { n: missing }) : t('home.allSent')}
        />
        <Stat accent={needs ? 'red' : 'slate'} icon={AlertTriangle} label={t('home.needs')} value={n(needs)} hint={t('home.sentBack')} />
      </div>

      {/* v169: every report the office sent back, any month, with its note */}
      {needs > 0 && (
        <div className="t-fixlist mb-6" role="alert" data-testid="needs-changes">
          <strong><AlertTriangle className="h-4 w-4" aria-hidden="true" /> {t('home.fixTitle', { n: n(needs) })}</strong>
          <ul>
            {fixList.map((r) => (
              <li key={r.id}>
                <span><b>{r.student_name || r.student_id}</b> · {month(r.month)} {n(r.year)}{r.review_note ? <> — <em>{r.review_note}</em></> : null}</span>
                <Link to={`${base}/report?student=${encodeURIComponent(r.student_id)}&month=${encodeURIComponent(r.month)}&year=${r.year}`} className="btn-primary btn-sm" data-testid={`fix-${r.id}`}>{t('home.fixOpen')}</Link>
              </li>
            ))}
          </ul>
        </div>
      )}

      {missing > 0 && students.length > 0 && (
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-gold-300 bg-gold-50 px-5 py-4 text-pine-950 dark:border-gold-700 dark:bg-gold-700/20 dark:text-gold-100">
          <p className="text-sm"><strong>{t('home.due', { n: missing, month: month(due.month), year: n(due.year) })}</strong></p>
          <Link to={`${base}/report`} className="btn-gold btn-sm"><ClipboardList className="h-4 w-4" /> {t('home.write')}</Link>
        </div>
      )}

      {students.length > 0 && (
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div className="t-chipbar" role="group" aria-label={t('home.filter')}>
            {[['all', t('home.fAll')], ['due', t('home.fDue')], ['sent', t('home.fSent')], ['fix', t('home.needs')]].map(([k, label]) => (
              (k === 'all' || counts[k] > 0) && (
                <button key={k} type="button" className="t-chip" aria-pressed={filter === k} onClick={() => setFilter(k)}>
                  {label} <span className="t-chip-n">{n(counts[k])}</span>
                </button>
              )
            ))}
          </div>
          <div className="relative w-full max-w-xs">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink/40" aria-hidden="true" />
            <input className="input pl-9" placeholder={t('home.search')} value={q} onChange={(e) => setQ(e.target.value)} aria-label={t('home.search')} />
          </div>
        </div>
      )}

      {!students.length ? (
        <EmptyState title={t('home.noneTitle')}>{t('home.noneBody', { id: teacher?.id })}</EmptyState>
      ) : (
        <>
          {!shown.length && <p className="rounded-xl border border-dashed border-ink/20 px-4 py-6 text-center text-sm text-ink/70">{t('home.noMatch')}</p>}
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {shown.map((s, i) => (
              <StudentCard key={s.id} tone={TONES[i % TONES.length]} student={s} slots={schedules.filter((x) => x.student_id === s.id).sort(bySlot)} report={dueReports[s.id]} due={due} base={base} />
            ))}
          </div>
        </>
      )}
      <DeleteList />
    </>
  );
}

// v156: students the teacher asked to delete, until the office confirms
function DeleteList() {
  const { allStudents, reload, adminTeacherId } = useTeacher();
  const { t } = useT();
  const toast = useToast();
  const list = (allStudents || []).filter((s) => s.deleteRequested);
  if (!list.length) return null;
  return (
    <section className="mt-8 rounded-2xl border border-red-200 bg-red-50/60 p-4 dark:border-red-900 dark:bg-red-900/10" data-testid="delete-list">
      <h2 className="text-base font-bold text-red-900 dark:text-red-100">{t('stu.delList')}</h2>
      <ul className="mt-2 space-y-2">
        {list.map((s) => (
          <li key={s.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-surface px-3 py-2 text-sm">
            <span><strong>{s.name}</strong> <span className="text-ink/60">{s.id}</span> · <span className="text-red-800 dark:text-red-200">{t('stu.delWaiting')}</span></span>
            <button type="button" className="btn-ghost btn-sm" onClick={async () => { try { await cancelStudentDelete(s.id, adminTeacherId); await reload(); } catch (e) { toast(e.message, 'error'); } }}>{t('stu.delCancel')}</button>
          </li>
        ))}
      </ul>
    </section>
  );
}
