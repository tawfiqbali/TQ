import PhoneLinks from '../../components/ui/PhoneLinks';
import { useState } from 'react';
import { Archive, History, PauseCircle, Phone, RotateCcw, Users } from 'lucide-react';
import { updateMyStudent } from '../../lib/teacherData';
import { useToast } from '../../components/ui/Toast';
import { useTeacher } from '../TeacherContext';
import { Card, PageHeader, Stat } from '../ui';
import { useT } from '../i18n';

/**
 * Students on Hold or Inactive. They stay out of My Students, Attendance and
 * Reports until the office makes them Active again (Management Portal →
 * Students → Status).
 */
export default function StudentHistory() {
  const { allStudents = [], stats, reload, adminTeacherId } = useTeacher();
  const { t, n, date } = useT();
  const toast = useToast();
  const [busy, setBusy] = useState('');
  // Back to My Students (or between Hold and Inactive)
  const setStatus = async (student, status) => {
    setBusy(student.id);
    try {
      await updateMyStudent(student.id, { status }, adminTeacherId);
      await reload();
      toast(status === 'Active' ? t('hist.madeActive', { name: student.name }) : t('stu.saved'));
    } catch (e) {
      toast(e.message, 'error');
    }
    setBusy('');
  };
  const groups = [
    { key: 'Hold', title: t('hist.hold'), Icon: PauseCircle, tone: 'text-amber-800 bg-amber-50 border-amber-200 dark:bg-amber-900/20 dark:text-amber-200 dark:border-amber-800' },
    { key: 'Inactive', title: t('hist.inactive'), Icon: Archive, tone: 'text-slate-700 bg-slate-100 border-slate-200 dark:bg-white/5 dark:text-ink/80 dark:border-white/10' },
  ];
  const of = (k) => allStudents.filter((s) => s.status === k);
  const none = !of('Hold').length && !of('Inactive').length;
  return (
    <>
      <PageHeader title={t('hist.title')} subtitle={t('hist.sub')} />
      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4" data-testid="history-stats">
        <Stat accent="slate" icon={History} label={t('hist.allTime')} value={n(stats?.allTime ?? allStudents.length)} hint={t('hist.allHint')} />
        <Stat accent="teal" icon={Users} label={t('hist.active')} value={n(stats?.active ?? of('Active').length)} />
        <Stat accent="gold" icon={PauseCircle} label={t('hist.holdN')} value={n(of('Hold').length)} />
        <Stat accent="slate" icon={Archive} label={t('hist.inactiveN')} value={n(of('Inactive').length)} />
      </div>
      {none ? (
        <Card><p className="py-6 text-center text-sm text-ink/70">{t('hist.none')}</p></Card>
      ) : groups.map(({ key, title, Icon, tone }) => of(key).length > 0 && (
        <Card key={key} className="mb-5" data-testid={`history-${key.toLowerCase()}`}>
          <h2 className="mb-3 flex items-center gap-2 text-lg text-heading"><Icon className="h-5 w-5" aria-hidden="true" /> {title} <span className="text-sm text-ink/60">({n(of(key).length)})</span></h2>
          <ul className="divide-y divide-ink/10">
            {of(key).map((s) => (
              <li key={s.id} className="flex flex-wrap items-center justify-between gap-2 py-3">
                <div className="min-w-0">
                  <p className="font-semibold text-heading">{s.name} <span className="font-mono text-xs text-ink/60" lang="en">{s.id}</span></p>
                  <p className="text-xs text-ink/70">
                    {[s.course, s.statusChangedAt && t('hist.since', { date: date(s.statusChangedAt) }), s.since && t('hist.joined', { date: date(s.since) })].filter(Boolean).join(' · ')}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {s.phone && s.phone !== 'N/A' && <span className="text-xs"><PhoneLinks value={s.phone} /></span>}
                  <span className={`rounded-full border px-2.5 py-0.5 text-xs font-bold ${tone}`}>{title}</span>
                  <button type="button" className="btn-outline btn-sm" disabled={busy === s.id} onClick={() => setStatus(s, 'Active')} data-testid={`activate-${s.id}`}>
                    <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" /> {t('hist.makeActive')}
                  </button>
                </div>
              </li>
            ))}
          </ul>
        </Card>
      ))}
      <p className="mt-2 text-xs text-ink/70">{t('hist.ask')}</p>
    </>
  );
}
