import { useEffect, useMemo, useState } from 'react';
import { Badge, Card, EmptyState, PageHeader, Stat } from '../ui';
import { adminCancelTeacherPayment, lastMonthSalary, salaryHistory, teacherSalary } from '../../lib/teacherData';
import { useConfirm } from '../../components/ui/Confirm';
import { useToast } from '../../components/ui/Toast';
import { useT } from '../i18n';
import { useTeacher } from '../TeacherContext';

// Read-only: the teacher's salary month by month (Paid / Pending / Unpaid)
export default function Salary() {
  const { t, n, month, money, date, err } = useT();
  const { adminTeacherId, adminMode } = useTeacher();
  const confirm = useConfirm();
  const toast = useToast();
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [tick, setTick] = useState(0);

  useEffect(() => {
    teacherSalary(adminTeacherId).then(setData).catch((e) => setError(e.message));
  }, [adminTeacherId, tick]);
  // v187: the office can remove a disbursement here (it disappears for the teacher too)
  const cancel = async (p) => {
    if (!(await confirm({ title: 'Remove this disbursement?', message: `${money(p.amount)} for ${p.month} ${p.year}${p.date ? ` (paid ${p.date})` : ''} is removed from the salary records and from this teacher's dashboard.`, confirmText: 'Remove', tone: 'danger' }))) return;
    try { await adminCancelTeacherPayment(p.id); toast('Disbursement removed.'); setTick((x) => x + 1); } catch (e) { toast(e.message, 'error'); }
  };

  const rows = useMemo(() => salaryHistory(data), [data]);
  const year = new Date().getFullYear();
  const paidThisYear = (data?.payments || []).filter((p) => String(p.date || '').startsWith(String(year)) || Number(p.year) === year).reduce((a, p) => a + (Number(p.amount) || 0), 0);
  const pending = rows.filter((r) => r.status === 'Pending').length;
  const unpaid = rows.filter((r) => r.status === 'Unpaid').length;
  const lastSal = useMemo(() => lastMonthSalary(data), [data]);
  const thisMonth = new Date().toLocaleString('en-GB', { month: 'long' });

  return (
    <>
      <PageHeader title={t('sal.title')} subtitle={t('sal.sub')} />
      {error && <p role="alert" className="mb-6 rounded-xl bg-red-50 px-4 py-3 text-sm text-red-800">{err(error)}</p>}
      {!data && !error && <p className="text-sm text-ink/70">{t('loading.generic')}</p>}
      {data && (
        <>
          <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
            {/* v187: last month's salary (paid this month), not the running one */}
            <Stat label={t('sal.lastMonth', { month: month(lastSal.month) })} value={money(lastSal.salary)}
              hint={lastSal.extra ? t('sal.withExtra', { extra: money(lastSal.extra) }) : t('sal.paidInMonth', { month: month(thisMonth) })} />
            <Stat label={t('sal.paidIn', { year: n(year) })} value={money(paidThisYear)} />
            <Stat label={t('sal.pending')} value={n(pending)} tone={pending ? 'gold' : 'pine'} hint={t('sal.processing')} />
            <Stat label={t('sal.unpaid')} value={n(unpaid)} tone={unpaid ? 'red' : 'pine'} hint={unpaid ? t('sal.contact') : t('sal.nothing')} />
          </div>

          {!rows.length ? (
            <EmptyState title={t('sal.noneTitle')}>{t('sal.noneBody')}</EmptyState>
          ) : (
            <Card className="p-0 sm:p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <caption className="sr-only">{t('sal.caption')}</caption>
                  <thead>
                    <tr className="border-b border-ink/10 text-[11px] uppercase tracking-[0.12em] text-ink/70">
                      <th scope="col" className="px-5 py-3 font-semibold">{t('sal.month')}</th>
                      <th scope="col" className="px-5 py-3 text-right font-semibold">{t('sal.salary')}</th>
                      <th scope="col" className="px-5 py-3 text-right font-semibold">{t('sal.paid')}</th>
                      <th scope="col" className="hidden px-5 py-3 font-semibold sm:table-cell">{t('sal.paidOn')}</th>
                      <th scope="col" className="px-5 py-3 font-semibold">{t('sal.status')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((r) => (
                      <tr key={`${r.month}-${r.year}`} className="border-b border-ink/5 last:border-0">
                        <th scope="row" className="px-5 py-3.5 font-semibold text-heading">{month(r.month)} {n(r.year)}</th>
                        <td className="px-5 py-3.5 text-right tabular-nums">{money(r.expected)}{r.extra > 0 && <span className="block text-[11px] font-semibold text-ink/65">{t('sal.extraLine', { extra: money(r.extra), what: r.extras.map((e) => e.title).join(', ') })}</span>}</td>
                        <td className="px-5 py-3.5 text-right tabular-nums">{r.paid ? money(r.paid) : '—'}
                          {adminMode && r.payments.map((p) => (
                            <button key={p.id} type="button" className="ml-2 rounded-md border border-red-300 px-1.5 py-0.5 text-[11px] font-bold text-red-700 hover:bg-red-50" onClick={() => cancel(p)} data-testid={`sal-cancel-${p.id}`} title="Remove this disbursement">Remove</button>
                          ))}</td>
                        <td className="hidden px-5 py-3.5 text-ink/75 sm:table-cell">{r.dates.map((d) => date(String(d).slice(0, 10))).join(', ') || '—'}</td>
                        <td className="px-5 py-3.5"><Badge status={r.status} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          )}
          <p className="mt-4 text-xs leading-relaxed text-ink/70">{t('sal.legend')}</p>
        </>
      )}
    </>
  );
}
