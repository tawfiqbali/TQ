import { memo, useCallback, useEffect, useMemo, useState } from 'react';
import { Award, CalendarCheck, Check, ClipboardCheck, Download, Flame, Gift, Lock, Medal, Sparkles, Star, TrendingUp } from 'lucide-react';
import { useTeacher } from '../TeacherContext';
import { Card, PageHeader, Stat } from '../ui';
import { MONTHS, getPointRules, teacherStats } from '../../lib/teacherData';
import { useToast } from '../../components/ui/Toast';
import { useT } from '../i18n';
import { downloadTeacherSummary } from '../summaryPdf';

const BREAKDOWN = ['present', 'daysLogged', 'reports', 'onTime', 'reviewed', 'perfectAttendance', 'studentLevels', 'adjustments'];

// Points of the last six months as simple bars (with a table for screen readers)
const HistoryChart = memo(function HistoryChart({ history }) {
  const { t, n, month } = useT();
  const max = Math.max(1, ...history.map((h) => h.points));
  return (
    <div>
      <div className="flex items-end gap-2 sm:gap-3" aria-hidden="true">
        {history.map((h, i) => (
          <div key={`${h.month}${h.year}`} className="flex flex-1 flex-col items-center gap-1.5">
            <span className="text-xs font-semibold tabular-nums text-heading">{n(h.points)}</span>
            <div className="t-bar-track">
              <div className={`t-bar ${i === history.length - 1 ? 'is-now' : ''}`} style={{ height: `${h.points > 0 ? Math.max(6, (h.points / max) * 100) : 0}%` }} />
            </div>
            <span className="text-[11px] font-semibold text-ink/70">{month(h.month).slice(0, 3)}</span>
          </div>
        ))}
      </div>
      <table className="sr-only">
        <caption>{t('pg.history')}</caption>
        <tbody>{history.map((h) => <tr key={`${h.month}${h.year}`}><th>{month(h.month)} {h.year}</th><td>{h.points}</td></tr>)}</tbody>
      </table>
    </div>
  );
});

// A few words of encouragement based on the month's numbers
function encouragement(stats, t) {
  const out = [];
  const a = stats.attendance || {};
  if (stats.streak >= 5) out.push(t('pg.msgStreak', { n: stats.streak }));
  if (a.rate != null && a.rate >= 90) out.push(t('pg.msgAttendance'));
  if (stats.reports?.expected && stats.reports.submitted >= stats.reports.expected) out.push(t('pg.msgReports'));
  if (stats.rank?.position === 1 && stats.rank.of > 1) out.push(t('pg.msgTop'));
  if (!out.length) out.push(t('pg.msgStart'));
  return out;
}

/**
 * "My Progress": attendance rate, points, level ("Hardworking Level"),
 * rank, streak, rewards and a downloadable month summary.
 */
export default function Progress() {
  const { teacher, students, adminTeacherId } = useTeacher();
  const tr = useT();
  const { t, n, lang, month: monthName } = tr;
  const toast = useToast();
  const now = new Date();
  const [month, setMonth] = useState(MONTHS[now.getMonth()]);
  const [year, setYear] = useState(now.getFullYear());
  const [stats, setStats] = useState(null);
  const [rules, setRules] = useState(null);
  const [error, setError] = useState('');
  const [pdfBusy, setPdfBusy] = useState(false);

  const load = useCallback(async () => {
    setError('');
    setStats(null);
    try {
      const [s, r] = await Promise.all([teacherStats({ teacherId: adminTeacherId, month, year }), getPointRules()]);
      setStats(s);
      setRules(r?.config || null);
    } catch (e) {
      setError(e.message);
    }
  }, [adminTeacherId, month, year]);
  useEffect(() => {
    load();
  }, [load]);

  const levelName = (l) => (l ? (lang === 'bn' ? l.bn : l.en) : '—');
  const allTime = stats?.points?.allTime?.total ?? 0;
  const monthPts = stats?.points?.month || {};
  const rewards = useMemo(() => {
    const levels = rules?.levels || [];
    const min = (name) => levels.find((l) => l.en === name)?.min ?? Infinity;
    return (rules?.rewards || []).map((r) => ({ ...r, unlocked: allTime >= min(r.level), levelLabel: levelName(levels.find((l) => l.en === r.level)) }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rules, allTime, lang]);

  const pdf = async () => {
    setPdfBusy(true);
    try {
      const ok = await downloadTeacherSummary({ tr, teacher, students, stats, month, year, adminTeacherId });
      if (!ok) toast(t('pdf.popup'), 'error');
    } catch (e) {
      toast(e.message, 'error');
    } finally {
      setPdfBusy(false);
    }
  };

  const years = [now.getFullYear(), now.getFullYear() - 1];

  return (
    <>
      <PageHeader
        title={t('pg.title')}
        subtitle={t('pg.sub')}
        action={
          <div className="flex flex-wrap items-end gap-2">
            <select className="input w-36" value={month} onChange={(e) => setMonth(e.target.value)} aria-label={t('rp.month')}>
              {MONTHS.map((m) => <option key={m} value={m}>{monthName(m)}</option>)}
            </select>
            <select className="input w-24" value={year} onChange={(e) => setYear(Number(e.target.value))} aria-label={t('rp.year')}>
              {years.map((y) => <option key={y} value={y}>{n(y)}</option>)}
            </select>
            <button type="button" className="btn-primary" onClick={pdf} disabled={!stats || pdfBusy}>
              <Download className="h-4 w-4" /> {pdfBusy ? t('loading.generic') : t('pdf.download')}
            </button>
          </div>
        }
      />

      {error && <p role="alert" className="mb-6 rounded-xl bg-red-50 px-4 py-3 text-sm text-red-800">{tr.err(error)}</p>}
      {!stats && !error && <p className="text-sm text-ink/70">{t('loading.generic')}</p>}

      {stats && (
        <>
          {/* Level: light mode = white card with a gold top line, dark mode = plain deep teal */}
          <section className="t-level mb-6 p-5 sm:p-7" aria-label={t('pg.level')}>
            <div className="flex flex-wrap items-center justify-between gap-5">
              <div className="flex min-w-0 items-center gap-4">
                <span className="t-level-badge"><Award className="h-7 w-7" aria-hidden="true" /></span>
                <div className="min-w-0">
                  <p className="t-level-label">{t('pg.hardworkingLevel')}</p>
                  <p className="t-level-name font-display">{levelName(stats.level)}</p>
                  <p className="t-level-sub">{t('pg.totalPoints', { n: allTime })}</p>
                </div>
              </div>
              <div className="flex gap-3">
                <div className="t-level-mini">
                  <Medal className="t-level-ico h-5 w-5" aria-hidden="true" />
                  <p className="t-level-num font-display">#{n(stats.rank?.position ?? '—')}</p>
                  <p className="t-level-cap">{t('pg.rankOf', { n: stats.rank?.of ?? 0 })}</p>
                </div>
                <div className="t-level-mini">
                  <Flame className="t-level-ico h-5 w-5" aria-hidden="true" />
                  <p className="t-level-num font-display">{n(stats.streak)}</p>
                  <p className="t-level-cap">{t('pg.streak')}</p>
                </div>
              </div>
            </div>
            <div className="t-level-foot">
              <div className="t-level-cap flex justify-between font-semibold">
                <span>{levelName(stats.level)}</span>
                <span>{stats.nextLevel ? levelName(stats.nextLevel) : t('pg.topLevel')}</span>
              </div>
              <div className="t-level-track" role="progressbar" aria-valuenow={stats.levelProgress} aria-valuemin={0} aria-valuemax={100} aria-label={t('pg.toNext')}>
                <div className="t-level-fill" style={{ width: `${stats.levelProgress}%` }} />
              </div>
              {stats.nextLevel && <p className="t-level-cap mt-2">{t('pg.pointsToNext', { n: Math.max(0, stats.nextLevel.min - allTime), level: levelName(stats.nextLevel) })}</p>}
            </div>
          </section>

          <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-5">
            <Stat label={t('pg.conducted')} value={n(stats.attendance.conducted ?? stats.attendance.present)} hint={t('pg.conductedHint', { p: n(stats.attendance.present), r: n(stats.attendance.recovery ?? 0) })} />
            <Stat label={t('pg.attRate')} value={stats.attendance.rate == null ? '—' : `${n(stats.attendance.rate)}%`} hint={t('pg.attHint', { p: n(stats.attendance.present), a: n(stats.attendance.absent) })} tone={stats.attendance.rate != null && stats.attendance.rate < 75 ? 'gold' : 'pine'} />
            <Stat label={t('pg.logRate')} value={stats.attendance.logRate == null ? '—' : `${n(stats.attendance.logRate)}%`} hint={t('pg.logHint')} />
            <Stat label={t('pg.reports')} value={n(`${stats.reports.submitted} / ${stats.reports.expected}`)} hint={monthName(stats.month)} tone={stats.reports.submitted < stats.reports.expected ? 'gold' : 'pine'} />
            <Stat label={t('pg.monthPoints')} value={n(monthPts.total ?? 0)} hint={monthName(stats.month)} />
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <h2 className="mb-4 flex items-center gap-2 text-lg text-heading"><Star className="h-5 w-5 text-gold-500" aria-hidden="true" /> {t('pg.breakdown')}</h2>
              <ul className="t-points">
                {BREAKDOWN.map((k) => {
                  const v = monthPts[k] ?? 0;
                  return (
                    <li key={k} className={`t-points-row ${v === 0 ? 'is-zero' : ''}`}>
                      <span>{t(`pg.pt.${k}`)}</span>
                      <span className={`t-pill ${v < 0 ? 'is-neg' : v > 0 ? 'is-pos' : ''}`}>{v > 0 ? '+' : ''}{n(v)}</span>
                    </li>
                  );
                })}
              </ul>
              <div className="t-points-total">
                <span>{t('pg.total')}</span>
                <span className="font-display text-2xl tabular-nums">{n(monthPts.total ?? 0)}</span>
              </div>
              {rules?.points && (
                <p className="mt-3 text-xs leading-relaxed text-ink/70">
                  {t('pg.rulesHint', { present: n(rules.points.presentMark), report: n(rules.points.monthlyReport), bonus: n(rules.points.reportOnTimeBonus), day: n(rules.points.reportDeadlineDay) })}
                </p>
              )}
            </Card>

            <Card>
              <h2 className="mb-4 flex items-center gap-2 text-lg text-heading"><TrendingUp className="h-5 w-5 text-pine-500" aria-hidden="true" /> {t('pg.history')}</h2>
              <HistoryChart history={stats.history || []} />
            </Card>

            <Card>
              <h2 className="mb-4 flex items-center gap-2 text-lg text-heading"><Gift className="h-5 w-5 text-gold-500" aria-hidden="true" /> {t('pg.rewards')}</h2>
              {rewards.length ? (
                <ul className="space-y-2">
                  {rewards.map((r) => (
                    <li key={`${r.level}-${r.en}`} className={`t-reward ${r.unlocked ? 'is-on' : ''}`}>
                      <span className="t-reward-ico">{r.unlocked ? <Check className="h-4 w-4" aria-hidden="true" /> : <Lock className="h-4 w-4" aria-hidden="true" />}</span>
                      <span className="flex-1">{lang === 'bn' ? r.bn : r.en}</span>
                      <span className="t-reward-chip">{r.levelLabel}</span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-sm text-ink/70">{t('pg.noRewards')}</p>
              )}
            </Card>

            <Card className="flex flex-col justify-between">
              <div>
                <h2 className="mb-3 flex items-center gap-2 text-lg text-heading"><Sparkles className="h-5 w-5 text-gold-500" aria-hidden="true" /> {t('pg.inspire')}</h2>
                <ul className="space-y-2 text-sm text-ink/80">
                  {encouragement(stats, t).map((line) => (
                    <li key={line} className="flex gap-2"><CalendarCheck className="mt-0.5 h-4 w-4 shrink-0 text-pine-500" aria-hidden="true" /> {line}</li>
                  ))}
                </ul>
              </div>
              <blockquote className="mt-5 border-l-4 border-gold-400 pl-4">
                <p className="font-arabic text-xl leading-loose text-heading" lang="ar" dir="rtl">خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ</p>
                <p className="mt-1 text-sm text-ink/75">{t('pg.hadith')}</p>
                <footer className="mt-1 flex items-center gap-1 text-xs text-ink/70"><ClipboardCheck className="h-3.5 w-3.5" aria-hidden="true" /> {t('pg.hadithSource')}</footer>
              </blockquote>
            </Card>
          </div>
        </>
      )}
    </>
  );
}
