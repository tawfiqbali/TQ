import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { Navigate, Outlet, useLocation, useParams } from 'react-router-dom';
import FullPageLoader from '../components/ui/FullPageLoader';
import { getMyAccess, saveTeacherId, teacherStillActive } from '../lib/auth';
import { hasStoredSession, isSupabaseEnabled } from '../lib/supabaseClient';
import { listSchedules, teacherHome } from '../lib/teacherData';
import useAdminRole from '../hooks/useAdminRole';
import TeacherNotice from './TeacherNotice';
import TeacherUnlock, { FirstSignIn } from './TeacherUnlock';
import { useT } from './i18n';

const TeacherContext = createContext(null);
// My Students, Attendance, Reports and Schedule show Active students only;
// Hold and Inactive students are in Student history
const EMPTY = [];
// v156: a student the teacher asked to delete leaves the active lists at once
const activeOnly = (list) => (list ? list.filter((s) => (!s.status || s.status === 'Active') && !s.deleteRequested) : EMPTY);
export const useTeacher = () => useContext(TeacherContext);

// Loads one teacher's record, students and schedule (teacherId only in admin mode)
function useTeacherData(enabled, teacherId) {
  const [home, setHome] = useState(null);
  const [schedules, setSchedules] = useState([]);
  const [error, setError] = useState('');
  const reload = useCallback(async () => {
    setError('');
    try {
      const [h, s] = await Promise.all([teacherHome(teacherId), listSchedules(teacherId)]);
      setHome(h);
      setSchedules(s || []);
    } catch (e) {
      setError(e.message);
    }
  }, [teacherId]);
  useEffect(() => {
    if (enabled) reload();
  }, [enabled, reload]);
  // Stay in step with the office: refresh when the tab comes back into view
  // and every minute while it is open (changes made in the Management Portal
  // then show up without a page reload)
  useEffect(() => {
    if (!enabled) return undefined;
    const onShow = () => document.visibilityState === 'visible' && reload();
    document.addEventListener('visibilitychange', onShow);
    window.addEventListener('focus', onShow);
    const timer = setInterval(() => document.visibilityState === 'visible' && reload(), 60_000);
    return () => {
      document.removeEventListener('visibilitychange', onShow);
      window.removeEventListener('focus', onShow);
      clearInterval(timer);
    };
  }, [enabled, reload]);
  return { home, schedules, setSchedules, error, reload };
}

/**
 * Guards every /teacher page:
 *   not signed in       → /teacher/login (then back to the same link)
 *   signed in, new      → /teacher/onboarding (name + WhatsApp → Teacher ID)
 *   pending             → waiting for the office to confirm a name match
 *   Executive / Junior  → told to use the admin panel
 *   locked              → Teacher ID + password for this device (first
 *                         sign-in: opens straight away)
 *   teacher             → the page, with their students and schedules loaded
 * While open, it checks every minute that this is still the teacher's one
 * active device; if another device took over, it closes here.
 */
export function TeacherGate() {
  const location = useLocation();
  const here = `${location.pathname}${location.search}`;
  const [access, setAccess] = useState(undefined);
  const [accessError, setAccessError] = useState('');
  const [kicked, setKicked] = useState(false);
  const { t } = useT();

  const loadAccess = useCallback(async () => {
    if (!isSupabaseEnabled || !hasStoredSession()) return setAccess({ role: 'none' });
    try {
      const a = await getMyAccess({ fresh: true });
      if (a.role === 'teacher') setKicked(false);
      setAccess(a);
    } catch (e) {
      setAccessError(e.message);
      setAccess({ role: 'error' });
    }
  }, []);
  useEffect(() => {
    loadAccess();
  }, [loadAccess]);

  // Waiting for the office: check again by itself, so the Teacher ID and
  // password appear on this screen the moment an Executive approves
  const waiting = access?.role === 'pending';
  useEffect(() => {
    if (!waiting) return undefined;
    const check = () => document.visibilityState === 'visible' && loadAccess();
    const timer = setInterval(check, 8000);
    document.addEventListener('visibilitychange', check);
    return () => {
      clearInterval(timer);
      document.removeEventListener('visibilitychange', check);
    };
  }, [waiting, loadAccess]);

  // One device at a time: notice at once when another device took over
  const isTeacher = access?.role === 'teacher';
  useEffect(() => {
    if (!isTeacher) return undefined;
    const check = async () => {
      if (document.visibilityState !== 'visible') return;
      if (!(await teacherStillActive())) {
        setKicked(true);
        loadAccess();
      }
    };
    const timer = setInterval(check, 45_000);
    document.addEventListener('visibilitychange', check);
    window.addEventListener('focus', check);
    return () => {
      clearInterval(timer);
      document.removeEventListener('visibilitychange', check);
      window.removeEventListener('focus', check);
    };
  }, [isTeacher, loadAccess]);

  const data = useTeacherData(access?.role === 'teacher', undefined);
  // Remember this Teacher ID on the device: next time the sign-in page only asks for the password
  useEffect(() => {
    if (access?.role === 'teacher' && access.teacherId) saveTeacherId(access.teacherId);
  }, [access]);
  const value = useMemo(
    () => ({
      access, home: data.home, teacher: data.home?.teacher, students: activeOnly(data.home?.students), allStudents: data.home?.students || [], stats: data.home?.stats || null,
      schedules: data.schedules, setSchedules: data.setSchedules, reload: data.reload, refreshAccess: loadAccess,
      base: '/teacher', adminTeacherId: undefined, adminMode: false,
    }),
    [access, data.home, data.schedules, data.setSchedules, data.reload, loadAccess],
  );

  const onboarding = location.pathname.startsWith('/teacher/onboarding');
  if (access === undefined) return <FullPageLoader label={t('loading.dashboard')} />;
  if (access.role === 'none') return <Navigate to={`/teacher/login?next=${encodeURIComponent(here)}`} replace />;
  if (access.role === 'super' || access.role === 'junior' || access.role === 'junior_locked' || access.role === 'exec_locked') return <TeacherNotice kind="admin" email={access.email} role={access.role === 'junior' ? 'junior' : 'super'} />;
  if (access.role === 'error') return <TeacherNotice kind="error" message={accessError} onRetry={loadAccess} />;
  if (access.role === 'pending') return <TeacherNotice kind="pending" access={access} onRetry={loadAccess} />;
  // Just approved (or linked by the office): the Teacher ID and password are shown first
  if (access.role === 'locked' && access.firstTime && !access.off) return <FirstSignIn access={access} onDone={loadAccess} />;
  if (access.role === 'locked') return <TeacherUnlock access={access} kicked={kicked} onDone={loadAccess} />;
  if (access.role === 'new' && !onboarding) return <Navigate to={`/teacher/onboarding?next=${encodeURIComponent(here)}`} replace />;
  if (access.role === 'teacher' && onboarding) {
    const next = new URLSearchParams(location.search).get('next') || '';
    return <Navigate to={next.startsWith('/teacher') && !next.startsWith('/teacher/onboarding') ? next : '/teacher'} replace />;
  }
  if (access.role === 'teacher' && !data.home && !data.error) return <FullPageLoader label={t('loading.students')} />;
  if (access.role === 'teacher' && data.error && !data.home) return <TeacherNotice kind="error" message={data.error} onRetry={loadAccess} />;

  return (
    <TeacherContext.Provider value={value}>
      <Outlet />
    </TeacherContext.Provider>
  );
}

/**
 * Executives: /admin/teachers/QIT-001/… opens that teacher's own dashboard
 * with every page editable (attendance, schedule, reports, requests, points).
 */
export function AdminTeacherGate() {
  const { teacherId } = useParams();
  const { email, isSuper } = useAdminRole();
  const data = useTeacherData(Boolean(isSuper && teacherId), teacherId);
  const value = useMemo(
    () => ({
      access: { role: 'teacher', email: data.home?.teacher?.email, teacherId, fullName: data.home?.teacher?.fullName, adminEmail: email },
      home: data.home, teacher: data.home?.teacher, students: activeOnly(data.home?.students), allStudents: data.home?.students || [], stats: data.home?.stats || null,
      schedules: data.schedules, setSchedules: data.setSchedules, reload: data.reload, refreshAccess: data.reload,
      base: `/admin/teachers/${encodeURIComponent(teacherId)}`, adminTeacherId: teacherId, adminMode: true,
    }),
    [data.home, data.schedules, data.setSchedules, data.reload, teacherId, email],
  );
  if (email === null) return <FullPageLoader label="Checking your access" />;
  if (!isSuper) return <Navigate to="/admin/portal" replace />;
  if (data.error && !data.home) return <TeacherNotice kind="error" message={data.error} onRetry={data.reload} />;
  if (!data.home) return <FullPageLoader label={`Opening ${teacherId}`} />;
  return (
    <TeacherContext.Provider value={value}>
      <Outlet />
    </TeacherContext.Provider>
  );
}
