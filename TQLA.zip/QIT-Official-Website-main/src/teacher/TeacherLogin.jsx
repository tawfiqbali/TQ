import { useEffect, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { CalendarClock, ClipboardList, KeyRound, LifeBuoy, Phone, ShieldCheck, Smartphone, Wallet } from 'lucide-react';
import { getMyAccess, signInWithGoogle } from '../lib/auth';
import { hasStoredSession } from '../lib/supabaseClient';
import { EMERGENCY_PHONE, EMERGENCY_TEL, EMERGENCY_WA } from '../lib/teacherData';
import LogoMark from '../components/shared/LogoMark';
import GoogleMark from '../components/shared/GoogleMark';
import { useT, useTeacherDocument } from './i18n';
import { LangToggle } from './ui';
import { GlassStage } from '../components/ui/GlassAuth';

/**
 * Teacher sign-in: always "Continue with Google" first.
 *  - First time: the Gmail is enough (it links to the Teacher ID, or gives a
 *    new teacher the next ID).
 *  - After that: the same Gmail, then Teacher ID + password (next screen).
 *  - One device at a time.
 */
export default function TeacherLogin() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const next = params.get('next') || '/teacher';
  const target = next.startsWith('/teacher') && !next.startsWith('/teacher/login') ? next : '/teacher';
  const { t, err } = useT();
  useTeacherDocument(t('login.title'));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  // This device already signed in with Google: wait for the check instead of flashing the Google step
  const [checking, setChecking] = useState(() => hasStoredSession());

  useEffect(() => {
    // Already signed in with Google on this device: go on (the dashboard asks
    // for the Teacher ID + password if this device still needs them)
    if (hasStoredSession()) {
      getMyAccess({ fresh: true })
        .then((a) => (['teacher', 'new', 'pending', 'locked'].includes(a.role) ? navigate(target, { replace: true }) : setChecking(false)))
        .catch(() => setChecking(false));
    }
  }, [navigate, target]);

  const google = async () => {
    setBusy(true);
    setError('');
    try {
      await signInWithGoogle({ next: target, intent: 'teacher' });
    } catch (e2) {
      setError(e2.message);
      setBusy(false);
    }
  };

  const features = [
    { Icon: CalendarClock, text: t('login.f1') },
    { Icon: ClipboardList, text: t('login.f2') },
    { Icon: Wallet, text: t('login.f3') },
    { Icon: LifeBuoy, text: t('login.f4') },
  ];
  const rules = [
    { Icon: GoogleMark, text: t('login.rule1') },
    { Icon: KeyRound, text: t('login.rule2') },
    { Icon: Smartphone, text: t('login.rule3') },
  ];

  return (
    <GlassStage testId="teacher-login-card" below={(
      <div className="mt-6 flex justify-center gap-5 text-sm text-white/65">
        <Link to="/" className="hover:text-white">{t('login.back')}</Link>
        <Link to="/admin/login" className="hover:text-white">{t('login.admin')}</Link>
      </div>
    )}>
      <div className="glass-top"><LangToggle className="shrink-0 border" /></div>
      <span className="glass-brand"><LogoMark className="h-9 w-8" /></span>
      <p className="glass-eyebrow mt-4">{t('brand.institute')}</p>
      <h1 className="glass-title">{t('login.title')}</h1>
      {checking ? (
        <div className="glass-checking" role="status" aria-label="Checking this device" data-testid="teacher-checking"><span /><span /><span /></div>
      ) : (
        <div className="glass-rise">
          <button type="button" onClick={google} disabled={busy} className="glass-btn is-plain" data-testid="teacher-google">
            <GoogleMark />
            {busy ? t('login.opening') : t('login.google')}
          </button>
          {error && <p role="alert" className="glass-error">{err(error)}</p>}
          <ul className="glass-list" data-testid="login-rules">
            {rules.map(({ Icon, text }) => (
              <li key={text}><Icon className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" /> {text}</li>
            ))}
            <li className="is-note"><ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" /> {t('lock.rule')}</li>
          </ul>
          <ul className="glass-feats">
            {features.map(({ Icon, text }) => (
              <li key={text}><Icon className="h-3.5 w-3.5" aria-hidden="true" /> {text}</li>
            ))}
          </ul>
          <p className="glass-sub" style={{ fontSize: '0.76rem', marginTop: 14 }}>
            {t('login.help')}{' '}
            <a href={EMERGENCY_TEL} className="inline-flex items-center gap-1 font-semibold text-white underline"><Phone className="h-3 w-3" aria-hidden="true" /> {EMERGENCY_PHONE}</a>{' · '}
            <a href={EMERGENCY_WA} target="_blank" rel="noreferrer" className="font-semibold text-white underline">WhatsApp</a>
          </p>
        </div>
      )}
    </GlassStage>
  );
}
