/**
 * Dashboard Editor settings, shared by every Teacher Dashboard page:
 *  - text overrides (English and Bangla) the Executives typed in the portal
 *  - which entry fields are required (shown with a red *)
 * Loaded from the cloud once, refreshed when the tab is focused, and kept in
 * this browser so the page opens with the last known settings.
 */
import { useEffect, useSyncExternalStore } from 'react';
import { getDashConfig } from '../lib/teacherData';

/**
 * Every entry field a teacher fills in. `def` is the built-in default;
 * `locked` fields are always required (the system can't work without them).
 * The keys match the checks in supabase/teacher-dashboard.sql (section 7k).
 */
export const FIELD_GROUPS = [
  {
    key: 'att', label: 'Daily attendance', where: 'Attendance → a student with a class today',
    fields: [
      { key: 'att.status', label: 'Present / Absent', locked: true },
      { key: 'att.lesson', label: 'Today’s lesson', def: true },
    ],
  },
  {
    key: 'rec', label: 'Recovery class', where: 'Attendance → Log recovery class',
    fields: [
      { key: 'rec.student', label: 'Student', locked: true },
      { key: 'rec.date', label: 'Class date', locked: true },
      { key: 'rec.status', label: 'Present / Absent', locked: true },
      { key: 'rec.lesson', label: 'Today’s lesson', def: true },
      { key: 'rec.note', label: 'Which class it makes up for', def: false },
    ],
  },
  {
    key: 'flex', label: 'Flexible student’s class', where: 'Attendance → Log a class',
    fields: [
      { key: 'flex.date', label: 'Class date', locked: true },
      { key: 'flex.lesson', label: 'Today’s lesson', def: true },
      { key: 'flex.note', label: 'Note', def: false },
    ],
  },
  {
    key: 'report', label: 'Monthly progress report', where: 'Monthly Report',
    fields: [
      { key: 'report.student', label: 'Student, month and year', locked: true },
      { key: 'report.total', label: 'Total classes', def: true },
      { key: 'report.present', label: 'Present', def: true },
      { key: 'report.reason', label: 'Reason for absences (when absent)', def: false },
      { key: 'report.level', label: 'Current status (level)', def: true },
      { key: 'report.notes', label: 'Status notes', def: false },
      { key: 'report.taught', label: 'What was taught this month', def: false },
      { key: 'report.lesson', label: 'Current lesson', def: false },
      { key: 'report.target', label: 'Next month’s target', def: false },
      { key: 'report.remarks', label: 'Teacher’s remarks', def: true },
    ],
  },
  {
    key: 'stu', label: 'Add / edit a student', where: 'My Students → Add student or ✎',
    fields: [
      { key: 'stu.name', label: 'Student name', locked: true },
      { key: 'stu.phone', label: 'WhatsApp number', def: false },
      { key: 'stu.course', label: 'Course', def: false },
      { key: 'stu.classTime', label: 'Class time note (fixed schedule)', def: false },
    ],
  },
  {
    key: 'sup', label: 'Support request', where: 'Support → New request',
    fields: [
      { key: 'sup.message', label: 'Message', locked: true },
      { key: 'sup.subject', label: 'Subject', def: true },
      { key: 'sup.leaveFrom', label: 'Leave: first day', locked: true },
      { key: 'sup.leaveTo', label: 'Leave: last day', def: false },
    ],
  },
];
const DEFAULTS = Object.fromEntries(FIELD_GROUPS.flatMap((g) => g.fields.map((f) => [f.key, f])));

const CACHE = 'qit:dash-config';
const EMPTY = { text: { en: {}, bn: {} }, required: {} };
const listeners = new Set();
let state = (() => {
  try {
    return { ...EMPTY, ...JSON.parse(localStorage.getItem(CACHE) || '{}') };
  } catch {
    return EMPTY;
  }
})();
let loadedAt = 0;
let pending = null;

function publish(config) {
  state = { text: { en: {}, bn: {}, ...(config?.text || {}) }, required: { ...(config?.required || {}) } };
  try {
    localStorage.setItem(CACHE, JSON.stringify(state));
  } catch {
    /* the settings still apply for this visit */
  }
  listeners.forEach((fn) => fn());
}

/** Fetch the latest settings (at most once every 30 seconds unless forced). */
export function loadDashConfig(force = false) {
  if (pending) return pending;
  if (!force && Date.now() - loadedAt < 30000) return Promise.resolve(state);
  pending = getDashConfig()
    .then((row) => {
      loadedAt = Date.now();
      publish(row?.config);
      return state;
    })
    .catch(() => state) // offline or not set up yet: keep the built-in texts
    .finally(() => {
      pending = null;
    });
  return pending;
}

/** Use after saving in the Dashboard Editor so this browser updates at once. */
export const applyDashConfig = (config) => {
  loadedAt = Date.now();
  publish(config);
};

const subscribe = (fn) => {
  listeners.add(fn);
  return () => listeners.delete(fn);
};
export const getDashState = () => state;

let watching = false;
function watch() {
  if (watching || typeof window === 'undefined') return;
  watching = true;
  loadDashConfig();
  const again = () => document.visibilityState === 'visible' && loadDashConfig();
  window.addEventListener('focus', again);
  document.addEventListener('visibilitychange', again);
}

export function useDashConfig() {
  const cfg = useSyncExternalStore(subscribe, getDashState, getDashState);
  useEffect(watch, []);
  return cfg;
}

/** isRequired('report.remarks') → true/false, following the Executives' choice. */
export function requiredIn(cfg, key) {
  const f = DEFAULTS[key];
  if (f?.locked) return true;
  const v = cfg?.required?.[key];
  return typeof v === 'boolean' ? v : Boolean(f?.def);
}
export function useRequired() {
  const cfg = useDashConfig();
  return (key) => requiredIn(cfg, key);
}
