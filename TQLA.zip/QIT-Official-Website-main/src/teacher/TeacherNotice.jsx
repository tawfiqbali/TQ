import { Link } from 'react-router-dom';
import { signOut } from '../lib/auth';
import LogoMark from '../components/shared/LogoMark';
import { useT, useTeacherDocument } from './i18n';
import { EMERGENCY_TEL, EMERGENCY_WA, EMERGENCY_PHONE } from '../lib/teacherData';
import { UnlockForm } from './TeacherUnlock';

// Full-page messages for the teacher area (admin account, errors)
export default function TeacherNotice({ kind, email, role, message, onRetry, access }) {
  const { t, err } = useT();
  useTeacherDocument(t('brand.dashboard'));
  const out = async () => {
    await signOut({ full: true });
    window.location.assign('/teacher/login');
  };
  return (
    <main className="flex min-h-screen items-center justify-center bg-paper px-4 py-12">
      <div className="w-full max-w-md rounded-3xl bg-surface p-8 text-center shadow-2xl" role={kind === 'error' ? 'alert' : undefined}>
        <LogoMark className="mx-auto h-12 w-12" />
        {kind === 'pending' ? (
          <>
            <h1 className="mt-5 text-xl text-heading">{access?.claimTeacherId ? t('notice.pendingTitle') : t('notice.newTitle')}</h1>
            <p className="mt-3 text-sm leading-relaxed text-ink/70">{access?.claimTeacherId
              ? t('notice.pendingBody', { name: access?.claimName || access?.fullName || '' })
              : t('notice.newBody', { name: access?.fullName || '' })}</p>
            <p className="mt-2 text-xs text-ink/70">{access?.email}</p>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <button type="button" className="btn-primary" onClick={onRetry}>{t('notice.pendingCheck')}</button>
              <button type="button" className="btn-ghost" onClick={out}>{t('brand.signOut')}</button>
            </div>
            <div className="mt-6 border-t border-ink/10 pt-5 text-left">
              <p className="mb-3 text-sm font-semibold text-heading">{t('lock.pendingId')}</p>
              <UnlockForm compact onDone={onRetry} />
            </div>
            <p className="mt-5 text-xs text-ink/70">
              {t('notice.pendingHelp')}{' '}
              <a className="font-semibold text-brand underline" href={EMERGENCY_TEL}>{EMERGENCY_PHONE}</a> ·{' '}
              <a className="font-semibold text-brand underline" href={EMERGENCY_WA} target="_blank" rel="noreferrer">WhatsApp</a>
            </p>
          </>
        ) : kind === 'admin' ? (
          <>
            <h1 className="mt-5 text-xl text-heading">{t('notice.adminTitle')}</h1>
            <p className="mt-3 text-sm leading-relaxed text-ink/70">{t('notice.adminBody', { email, role: role === 'super' ? t('notice.exec') : t('notice.junior') })}</p>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <Link to={role === 'super' ? '/admin' : '/admin/portal'} className="btn-primary">{t('notice.openAdmin')}</Link>
              <button type="button" className="btn-ghost" onClick={out}>{t('brand.signOut')}</button>
            </div>
          </>
        ) : (
          <>
            <h1 className="mt-5 text-xl text-heading">{t('notice.errTitle')}</h1>
            <p className="mt-3 text-sm leading-relaxed text-ink/70">{message ? err(message) : t('notice.tryAgain')}</p>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              {onRetry && <button type="button" className="btn-primary" onClick={onRetry}>{t('notice.retry')}</button>}
              <button type="button" className="btn-ghost" onClick={out}>{t('brand.signOut')}</button>
            </div>
          </>
        )}
      </div>
    </main>
  );
}
