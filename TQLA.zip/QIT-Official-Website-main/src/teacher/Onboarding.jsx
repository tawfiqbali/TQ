import { useState } from 'react';
import { BadgeCheck, LogOut } from 'lucide-react';
import { useTeacher } from './TeacherContext';
import { clearAccessCache, saveTeacherId, signOut } from '../lib/auth';
import LoginCard from './LoginCard';
import { UnlockForm } from './TeacherUnlock';
import { completeProfile } from '../lib/teacherData';
import LogoMark from '../components/shared/LogoMark';
import { useT, useTeacherDocument } from './i18n';
import { LangToggle } from './ui';

const digitsOf = (s) => String(s || '').replace(/[০-৯]/g, (c) => '০১২৩৪৫৬৭৮৯'.indexOf(c)).replace(/\D/g, '');

/**
 * First sign-in: the teacher must give their full name and WhatsApp number.
 * The database then issues their official Teacher ID (their existing one if
 * the office already put this Gmail on their record). The dashboard stays
 * closed until this is done (TeacherGate).
 */
export default function Onboarding() {
  const { access, refreshAccess } = useTeacher();
  const { t, err } = useT();
  useTeacherDocument(t('ob.title'));
  const [name, setName] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [touched, setTouched] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(null);

  const nameOk = name.trim().length >= 2;
  const waDigits = digitsOf(whatsapp);
  const waOk = waDigits.length >= 10 && waDigits.length <= 15;

  const submit = async (e) => {
    e.preventDefault();
    setTouched(true);
    if (!nameOk || !waOk || busy) return;
    setBusy(true);
    setError('');
    try {
      const result = await completeProfile(name.trim(), whatsapp.trim());
      if (result?.teacherId && !result.pending) saveTeacherId(result.teacherId);
      setDone(result);
    } catch (e2) {
      setError(e2.message);
    } finally {
      setBusy(false);
    }
  };

  // The gate then sends them on to the page they came for (?next=…)
  const open = async () => {
    clearAccessCache();
    await refreshAccess();
  };

  const out = async () => {
    await signOut({ full: true });
    window.location.assign('/teacher/login');
  };

  return (
    <main className="dot-grid flex min-h-screen items-center justify-center bg-pine-950 px-4 py-12">
      <div className="w-full max-w-md rounded-3xl bg-white p-8 shadow-2xl">
        <div className="flex items-start justify-between">
          <LogoMark className="h-12 w-10" />
          {!done && <LangToggle className="border border-pine-950/15 text-pine-900 hover:bg-pine-50" />}
        </div>
        {done?.pending ? (
          <div className="text-center">
            <BadgeCheck className="mx-auto mt-4 h-14 w-14 text-gold-500" aria-hidden="true" />
            <h1 className="mt-3 text-2xl text-pine-950">{done.newTeacher ? t('notice.newTitle') : t('notice.pendingTitle')}</h1>
            <p className="mt-3 text-sm leading-relaxed text-pine-950/70">{done.newTeacher
              ? t('notice.newBody', { name: done.fullName })
              : t('notice.pendingBody', { name: done.claimName || done.fullName })}</p>
            <button type="button" className="btn-primary mt-6 w-full py-3" onClick={open}>{t('notice.pendingCheck')}</button>
            <div className="mt-6 border-t border-pine-950/10 pt-5 text-left">
              <p className="mb-3 text-sm font-semibold text-pine-950">{t('lock.pendingId')}</p>
              <UnlockForm compact onDone={open} />
            </div>
          </div>
        ) : done ? (
          <div className="text-center">
            <BadgeCheck className="mx-auto mt-4 h-14 w-14 text-pine-700" aria-hidden="true" />
            <h1 className="mt-3 text-2xl text-pine-950">{t('ob.welcome', { name: done.fullName })}</h1>
            <p className="mt-2 text-sm text-pine-950/70">{t('ob.idIs')}</p>
            <p className="mt-2 inline-block rounded-2xl bg-pine-950 px-6 py-3 font-display text-3xl tracking-wider text-gold-300" lang="en" aria-label={`${t('brand.id')} ${done.teacherId}`}>{done.teacherId}</p>
            <p className="mt-4 text-sm leading-relaxed text-pine-950/70">{done.linked ? t('ob.linked') : t('ob.fresh')}</p>
            <LoginCard className="mt-5" />
            <button type="button" className="btn-primary mt-6 w-full py-3" onClick={open}>{t('ob.open')}</button>
          </div>
        ) : (
          <>
            <h1 className="mt-5 text-2xl text-pine-950">{t('ob.title')}</h1>
            <p className="mt-1.5 text-sm leading-relaxed text-pine-950/70">{t('ob.intro')}</p>
            <details className="mt-5 rounded-2xl border border-pine-950/15 bg-pine-50/60 px-4 py-3" data-testid="ob-have-id">
              <summary className="cursor-pointer text-sm font-semibold text-pine-950">{t('lock.haveId')}</summary>
              <p className="mt-2 text-xs leading-relaxed text-pine-950/70">{t('lock.haveIdBody')}</p>
              <div className="mt-3"><UnlockForm compact onDone={open} /></div>
            </details>
            <p className="mt-5 text-sm font-semibold text-pine-950">{t('lock.newTeacher')}</p>
            <form onSubmit={submit} className="mt-3 space-y-4" noValidate>
              <div>
                <label className="label" htmlFor="ob-email">{t('ob.gmail')}</label>
                <input id="ob-email" className="input opacity-70" value={access?.email || ''} readOnly />
              </div>
              <div>
                <label className="label" htmlFor="ob-name">{t('ob.name')} <span className="text-red-700">*</span></label>
                <input id="ob-name" className="input" autoComplete="name" placeholder={t('ob.namePh')} value={name} onChange={(e) => setName(e.target.value)} aria-invalid={touched && !nameOk} aria-describedby="ob-name-err" required />
                {touched && !nameOk && <p id="ob-name-err" className="mt-1 text-xs text-red-700">{t('ob.nameErr')}</p>}
              </div>
              <div>
                <label className="label" htmlFor="ob-wa">{t('ob.wa')} <span className="text-red-700">*</span></label>
                <input id="ob-wa" className="input" type="tel" inputMode="tel" autoComplete="tel" placeholder="+880 1XXX-XXXXXX" value={whatsapp} onChange={(e) => setWhatsapp(e.target.value)} aria-invalid={touched && !waOk} aria-describedby="ob-wa-hint" required />
                <p id="ob-wa-hint" className={`mt-1 text-xs ${touched && !waOk ? 'text-red-700' : 'text-pine-950/55'}`}>{touched && !waOk ? t('ob.waErr') : t('ob.waHint')}</p>
              </div>
              {error && <p role="alert" className="rounded-xl bg-red-50 px-3.5 py-2.5 text-sm text-red-800">{err(error)}</p>}
              <button type="submit" className="btn-primary w-full py-3" disabled={busy}>{busy ? t('ob.busy') : t('ob.submit')}</button>
            </form>
            <button type="button" onClick={out} className="mx-auto mt-5 flex items-center gap-1.5 text-xs text-pine-950/55 hover:text-pine-950">
              <LogOut className="h-3.5 w-3.5" /> {t('ob.notYou')}
            </button>
          </>
        )}
      </div>
    </main>
  );
}
