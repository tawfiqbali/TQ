import { useEffect, useState } from 'react';
import { BadgeCheck, Eye, EyeOff, LockKeyhole, ShieldCheck, UserRound } from 'lucide-react';
import { getFirstLogin, getSavedTeacherId, signOut, unlockTeacher } from '../lib/auth';
import LogoMark from '../components/shared/LogoMark';
import { useT, useTeacherDocument } from './i18n';
import { LangToggle } from './ui';
import { GlassCode, GlassStage, glassPause } from '../components/ui/GlassAuth';

const errorText = (t, r) => {
  if (!r) return '';
  if (r.error === 'wrong') return r.left > 0 ? t('lock.e_wrong', { left: r.left }) : t('lock.e_wrong0');
  if (r.error === 'too_many') return t('lock.e_too_many', { m: r.minutes || 15 });
  const key = `lock.e_${r.error}`;
  const s = t(key);
  return s === key ? r.error : s;
};

/**
 * Teacher ID + password form. The Google account is already signed in; the
 * database checks that this Gmail belongs to the Teacher ID (teacher_unlock).
 */
export function UnlockForm({ onDone, compact = false, submitLabel, lockedId, glass = false, onVerified }) {
  const { t } = useT();
  // lockedId: the Teacher ID this Gmail is locked to (filled in, only the password is asked)
  const [id, setId] = useState(lockedId || getSavedTeacherId);
  const [pw, setPw] = useState('');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [phase, setPhase] = useState('idle'); // glass look: idle | error | success
  // the entrance motion plays once when the panel appears (not again while typing)
  const [arriving, setArriving] = useState(true);
  useEffect(() => {
    const tm = setTimeout(() => setArriving(false), 2000);
    return () => clearTimeout(tm);
  }, []);

  const submit = async (e) => {
    e.preventDefault();
    if (busy) return;
    if (!id.trim()) return setError(t('lock.e_id_required'));
    if (!pw) return setError(t('login.pwErr'));
    setBusy(true);
    setError('');
    try {
      const r = await unlockTeacher({ teacherId: id, password: pw });
      if (r.ok) {
        if (glass) {
          // the boxes fold into a tick before the dashboard opens
          setPhase('success');
          onVerified?.();
          await glassPause();
        }
        setPw('');
        await onDone?.(r);
        return;
      }
      setError(errorText(t, r));
      setPhase('error');
    } catch (e2) {
      setError(e2.message);
      setPhase('error');
    }
    setBusy(false);
  };

  if (glass) {
    return (
      <form onSubmit={submit} noValidate data-testid="unlock-form" className={arriving ? 'glass-reveal' : ''}>
        {lockedId ? (
          <p className="glass-chip">{t('login.id')} <b lang="en" data-testid="locked-id">{lockedId}</b></p>
        ) : (
          <>
            <label htmlFor="ul-id" className="glass-label">{t('login.id')}</label>
            <input id="ul-id" className="glass-input uppercase" autoComplete="username" autoCapitalize="characters" spellCheck={false} placeholder={t('login.idPh')}
              value={id} onChange={(e) => setId(e.target.value)} data-testid="unlock-id" />
          </>
        )}
        <GlassCode value={pw} onChange={(x) => { setPw(x); if (phase === 'error') setPhase('idle'); }} show={show} state={phase} id="ul-pw" testId="unlock-pw"
          autoFocus={Boolean(lockedId)} inputMode="numeric" ariaLabel={t('login.pw')} />
        {phase !== 'success' && (
          <button type="button" className="glass-link" style={{ marginTop: 12, fontSize: '0.78rem' }} onClick={() => setShow((v) => !v)} aria-pressed={show}>
            {show ? <EyeOff className="mr-1 inline h-3.5 w-3.5" aria-hidden="true" /> : <Eye className="mr-1 inline h-3.5 w-3.5" aria-hidden="true" />}
            {show ? t('login.hide') : t('login.show')}
          </button>
        )}
        {error && phase !== 'success' && <p role="alert" className="glass-error" data-testid="unlock-error">{error}</p>}
        {phase !== 'success' && (
          <button type="submit" disabled={busy} className="glass-btn" data-testid="unlock-submit">
            <LockKeyhole className="h-4 w-4" aria-hidden="true" />
            {busy ? t('lock.busy') : submitLabel || t('lock.submit')}
          </button>
        )}
      </form>
    );
  }

  return (
    <form onSubmit={submit} noValidate className={compact ? 'space-y-3' : 'space-y-4'} data-testid="unlock-form">
      {lockedId ? (
        <div className="flex items-center gap-3 rounded-2xl border border-gray-200 bg-[#034751]/[0.04] px-4 py-3">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#034751] text-white"><UserRound className="h-5 w-5" aria-hidden="true" /></span>
          <div className="min-w-0">
            <p className="text-xs font-semibold text-gray-600">{t('login.id')}</p>
            <p className="font-display text-xl tracking-wider text-[#034751]" lang="en" data-testid="locked-id">{lockedId}</p>
          </div>
        </div>
      ) : (
      <div>
        <label htmlFor="ul-id" className="label text-gray-900 dark:text-ink">{t('login.id')}</label>
        <input
          id="ul-id"
          className="input font-semibold uppercase tracking-wide placeholder:normal-case placeholder:tracking-normal"
          autoComplete="username"
          autoCapitalize="characters"
          spellCheck={false}
          placeholder={t('login.idPh')}
          value={id}
          onChange={(e) => setId(e.target.value)}
          data-testid="unlock-id"
        />
      </div>
      )}
      <div>
        <label htmlFor="ul-pw" className="label text-gray-900 dark:text-ink">{t('login.pw')}</label>
        <div className="relative">
          <input
            id="ul-pw"
            type={show ? 'text' : 'password'}
            inputMode="numeric"
            autoComplete="current-password"
            autoFocus={Boolean(lockedId)}
            className="input pr-11"
            value={pw}
            onChange={(e) => setPw(e.target.value)}
            data-testid="unlock-pw"
          />
          <button type="button" onClick={() => setShow((v) => !v)} aria-label={show ? t('login.hide') : t('login.show')} aria-pressed={show}
            className="absolute inset-y-0 right-0 flex w-11 items-center justify-center text-[#005359] hover:text-[#034751]">
            {show ? <EyeOff className="h-4 w-4" aria-hidden="true" /> : <Eye className="h-4 w-4" aria-hidden="true" />}
          </button>
        </div>
      </div>
      {error && <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-3.5 py-2.5 text-sm text-red-800" data-testid="unlock-error">{error}</p>}
      <button type="submit" disabled={busy}
        className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#034751] px-4 py-3 text-sm font-semibold text-white shadow-md transition hover:bg-[#005359] disabled:opacity-60"
        data-testid="unlock-submit">
        <LockKeyhole className="h-4 w-4" aria-hidden="true" />
        {busy ? t('lock.busy') : submitLabel || t('lock.submit')}
      </button>
    </form>
  );
}

/** Full page: signed in with Google, this device still needs Teacher ID + password. */
export default function TeacherUnlock({ access, kicked, onDone }) {
  const { t, date } = useT();
  useTeacherDocument(t('lock.title'));
  const [ok, setOk] = useState(false);
  const other = async () => {
    await signOut({ full: true });
    window.location.assign('/teacher/login');
  };
  return (
    <GlassStage success={ok} testId="unlock-page" below={!ok && (
      <p className="mt-5 flex items-start justify-center gap-2 px-3 text-center text-xs leading-relaxed text-white/60">
        <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" /> {t('lock.rule')}
      </p>
    )}>
      <div className="glass-top"><LangToggle className="shrink-0 border" /></div>
      <span className="glass-brand"><LogoMark className="h-9 w-8" /></span>
      <p className="glass-eyebrow mt-4">{t('brand.institute')}</p>
      <h1 className="glass-title" aria-live="polite">{ok ? t('lock.welcome') : t('lock.title')}</h1>
      {ok ? <p className="glass-sub">{t('lock.opening')}</p> : (
        <>
          {kicked && <p role="status" className="glass-note" data-testid="kicked">{t('lock.kicked')}</p>}
          {access?.off ? <p className="glass-error">{t('lock.off')}</p> : (
            <>
              <p className="glass-sub">{t('lock.intro', { email: access?.email || '' })}</p>
              {access?.elsewhere && !kicked && (
                <p className="glass-note" data-testid="elsewhere">
                  {t('lock.elsewhere', { device: [access.device, access.since && date(access.since, { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' })].filter(Boolean).join(', ') || '—' })}
                </p>
              )}
            </>
          )}
        </>
      )}
      {!access?.off && <UnlockForm glass onDone={onDone} onVerified={() => setOk(true)} lockedId={access?.teacherId} />}
      {!ok && <button type="button" onClick={other} className="glass-link">{t('lock.otherGmail')}</button>}
    </GlassStage>
  );
}

/**
 * The office approved this teacher (or linked them to their record): their
 * Teacher ID and password are shown first, then the dashboard opens. Seen at
 * once if they were waiting on this screen, or the next time they come back.
 */
export function FirstSignIn({ access, onDone }) {
  const { t } = useT();
  useTeacherDocument(t('first.title'));
  const [info, setInfo] = useState(null);
  const [show, setShow] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => {
    let alive = true;
    getFirstLogin().then((d) => alive && setInfo(d || {})).catch(() => alive && setInfo({}));
    return () => {
      alive = false;
    };
  }, []);
  const id = info?.teacherId || access?.teacherId || '';
  const open = async () => {
    setBusy(true);
    setError('');
    try {
      const r = await unlockTeacher();
      if (r.ok) return void (await onDone?.(r));
      setError(t('lock.e_session'));
    } catch (e) {
      setError(e.message);
    }
    setBusy(false);
  };
  return (
    <main className="dot-grid flex min-h-screen items-center justify-center bg-pine-950 px-4 py-12">
      <div className="w-full max-w-md rounded-3xl border border-gray-200 bg-white p-6 text-center shadow-2xl sm:p-8" data-testid="first-signin">
        <div className="flex items-start justify-between">
          <LogoMark className="h-12 w-10" />
          <LangToggle className="shrink-0 border border-gray-300 text-[#034751] hover:bg-teal-50" />
        </div>
        <BadgeCheck className="mx-auto mt-2 h-14 w-14 text-[#0a7a55]" aria-hidden="true" />
        <h1 className="mt-3 text-2xl text-[#034751]">{t('first.title')}</h1>
        <p className="mt-2 text-sm leading-relaxed text-gray-700">{t('first.body', { name: info?.fullName || access?.fullName || '' })}</p>
        <dl className="mt-5 grid grid-cols-2 gap-3 text-left" lang="en">
          <div className="rounded-2xl border-2 border-[#034751] bg-[#034751]/[0.05] px-4 py-3">
            <dt className="text-xs font-semibold text-gray-600">{t('login.id')}</dt>
            <dd className="font-display text-2xl tracking-wider text-[#034751]" data-testid="first-id">{id || '…'}</dd>
          </div>
          <div className="rounded-2xl border-2 border-[#034751] bg-[#034751]/[0.05] px-4 py-3">
            <dt className="text-xs font-semibold text-gray-600">{t('login.pw')}</dt>
            {info === null ? <dd className="text-2xl text-[#034751]">…</dd> : info.password ? (
              <dd className="flex items-center justify-between gap-2">
                <span className="font-display text-2xl tracking-wider text-[#034751]" data-testid="first-pw">{show ? info.password : '••••••'}</span>
                <button type="button" onClick={() => setShow((v) => !v)} aria-label={show ? t('login.hide') : t('login.show')} aria-pressed={show} className="text-[#005359]">
                  {show ? <EyeOff className="h-4 w-4" aria-hidden="true" /> : <Eye className="h-4 w-4" aria-hidden="true" />}
                </button>
              </dd>
            ) : <dd className="text-xs leading-snug text-gray-700">{t('card.custom')}</dd>}
          </div>
        </dl>
        <p className="mt-3 text-xs leading-relaxed text-gray-600">{t('first.keep')}</p>
        {error && <p role="alert" className="mt-3 rounded-xl border border-red-200 bg-red-50 px-3.5 py-2.5 text-sm text-red-800">{error}</p>}
        <button type="button" onClick={open} disabled={busy} data-testid="first-open"
          className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-[#034751] px-4 py-3 text-sm font-semibold text-white shadow-md transition hover:bg-[#005359] disabled:opacity-60">
          {busy ? t('lock.opening') : t('ob.open')}
        </button>
      </div>
    </main>
  );
}
