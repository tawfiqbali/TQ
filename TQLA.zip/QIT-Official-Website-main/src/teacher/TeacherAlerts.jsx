import { useCallback, useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell, BellOff, BellRing, Smartphone, X } from 'lucide-react';
import { useT } from './i18n';
import { alertText } from '../lib/alertText';
import { listTeacherAlerts, markAlertsRead, removePushSubscription, savePushSubscription, watchTeacherAlerts } from '../lib/teacherData';

/**
 * v179: notifications for teachers.
 * - the bell in the header lists what the office did (report reviewed or sent
 *   back, salary paid, student added / moved / on hold, request answered,
 *   points, recovery class, ID / password change, office notices)
 * - "Turn on phone notifications" lets the same alerts reach the phone, also
 *   when the dashboard is closed (iPhone: from the Home Screen app).
 */

/* ---------------- phone notifications (Web Push) ---------------- */
const isIos = () => /iPhone|iPad|iPod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
const standalone = () => window.matchMedia?.('(display-mode: standalone)').matches || window.navigator.standalone === true;
const device = () => {
  const ua = navigator.userAgent;
  const kind = /iPhone/i.test(ua) ? 'iPhone' : /iPad/i.test(ua) ? 'iPad' : /Android/i.test(ua) ? 'Android' : /Windows/i.test(ua) ? 'Windows' : /Mac/i.test(ua) ? 'Mac' : 'Device';
  const browser = /EdgA?\//.test(ua) ? 'Edge' : /SamsungBrowser/.test(ua) ? 'Samsung Internet' : /Firefox|FxiOS/.test(ua) ? 'Firefox' : /CriOS|Chrome/.test(ua) ? 'Chrome' : /Safari/.test(ua) ? 'Safari' : '';
  return `${kind}${browser ? ` · ${browser}` : ''}${standalone() ? ' · app' : ''}`;
};
function keyBytes(base64) {
  const pad = '='.repeat((4 - (base64.length % 4)) % 4);
  const raw = atob((base64 + pad).replace(/-/g, '+').replace(/_/g, '/'));
  return Uint8Array.from(raw, (c) => c.charCodeAt(0));
}
const supported = () => typeof window !== 'undefined' && 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
async function swReg() {
  const reg = (await navigator.serviceWorker.getRegistration('/')) || (await navigator.serviceWorker.register('/sw.js', { scope: '/' }));
  await navigator.serviceWorker.ready;
  return reg;
}

/** state: 'checking' | 'on' | 'off' | 'ios-home' | 'denied' | 'unsupported' | 'busy' */
export function usePhonePush(teacherId, enabled = true) {
  const { lang } = useT();
  const [state, setState] = useState('checking');
  const [error, setError] = useState('');
  const subRef = useRef(null);

  const check = useCallback(async () => {
    if (!enabled) return setState('unsupported');
    if (isIos() && !standalone()) return setState('ios-home');
    if (!supported()) return setState('unsupported');
    if (Notification.permission === 'denied') return setState('denied');
    try {
      const reg = await navigator.serviceWorker.getRegistration('/');
      const sub = reg ? await reg.pushManager.getSubscription() : null;
      subRef.current = sub;
      setState(sub && Notification.permission === 'granted' ? 'on' : 'off');
    } catch {
      setState('off');
    }
  }, [enabled]);
  useEffect(() => { check(); }, [check]);

  // keep this phone linked to the teacher (and its language) in the database
  useEffect(() => {
    if (state !== 'on' || !subRef.current || !teacherId) return;
    savePushSubscription({ ...subRef.current.toJSON(), qitLang: lang }, device()).catch(() => null);
  }, [state, lang, teacherId]);

  const turnOn = async () => {
    setError('');
    if (isIos() && !standalone()) { setState('ios-home'); return; }
    if (!supported()) { setState('unsupported'); return; }
    setState('busy');
    try {
      // ask first, straight from the tap (browsers require that)
      const perm = await Notification.requestPermission();
      if (perm !== 'granted') { setState(perm === 'denied' ? 'denied' : 'off'); return; }
      const reg = await swReg();
      const r = await fetch('/.netlify/functions/push', { cache: 'no-store' });
      const cfg = r.ok ? await r.json() : null;
      if (!cfg?.publicKey) { setError('notReady'); setState('off'); return; }
      let sub = await reg.pushManager.getSubscription();
      if (sub && sub.options?.applicationServerKey) {
        const have = new Uint8Array(sub.options.applicationServerKey);
        const want = keyBytes(cfg.publicKey);
        if (have.length !== want.length || have.some((b, i) => b !== want[i])) { await sub.unsubscribe(); sub = null; }
      }
      if (!sub) sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: keyBytes(cfg.publicKey) });
      await savePushSubscription({ ...sub.toJSON(), qitLang: lang }, device());
      subRef.current = sub;
      setState('on');
    } catch {
      setError('failed');
      setState('off');
    }
  };
  const turnOff = async () => {
    setState('busy');
    try {
      const sub = subRef.current || (await (await navigator.serviceWorker.getRegistration('/'))?.pushManager.getSubscription());
      if (sub) {
        await removePushSubscription(sub.endpoint).catch(() => null);
        await sub.unsubscribe().catch(() => null);
      }
      subRef.current = null;
    } finally {
      setState('off');
    }
  };
  return { state, error, turnOn, turnOff };
}

/* ---------------- the list in the dashboard ---------------- */
export function useTeacherAlerts(teacherId) {
  const [list, setList] = useState([]);
  const load = useCallback(async () => {
    if (!teacherId) return;
    try { setList((await listTeacherAlerts(teacherId)) || []); } catch { /* not set up yet / offline */ }
  }, [teacherId]);
  useEffect(() => {
    load();
    let stop = null;
    if (teacherId) watchTeacherAlerts(teacherId, load).then((f) => { stop = f; }).catch(() => null);
    const vis = () => document.visibilityState === 'visible' && load();
    const fromSw = (e) => e.data?.type === 'qit-alert' && load();
    document.addEventListener('visibilitychange', vis);
    window.addEventListener('online', load);
    navigator.serviceWorker?.addEventListener?.('message', fromSw);
    const id = setInterval(load, 120000);
    return () => {
      stop?.();
      clearInterval(id);
      document.removeEventListener('visibilitychange', vis);
      window.removeEventListener('online', load);
      navigator.serviceWorker?.removeEventListener?.('message', fromSw);
    };
  }, [teacherId, load]);
  const unread = list.filter((a) => !a.read_at).length;
  const markRead = useCallback(async () => {
    setList((l) => l.map((a) => (a.read_at ? a : { ...a, read_at: new Date().toISOString() })));
    try { await markAlertsRead(teacherId); } catch { /* next time */ }
  }, [teacherId]);
  return { list, unread, load, markRead };
}

function PhoneBox({ push, compact }) {
  const { t } = useT();
  const { state, error } = push;
  return (
    <div className={`t-alert-phone ${state === 'on' ? 'is-on' : ''}`} data-testid="push-box" data-state={state}>
      <div className="flex items-start gap-2.5">
        <Smartphone className="mt-0.5 h-5 w-5 shrink-0" aria-hidden="true" />
        <div className="min-w-0 flex-1">
          <p className="text-sm font-bold text-heading">{state === 'on' ? t('alerts.on') : t('alerts.phoneTitle')}</p>
          {!compact && state !== 'on' && <p className="mt-0.5 text-xs text-ink/75">{t('alerts.phoneWhy')}</p>}
          {state === 'ios-home' && <p className="mt-1.5 text-xs font-semibold text-ink/85" data-testid="push-ios">{t('alerts.iosHome')}</p>}
          {state === 'denied' && <p className="mt-1.5 text-xs font-semibold text-red-700">{t('alerts.denied')}</p>}
          {state === 'unsupported' && <p className="mt-1.5 text-xs font-semibold text-ink/85">{t('alerts.unsupported')}</p>}
          {error && <p className="mt-1.5 text-xs font-semibold text-red-700" role="alert">{t(`alerts.${error}`)}</p>}
        </div>
      </div>
      {(state === 'off' || state === 'busy' || state === 'checking') && (
        <button type="button" className="t-alert-on" onClick={push.turnOn} disabled={state !== 'off'} data-testid="push-on">
          <BellRing className="h-4 w-4" aria-hidden="true" /> {state === 'busy' ? t('alerts.turningOn') : t('alerts.turnOn')}
        </button>
      )}
      {state === 'on' && (
        <button type="button" className="t-alert-off" onClick={push.turnOff} data-testid="push-off">
          <BellOff className="h-3.5 w-3.5" aria-hidden="true" /> {t('alerts.turnOff')}
        </button>
      )}
    </div>
  );
}

/** The bell in the header + its pop-up list */
export function AlertsBell({ teacherId, base, adminMode }) {
  const { t, lang, date } = useT();
  const navigate = useNavigate();
  const { list, unread, markRead } = useTeacherAlerts(teacherId);
  const push = usePhonePush(teacherId, !adminMode);
  const [open, setOpen] = useState(false);
  const [full, setFull] = useState(null);

  // a tapped phone notification for an office notice opens the list
  useEffect(() => {
    const qs = new URLSearchParams(window.location.search);
    if (qs.get('alerts') === '1') {
      setOpen(true);
      qs.delete('alerts');
      const rest = qs.toString();
      window.history.replaceState(null, '', window.location.pathname + (rest ? `?${rest}` : ''));
    }
  }, []);
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open]);
  // opening the list marks everything as seen (not when the office is looking)
  useEffect(() => {
    if (open && unread && !adminMode) markRead();
  }, [open, unread, adminMode, markRead]);

  const go = (a) => {
    if (a.kind === 'message') { setFull(full === a.id ? null : a.id); return; }
    const url = String(a.url || '/teacher').replace(/^\/teacher(?=\/|\?|$)/, base).replace(/[?&]alerts=1/, '');
    setOpen(false);
    navigate(url);
  };

  return (
    <>
      <button type="button" className="t-head-btn t-bell" onClick={() => setOpen(true)} aria-label={t('alerts.title')} title={t('alerts.title')} data-testid="alerts-bell">
        <Bell className="h-4 w-4" />
        {unread > 0 && <span className="t-bell-dot" data-testid="alerts-unread">{lang === 'bn' ? String(Math.min(unread, 99)).replace(/[0-9]/g, (d) => '০১২৩৪৫৬৭৮৯'[d]) : Math.min(unread, 99)}</span>}
      </button>
      {open && (
        <div className="t-alerts-veil" onMouseDown={(e) => e.target === e.currentTarget && setOpen(false)}>
          <section className="t-alerts qit-pop-in" role="dialog" aria-modal="true" aria-labelledby="t-alerts-title" data-testid="alerts-panel">
            <div className="t-alerts-head">
              <h2 id="t-alerts-title" className="text-base font-extrabold text-heading">{t('alerts.title')}</h2>
              <button type="button" className="rounded p-1 text-ink/60 hover:text-ink" onClick={() => setOpen(false)} aria-label={t('alerts.close')}><X className="h-5 w-5" /></button>
            </div>
            {!adminMode && <PhoneBox push={push} />}
            <ul className="t-alerts-list">
              {list.map((a) => {
                const x = alertText(a, lang);
                return (
                  <li key={a.id}>
                    <button type="button" className={`t-alert-row k-${a.kind} ${a.read_at ? '' : 'is-new'}`} onClick={() => go(a)} data-testid={`alert-${a.id}`}>
                      <span className="t-alert-title">{x.title}</span>
                      {x.body && <span className={`t-alert-body ${full === a.id ? 'is-full' : ''}`}>{x.body}</span>}
                      <span className="t-alert-time">{date(a.created_at, { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' })}</span>
                    </button>
                  </li>
                );
              })}
              {!list.length && <li className="px-2 py-6 text-center text-sm text-ink/70">{t('alerts.empty')}</li>}
            </ul>
          </section>
        </div>
      )}
    </>
  );
}

/** A small card on the dashboard until phone notifications are on (or "Later") */
const LATER = 'qit:push-later';
export function PushInvite({ teacherId }) {
  const { t } = useT();
  const push = usePhonePush(teacherId, true);
  const [later, setLater] = useState(() => { try { return Number(localStorage.getItem(LATER) || 0) > Date.now(); } catch { return false; } });
  if (later || ['on', 'checking', 'unsupported', 'denied'].includes(push.state)) return null;
  const snooze = () => {
    try { localStorage.setItem(LATER, String(Date.now() + 7 * 864e5)); } catch { /* fine */ }
    setLater(true);
  };
  return (
    <div className="t-push-invite mb-4" data-testid="push-invite">
      <PhoneBox push={push} compact={false} />
      <button type="button" className="t-alert-later" onClick={snooze}>{t('alerts.later')}</button>
    </div>
  );
}
