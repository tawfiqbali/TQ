import { memo, useEffect, useState } from 'react';
import { Eye, EyeOff, KeyRound } from 'lucide-react';
import { myLoginInfo } from '../lib/teacherData';
import { useT } from './i18n';

/**
 * The teacher's Teacher ID + password for next time. Shown after the first
 * Google sign-in, and on the dashboard until they tap "Got it".
 * The password is only shown while it is still the automatic one
 * v156: the password in use is always shown to the teacher (their own dashboard).
 */
function LoginCard({ onDismiss, className = '' }) {
  const { t } = useT();
  const [info, setInfo] = useState(null);
  const [show, setShow] = useState(true); // v156: always shown (the teacher's own dashboard)
  useEffect(() => {
    let alive = true;
    myLoginInfo().then((i) => alive && setInfo(i || null)).catch(() => alive && setInfo(null));
    return () => {
      alive = false;
    };
  }, []);
  if (!info?.teacherId) return null;
  return (
    <section aria-labelledby="login-card-title" className={`rounded-2xl border border-[#005359]/30 bg-white p-5 text-left shadow-md dark:border-pine-600/60 dark:bg-surface ${className}`}>
      <div className="flex items-start gap-3">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#034751] text-white"><KeyRound className="h-5 w-5" aria-hidden="true" /></span>
        <div className="min-w-0 flex-1">
          <h2 id="login-card-title" className="font-semibold text-[#034751] dark:text-pine-100">{t('card.title')}</h2>
          {!info.active ? (
            <p className="mt-1 text-sm text-gray-700 dark:text-ink/80">{t('card.off')}</p>
          ) : (
            <>
              <p className="mt-1 text-sm text-gray-700 dark:text-ink/80">{t('card.body')}</p>
              <dl className="mt-3 grid grid-cols-2 gap-2 text-sm" lang="en">
                <div className="rounded-xl border border-gray-200 bg-gray-50 px-3 py-2 dark:border-white/10 dark:bg-white/5">
                  <dt className="text-xs font-semibold text-gray-600 dark:text-ink/70">{t('brand.id')}</dt>
                  <dd className="font-display text-lg tracking-wider text-[#034751] dark:text-pine-100" data-testid="card-id">{info.teacherId}</dd>
                </div>
                <div className="rounded-xl border border-gray-200 bg-gray-50 px-3 py-2 dark:border-white/10 dark:bg-white/5">
                  <dt className="text-xs font-semibold text-gray-600 dark:text-ink/70">{t('card.pw')}</dt>
                  {info.password ? (
                    <dd className="flex items-center justify-between gap-2">
                      <span className="font-display text-lg tracking-wider text-[#034751] dark:text-pine-100" data-testid="card-pw">{show ? info.password : '••••'}</span>
                      <button type="button" onClick={() => setShow((v) => !v)} aria-label={show ? t('card.hide') : t('card.show')} aria-pressed={show} className="text-[#005359] dark:text-pine-200">
                        {show ? <EyeOff className="h-4 w-4" aria-hidden="true" /> : <Eye className="h-4 w-4" aria-hidden="true" />}
                      </button>
                    </dd>
                  ) : (
                    <dd className="text-xs text-gray-700 dark:text-ink/75">{t('card.custom')}</dd>
                  )}
                </div>
              </dl>
              <p className="mt-2 text-xs text-gray-600 dark:text-ink/70">{t('card.keep')}</p>
            </>
          )}
        </div>
      </div>
      {onDismiss && (
        <div className="mt-3 text-right">
          <button type="button" onClick={onDismiss} className="rounded-lg px-3 py-1.5 text-sm font-semibold text-[#005359] hover:bg-teal-50 dark:text-pine-200 dark:hover:bg-white/10">{t('card.ok')}</button>
        </div>
      )}
    </section>
  );
}
export default memo(LoginCard);
