import { useCallback, useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import { CalendarCheck, CalendarDays, CheckCircle2, ClipboardList, LifeBuoy, Menu, X } from 'lucide-react';
import { listMyInquiries } from '../lib/teacherData';
import { useT } from './i18n';

// v154: phones — a bottom bar with the main pages; ☰ opens every page
export function TeacherDock({ base, menuOpen, onMenu, badge = 0 }) {
  const { t } = useT();
  const items = [
    ['/attendance', 'attendance', CalendarCheck],
    ['/schedule', 'schedule', CalendarDays],
    ['/report', 'reportShort', ClipboardList],
    ['/support', 'support', LifeBuoy],
  ];
  return (
    <nav className="t-dock print:hidden" aria-label={t('brand.dashboard')} data-testid="t-dock">
      {items.map(([path, key, Icon]) => (
        <NavLink key={path} to={base + path} className={({ isActive }) => `t-dock-btn ${isActive && !menuOpen ? 'active' : ''}`}>
          <span className="relative"><Icon className="h-5 w-5" aria-hidden="true" />{path === '/support' && badge > 0 && <i className="t-dock-badge">{badge}</i>}</span>
          <span>{t(`dock.${key}`)}</span>
        </NavLink>
      ))}
      <button type="button" className={`t-dock-btn ${menuOpen ? 'active' : ''}`} aria-expanded={menuOpen} onClick={onMenu} data-testid="t-dock-menu">
        <Menu className="h-5 w-5" aria-hidden="true" /><span>{t('dock.menu')}</span>
      </button>
    </nav>
  );
}

// Answers from the office: a resolved request shows here until the teacher presses OK
const SEEN_KEY = 'qit:seen-inquiries';
const readSeen = () => { try { return JSON.parse(localStorage.getItem(SEEN_KEY) || '[]'); } catch { return []; } };
const tag = (i) => `${i.id}|${i.updated_at}`;

export function useResolvedNotices(teacherId, enabled) {
  const [list, setList] = useState([]);
  const load = useCallback(() => {
    if (!enabled || !teacherId) return;
    listMyInquiries(teacherId)
      .then((rows) => {
        const seen = new Set(readSeen());
        setList((rows || []).filter((i) => i.status === 'resolved' && !seen.has(tag(i))));
      })
      .catch(() => {});
  }, [teacherId, enabled]);
  useEffect(() => {
    load();
    const id = setInterval(load, 60000);
    const vis = () => document.visibilityState === 'visible' && load();
    document.addEventListener('visibilitychange', vis);
    window.addEventListener('online', load);
    return () => { clearInterval(id); document.removeEventListener('visibilitychange', vis); window.removeEventListener('online', load); };
  }, [load]);
  const dismiss = (i) => {
    try { localStorage.setItem(SEEN_KEY, JSON.stringify([...readSeen(), tag(i)].slice(-300))); } catch { /* shown again next time */ }
    setList((l) => l.filter((x) => x.id !== i.id));
  };
  return { list, dismiss };
}

export function ResolvedNotices({ list, onDismiss }) {
  const { t } = useT();
  if (!list.length) return null;
  return (
    <div className="mb-4 space-y-2" data-testid="resolved-notices">
      {list.slice(0, 3).map((i) => (
        <div key={i.id} className="t-resolved" role="status">
          <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0" aria-hidden="true" />
          <div className="min-w-0 flex-1">
            <p className="font-bold">{t('notice.resolved', { subject: i.subject })}</p>
            {i.admin_reply && <p className="mt-1 whitespace-pre-wrap text-sm">{i.admin_reply}</p>}
          </div>
          <button type="button" className="t-resolved-ok" onClick={() => onDismiss(i)} aria-label={t('notice.ok')}>
            <X className="h-4 w-4" aria-hidden="true" /> {t('notice.ok')}
          </button>
        </div>
      ))}
    </div>
  );
}
