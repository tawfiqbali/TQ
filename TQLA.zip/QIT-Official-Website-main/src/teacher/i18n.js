/**
 * Teacher Dashboard language: বাংলা (default) or English.
 * The choice is saved in this browser ('qit:teacher-lang') and shared by every
 * teacher page, including sign-in and onboarding. Bangla uses the website's
 * Bangla fonts (Noto Sans Bengali for text, Noto Serif Bengali for headings).
 */
import { useEffect, useSyncExternalStore } from 'react';
import { MONTHS, WEEKDAYS } from '../lib/teacherData';
import { getDashState, useDashConfig } from './dashConfig';

const KEY = 'qit:teacher-lang';
const listeners = new Set();
function read() {
  try {
    const v = localStorage.getItem(KEY);
    return v === 'en' || v === 'bn' ? v : 'bn';
  } catch {
    return 'bn';
  }
}
let current = read();
export function setTeacherLang(lang) {
  current = lang === 'en' ? 'en' : 'bn';
  try {
    localStorage.setItem(KEY, current);
  } catch {
    /* still applies for this visit */
  }
  listeners.forEach((fn) => fn());
}
const subscribe = (fn) => {
  listeners.add(fn);
  return () => listeners.delete(fn);
};

const BN_DIGITS = '০১২৩৪৫৬৭৮৯';
const BN_MONTHS = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
const BN_WEEKDAYS = ['রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার'];
const BN_WEEKDAYS_SHORT = ['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র', 'শনি'];

/* ------------------------------------------------------------------ */
export const EN = {
  common: { required: 'This field is required.', optional: 'optional' },
  brand: { dashboard: 'Teacher Dashboard', institute: 'Quran International Institute', id: 'Teacher ID', signOut: 'Sign out', switchTo: 'বাংলা', switchLabel: 'বাংলায় দেখুন', light: 'Light mode', dark: 'Dark mode' },
  menu: { label: 'Menu', classes: 'My classes', reports: 'Reports & progress', money: 'Salary & support' },
  creds: { id: 'Teacher ID', pw: 'Password', newPwTitle: 'Your password has changed', newPwBody: 'From now on, sign in with this password. (Your old password worked one last time.)', newIdTitle: 'Your Teacher ID has changed', newIdBody: 'Your old ID {old} worked one last time. From now on, sign in with this ID and password.', keep: 'They are always shown at the top of your dashboard.', ok: 'OK, I have noted it' },
  dock: { attendance: 'Attendance', schedule: 'Schedule', reportShort: 'Reports', support: 'Support', menu: 'Menu' },
  notice: { resolved: 'The office resolved your request: “{subject}”', ok: 'OK' },
  alerts: { title: 'Notifications', close: 'Close', empty: 'No notifications yet.', phoneTitle: 'Get notifications on this phone', phoneWhy: 'Office notices, report reviews, salary, new or moved students and answers to your requests — straight to your phone, even when the dashboard is closed.', turnOn: 'Turn on phone notifications', turningOn: 'Turning on…', turnOff: 'Turn off on this phone', on: 'This phone gets notifications ✓', iosHome: 'iPhone: tap the Share button → “Add to Home Screen”, open QIT from your Home Screen, sign in, then tap “Turn on phone notifications” there.', denied: 'Notifications are blocked for this website. Allow them in your phone or browser settings (Site settings → Notifications), then try again.', unsupported: 'This browser cannot show notifications. On Android use Chrome; on iPhone use the Home Screen app.', notReady: 'Phone notifications are not ready on the website yet. Please tell the QIT office.', failed: 'Could not turn on notifications. Please try again.', later: 'Later' },
  nav: { students: 'My Students', attendance: 'Attendance', schedule: 'Schedule', report: 'Monthly Report', progress: 'My Progress', history: 'Student History', salary: 'Salary', support: 'Support' },
  emg: { button: 'Emergency', title: 'Emergency office contact', body: 'For urgent problems during classes, call or WhatsApp the QIT office.', call: 'Call', close: 'Close' },
  admin: { banner: 'Admin mode — viewing {name} ({id}). Every change here is saved to this teacher’s dashboard.', back: 'Back to portal' },
  stu: {
    statusDate: 'From which date?', medium: 'Class division', bangla: 'Bangla Medium', english: 'English Medium', assignDate: 'First class date (optional)', sameTitle: 'This student is already in the list', sameText: 'A student with this WhatsApp number and this same name is already studying at QIT. Brothers and sisters need different names — check the name. If it is the same student taking a second class with you, tick below.', sameOk: 'Same student, 2 different classes', delete: 'Delete this student', deleteHint: 'The office confirms the delete. Until then the student moves to your Delete list.', deleteReason: 'Reason (optional)', deleteSend: 'Send delete request', deleteSent: 'Sent to the office. The student is in your Delete list until it is confirmed.', delList: 'Delete list (waiting for the office)', delCancel: 'Keep student', delWaiting: 'Waiting for the office', recPending: 'Needs office approval', recRejected: 'Not approved', recPendingHint: 'A recovery class for an earlier month is counted after the office approves it.',
    edit: 'Edit', editFor: 'Edit {name}', editTitle: 'Edit student', editSub: 'Changes are saved for the QIT office too.', name: 'Student name', phones: 'WhatsApp number(s)',
    addPhone: 'Add another number', removePhone: 'Remove this number', course: 'Course', coursePh: 'e.g. Quran & Tajweed', schedule: 'Class schedule',
    fixed: 'Fixed', flexible: 'Flexible', fixedHint: 'Same days and times every week — set them below.',
    flexHint: 'No fixed days. Log each class when it happens; the monthly total is the classes you log.',
    classTime: 'Class time note', classTimePh: 'e.g. 5:00 PM, or “evenings”', weekly: 'Weekly class times', save: 'Save changes', saving: 'Saving…',
    saved: 'Student details saved.', status: 'Status', statusActive: 'Active', statusActiveHint: 'Taking classes. Shown in My Students, Attendance and Reports.', statusOffHint: 'Moves to Student history. No attendance or reports until you make them Active again.', movedToHistory: 'Saved. The student is now in Student history.', toFlexQ: 'Switch to a flexible schedule?', toFlexMsg: '{name}’s weekly class times will be removed. You will log each class when it happens.',
    toFlexYes: 'Switch to flexible', cancel: 'Cancel', close: 'Close', nameErr: 'Please enter the student’s full name.',
    add: 'Add student', addTitle: 'Add a new student', addSub: 'Enter the student’s name, WhatsApp number, course and class time. The student joins the QIT student list right away.',
    added: 'Student added. The office can see them now.', addSchedHint: 'After adding, set weekly class times with the ✎ button on the student’s card.', adding: 'Adding…', addBtn: 'Add student',
  },
  att: {
    title: 'Daily attendance', sub: 'Mark each student Present or Absent and write today’s lesson. Once submitted, an entry is locked — only the QIT office can change it.',
    lesson: 'Today’s lesson', lessonPh: 'What did you teach? e.g. Surah Al-Mulk 1–5, Tajweed: Ikhfa', lessonFor: 'Today’s lesson for {name}',
    submit: 'Submit', submitting: 'Submitting…', completed: 'Completed', lockedNote: 'Locked · only the QIT office can change this entry.',
    submittedAt: 'Submitted {time}', editedByOffice: 'Corrected by the QIT office', needStatus: 'Choose Present or Absent.', needLesson: 'Write today’s lesson.', needReason: 'Write the reason for the absence.', reasonLabel: 'Reason for absence',
    lockHint: 'Once submitted, this entry can’t be changed.', notMarked: 'Not marked', outOfRange: 'This day can no longer be filled in.',
    submitAll: 'Submit all ready ({n})', confirmTitle: 'Submit attendance?', confirmOne: '{name}: {status}. After submitting you can’t change or delete it.',
    confirmMany: '{n} students. After submitting you can’t change or delete these entries.', confirmBtn: 'Submit', submitted: 'Attendance submitted ({n}).',
    recovery: 'Recovery class', recoveryShort: 'Recovery', logRecovery: 'Log recovery class', recTitle: 'Log a recovery class',
    recSub: 'For a missed or rescheduled class. It counts toward total classes conducted and can be logged on any day (up to 3 per student per day).',
    recStudent: 'Student', recChoose: 'Choose a student', recDate: 'Class date', recStatus: 'Attendance', recFor: 'Which class does it make up for? (optional)',
    recForPh: 'e.g. Missed class on 12 September', recSave: 'Submit recovery class', recSaved: 'Recovery class logged.',
    recConfirm: 'Recovery class for {name} on {date}. After submitting you can’t change or delete it.', recThatDay: 'Recovery class', close: 'Close', cancel: 'Cancel',
    conducted: 'Classes conducted', conductedHint: '{p} regular + {r} recovery', recoveryCount: 'Recovery classes', presentHint: 'attendance {pct}',
    adminEditHint: 'Executives: change or delete entries in Management Portal → Attendance log.',
    flexTitle: 'Flexible students', flexSub: 'No fixed days. Tap “Log a class” each time you teach them — their monthly total is the classes you log.',
    flexCount: '{n} class(es) in {month}', logClass: 'Log a class', flexDialog: 'Log a completed class', flexFor: '{name} · flexible schedule',
    flexDone: 'Class logged.', flexConfirm: 'Class with {name} on {date}. After submitting you can’t change or delete it.',
    flexLogged: 'Classes logged in {month}', flexNone: 'No classes logged yet this month.', flexExtra: 'A class is already logged on this day, so this one is saved as an extra class.',
    fixedTitle: 'Fixed-schedule students', flexNote: 'Note (optional)',
    noneBody: 'Attendance can be marked once the office assigns students to you.', present: 'Present', absent: 'Absent',
    classAt: 'class at {time}', noClassToday: 'no class scheduled', noneThisDay: 'No student has a class on this day.', noTimesSet: '{n} student(s) have no class times yet — add them in Schedule to see them here.', statusFor: 'Attendance for {name}', reasonPh: 'e.g. sick, travelling, no internet',
    reasonFor: 'Reason {name} was absent', rate: 'Attendance · {month}', daysMarked: 'Days marked', prevDay: 'Previous day', nextDay: 'Next day',
    day: 'Day', today: 'Today', allPresent: 'Mark everyone present', classesThatDay: '{n} student(s) have class this day',
    unsaved: '{n} unsaved change(s)', save: 'Save attendance', saved: 'Attendance saved ({n}).', calendarHint: 'Green = everyone present · amber = someone absent · gold dot = recovery class. You can fill in the last 31 days.',
    fromDaily: 'From your daily attendance: {p} present, {a} absent, {r} recovery class(es). Total = regular classes + recovery classes.',
    autoFilled: 'Filled in from your daily attendance. You can still change it.', differs: 'Your daily attendance says {p} present of {t} classes.', use: 'Use attendance numbers',
    flexTotal: 'Flexible schedule: total = the {n} class(es) you logged this month. There is no fixed target, so no missed classes.',
    baseline: 'Progress reports start from September 2026.',
  },
  pg: {
    title: 'My progress', sub: 'Your attendance, points and level. Every marked class and on-time report earns points.',
    hardworkingLevel: 'Hardworking level', level: 'Level', totalPoints: '{n} points earned in total', rankOf: 'of {n} teachers this month', streak: 'class days in a row',
    topLevel: 'Top level reached', toNext: 'Progress to the next level', pointsToNext: '{n} more points to reach “{level}”',
    attRate: 'Student attendance', attHint: '{p} present · {a} absent', conducted: 'Classes conducted', conductedHint: '{p} regular + {r} recovery', logRate: 'Classes marked', logHint: 'of scheduled classes so far', reports: 'Monthly reports',
    monthPoints: 'Points this month', rank: 'Rank', breakdown: 'How you earned your points', total: 'Total',
    pt: { present: 'Students present', daysLogged: 'Days attendance was marked', reports: 'Monthly reports sent', onTime: 'On-time report bonus', reviewed: 'Reports reviewed by the office', perfectAttendance: 'Students with full attendance', studentLevels: 'Students’ study levels', adjustments: 'Office bonus / adjustment' },
    rulesHint: 'Each present mark earns {present}, each monthly report {report}, and {bonus} extra when it is sent by day {day} of the next month.',
    history: 'Points over the last six months', rewards: 'Rewards', noRewards: 'No rewards set yet.', inspire: 'Keep going',
    msgStreak: 'Mashallah! {n} class days in a row with attendance marked.', msgAttendance: 'Excellent attendance this month. Your students are showing up!',
    msgReports: 'Every monthly report is in. Jazakallahu khairan!', msgTop: 'You are the top teacher this month!', msgStart: 'Mark today’s attendance and send your reports on time to climb to the next level.',
    hadith: '“The best of you are those who learn the Quran and teach it.”', hadithSource: 'Sahih al-Bukhari 5027',
  },
  pdf: { download: 'Download PDF', title: 'Teacher monthly summary', students: 'Students', report: 'Monthly report', points: 'Points', popup: 'Allow pop-ups for this site to download the PDF.', note: 'In the print window choose “Save as PDF” as the printer.' },
  login: {
    gone: 'Teacher ID {id} is no longer active on this device. Sign in with Google or another Teacher ID, or contact the QIT office.',
    f1: 'Your students and class schedule', f2: 'Monthly progress reports in minutes', f3: 'Salary history — Paid, Pending, Unpaid', f4: 'Support and leave requests to the office',
    title: 'Teacher sign-in', back: 'Back to the website', admin: 'Admin sign-in',
    google: 'Continue with Google', opening: 'Opening Google…',
    hint: 'First time? Sign in with your Gmail. If the office has your Gmail you get your own Teacher ID; if you are new, you get a new one.',
    rule1: 'First time: sign in with your Gmail.', rule2: 'After that: your Teacher ID is filled in — just enter your password.', rule3: 'You can use several devices, always with this same Gmail.',
    orId: 'Already have your Teacher ID and password?', useId: 'Sign in with Teacher ID',
    id: 'Teacher ID', idPh: 'e.g. QIT-077', idErr: 'Enter your Teacher ID (for example QIT-077).', pw: 'Password', pwErr: 'Enter your password.',
    show: 'Show password', hide: 'Hide password', submit: 'Sign in', busy: 'Signing in…',
    welcomeBack: 'Welcome back', savedAs: 'Signing in as', notYou: 'Not you? Use another account', useGoogle: 'Sign in with Google instead',
    pwHint: 'The QIT office gives you your password (it is also shown after a Google sign-in). Forgot it? Contact the office.',
    help: 'Problems signing in? Contact the QIT office.',
  },
  card: {
    title: 'Your Teacher ID sign-in', body: 'After you sign out, this device asks only for this password (your Teacher ID is filled in). On a new phone, sign in with this same Gmail first.',
    pw: 'Password', custom: 'The office has set your password. Ask them if you have forgotten it.', off: 'Teacher ID sign-in is switched off. Contact the QIT office.',
    keep: 'Keep your password private. You cannot change it; the office can reset it.', ok: 'Got it', show: 'Show password', hide: 'Hide password',
  },
  hist: {
    title: 'Student history', sub: 'Students on hold or inactive. They are not in My Students, Attendance or Reports until you make them Active again.', makeActive: 'Make active', madeActive: '{name} is active again and back in My Students.',
    hold: 'On hold', inactive: 'Inactive', none: 'No students on hold or inactive.', since: 'Since {date}', joined: 'Joined {date}',
    allTime: 'All-time students taught', active: 'Active students', holdN: 'On hold', inactiveN: 'Inactive', allHint: 'Everyone you have taught, including students now with another teacher',
    ask: 'To bring a student back, press Make active. To put a student on hold, open My Students, press Edit and choose the status.',
  },
  lock: {
    title: 'Welcome back', intro: 'Your Gmail {email} is linked to this Teacher ID. Enter your password to open your dashboard.',
    rule: 'For your safety, your Teacher ID works only with your own Gmail (the one you first signed in with), on any of your devices.',
    elsewhere: 'Your dashboard is open on another device ({device}). Continuing here signs that device out.',
    kicked: 'The office signed this device out, or your password was changed. Enter your password again.',
    off: 'Sign-in for your Teacher ID is switched off. Contact the QIT office.',
    submit: 'Open my dashboard', busy: 'Checking…', otherGmail: 'Use another Gmail', welcome: 'Welcome back', opening: 'Opening your dashboard…',
    e_wrong: 'That Teacher ID or password is not correct. {left} tries left.', e_wrong0: 'That Teacher ID or password is not correct.',
    e_too_many: 'Too many wrong tries. Please wait {m} minutes, or contact the QIT office.',
    e_not_your_id: 'This Gmail is linked to a different Teacher ID. Enter your own Teacher ID.',
    e_gmail_mismatch: 'This Teacher ID is locked to a different Gmail. Sign in with the Gmail you used before, or ask the QIT office to change it.',
    e_id_off: 'Sign-in for this Teacher ID is switched off. Contact the QIT office.',
    e_id_required: 'Enter your Teacher ID.', e_google_required: 'Please sign in with Google first.', e_session: 'Please sign out and sign in again.',
    e_admin_account: 'This Gmail is an admin account, not a teacher account.',
    haveId: 'Already a QIT teacher?', haveIdBody: 'Enter your Teacher ID and password to link this Gmail to your record.', newTeacher: 'New teacher? Fill in your details below.',
    pendingId: 'Have your Teacher ID and password? Link now instead of waiting:',
  },
  first: {
    title: 'You are approved', body: 'Welcome, {name}. The QIT office has given you your Teacher ID and password. Note them down, then open your dashboard.',
    keep: 'After you sign out, this phone asks only for this password. Keep it private.',
  },
  ob: {
    title: 'Complete your profile', intro: 'One last step. The QIT office uses these details to give you your official Teacher ID.',
    gmail: 'Gmail', name: 'Full name', namePh: 'e.g. Hafez Abdur Rahman', nameErr: 'Please enter your full name.',
    wa: 'WhatsApp number', waHint: 'The number the office contacts you on.', waErr: 'Enter your full WhatsApp number (10–15 digits), with the country code if outside Bangladesh.',
    submit: 'Continue', busy: 'Sending…', notYou: 'Not you? Sign out',
    welcome: 'Welcome, {name}', idIs: 'Your official Teacher ID is', linked: 'Your account is connected to your QIT teacher record.',
    fresh: 'Keep this ID for your records. The office will connect your students to it.', open: 'Open my dashboard',
  },
  notice: {
    adminTitle: 'This is an admin account', adminBody: '{email} is signed in as {role}. The Teacher Dashboard is only for teachers.',
    exec: 'an Executive', junior: 'a Junior Admin', openAdmin: 'Open the admin panel', errTitle: 'Something went wrong', tryAgain: 'Please try again.', retry: 'Try again',
    pendingTitle: 'Waiting for the office to confirm', pendingBody: 'Your name matches “{name}” in our teacher records. To keep every teacher’s information safe, the QIT office will confirm it is you. You will then see your students and salary here.', pendingCheck: 'Check again', pendingHelp: 'Need it sooner? Contact the office.',
    newTitle: 'Waiting for the office', newBody: 'Thank you, {name}. The QIT office will check your details and give you your Teacher ID and password. Then your dashboard opens here.',
  },
  loading: { dashboard: 'Opening your dashboard', students: 'Loading your students', generic: 'Loading…' },
  home: {
    hello: 'Assalamu alaikum, {name}', sub: 'Teacher ID {id}{dept} — your assigned students and class times.',
    students: 'Students', perWeek: 'Classes per week', fromSchedule: 'from your schedule', addUnder: 'add them under Schedule',
    reports: '{month} reports', toSend: '{n} still to send', allSent: 'all sent — thank you', needs: 'Needs changes', fixTitle: 'Reports sent back by the office ({n}) — please correct and send again', fixOpen: 'Correct now', sentBack: 'reports sent back by the office',
    due: 'Reports still due for {month} {year}: {n}.', dueSalary: 'Your salary is calculated from these reports.', write: 'Write reports',
    search: 'Search students', noneTitle: 'No students assigned yet',
    noneBody: 'When the QIT office assigns students to your Teacher ID ({id}), they appear here. If you already teach at QIT, send a message from Support so the office can connect your account.',
    whatsapp: 'WhatsApp', classes: 'Classes', notSet: 'Not set yet', officeNote: 'Office note: {note}', schedule: 'Schedule',
    writeReport: 'Write report', editReport: 'Edit report', reportDue: '{month} report due',
    reportLbl: '{month} report', notSent: 'Not sent yet', filter: 'Show students', fAll: 'All', fDue: 'Report due', fSent: 'Report sent', noMatch: 'No students match.',
  },
  sch: {
    title: 'Class schedule', sub: 'Classes a week: {classes} · students: {students} · Bangladesh time', noneBody: 'Your weekly timetable appears here once the office assigns students to you.',
    editTitle: 'Edit class time', another: 'Add a different time', removeSet: 'Remove this time', deleteAll: 'Delete schedule', deleteQ: 'Delete the whole weekly schedule?', deleteMsg: 'All weekly class times of {name} will be removed.', saveTimes: 'Save class times', savedTimes: 'Class times saved.', deleted: 'Schedule deleted.', applyHint: 'Press Save changes to apply.', unsaved: 'Not saved yet', pickTime: 'Choose class time', needAmPm: 'Choose AM or PM', hour: 'Hour', minute: 'Minute', done: 'Done', today: 'Today', noClasses: 'No classes', manage: 'Manage class times', manageSub: 'Choose a student, then add, change or remove their weekly classes.', student: 'Student',
    empty: 'No class times yet', officeNote: ' (office note: {note})', add: 'Add class time', note: 'Note (optional)', notePh: 'Note (optional), e.g. on Zoom',
    addBtn: 'Add', adding: 'Adding…', bdTime: 'Times are Bangladesh time.', minutes: '{n} minutes', min: '{n} min', pickDay: 'Pick at least one day and a start time.',
    clash: '{day} at {time} is already in the schedule.', removeQ: 'Remove the {day} {time} class?', cancel: 'Cancel', save: 'Save', day: 'Day', start: 'Start time',
    length: 'Class length', edit: 'Edit {day} class', remove: 'Remove {day} class', days: 'Days', removeYes: 'Remove class', removed: 'Class removed.', saved: 'Class time saved.', added: 'Class time added.',
  },
  rp: {
    classStart: 'Classes started on (if this month)', startHint: 'Leave empty when the student studied the whole month.', startFull: 'Started in the first 3 days: full month.', startDays: 'Counted as {n} days of the month.', startOther: 'Not in this month: full month.',
    title: 'Monthly progress report', sub: '{done} of {total} sent for {month} {year}. Your salary is calculated from these reports.',
    noneBody: 'Reports can be written once the office assigns students to you.', sentNew: '{name}’s {month} report was sent to the office. Jazakallahu khairan!',
    sentUpd: '{name}’s {month} report was updated. Jazakallahu khairan!', next: 'Next: {name}', allDone: 'All reports sent — back to students',
    student: 'Student', month: 'Month', year: 'Year', choose: 'Select a student…', chooseTitle: 'Choose a student to start', chooseBody: 'Their details and last report are filled in automatically.',
    locked: 'The office has reviewed this report, so it can no longer be changed.', askedChanges: 'The office asked for changes: {note}', alreadySent: 'Already sent on {date} — you can still correct it.',
    s1: '1. Attendance', total: 'Total classes', totalHint: 'Classes scheduled this month.', totalFromSch: 'Your schedule has {n} classes in {month}.',
    present: 'Present', absent: 'Absent', absentHint: 'Worked out for you', attendance: '{pct}% attendance', reason: 'Reason for absence', reasonHint: 'e.g. illness, travel, exams, internet problem',
    s2: '2. Current status', notes: 'Notes on progress', notesHint: 'Optional: tajweed, fluency, memorisation, behaviour…',
    s3: '3. Lesson progress', taught: 'Taught this month', taughtHint: 'e.g. Qaida pages 10–15, Surah Al-Fatiha memorised', lesson: 'Current lesson', lessonHint: 'Where the student is now, e.g. Surah Al-Mulk, ayah 1–15',
    s4: '4. Next targets & remarks', target: 'Next targets / homework', targetHint: 'What the student should reach next month', lastTarget: 'Last target: {t}',
    remarks: 'Remarks', remarksHint: 'Your message for the guardian and the office (required).',
    eTotal: 'How many classes were scheduled this month?', eRange: 'Enter a number from 0 to 62.', ePresent: 'How many classes did the student attend?', eWhole: 'Enter a whole number.',
    eMore: 'Cannot be more than the total classes.', eLevel: 'Choose the student’s current level.', eRemarks: 'Remarks are required.', fix: 'Please fill in the fields marked in red.',
    submit: 'Submit report', update: 'Update report', sending: 'Sending…', level: 'Current level',
    bg: 'Student background', bgEmpty: 'Choose a student to see their details here.', sid: 'Student ID', course: 'Course', status: 'Status', times: 'Class times',
    notSet: 'Not set', last: 'Last report', firstReport: 'No earlier report — this is the first one.', lessonThen: 'Lesson then', targetSet: 'Target set', lvl: 'Level',
  },
  sal: {
    title: 'Salary', sub: 'Your salary history, month by month. Salaries are paid at the start of the following month.',
    monthly: 'Monthly salary', lastMonth: '{month} salary', paidInMonth: 'paid in {month}', withExtra: 'includes {extra} extra responsibility', extraLine: 'incl. {extra} extra ({what})', fixed: 'Fixed salary', perStudent: 'Based on your students', paidIn: 'Paid in {year}', pending: 'Pending', processing: 'being processed',
    unpaid: 'Unpaid', contact: 'contact the office via Support', nothing: 'nothing overdue', noneTitle: 'No salary history yet', noneBody: 'Your first month appears here once it ends.',
    month: 'Month', salary: 'Salary', paid: 'Paid', paidOn: 'Paid on', status: 'Status', caption: 'Salary by month',
    legend: 'Paid = fully paid · Pending = last month (being processed) or part-paid · Unpaid = an older month with no payment yet. Each month shows that month’s salary as the office works it out (new, moved or paused students, extra responsibilities); it is paid the following month. Questions? Use Support → Salary.',
  },
  sup: {
    title: 'Support & requests', sub: 'Ask the QIT office a question, report a problem or request leave. Replies appear here.',
    new: 'New request', type: 'Type', general: 'General question', issue: 'Problem / issue', leave: 'Leave request', salary: 'Salary', other: 'Other',
    first: 'First day', last: 'Last day', subject: 'Subject', subjectPhLeave: 'e.g. Leave for family event', subjectPh: 'e.g. Zoom link not working',
    message: 'Message', messagePhLeave: 'Reason, and how the missed classes will be covered', messagePh: 'Tell us what you need',
    eSubject: 'Add a short subject (at least 3 letters).', eMessage: 'Write your message.', eFirst: 'Choose the first day of leave.', eLast: 'The last day must be on or after the first day.',
    sentOk: 'Sent to the office. You’ll see their reply below.', send: 'Send to QIT office', sending: 'Sending…', yours: 'Your requests',
    noneTitle: 'No requests yet', noneBody: 'Anything you send appears here with the office’s reply.', reply: 'Office reply',
  },
  badge: { Paid: 'Paid', Pending: 'Pending', Unpaid: 'Unpaid', submitted: 'Submitted', reviewed: 'Reviewed', needs_changes: 'Needs changes', open: 'Open', in_progress: 'In progress', resolved: 'Resolved', missing: 'Not submitted' },
  cb: { failed: 'Sign-in didn’t work', teacher: 'Teacher sign-in', admin: 'Admin sign-in', signing: 'Signing you in',
    noAdmin: '{email} does not have admin access. Only Gmails added by an Executive can sign in here.',
    google: 'Please sign in with the “Continue with Google” button.' },
};

export const BN = {
  common: { required: 'এই ঘরটি পূরণ করা আবশ্যক।', optional: 'ঐচ্ছিক' },
  brand: { dashboard: 'শিক্ষক ড্যাশবোর্ড', institute: 'কুরআন ইন্টারন্যাশনাল ইনস্টিটিউট', id: 'শিক্ষক আইডি', signOut: 'সাইন আউট', switchTo: 'English', switchLabel: 'View in English', light: 'লাইট মোড', dark: 'ডার্ক মোড' },
  menu: { label: 'মেনু', classes: 'আমার ক্লাস', reports: 'রিপোর্ট ও অগ্রগতি', money: 'বেতন ও সহায়তা' },
  creds: { id: 'শিক্ষক আইডি', pw: 'পাসওয়ার্ড', newPwTitle: 'আপনার পাসওয়ার্ড বদলেছে', newPwBody: 'এখন থেকে এই পাসওয়ার্ড দিয়ে সাইন-ইন করুন। (পুরোনো পাসওয়ার্ড শেষবারের মতো কাজ করেছে।)', newIdTitle: 'আপনার শিক্ষক আইডি বদলেছে', newIdBody: 'পুরোনো আইডি {old} শেষবারের মতো কাজ করেছে। এখন থেকে এই আইডি ও পাসওয়ার্ড দিয়ে সাইন-ইন করুন।', keep: 'এগুলো সবসময় আপনার ড্যাশবোর্ডের ওপরে দেখা যাবে।', ok: 'ঠিক আছে, লিখে রেখেছি' },
  dock: { attendance: 'হাজিরা', schedule: 'সময়সূচি', reportShort: 'রিপোর্ট', support: 'সহায়তা', menu: 'মেনু' },
  notice: { resolved: 'অফিস আপনার অনুরোধের সমাধান করেছে: “{subject}”', ok: 'ঠিক আছে' },
  alerts: { title: 'নোটিফিকেশন', close: 'বন্ধ করুন', empty: 'এখনো কোনো নোটিফিকেশন নেই।', phoneTitle: 'এই ফোনে নোটিফিকেশন পান', phoneWhy: 'অফিসের নোটিশ, রিপোর্ট রিভিউ, বেতন, নতুন বা স্থানান্তরিত শিক্ষার্থী ও আপনার অনুরোধের উত্তর — সরাসরি ফোনে, ড্যাশবোর্ড বন্ধ থাকলেও।', turnOn: 'ফোনে নোটিফিকেশন চালু করুন', turningOn: 'চালু হচ্ছে…', turnOff: 'এই ফোনে বন্ধ করুন', on: 'এই ফোনে নোটিফিকেশন আসবে ✓', iosHome: 'iPhone: Share বাটন চাপুন → “Add to Home Screen”, তারপর Home Screen থেকে QIT খুলে সাইন-ইন করে সেখানে “ফোনে নোটিফিকেশন চালু করুন” চাপুন।', denied: 'এই ওয়েবসাইটের নোটিফিকেশন বন্ধ করা আছে। ফোন বা ব্রাউজারের সেটিংস (Site settings → Notifications) থেকে চালু করে আবার চেষ্টা করুন।', unsupported: 'এই ব্রাউজারে নোটিফিকেশন দেখানো যায় না। Android-এ Chrome, iPhone-এ Home Screen অ্যাপ ব্যবহার করুন।', notReady: 'ওয়েবসাইটে ফোন নোটিফিকেশন এখনো চালু হয়নি। QIT অফিসকে জানান।', failed: 'নোটিফিকেশন চালু করা যায়নি। আবার চেষ্টা করুন।', later: 'পরে' },
  nav: { students: 'আমার শিক্ষার্থী', attendance: 'হাজিরা', schedule: 'সময়সূচি', report: 'মাসিক রিপোর্ট', progress: 'আমার অগ্রগতি', history: 'শিক্ষার্থীর ইতিহাস', salary: 'বেতন', support: 'সহায়তা' },
  emg: { button: 'জরুরি যোগাযোগ', title: 'জরুরি অফিস যোগাযোগ', body: 'ক্লাস চলাকালীন জরুরি সমস্যায় QIT অফিসে কল বা হোয়াটসঅ্যাপ করুন।', call: 'কল করুন', close: 'বন্ধ করুন' },
  admin: { banner: 'অ্যাডমিন মোড — {name} ({id})-এর ড্যাশবোর্ড। এখানে করা সব পরিবর্তন এই শিক্ষকের ড্যাশবোর্ডে সংরক্ষিত হবে।', back: 'পোর্টালে ফিরুন' },
  stu: {
    statusDate: 'কোন তারিখ থেকে?', medium: 'ক্লাস বিভাগ', bangla: 'বাংলা মিডিয়াম', english: 'ইংলিশ মিডিয়াম', assignDate: 'প্রথম ক্লাসের তারিখ (ঐচ্ছিক)', sameTitle: 'এই শিক্ষার্থী তালিকায় আগে থেকেই আছে', sameText: 'এই হোয়াটসঅ্যাপ নম্বর ও একই নামের একজন শিক্ষার্থী আগে থেকেই QIT-এ পড়ছে। ভাই-বোনের নাম আলাদা হতে হবে — নামটি দেখে নিন। একই শিক্ষার্থী যদি আপনার কাছে আরেকটি ক্লাস নেয়, নিচে টিক দিন।', sameOk: 'একই শিক্ষার্থী, ২টি আলাদা ক্লাস', delete: 'এই শিক্ষার্থীকে মুছুন', deleteHint: 'অফিস নিশ্চিত করলে মুছে যাবে। ততক্ষণ শিক্ষার্থী আপনার Delete তালিকায় থাকবে।', deleteReason: 'কারণ (ঐচ্ছিক)', deleteSend: 'মুছে ফেলার অনুরোধ পাঠান', deleteSent: 'অফিসে পাঠানো হয়েছে। নিশ্চিত না হওয়া পর্যন্ত শিক্ষার্থী আপনার Delete তালিকায় থাকবে।', delList: 'Delete তালিকা (অফিসের অনুমোদনের অপেক্ষায়)', delCancel: 'শিক্ষার্থী রাখুন', delWaiting: 'অফিসের অপেক্ষায়', recPending: 'অফিসের অনুমোদন লাগবে', recRejected: 'অনুমোদিত হয়নি', recPendingHint: 'আগের মাসের রিকভারি ক্লাস অফিস অনুমোদন দিলে গণনা হবে।',
    edit: 'সম্পাদনা', editFor: '{name} সম্পাদনা', editTitle: 'শিক্ষার্থীর তথ্য সম্পাদনা', editSub: 'পরিবর্তনগুলো QIT অফিসেও সংরক্ষিত হবে।', name: 'শিক্ষার্থীর নাম', phones: 'হোয়াটসঅ্যাপ নম্বর',
    addPhone: 'আরেকটি নম্বর যোগ করুন', removePhone: 'এই নম্বরটি মুছুন', course: 'কোর্স', coursePh: 'যেমন: কুরআন ও তাজবীদ', schedule: 'ক্লাসের সময়সূচি',
    fixed: 'নির্দিষ্ট', flexible: 'সুবিধাজনক', fixedHint: 'প্রতি সপ্তাহে একই দিন ও সময় — নিচে ঠিক করে দিন।',
    flexHint: 'নির্দিষ্ট কোনো দিন নেই। প্রতিটি ক্লাস হওয়ার পর তা যোগ করুন; মাসের মোট ক্লাস = আপনার যোগ করা ক্লাস।',
    classTime: 'ক্লাসের সময়ের নোট', classTimePh: 'যেমন: বিকাল ৫টা, বা “সন্ধ্যায়”', weekly: 'সাপ্তাহিক ক্লাসের সময়', save: 'পরিবর্তন সংরক্ষণ', saving: 'সংরক্ষণ হচ্ছে…',
    saved: 'শিক্ষার্থীর তথ্য সংরক্ষিত হয়েছে।', status: 'অবস্থা', statusActive: 'সক্রিয়', statusActiveHint: 'ক্লাস চলছে। আমার শিক্ষার্থী, হাজিরা ও রিপোর্টে দেখা যাবে।', statusOffHint: 'শিক্ষার্থীর ইতিহাসে চলে যাবে। আবার সক্রিয় না করা পর্যন্ত হাজিরা বা রিপোর্ট নেই।', movedToHistory: 'সংরক্ষিত হয়েছে। শিক্ষার্থী এখন শিক্ষার্থীর ইতিহাসে আছে।', toFlexQ: 'সুবিধাজনক সময়সূচিতে পরিবর্তন করবেন?', toFlexMsg: '{name}-এর সাপ্তাহিক ক্লাসের সময়গুলো মুছে যাবে। প্রতিটি ক্লাস হওয়ার পর তা যোগ করবেন।',
    toFlexYes: 'সুবিধাজনক করুন', cancel: 'বাতিল', close: 'বন্ধ করুন', nameErr: 'শিক্ষার্থীর পূর্ণ নাম লিখুন।',
    add: 'শিক্ষার্থী যোগ করুন', addTitle: 'নতুন শিক্ষার্থী যোগ করুন', addSub: 'শিক্ষার্থীর নাম, হোয়াটসঅ্যাপ নম্বর, কোর্স ও ক্লাসের সময় লিখুন। শিক্ষার্থী সঙ্গে সঙ্গে QIT-এর শিক্ষার্থী তালিকায় যুক্ত হবে।',
    added: 'শিক্ষার্থী যুক্ত হয়েছে। অফিস এখন দেখতে পাচ্ছে।', addSchedHint: 'যোগ করার পর শিক্ষার্থীর কার্ডের ✎ বাটন থেকে সাপ্তাহিক ক্লাসের সময় ঠিক করুন।', adding: 'যোগ হচ্ছে…', addBtn: 'শিক্ষার্থী যোগ করুন',
  },
  att: {
    title: 'দৈনিক হাজিরা', sub: 'প্রত্যেক শিক্ষার্থীর উপস্থিত বা অনুপস্থিত চিহ্নিত করুন এবং আজকের পাঠ লিখুন। জমা দেওয়ার পর তা লক হয়ে যায় — শুধু QIT অফিস পরিবর্তন করতে পারে।',
    lesson: 'আজকের পাঠ', lessonPh: 'আজ কী পড়িয়েছেন? যেমন: সূরা আল-মুলক ১–৫, তাজবীদ: ইখফা', lessonFor: '{name}-এর আজকের পাঠ',
    submit: 'জমা দিন', submitting: 'জমা হচ্ছে…', completed: 'সম্পন্ন', lockedNote: 'লক করা · শুধু QIT অফিস এই এন্ট্রি পরিবর্তন করতে পারে।',
    submittedAt: 'জমা দেওয়া হয়েছে {time}', editedByOffice: 'QIT অফিস সংশোধন করেছে', needStatus: 'উপস্থিত বা অনুপস্থিত বেছে নিন।', needLesson: 'আজকের পাঠ লিখুন।', needReason: 'অনুপস্থিতির কারণ লিখুন।', reasonLabel: 'অনুপস্থিতির কারণ',
    lockHint: 'জমা দেওয়ার পর এই এন্ট্রি আর পরিবর্তন করা যাবে না।', notMarked: 'হাজিরা দেওয়া হয়নি', outOfRange: 'এই দিনের হাজিরা আর দেওয়া যাবে না।',
    submitAll: 'প্রস্তুতগুলো জমা দিন ({n})', confirmTitle: 'হাজিরা জমা দেবেন?', confirmOne: '{name}: {status}। জমা দেওয়ার পর আর পরিবর্তন বা মুছে ফেলা যাবে না।',
    confirmMany: '{n} জন শিক্ষার্থী। জমা দেওয়ার পর এই এন্ট্রিগুলো আর পরিবর্তন বা মুছে ফেলা যাবে না।', confirmBtn: 'জমা দিন', submitted: 'হাজিরা জমা হয়েছে ({n})।',
    recovery: 'রিকভারি ক্লাস', recoveryShort: 'রিকভারি', logRecovery: 'রিকভারি ক্লাস যোগ করুন', recTitle: 'রিকভারি ক্লাস যোগ করুন',
    recSub: 'মিস হওয়া বা পুনর্নির্ধারিত ক্লাসের জন্য। এটি মোট পরিচালিত ক্লাসে যোগ হয় এবং যেকোনো দিনে দেওয়া যায় (একজন শিক্ষার্থীর জন্য দিনে সর্বোচ্চ ৩টি)।',
    recStudent: 'শিক্ষার্থী', recChoose: 'শিক্ষার্থী বেছে নিন', recDate: 'ক্লাসের তারিখ', recStatus: 'হাজিরা', recFor: 'কোন ক্লাসের পরিবর্তে? (ঐচ্ছিক)',
    recForPh: 'যেমন: ১২ সেপ্টেম্বরের মিস হওয়া ক্লাস', recSave: 'রিকভারি ক্লাস জমা দিন', recSaved: 'রিকভারি ক্লাস যোগ হয়েছে।',
    recConfirm: '{date} তারিখে {name}-এর রিকভারি ক্লাস। জমা দেওয়ার পর আর পরিবর্তন বা মুছে ফেলা যাবে না।', recThatDay: 'রিকভারি ক্লাস', close: 'বন্ধ করুন', cancel: 'বাতিল',
    conducted: 'পরিচালিত ক্লাস', conductedHint: '{p}টি নিয়মিত + {r}টি রিকভারি', recoveryCount: 'রিকভারি ক্লাস', presentHint: 'উপস্থিতি {pct}',
    adminEditHint: 'এক্সিকিউটিভ: এন্ট্রি পরিবর্তন বা মুছতে ম্যানেজমেন্ট পোর্টাল → Attendance log ব্যবহার করুন।',
    flexTitle: 'সুবিধাজনক সময়ের শিক্ষার্থী', flexSub: 'নির্দিষ্ট কোনো দিন নেই। প্রতিবার পড়ানোর পর “ক্লাস যোগ করুন” চাপুন — মাসের মোট ক্লাস = আপনার যোগ করা ক্লাস।',
    flexCount: '{month}-এ {n}টি ক্লাস', logClass: 'ক্লাস যোগ করুন', flexDialog: 'সম্পন্ন ক্লাস যোগ করুন', flexFor: '{name} · সুবিধাজনক সময়সূচি',
    flexDone: 'ক্লাস যোগ হয়েছে।', flexConfirm: '{date} তারিখে {name}-এর ক্লাস। জমা দেওয়ার পর আর পরিবর্তন বা মুছে ফেলা যাবে না।',
    flexLogged: '{month}-এ যোগ করা ক্লাস', flexNone: 'এ মাসে এখনো কোনো ক্লাস যোগ হয়নি।', flexExtra: 'এই দিনে আগেই একটি ক্লাস যোগ আছে, তাই এটি অতিরিক্ত ক্লাস হিসেবে সংরক্ষিত হবে।',
    fixedTitle: 'নির্দিষ্ট সময়ের শিক্ষার্থী', flexNote: 'নোট (ঐচ্ছিক)',
    noneBody: 'অফিস আপনার সাথে শিক্ষার্থী যুক্ত করলে হাজিরা দেওয়া যাবে।', present: 'উপস্থিত', absent: 'অনুপস্থিত',
    classAt: '{time}-এ ক্লাস', noClassToday: 'আজ ক্লাস নির্ধারিত নেই', noneThisDay: 'এই দিনে কোনো শিক্ষার্থীর ক্লাস নেই।', noTimesSet: '{n} জন শিক্ষার্থীর ক্লাসের সময় দেওয়া নেই — এখানে দেখতে সময়সূচি-তে সময় যোগ করুন।', statusFor: '{name}-এর হাজিরা', reasonPh: 'যেমন: অসুস্থ, সফরে, ইন্টারনেট সমস্যা',
    reasonFor: '{name}-এর অনুপস্থিতির কারণ', rate: 'উপস্থিতির হার · {month}', daysMarked: 'হাজিরা দেওয়া দিন', prevDay: 'আগের দিন', nextDay: 'পরের দিন',
    day: 'দিন', today: 'আজ', allPresent: 'সবাইকে উপস্থিত করুন', classesThatDay: 'এই দিনে {n} জন শিক্ষার্থীর ক্লাস আছে',
    unsaved: '{n}টি পরিবর্তন সংরক্ষণ বাকি', save: 'হাজিরা সংরক্ষণ করুন', saved: 'হাজিরা সংরক্ষিত হয়েছে ({n})।', calendarHint: 'সবুজ = সবাই উপস্থিত · হলুদ = কেউ অনুপস্থিত · সোনালি বিন্দু = রিকভারি ক্লাস। গত ৩১ দিনের হাজিরা দেওয়া যায়।',
    fromDaily: 'আপনার দৈনিক হাজিরা থেকে: {p} দিন উপস্থিত, {a} দিন অনুপস্থিত, {r}টি রিকভারি ক্লাস। মোট = নিয়মিত ক্লাস + রিকভারি ক্লাস।',
    autoFilled: 'আপনার দৈনিক হাজিরা থেকে পূরণ করা হয়েছে। চাইলে পরিবর্তন করতে পারবেন।', differs: 'দৈনিক হাজিরা অনুযায়ী {t}টি ক্লাসের মধ্যে {p}টিতে উপস্থিত।', use: 'হাজিরার সংখ্যা ব্যবহার করুন',
    flexTotal: 'সুবিধাজনক সময়সূচি: মোট = এ মাসে আপনার যোগ করা {n}টি ক্লাস। নির্দিষ্ট লক্ষ্য নেই, তাই কোনো ক্লাস বাদ পড়া হিসাব হয় না।',
    baseline: 'অগ্রগতি রিপোর্ট সেপ্টেম্বর ২০২৬ থেকে শুরু।',
  },
  pg: {
    title: 'আমার অগ্রগতি', sub: 'আপনার উপস্থিতি, পয়েন্ট ও লেভেল। প্রতিটি হাজিরা ও সময়মতো রিপোর্টে পয়েন্ট যোগ হয়।',
    hardworkingLevel: 'পরিশ্রমের লেভেল', level: 'লেভেল', totalPoints: 'মোট {n} পয়েন্ট অর্জিত', rankOf: 'এ মাসে {n} জন শিক্ষকের মধ্যে', streak: 'টানা ক্লাসের দিন',
    topLevel: 'সর্বোচ্চ লেভেল অর্জিত', toNext: 'পরবর্তী লেভেলের অগ্রগতি', pointsToNext: '“{level}” লেভেলে পৌঁছাতে আর {n} পয়েন্ট',
    attRate: 'শিক্ষার্থীদের উপস্থিতি', attHint: '{p} উপস্থিত · {a} অনুপস্থিত', conducted: 'পরিচালিত ক্লাস', conductedHint: '{p}টি নিয়মিত + {r}টি রিকভারি', logRate: 'হাজিরা দেওয়া ক্লাস', logHint: 'এখন পর্যন্ত নির্ধারিত ক্লাসের মধ্যে', reports: 'মাসিক রিপোর্ট',
    monthPoints: 'এ মাসের পয়েন্ট', rank: 'অবস্থান', breakdown: 'যেভাবে পয়েন্ট অর্জন করেছেন', total: 'মোট',
    pt: { present: 'উপস্থিত শিক্ষার্থী', daysLogged: 'হাজিরা দেওয়া দিন', reports: 'পাঠানো মাসিক রিপোর্ট', onTime: 'সময়মতো রিপোর্টের বোনাস', reviewed: 'অফিসে যাচাইকৃত রিপোর্ট', perfectAttendance: 'শতভাগ উপস্থিত শিক্ষার্থী', studentLevels: 'শিক্ষার্থীদের পড়ার অবস্থা', adjustments: 'অফিসের বোনাস / সমন্বয়' },
    rulesHint: 'প্রতিটি উপস্থিতিতে {present}, প্রতিটি মাসিক রিপোর্টে {report} পয়েন্ট, আর পরের মাসের {day} তারিখের মধ্যে পাঠালে অতিরিক্ত {bonus} পয়েন্ট।',
    history: 'গত ছয় মাসের পয়েন্ট', rewards: 'পুরস্কার', noRewards: 'এখনো কোনো পুরস্কার নির্ধারণ করা হয়নি।', inspire: 'এগিয়ে চলুন',
    msgStreak: 'মাশাআল্লাহ! টানা {n} দিন হাজিরা দিয়েছেন।', msgAttendance: 'এ মাসে চমৎকার উপস্থিতি। আপনার শিক্ষার্থীরা নিয়মিত আসছে!',
    msgReports: 'সব মাসিক রিপোর্ট পাঠানো হয়েছে। জাযাকাল্লাহু খাইরান!', msgTop: 'এ মাসে আপনি শীর্ষ শিক্ষক!', msgStart: 'আজকের হাজিরা দিন এবং সময়মতো রিপোর্ট পাঠিয়ে পরবর্তী লেভেলে এগিয়ে যান।',
    hadith: '“তোমাদের মধ্যে সর্বোত্তম সেই ব্যক্তি, যে কুরআন শেখে এবং অন্যকে শেখায়।”', hadithSource: 'সহীহ বুখারী ৫০২৭',
  },
  pdf: { download: 'পিডিএফ ডাউনলোড', title: 'শিক্ষকের মাসিক সারাংশ', students: 'শিক্ষার্থী', report: 'মাসিক রিপোর্ট', points: 'পয়েন্ট', popup: 'পিডিএফ ডাউনলোডের জন্য এই সাইটে পপ-আপ চালু করুন।', note: 'প্রিন্ট উইন্ডোতে প্রিন্টার হিসেবে “Save as PDF” বেছে নিন।' },
  login: {
    gone: 'শিক্ষক আইডি {id} এই ডিভাইসে আর সক্রিয় নেই। Google বা অন্য শিক্ষক আইডি দিয়ে সাইন-ইন করুন, অথবা QIT অফিসে যোগাযোগ করুন।',
    f1: 'আপনার শিক্ষার্থী ও ক্লাসের সময়সূচি', f2: 'কয়েক মিনিটেই মাসিক অগ্রগতি রিপোর্ট', f3: 'বেতনের হিসাব — পরিশোধিত, প্রক্রিয়াধীন, বকেয়া', f4: 'অফিসে সহায়তা ও ছুটির আবেদন',
    title: 'শিক্ষক সাইন-ইন', back: 'ওয়েবসাইটে ফিরে যান', admin: 'অ্যাডমিন সাইন-ইন',
    google: 'Google দিয়ে প্রবেশ করুন', opening: 'Google খোলা হচ্ছে…',
    hint: 'প্রথমবার? আপনার Gmail দিয়ে সাইন-ইন করুন। অফিসে আপনার Gmail থাকলে আপনার নিজের শিক্ষক আইডি পাবেন; নতুন হলে নতুন আইডি পাবেন।',
    rule1: 'প্রথমবার: আপনার Gmail দিয়ে সাইন-ইন করুন।', rule2: 'এরপর থেকে: শিক্ষক আইডি নিজে থেকেই লেখা থাকবে — শুধু পাসওয়ার্ড দিন।', rule3: 'একাধিক ডিভাইসে ব্যবহার করা যাবে, তবে সবসময় এই একই Gmail দিয়ে।',
    orId: 'শিক্ষক আইডি ও পাসওয়ার্ড আগে থেকেই আছে?', useId: 'শিক্ষক আইডি দিয়ে সাইন-ইন',
    id: 'শিক্ষক আইডি', idPh: 'যেমন QIT-077', idErr: 'আপনার শিক্ষক আইডি লিখুন (যেমন QIT-077)।', pw: 'পাসওয়ার্ড', pwErr: 'পাসওয়ার্ড লিখুন।',
    show: 'পাসওয়ার্ড দেখুন', hide: 'পাসওয়ার্ড লুকান', submit: 'সাইন-ইন করুন', busy: 'সাইন-ইন হচ্ছে…',
    welcomeBack: 'আবার স্বাগতম', savedAs: 'সাইন-ইন করছেন', notYou: 'আপনি নন? অন্য অ্যাকাউন্ট ব্যবহার করুন', useGoogle: 'বরং Google দিয়ে সাইন-ইন করুন',
    pwHint: 'QIT অফিস আপনাকে পাসওয়ার্ড জানিয়ে দেবে (Google দিয়ে সাইন-ইন করলেও দেখানো হয়)। ভুলে গেলে অফিসে যোগাযোগ করুন।',
    help: 'সাইন-ইনে সমস্যা? QIT অফিসে যোগাযোগ করুন।',
  },
  card: {
    title: 'শিক্ষক আইডি দিয়ে সাইন-ইন', body: 'সাইন আউটের পর এই ডিভাইসে শুধু এই পাসওয়ার্ড লাগবে (শিক্ষক আইডি লেখা থাকবে)। নতুন ফোনে আগে এই একই Gmail দিয়ে সাইন-ইন করুন।',
    pw: 'পাসওয়ার্ড', custom: 'অফিস আপনার পাসওয়ার্ড ঠিক করে দিয়েছে। ভুলে গেলে অফিসে জিজ্ঞেস করুন।', off: 'শিক্ষক আইডি দিয়ে সাইন-ইন বন্ধ আছে। QIT অফিসে যোগাযোগ করুন।',
    keep: 'পাসওয়ার্ড গোপন রাখুন। আপনি এটি বদলাতে পারবেন না; অফিস রিসেট করতে পারে।', ok: 'বুঝেছি', show: 'পাসওয়ার্ড দেখুন', hide: 'পাসওয়ার্ড লুকান',
  },
  hist: {
    title: 'শিক্ষার্থীর ইতিহাস', sub: 'বিরতিতে বা নিষ্ক্রিয় শিক্ষার্থী। আবার সক্রিয় না করা পর্যন্ত এরা আমার শিক্ষার্থী, হাজিরা বা রিপোর্টে থাকবে না।', makeActive: 'সক্রিয় করুন', madeActive: '{name} আবার সক্রিয় হয়েছে এবং আমার শিক্ষার্থী তালিকায় ফিরে এসেছে।',
    hold: 'বিরতিতে', inactive: 'নিষ্ক্রিয়', none: 'বিরতিতে বা নিষ্ক্রিয় কোনো শিক্ষার্থী নেই।', since: '{date} থেকে', joined: 'যুক্ত হয়েছে {date}',
    allTime: 'মোট শিক্ষার্থী (সব সময়)', active: 'সক্রিয় শিক্ষার্থী', holdN: 'বিরতিতে', inactiveN: 'নিষ্ক্রিয়', allHint: 'এ পর্যন্ত যাদের পড়িয়েছেন, অন্য শিক্ষকের কাছে চলে যাওয়া শিক্ষার্থীসহ',
    ask: 'শিক্ষার্থীকে ফিরিয়ে আনতে “সক্রিয় করুন” বাটনে চাপ দিন। বিরতিতে রাখতে আমার শিক্ষার্থী থেকে সম্পাদনা খুলে অবস্থা বেছে নিন।',
  },
  lock: {
    title: 'আবার স্বাগতম', intro: 'আপনার Gmail {email} এই শিক্ষক আইডির সাথে যুক্ত। ড্যাশবোর্ড খুলতে পাসওয়ার্ড দিন।',
    rule: 'আপনার নিরাপত্তার জন্য শিক্ষক আইডি শুধু আপনার নিজের Gmail দিয়ে এবং আপনার যেকোনো ডিভাইসে কাজ করে।',
    elsewhere: 'আপনার ড্যাশবোর্ড অন্য একটি ডিভাইসে ({device}) খোলা আছে। এখানে চালিয়ে গেলে সেই ডিভাইস থেকে সাইন আউট হয়ে যাবে।',
    kicked: 'অফিস এই ডিভাইসটি সাইন-আউট করেছে অথবা আপনার পাসওয়ার্ড পরিবর্তন হয়েছে। আবার পাসওয়ার্ড দিন।',
    off: 'আপনার শিক্ষক আইডি দিয়ে সাইন-ইন বন্ধ আছে। QIT অফিসে যোগাযোগ করুন।',
    submit: 'ড্যাশবোর্ড খুলুন', busy: 'যাচাই করা হচ্ছে…', otherGmail: 'অন্য Gmail ব্যবহার করুন', welcome: 'স্বাগতম', opening: 'ড্যাশবোর্ড খোলা হচ্ছে…',
    e_wrong: 'শিক্ষক আইডি বা পাসওয়ার্ড সঠিক নয়। আর {left} বার চেষ্টা করতে পারবেন।', e_wrong0: 'শিক্ষক আইডি বা পাসওয়ার্ড সঠিক নয়।',
    e_too_many: 'অনেকবার ভুল হয়েছে। {m} মিনিট অপেক্ষা করুন, অথবা QIT অফিসে যোগাযোগ করুন।',
    e_not_your_id: 'এই Gmail অন্য একটি শিক্ষক আইডির সাথে যুক্ত। আপনার নিজের শিক্ষক আইডি দিন।',
    e_gmail_mismatch: 'এই শিক্ষক আইডি অন্য একটি Gmail-এর সাথে লক করা। আগে যে Gmail ব্যবহার করেছেন সেটি দিয়ে সাইন-ইন করুন, অথবা পরিবর্তনের জন্য QIT অফিসে বলুন।',
    e_id_off: 'এই শিক্ষক আইডি দিয়ে সাইন-ইন বন্ধ আছে। QIT অফিসে যোগাযোগ করুন।',
    e_id_required: 'আপনার শিক্ষক আইডি লিখুন।', e_google_required: 'আগে Google দিয়ে সাইন-ইন করুন।', e_session: 'সাইন আউট করে আবার সাইন-ইন করুন।',
    e_admin_account: 'এই Gmail একটি অ্যাডমিন অ্যাকাউন্ট, শিক্ষক অ্যাকাউন্ট নয়।',
    haveId: 'আগে থেকেই QIT-এর শিক্ষক?', haveIdBody: 'এই Gmail আপনার রেকর্ডের সাথে যুক্ত করতে শিক্ষক আইডি ও পাসওয়ার্ড দিন।', newTeacher: 'নতুন শিক্ষক? নিচে আপনার তথ্য দিন।',
    pendingId: 'শিক্ষক আইডি ও পাসওয়ার্ড জানা আছে? অপেক্ষা না করে এখনই যুক্ত করুন:',
  },
  first: {
    title: 'আপনি অনুমোদিত হয়েছেন', body: 'স্বাগতম, {name}। QIT অফিস আপনাকে শিক্ষক আইডি ও পাসওয়ার্ড দিয়েছে। এগুলো লিখে রাখুন, তারপর ড্যাশবোর্ড খুলুন।',
    keep: 'সাইন আউটের পর এই ফোনে শুধু এই পাসওয়ার্ড লাগবে। পাসওয়ার্ড গোপন রাখুন।',
  },
  ob: {
    title: 'আপনার প্রোফাইল সম্পূর্ণ করুন', intro: 'শেষ ধাপ। এই তথ্য দেখে QIT অফিস আপনাকে অফিসিয়াল শিক্ষক আইডি দেবে।',
    gmail: 'Gmail', name: 'পূর্ণ নাম', namePh: 'যেমন: হাফেজ আব্দুর রহমান', nameErr: 'অনুগ্রহ করে আপনার পূর্ণ নাম লিখুন।',
    wa: 'হোয়াটসঅ্যাপ নম্বর', waHint: 'যে নম্বরে অফিস আপনার সাথে যোগাযোগ করবে।', waErr: 'পূর্ণ হোয়াটসঅ্যাপ নম্বর লিখুন (১০–১৫ অঙ্ক); বাংলাদেশের বাইরে হলে কান্ট্রি কোডসহ।',
    submit: 'এগিয়ে যান', busy: 'পাঠানো হচ্ছে…', notYou: 'আপনি নন? সাইন আউট করুন',
    welcome: 'স্বাগতম, {name}', idIs: 'আপনার অফিসিয়াল শিক্ষক আইডি', linked: 'আপনার অ্যাকাউন্ট QIT-এর শিক্ষক রেকর্ডের সাথে যুক্ত হয়েছে।',
    fresh: 'এই আইডিটি সংরক্ষণ করুন। অফিস আপনার শিক্ষার্থীদের এই আইডির সাথে যুক্ত করবে।', open: 'ড্যাশবোর্ড খুলুন',
  },
  notice: {
    adminTitle: 'এটি একটি অ্যাডমিন অ্যাকাউন্ট', adminBody: '{email} {role} হিসেবে সাইন-ইন আছেন। শিক্ষক ড্যাশবোর্ড শুধু শিক্ষকদের জন্য।',
    exec: 'এক্সিকিউটিভ', junior: 'জুনিয়র অ্যাডমিন', openAdmin: 'অ্যাডমিন প্যানেল খুলুন', errTitle: 'কিছু একটা সমস্যা হয়েছে', tryAgain: 'অনুগ্রহ করে আবার চেষ্টা করুন।', retry: 'আবার চেষ্টা করুন',
    pendingTitle: 'অফিসের নিশ্চিতকরণের অপেক্ষায়', pendingBody: 'আপনার নাম আমাদের শিক্ষক তালিকার “{name}”-এর সাথে মিলেছে। প্রত্যেক শিক্ষকের তথ্য সুরক্ষিত রাখতে QIT অফিস নিশ্চিত করবে যে এটি আপনি। এরপর এখানে আপনার শিক্ষার্থী ও বেতনের তথ্য দেখতে পাবেন।', pendingCheck: 'আবার দেখুন', pendingHelp: 'দ্রুত প্রয়োজন হলে অফিসে যোগাযোগ করুন।',
    newTitle: 'অফিসের অনুমোদনের অপেক্ষায়', newBody: 'ধন্যবাদ, {name}। QIT অফিস আপনার তথ্য যাচাই করে আপনার শিক্ষক আইডি ও পাসওয়ার্ড দেবে। এরপর এখানেই আপনার ড্যাশবোর্ড খুলবে।',
  },
  loading: { dashboard: 'আপনার ড্যাশবোর্ড খোলা হচ্ছে', students: 'আপনার শিক্ষার্থীদের তথ্য আসছে', generic: 'লোড হচ্ছে…' },
  home: {
    hello: 'আসসালামু আলাইকুম, {name}', sub: 'শিক্ষক আইডি {id}{dept} — আপনার শিক্ষার্থী ও ক্লাসের সময়।',
    students: 'শিক্ষার্থী', perWeek: 'সাপ্তাহিক ক্লাস', fromSchedule: 'আপনার সময়সূচি থেকে', addUnder: '“সময়সূচি” থেকে যোগ করুন',
    reports: '{month}-এর রিপোর্ট', toSend: 'আরও {n}টি পাঠানো বাকি', allSent: 'সব পাঠানো হয়েছে — ধন্যবাদ', needs: 'সংশোধন প্রয়োজন', fixTitle: 'অফিস যে রিপোর্টগুলো ফেরত পাঠিয়েছে ({n}) — সংশোধন করে আবার পাঠান', fixOpen: 'এখন সংশোধন করুন', sentBack: 'অফিস থেকে ফেরত পাঠানো রিপোর্ট',
    due: '{month} {year}-এর {n}টি মাসিক রিপোর্ট বাকি।', dueSalary: 'এই রিপোর্টের ভিত্তিতেই আপনার বেতন হিসাব করা হয়।', write: 'রিপোর্ট লিখুন',
    search: 'শিক্ষার্থী খুঁজুন', noneTitle: 'এখনো কোনো শিক্ষার্থী যুক্ত হয়নি',
    noneBody: 'QIT অফিস আপনার শিক্ষক আইডিতে ({id}) শিক্ষার্থী যুক্ত করলে তারা এখানে দেখা যাবে। আপনি যদি আগে থেকেই QIT-তে পড়ান, “সহায়তা” থেকে বার্তা পাঠান যাতে অফিস আপনার অ্যাকাউন্ট যুক্ত করতে পারে।',
    whatsapp: 'হোয়াটসঅ্যাপ', classes: 'ক্লাস', notSet: 'এখনো ঠিক করা হয়নি', officeNote: 'অফিসের নোট: {note}', schedule: 'সময়সূচি',
    writeReport: 'রিপোর্ট লিখুন', editReport: 'রিপোর্ট সংশোধন', reportDue: '{month}-এর রিপোর্ট বাকি',
    reportLbl: '{month}-এর রিপোর্ট', notSent: 'এখনো পাঠানো হয়নি', filter: 'শিক্ষার্থী দেখুন', fAll: 'সবাই', fDue: 'রিপোর্ট বাকি', fSent: 'রিপোর্ট পাঠানো', noMatch: 'কোনো শিক্ষার্থী মেলেনি।',
  },
  sch: {
    title: 'ক্লাসের সময়সূচি', sub: '{students} জন শিক্ষার্থীর সপ্তাহে {classes}টি ক্লাস · বাংলাদেশ সময়', noneBody: 'অফিস আপনার সাথে শিক্ষার্থী যুক্ত করলে এখানে সাপ্তাহিক রুটিন দেখা যাবে।',
    editTitle: 'ক্লাসের সময় সম্পাদনা', another: 'ভিন্ন সময় যোগ করুন', removeSet: 'এই সময় বাদ দিন', deleteAll: 'সময়সূচি মুছুন', deleteQ: 'পুরো সাপ্তাহিক সময়সূচি মুছবেন?', deleteMsg: '{name}-এর সব সাপ্তাহিক ক্লাসের সময় মুছে যাবে।', saveTimes: 'ক্লাসের সময় সংরক্ষণ করুন', savedTimes: 'ক্লাসের সময় সংরক্ষিত হয়েছে।', deleted: 'সময়সূচি মুছে ফেলা হয়েছে।', applyHint: 'প্রয়োগ করতে “পরিবর্তন সংরক্ষণ” বাটনে চাপ দিন।', unsaved: 'এখনো সংরক্ষিত হয়নি', pickTime: 'ক্লাসের সময় বেছে নিন', needAmPm: 'AM না PM — বেছে নিন', hour: 'ঘণ্টা', minute: 'মিনিট', done: 'ঠিক আছে', today: 'আজ', noClasses: 'ক্লাস নেই', manage: 'ক্লাসের সময় পরিচালনা', manageSub: 'একজন শিক্ষার্থী বেছে নিয়ে তার সাপ্তাহিক ক্লাস যোগ, পরিবর্তন বা মুছে ফেলুন।', student: 'শিক্ষার্থী',
    empty: 'এখনো কোনো ক্লাসের সময় যোগ করা হয়নি', officeNote: ' (অফিসের নোট: {note})', add: 'ক্লাসের সময় যোগ করুন', note: 'নোট (ঐচ্ছিক)', notePh: 'নোট (ঐচ্ছিক), যেমন: Zoom-এ',
    addBtn: 'যোগ করুন', adding: 'যোগ হচ্ছে…', bdTime: 'সব সময় বাংলাদেশ সময় অনুযায়ী।', minutes: '{n} মিনিট', min: '{n} মিনিট', pickDay: 'অন্তত একটি দিন ও শুরুর সময় বেছে নিন।',
    clash: '{day} {time}-এর ক্লাস আগেই সময়সূচিতে আছে।', removeQ: '{day} {time}-এর ক্লাসটি মুছে ফেলবেন?', cancel: 'বাতিল', save: 'সংরক্ষণ', day: 'দিন', start: 'শুরুর সময়',
    length: 'ক্লাসের সময়কাল', edit: '{day}-এর ক্লাস সম্পাদনা', remove: '{day}-এর ক্লাস মুছুন', days: 'দিন', removeYes: 'ক্লাস মুছুন', removed: 'ক্লাস মুছে ফেলা হয়েছে।', saved: 'ক্লাসের সময় সংরক্ষিত হয়েছে।', added: 'ক্লাসের সময় যোগ হয়েছে।',
  },
  rp: {
    classStart: 'ক্লাস শুরুর তারিখ (এই মাসে হলে)', startHint: 'পুরো মাস পড়লে খালি রাখুন।', startFull: 'প্রথম ৩ দিনের মধ্যে শুরু: পুরো মাস।', startDays: 'মাসের {n} দিন হিসেবে গণনা।', startOther: 'এই মাসে নয়: পুরো মাস।',
    title: 'মাসিক অগ্রগতি রিপোর্ট', sub: '{month} {year}: {total}টির মধ্যে {done}টি পাঠানো হয়েছে। এই রিপোর্টের ভিত্তিতেই আপনার বেতন হিসাব করা হয়।',
    noneBody: 'অফিস আপনার সাথে শিক্ষার্থী যুক্ত করলে রিপোর্ট লেখা যাবে।', sentNew: '{name}-এর {month} মাসের রিপোর্ট অফিসে পাঠানো হয়েছে। জাযাকাল্লাহু খাইরান!',
    sentUpd: '{name}-এর {month} মাসের রিপোর্ট হালনাগাদ হয়েছে। জাযাকাল্লাহু খাইরান!', next: 'পরবর্তী: {name}', allDone: 'সব রিপোর্ট পাঠানো হয়েছে — শিক্ষার্থী তালিকায় ফিরুন',
    student: 'শিক্ষার্থী', month: 'মাস', year: 'বছর', choose: 'শিক্ষার্থী বেছে নিন…', chooseTitle: 'শুরু করতে একজন শিক্ষার্থী বেছে নিন', chooseBody: 'তার তথ্য ও আগের রিপোর্ট নিজে থেকেই পূরণ হয়ে যাবে।',
    locked: 'অফিস এই রিপোর্টটি যাচাই করেছে, তাই এটি আর পরিবর্তন করা যাবে না।', askedChanges: 'অফিস সংশোধন চেয়েছে: {note}', alreadySent: '{date} তারিখে পাঠানো হয়েছে — এখনো সংশোধন করা যাবে।',
    s1: '১. উপস্থিতি', total: 'মোট ক্লাস', totalHint: 'এই মাসে নির্ধারিত ক্লাস।', totalFromSch: 'আপনার সময়সূচি অনুযায়ী {month} মাসে {n}টি ক্লাস।',
    present: 'উপস্থিত', absent: 'অনুপস্থিত', absentHint: 'নিজে থেকে হিসাব হবে', attendance: '{pct}% উপস্থিতি', reason: 'অনুপস্থিতির কারণ', reasonHint: 'যেমন: অসুস্থতা, ভ্রমণ, পরীক্ষা, ইন্টারনেট সমস্যা',
    s2: '২. পড়ার অবস্থা', notes: 'অগ্রগতি সম্পর্কে নোট', notesHint: 'ঐচ্ছিক: তাজবীদ, সাবলীলতা, মুখস্থ, আচরণ…',
    s3: '৩. পাঠের অগ্রগতি', taught: 'এই মাসে যা পড়ানো হয়েছে', taughtHint: 'যেমন: কায়দা ১০–১৫ পৃষ্ঠা, সূরা ফাতিহা মুখস্থ', lesson: 'বর্তমান সবক', lessonHint: 'শিক্ষার্থী এখন কোথায় আছে, যেমন: সূরা মুলক, আয়াত ১–১৫',
    s4: '৪. পরবর্তী লক্ষ্য ও মন্তব্য', target: 'পরবর্তী লক্ষ্য / বাড়ির কাজ', targetHint: 'আগামী মাসে শিক্ষার্থী কতদূর পৌঁছাবে', lastTarget: 'আগের লক্ষ্য: {t}',
    remarks: 'মন্তব্য', remarksHint: 'অভিভাবক ও অফিসের জন্য আপনার বার্তা (আবশ্যক)।',
    eTotal: 'এই মাসে কয়টি ক্লাস নির্ধারিত ছিল?', eRange: '০ থেকে ৬২-এর মধ্যে একটি সংখ্যা লিখুন।', ePresent: 'শিক্ষার্থী কয়টি ক্লাসে উপস্থিত ছিল?', eWhole: 'একটি পূর্ণ সংখ্যা লিখুন।',
    eMore: 'মোট ক্লাসের চেয়ে বেশি হতে পারবে না।', eLevel: 'শিক্ষার্থীর বর্তমান অবস্থা বেছে নিন।', eRemarks: 'মন্তব্য লেখা আবশ্যক।', fix: 'লাল চিহ্নিত ঘরগুলো পূরণ করুন।',
    submit: 'রিপোর্ট জমা দিন', update: 'রিপোর্ট হালনাগাদ করুন', sending: 'পাঠানো হচ্ছে…', level: 'বর্তমান অবস্থা',
    bg: 'শিক্ষার্থীর তথ্য', bgEmpty: 'শিক্ষার্থী বেছে নিলে তার তথ্য এখানে দেখা যাবে।', sid: 'শিক্ষার্থী আইডি', course: 'কোর্স', status: 'অবস্থা', times: 'ক্লাসের সময়',
    notSet: 'ঠিক করা হয়নি', last: 'আগের রিপোর্ট', firstReport: 'আগের কোনো রিপোর্ট নেই — এটিই প্রথম।', lessonThen: 'তখনকার সবক', targetSet: 'নির্ধারিত লক্ষ্য', lvl: 'অবস্থা',
  },
  sal: {
    title: 'বেতন', sub: 'মাস অনুযায়ী আপনার বেতনের হিসাব। প্রতি মাসের বেতন পরের মাসের শুরুতে পরিশোধ করা হয়।',
    monthly: 'মাসিক বেতন', lastMonth: '{month} মাসের বেতন', paidInMonth: '{month} মাসে পরিশোধ', withExtra: 'অতিরিক্ত দায়িত্ব {extra} সহ', extraLine: 'অতিরিক্ত {extra} সহ ({what})', fixed: 'নির্ধারিত বেতন', perStudent: 'আপনার শিক্ষার্থী অনুযায়ী', paidIn: '{year} সালে পরিশোধিত', pending: 'প্রক্রিয়াধীন', processing: 'প্রক্রিয়া চলছে',
    unpaid: 'বকেয়া', contact: '“সহায়তা” থেকে অফিসে জানান', nothing: 'কোনো বকেয়া নেই', noneTitle: 'এখনো বেতনের কোনো হিসাব নেই', noneBody: 'প্রথম মাস শেষ হলে এখানে দেখা যাবে।',
    month: 'মাস', salary: 'বেতন', paid: 'পরিশোধিত', paidOn: 'পরিশোধের তারিখ', status: 'অবস্থা', caption: 'মাস অনুযায়ী বেতন',
    legend: 'পরিশোধিত = সম্পূর্ণ পরিশোধ · প্রক্রিয়াধীন = গত মাসের বেতন (প্রক্রিয়া চলছে) বা আংশিক পরিশোধ · বকেয়া = আগের মাস, এখনো পরিশোধ হয়নি। প্রতিটি মাসে সেই মাসের বেতন দেখানো হয় (নতুন, স্থানান্তরিত বা বিরতিতে থাকা শিক্ষার্থী ও অতিরিক্ত দায়িত্ব হিসাব করে); এটি পরের মাসে পরিশোধ করা হয়। প্রশ্ন থাকলে “সহায়তা” → বেতন ব্যবহার করুন।',
  },
  sup: {
    title: 'সহায়তা ও আবেদন', sub: 'QIT অফিসে প্রশ্ন করুন, সমস্যা জানান বা ছুটির আবেদন করুন। উত্তর এখানে দেখা যাবে।',
    new: 'নতুন আবেদন', type: 'ধরন', general: 'সাধারণ প্রশ্ন', issue: 'সমস্যা', leave: 'ছুটির আবেদন', salary: 'বেতন', other: 'অন্যান্য',
    first: 'প্রথম দিন', last: 'শেষ দিন', subject: 'বিষয়', subjectPhLeave: 'যেমন: পারিবারিক অনুষ্ঠানের জন্য ছুটি', subjectPh: 'যেমন: Zoom লিংক কাজ করছে না',
    message: 'বার্তা', messagePhLeave: 'কারণ এবং বাদ পড়া ক্লাসগুলো কীভাবে পূরণ হবে', messagePh: 'আপনার কী প্রয়োজন লিখুন',
    eSubject: 'সংক্ষেপে বিষয় লিখুন (অন্তত ৩ অক্ষর)।', eMessage: 'আপনার বার্তা লিখুন।', eFirst: 'ছুটির প্রথম দিন বেছে নিন।', eLast: 'শেষ দিন প্রথম দিনের একই দিন বা পরে হতে হবে।',
    sentOk: 'অফিসে পাঠানো হয়েছে। নিচে তাদের উত্তর দেখতে পাবেন।', send: 'QIT অফিসে পাঠান', sending: 'পাঠানো হচ্ছে…', yours: 'আপনার আবেদনসমূহ',
    noneTitle: 'এখনো কোনো আবেদন নেই', noneBody: 'আপনি যা পাঠাবেন তা অফিসের উত্তরসহ এখানে দেখা যাবে।', reply: 'অফিসের উত্তর',
  },
  badge: { Paid: 'পরিশোধিত', Pending: 'প্রক্রিয়াধীন', Unpaid: 'বকেয়া', submitted: 'জমা হয়েছে', reviewed: 'যাচাই হয়েছে', needs_changes: 'সংশোধন প্রয়োজন', open: 'খোলা', in_progress: 'কাজ চলছে', resolved: 'সমাধান হয়েছে', missing: 'জমা হয়নি' },
  cb: { failed: 'সাইন-ইন সম্পন্ন হয়নি', teacher: 'শিক্ষক সাইন-ইন', admin: 'অ্যাডমিন সাইন-ইন', signing: 'সাইন-ইন করা হচ্ছে',
    noAdmin: '{email}-এর অ্যাডমিন অ্যাক্সেস নেই। শুধু এক্সিকিউটিভের যুক্ত করা Gmail দিয়েই এখানে সাইন-ইন করা যায়।',
    google: '“Google দিয়ে প্রবেশ করুন” বাটনে চাপ দিয়ে সাইন-ইন করুন।' },
};

const BN_STATUS = { active: 'সক্রিয়', inactive: 'নিষ্ক্রিয়', hold: 'বিরতিতে', paused: 'বিরতিতে', 'on hold': 'বিরতিতে', trial: 'ট্রায়াল', left: 'ছেড়ে গেছে', completed: 'সম্পন্ন' };

// Messages that come from the database or network, in Bangla
const BN_ERRORS = {
  'That Teacher ID or password is not correct.': 'শিক্ষক আইডি বা পাসওয়ার্ড সঠিক নয়।',
  'Sign-in with this Teacher ID is switched off. Sign in with Google, or contact the QIT office.': 'এই শিক্ষক আইডি দিয়ে সাইন-ইন বন্ধ আছে। Google দিয়ে সাইন-ইন করুন, অথবা QIT অফিসে যোগাযোগ করুন।',
  'Please enter your full name.': 'অনুগ্রহ করে আপনার পূর্ণ নাম লিখুন।',
  'Please enter a valid WhatsApp number.': 'সঠিক হোয়াটসঅ্যাপ নম্বর লিখুন।',
  'Teachers must sign in with a Gmail account through Google.': 'শিক্ষকদের Google-এর মাধ্যমে Gmail অ্যাকাউন্ট দিয়ে সাইন-ইন করতে হবে।',
  'This Google account belongs to an admin, not a teacher.': 'এই Google অ্যাকাউন্টটি অ্যাডমিনের, শিক্ষকের নয়।',
  'Complete your teacher profile first.': 'আগে আপনার শিক্ষক প্রোফাইল সম্পূর্ণ করুন।',
  'You do not have permission to do that.': 'এই কাজের অনুমতি আপনার নেই।',
  'Remarks are required.': 'মন্তব্য লেখা আবশ্যক।',
  'Present classes cannot be more than the total classes.': 'উপস্থিত ক্লাস মোট ক্লাসের চেয়ে বেশি হতে পারবে না।',
  'Please fill in every field marked with *.': 'তারকা (*) চিহ্নিত সব ঘর পূরণ করুন।',
  'Please write today’s lesson before submitting.': 'জমা দেওয়ার আগে আজকের পাঠ লিখুন।',
  'You have added many students today. Please ask the QIT office to add more.': 'আজ অনেক শিক্ষার্থী যোগ করেছেন। আরও যোগ করতে QIT অফিসকে জানান।',
  'Please enter the student’s full name.': 'শিক্ষার্থীর পূর্ণ নাম লিখুন।',
  'No more than 3 recovery classes can be logged for one student on the same day.': 'একজন শিক্ষার্থীর জন্য একই দিনে ৩টির বেশি রিকভারি ক্লাস দেওয়া যাবে না।',
  'Submitted attendance is locked. Only the QIT office can change it.': 'জমা দেওয়া হাজিরা লক করা। শুধু QIT অফিস পরিবর্তন করতে পারে।',
  'Attendance for this student’s class on that day is already submitted.': 'এই দিনে এই শিক্ষার্থীর ক্লাসের হাজিরা আগেই জমা দেওয়া হয়েছে।',
  'No connection. Check your internet and try again.': 'ইন্টারনেট সংযোগ নেই। সংযোগ দেখে আবার চেষ্টা করুন।',
  'Something went wrong. Please try again.': 'কিছু একটা সমস্যা হয়েছে। আবার চেষ্টা করুন।',
  'This month’s report was already reviewed by the office, so it can no longer be changed. Send a support request if something needs fixing.':
    'এই মাসের রিপোর্ট অফিস যাচাই করেছে, তাই আর পরিবর্তন করা যাবে না। কিছু ঠিক করার দরকার হলে “সহায়তা” থেকে জানান।',
  'Google sign-in did not finish. Please try again.': 'Google সাইন-ইন সম্পন্ন হয়নি। আবার চেষ্টা করুন।',
  'The teacher system is not set up in the cloud database yet. Please ask the QIT office.': 'শিক্ষক ব্যবস্থা এখনো চালু হয়নি। অনুগ্রহ করে QIT অফিসে যোগাযোগ করুন।',
};

const lookup = (obj, key) => key.split('.').reduce((o, k) => (o == null ? o : o[k]), obj);
const fill = (s, vars) => (vars ? s.replace(/\{(\w+)\}/g, (_, k) => (vars[k] ?? '')) : s);

// overrides = the Executives' edited texts ({ en: {key: text}, bn: {…} })
export function makeT(lang, overrides = getDashState().text) {
  const bn = lang === 'bn';
  const own = overrides?.[bn ? 'bn' : 'en'] || {};
  const n = (v) => (bn && v != null ? String(v).replace(/[0-9]/g, (d) => BN_DIGITS[d]) : v);
  const t = (key, vars) => {
    const o = own[key];
    const v = typeof o === 'string' && o.trim() ? o : lookup(bn ? BN : EN, key) ?? lookup(EN, key);
    if (typeof v !== 'string') return key;
    // Numbers inside the text follow the language too
    return fill(v, vars && bn ? Object.fromEntries(Object.entries(vars).map(([k, x]) => [k, typeof x === 'number' ? n(x) : x])) : vars);
  };
  const month = (m) => (bn ? BN_MONTHS[MONTHS.indexOf(m)] || m : m);
  const weekday = (d) => (bn ? BN_WEEKDAYS[d] : WEEKDAYS[d]);
  const weekdayShort = (d) => (bn ? BN_WEEKDAYS_SHORT[d] : WEEKDAYS[d].slice(0, 3));
  const time = (hhmm) => {
    const [h, m] = String(hhmm || '').split(':').map(Number);
    if (Number.isNaN(h)) return '';
    if (!bn) return `${((h + 11) % 12) + 1}:${String(m || 0).padStart(2, '0')} ${h >= 12 ? 'PM' : 'AM'}`;
    const part = h < 4 ? 'রাত' : h < 12 ? 'সকাল' : h < 15 ? 'দুপুর' : h < 18 ? 'বিকাল' : h < 20 ? 'সন্ধ্যা' : 'রাত';
    return `${part} ${n(((h + 11) % 12) + 1)}:${n(String(m || 0).padStart(2, '0'))}`;
  };
  const date = (value, opts = { day: 'numeric', month: 'short', year: 'numeric' }) => {
    if (!value) return '';
    const d = typeof value === 'string' && value.length === 10 ? new Date(`${value}T12:00:00`) : new Date(value);
    return d.toLocaleDateString(bn ? 'bn-BD' : 'en-GB', opts);
  };
  const money = (v) => (bn ? `৳${n(Number(v || 0).toLocaleString('en-IN'))}` : `${Number(v || 0).toLocaleString('en-IN')} BDT`);
  const err = (msg) => (bn ? BN_ERRORS[msg] || msg : msg);
  // Student status words that come from the office records
  const status = (v) => (bn ? BN_STATUS[String(v || '').trim().toLowerCase()] || v : v);
  return { lang, t, n, month, weekday, weekdayShort, time, date, money, err, status };
}

export function useT() {
  const lang = useSyncExternalStore(subscribe, () => current, () => 'bn');
  const cfg = useDashConfig();
  return { ...makeT(lang, cfg.text), setLang: setTeacherLang, toggle: () => setTeacherLang(lang === 'bn' ? 'en' : 'bn') };
}

/**
 * Applies the language to the page: <html lang="bn"> switches on the
 * website's Bangla fonts and spacing; in English the admin Bangla font
 * (Aikya) is used for any Bangla names.
 */
export function useTeacherDocument(title) {
  const { lang } = useT();
  useEffect(() => {
    const root = document.documentElement;
    root.lang = lang;
    root.classList.toggle('admin-ui', lang === 'en');
    return () => {
      root.lang = 'en';
      root.classList.remove('admin-ui');
    };
  }, [lang]);
  useEffect(() => {
    if (title) document.title = `${title} | QIT`;
  }, [title]);
  return lang;
}
