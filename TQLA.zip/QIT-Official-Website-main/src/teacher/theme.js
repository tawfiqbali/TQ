/**
 * Light / dark mode for the Teacher Dashboard only (saved in this browser as
 * 'qit:teacher-theme'). The first visit follows the phone or computer setting.
 * The website's own dark mode setting is not changed.
 */
import { useEffect, useSyncExternalStore } from 'react';

const KEY = 'qit:teacher-theme';
const listeners = new Set();
function read() {
  try {
    const v = localStorage.getItem(KEY);
    if (v === 'light' || v === 'dark') return v;
  } catch {
    /* storage blocked */
  }
  return typeof window !== 'undefined' && window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}
let current = read();
export function setTeacherTheme(next) {
  current = next === 'dark' ? 'dark' : 'light';
  try {
    localStorage.setItem(KEY, current);
  } catch {
    /* applies for this visit */
  }
  listeners.forEach((fn) => fn());
}
const subscribe = (fn) => {
  listeners.add(fn);
  return () => listeners.delete(fn);
};

export function useTeacherTheme() {
  const theme = useSyncExternalStore(subscribe, () => current, () => 'light');
  return { theme, dark: theme === 'dark', toggle: () => setTeacherTheme(theme === 'dark' ? 'light' : 'dark') };
}

// Applies the theme to the page while a teacher page is open
export function useApplyTeacherTheme() {
  const { dark } = useTeacherTheme();
  useEffect(() => {
    const root = document.documentElement;
    const had = root.classList.contains('dark');
    root.classList.toggle('dark', dark);
    root.style.colorScheme = dark ? 'dark' : 'light';
    return () => {
      root.classList.toggle('dark', had);
      root.style.colorScheme = '';
    };
  }, [dark]);
}
