import { memo, Suspense, useEffect, useState } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import { ArrowLeft, Archive, CalendarCheck, ChevronDown, CalendarDays, ClipboardList, LifeBuoy, LogOut, Moon, Phone, ShieldCheck, Siren, Sun, Trophy, Users, Wallet, X } from 'lucide-react';
import { useTeacher } from './TeacherContext';
import { signOut } from '../lib/auth';
import { useT, useTeacherDocument } from './i18n';
import { LangToggle } from './ui';
import SoundToggle from '../components/ui/SoundToggle';
import { useApplyTeacherTheme, useTeacherTheme } from './theme';
import { EMERGENCY_PHONE, EMERGENCY_TEL, EMERGENCY_WA } from '../lib/teacherData';
import { ResolvedNotices, TeacherDock, useResolvedNotices } from './TeacherDock';
import { CredsBar, LoginNotice, useLoginInfo } from './TeacherCreds';
import { AlertsBell, PushInvite } from './TeacherAlerts';

// Each page belongs to a coloured group (same idea as the admin portal menu)
const NAV = [
  { path: '', key: 'students', Icon: Users, end: true, group: 'classes' },
  { path: '/attendance', key: 'attendance', Icon: CalendarCheck, group: 'classes' },
  { path: '/schedule', key: 'schedule', Icon: CalendarDays, group: 'classes' },
  { path: '/history', key: 'history', Icon: Archive, group: 'classes' },
  { path: '/report', key: 'report', Icon: ClipboardList, group: 'reports' },
  { path: '/progress', key: 'progress', Icon: Trophy, group: 'reports' },
  { path: '/salary', key: 'salary', Icon: Wallet, group: 'money' },
  { path: '/support', key: 'support', Icon: LifeBuoy, group: 'money' },
];
const GROUPS = ['classes', 'reports', 'money'];

function WhatsAppGlyph({ className }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden="true">
      <path d="M17.5 14.4c-.3-.1-1.7-.8-2-.9-.3-.1-.5-.1-.7.1-.2.3-.8.9-.9 1.1-.2.2-.3.2-.6.1-.3-.1-1.2-.5-2.3-1.4-.9-.8-1.4-1.7-1.6-2-.2-.3 0-.5.1-.6l.4-.5c.2-.2.2-.3.3-.5.1-.2 0-.4 0-.5l-.9-2.1c-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.4s1 2.8 1.2 3c.1.2 2 3.1 4.9 4.3.7.3 1.2.5 1.6.6.7.2 1.3.2 1.8.1.6-.1 1.7-.7 1.9-1.4.2-.7.2-1.2.2-1.4-.1-.1-.3-.2-.6-.3zM12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2c-1.5 0-3-.4-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2z" />
    </svg>
  );
}

// Always-visible button: call or WhatsApp the office in an emergency
const EmergencyContact = memo(function EmergencyContact() {
  const { t } = useT();
  const [open, setOpen] = useState(false);
  return (
    <div className="t-emg fixed bottom-4 right-4 z-40 flex flex-col items-end gap-2 print:hidden">
      {open && (
        <div className="qit-pop-in w-64 rounded-2xl border border-red-200 bg-surface p-4 shadow-2xl dark:border-red-900" role="dialog" aria-label={t('emg.title')}>
          <div className="flex items-start justify-between gap-2">
            <p className="text-sm font-bold text-heading">{t('emg.title')}</p>
            <button type="button" onClick={() => setOpen(false)} className="rounded p-0.5 text-ink/50 hover:text-ink" aria-label={t('emg.close')}>
              <X className="h-4 w-4" />
            </button>
          </div>
          <p className="mt-1 text-xs text-ink/75">{t('emg.body')}</p>
          <p className="mt-2 font-display text-lg text-heading" lang="en">{EMERGENCY_PHONE}</p>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <a href={EMERGENCY_TEL} className="flex items-center justify-center gap-1.5 rounded-xl bg-red-700 px-3 py-2.5 text-sm font-semibold text-white hover:bg-red-800">
              <Phone className="h-4 w-4" aria-hidden="true" /> {t('emg.call')}
            </a>
            <a href={EMERGENCY_WA} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-1.5 rounded-xl bg-[#1FA855] px-3 py-2.5 text-sm font-semibold text-white hover:bg-[#178a45]">
              <WhatsAppGlyph className="h-4 w-4" /> WhatsApp
            </a>
          </div>
        </div>
      )}
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        className="flex items-center gap-2 rounded-full bg-red-700 px-4 py-3 text-sm font-semibold text-white shadow-xl ring-4 ring-red-700/20 transition hover:bg-red-800"
      >
        <Siren className="h-4 w-4" aria-hidden="true" />
        <span>{t('emg.button')}</span>
      </button>
    </div>
  );
});

export default function TeacherLayout() {
  const { teacher, access, base, adminMode } = useTeacher();
  const { pathname } = useLocation();
  const { t } = useT();
  const { dark, toggle } = useTeacherTheme();
  useApplyTeacherTheme();
  // v188: a slightly larger, easier-to-read text size on the Teacher Dashboard
  useEffect(() => {
    document.documentElement.classList.add('teacher-ui');
    return () => document.documentElement.classList.remove('teacher-ui');
  }, []);
  const page = NAV.find((n) => (n.end ? pathname === base || pathname === `${base}/` : pathname.startsWith(base + n.path)));
  useTeacherDocument(page ? t(`nav.${page.key}`) : t('brand.dashboard'));

  // Fetch the other pages in the background, so opening one never waits
  useEffect(() => {
    const load = () => {
      import('./pages/MyStudents'); import('./pages/Attendance'); import('./pages/Schedule'); import('./pages/StudentHistory');
      import('./pages/MonthlyReport'); import('./pages/Progress'); import('./pages/Salary'); import('./pages/Support');
    };
    const id = window.requestIdleCallback ? window.requestIdleCallback(load, { timeout: 2500 }) : setTimeout(load, 1200);
    return () => (window.cancelIdleCallback ? window.cancelIdleCallback(id) : clearTimeout(id));
  }, []);

  const [menuOpen, setMenuOpen] = useState(false); // phones: the menu folds away
  useEffect(() => {
    window.scrollTo(0, 0);
    setMenuOpen(false);
  }, [pathname]);

  const out = async () => {
    // The dashboard locks; next time only the password is needed on this device
    await signOut();
    window.location.assign('/teacher');
  };

  const name = teacher?.fullName || access?.fullName || '';
  const id = teacher?.id || access?.teacherId;
  const notices = useResolvedNotices(id, !adminMode);
  const login = useLoginInfo(!adminMode);
  const openMenu = () => { setMenuOpen((o) => !o); window.scrollTo({ top: 0, behavior: 'smooth' }); };

  return (
    <div className="teacher-app min-h-screen bg-paper pb-20" data-sfx="teacher">
      {adminMode && (
        <div className="sticky top-0 z-40 flex flex-wrap items-center justify-between gap-2 bg-gold-400 px-4 py-2 text-sm font-semibold text-pine-950 print:hidden">
          <span className="flex items-center gap-2">
            <ShieldCheck className="h-4 w-4" aria-hidden="true" /> {t('admin.banner', { name, id })}
          </span>
          <Link to="/admin/portal?tab=teacherDash" className="inline-flex items-center gap-1 rounded-lg bg-pine-950 px-3 py-1 text-xs text-white hover:bg-pine-900">
            <ArrowLeft className="h-3.5 w-3.5" /> {t('admin.back')}
          </Link>
        </div>
      )}
      {/* Header card, in the same style as the Management Portal */}
      <header className="mx-auto max-w-6xl px-4 pt-5 sm:px-6 sm:pt-6 print:hidden">
        <div className="t-head">
          <Link to={base} className="t-head-brand">
            <span className="t-head-logo" aria-hidden="true">QIT</span>
            <span className="min-w-0">
              <span className="t-head-title">{t('brand.dashboard')}</span>
              <span className="t-head-sub">{t('brand.institute')}</span>
            </span>
          </Link>
          <div className="t-head-side">
            <div className="t-head-tags">
              {name && <span className="t-tag" title={access?.email || undefined}>{name}</span>}
              <span className="t-tag t-tag-gold" lang="en" title={t('brand.id')}>{id}</span>
            </div>
            <div className="t-head-actions">
              <button type="button" onClick={toggle} className="t-head-btn" aria-label={dark ? t('brand.light') : t('brand.dark')} title={dark ? t('brand.light') : t('brand.dark')}>
                {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
              </button>
              {id && <AlertsBell teacherId={id} base={base} adminMode={adminMode} />}
              <LangToggle compact className="t-head-btn" />
              <SoundToggle className="t-head-btn" label={false} />
              {!adminMode && (
                <button type="button" onClick={out} className="t-head-btn" aria-label={t('brand.signOut')} title={t('brand.signOut')}>
                  <LogOut className="h-4 w-4" /> <span className="hidden sm:inline">{t('brand.signOut')}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </header>
      <div className="mx-auto max-w-6xl px-4 pt-4 sm:px-6 print:hidden">
        {/* Phones: one button showing the current page; tap to open the menu */}
        <button
          type="button"
          className={`t-nav-toggle tsec-${page?.group || 'classes'}`}
          aria-expanded={menuOpen}
          aria-controls="teacher-menu"
          onClick={() => setMenuOpen((o) => !o)}
        >
          {page && <page.Icon className="h-5 w-5 shrink-0" aria-hidden="true" />}
          <span className="min-w-0 flex-1 truncate">{page ? t(`nav.${page.key}`) : t('brand.dashboard')}</span>
          <span className="text-xs font-semibold opacity-80">{t('menu.label')}</span>
          <ChevronDown className={`h-5 w-5 shrink-0 transition ${menuOpen ? 'rotate-180' : ''}`} aria-hidden="true" />
        </button>
        {!adminMode && <CredsBar info={login.info} />}
        <nav id="teacher-menu" className={`t-nav ${menuOpen ? 'is-open' : ''}`} aria-label={t('brand.dashboard')}>
          {GROUPS.map((g) => (
            <div key={g} role="group" aria-labelledby={`tg-${g}`} className={`t-nav-group tsec-${g}`}>
              <div id={`tg-${g}`} className="t-nav-title">{t(`menu.${g}`)}</div>
              <div className="t-nav-items">
                {NAV.filter((n) => n.group === g).map(({ path, key, Icon, end }) => (
                  <NavLink key={key} to={base + path} end={end} className={({ isActive }) => `t-nav-btn ${isActive ? 'active' : ''}`}>
                    <span className="t-nav-ico"><Icon className="h-4 w-4" aria-hidden="true" /></span>
                    <span>{t(`nav.${key}`)}</span>
                  </NavLink>
                ))}
              </div>
            </div>
          ))}
        </nav>
      </div>
      <main className={`t-page tsec-${page?.group || 'classes'} mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-8`}>
        {/* The menu stays in place while a page loads; each page eases in */}
        <Suspense fallback={<div className="qit-panel-skeleton" aria-busy="true" />}>
          <div key={pathname} className="qit-panel-in">
            <ResolvedNotices list={notices.list} onDismiss={notices.dismiss} />
            {!adminMode && id && (pathname === base || pathname === `${base}/`) && <PushInvite teacherId={id} />}
            <Outlet />
          </div>
        </Suspense>
      </main>
      {!adminMode && <EmergencyContact />}
      <TeacherDock base={base} menuOpen={menuOpen} onMenu={openMenu} badge={notices.list.length} />
      {!adminMode && <LoginNotice info={login.info} onOk={login.ack} />}
    </div>
  );
}
