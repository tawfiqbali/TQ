import { useCallback, useEffect, useState } from 'react';
import { KeyRound, ShieldCheck } from 'lucide-react';
import { ackLoginNotice, myLoginInfo } from '../lib/teacherData';
import { useT } from './i18n';
import { lockScroll } from '../lib/scrollLock';

// v156: the teacher's Teacher ID + password are always on their dashboard,
// and a changed password / ID is announced once in a big notice.
export function useLoginInfo(enabled) {
  const [info, setInfo] = useState(null);
  const load = useCallback(() => {
    if (!enabled) return;
    myLoginInfo().then((i) => setInfo(i || null)).catch(() => {});
  }, [enabled]);
  useEffect(() => { load(); }, [load]);
  const ack = async () => {
    setInfo((i) => (i ? { ...i, notice: null } : i));
    try { await ackLoginNotice(); } catch { /* shown again next time */ }
  };
  return { info, ack, reload: load };
}

export function CredsBar({ info }) {
  const { t } = useT();
  if (!info?.teacherId || !info.active) return null;
  return (
    <div className="t-creds" data-testid="t-creds" lang="en">
      <KeyRound className="h-4 w-4 shrink-0" aria-hidden="true" />
      <span>{t('creds.id')} <strong data-testid="creds-id">{info.teacherId}</strong></span>
      {info.password && <span>{t('creds.pw')} <strong data-testid="creds-pw">{info.password}</strong></span>}
    </div>
  );
}

export function LoginNotice({ info, onOk }) {
  const { t } = useT();
  const n = info?.notice;
  useEffect(() => (n ? lockScroll() : undefined), [n]);
  if (!n) return null;
  const idChanged = n.kind === 'id' && n.oldId && n.oldId !== n.teacherId;
  return (
    <div className="t-notice-wrap" role="presentation">
      <div className="t-notice" role="alertdialog" aria-modal="true" aria-labelledby="t-notice-title" data-testid="login-notice">
        <span className="t-notice-ico"><ShieldCheck className="h-7 w-7" aria-hidden="true" /></span>
        <h2 id="t-notice-title">{idChanged ? t('creds.newIdTitle') : t('creds.newPwTitle')}</h2>
        <p>{idChanged ? t('creds.newIdBody', { old: n.oldId }) : t('creds.newPwBody')}</p>
        <dl lang="en">
          <div><dt>{t('creds.id')}</dt><dd data-testid="notice-id">{n.teacherId}</dd></div>
          <div><dt>{t('creds.pw')}</dt><dd data-testid="notice-pw">{n.password || info.password}</dd></div>
        </dl>
        <p className="t-notice-small">{t('creds.keep')}</p>
        <button type="button" onClick={onOk} data-testid="notice-ok">{t('creds.ok')}</button>
      </div>
    </div>
  );
}
