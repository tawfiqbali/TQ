import { Languages } from 'lucide-react';
import { useT } from './i18n';

// Small building blocks shared by the Teacher Dashboard pages
export function PageHeader({ title, subtitle, action }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div className="t-page-head">
        <h1 className="text-2xl text-heading sm:text-3xl">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-ink/75">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function Card({ className = '', children, ...rest }) {
  return (
    <section className={`t-card p-5 sm:p-6 ${className}`} {...rest}>
      {children}
    </section>
  );
}

// accent: 'teal' | 'gold' | 'slate' | 'red' gives the tile its own colour; icon: a lucide icon
export function Stat({ label, value, hint, tone = 'pine', icon: Icon, accent }) {
  const tones = { pine: 't-sec-text', gold: 'text-gold-700 dark:text-gold-300', red: 'text-red-700 dark:text-red-300' };
  return (
    <div className={`t-tile p-4 ${accent ? `t-acc t-k-${accent}` : 't-sec-top'}`}>
      <div className="flex items-start justify-between gap-2">
        <div className="text-[11px] font-semibold uppercase tracking-[0.12em] text-ink/70">{label}</div>
        {Icon && <span className="t-tile-ico shrink-0"><Icon className="h-4 w-4" aria-hidden="true" /></span>}
      </div>
      <div className={`mt-1 font-display text-2xl ${accent ? 't-tile-val' : tones[tone]}`}>{value}</div>
      {hint && <div className="mt-0.5 text-xs text-ink/70">{hint}</div>}
    </div>
  );
}

const BADGE = {
  Paid: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-200',
  Pending: 'bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-200',
  Unpaid: 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-200',
  submitted: 'bg-sky-100 text-sky-800 dark:bg-sky-900/50 dark:text-sky-200',
  reviewed: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-200',
  needs_changes: 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-200',
  open: 'bg-sky-100 text-sky-800 dark:bg-sky-900/50 dark:text-sky-200',
  in_progress: 'bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-200',
  resolved: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-200',
  missing: 'bg-ink/5 text-ink/70',
};
export function Badge({ status, children }) {
  const { t } = useT();
  return (
    <span className={`inline-flex items-center whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold ${BADGE[status] || BADGE.missing}`}>
      {children || t(`badge.${status}`)}
    </span>
  );
}

// বাংলা ⇄ English switch (saved in this browser)
export function LangToggle({ className = '', compact = false }) {
  const { t, toggle, lang } = useT();
  return (
    <button
      type="button"
      onClick={toggle}
      lang={lang === 'bn' ? 'en' : 'bn'}
      aria-label={t('brand.switchLabel')}
      title={t('brand.switchLabel')}
      className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-sm font-semibold transition ${className}`}
    >
      <Languages className="h-4 w-4" aria-hidden="true" />
      <span className={compact ? 'hidden sm:inline' : ''}>{t('brand.switchTo')}</span>
      {compact && <span className="sm:hidden">{lang === 'bn' ? 'EN' : 'বাং'}</span>}
    </button>
  );
}

export function EmptyState({ title, children }) {
  return (
    <div className="rounded-2xl border border-dashed border-gray-300 bg-surface/70 px-6 py-10 text-center shadow-sm dark:border-white/15">
      <p className="font-semibold text-heading">{title}</p>
      {children && <div className="mx-auto mt-1.5 max-w-md text-sm text-ink/75">{children}</div>}
    </div>
  );
}
