import { useMemo } from 'react';
import { useTeacher } from './TeacherContext';
import { setStudentSchedule } from '../lib/teacherData';
import { useT } from './i18n';
import { useToast } from '../components/ui/Toast';
import WeeklyClassTimes from '../components/ui/WeeklyClassTimes';

// Bangladesh week order: Saturday first
export const WEEK_ORDER = [6, 0, 1, 2, 3, 4, 5];
export const bySlot = (a, b) => WEEK_ORDER.indexOf(a.weekday) - WEEK_ORDER.indexOf(b.weekday) || String(a.start_time).localeCompare(String(b.start_time));

/**
 * A student's weekly class times. No class times yet: "Add class time".
 * Afterwards: "Edit class time" with the saved days already selected.
 * pendingRef: used inside Edit student, whose Save changes button saves this too.
 */
export default function ScheduleEditor({ student, pendingRef }) {
  const { schedules, setSchedules } = useTeacher();
  const { t, weekday, weekdayShort, time, err } = useT();
  const toast = useToast();
  const rows = useMemo(() => schedules.filter((s) => s.student_id === student.id).sort(bySlot), [schedules, student.id]);
  const onSave = async (slots) => {
    let saved;
    try {
      saved = await setStudentSchedule(student.id, slots);
    } catch (e) {
      throw new Error(err(e.message));
    }
    setSchedules((list) => [...list.filter((s) => s.student_id !== student.id), ...(saved || [])]);
    toast(slots.length ? t('sch.savedTimes') : t('sch.deleted'));
  };
  const labels = {
    addTitle: t('sch.add'), editTitle: t('sch.editTitle'), days: t('sch.days'), start: t('sch.start'), length: t('sch.length'), min: t('sch.min', { n: '{n}' }),
    note: t('sch.note'), another: t('sch.another'), removeSet: t('sch.removeSet'), deleteAll: t('sch.deleteAll'), deleteQ: t('sch.deleteQ'), deleteMsg: t('sch.deleteMsg', { name: student.name }),
    deleteYes: t('sch.deleteAll'), cancel: t('sch.cancel'), save: t('sch.saveTimes'), saving: t('stu.saving'), pickDay: t('sch.pickDay'), clash: t('sch.clash', { day: '{day}', time: '{time}' }),
    hint: t('sch.bdTime'), applyHint: t('sch.applyHint'), unsaved: t('sch.unsaved'), pickTime: t('sch.pickTime'), needAmPm: t('sch.needAmPm'), hour: t('sch.hour'), minute: t('sch.minute'), done: t('sch.done'),
  };
  return <WeeklyClassTimes rows={rows} onSave={onSave} pendingRef={pendingRef} labels={labels} weekdayLabel={weekdayShort} weekdayLong={weekday} timeLabel={time} />;
}
