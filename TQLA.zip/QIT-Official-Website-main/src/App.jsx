import { lazy, Suspense } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { SiteDataProvider, useSiteData } from './context/SiteDataContext';
import { ToastProvider } from './components/ui/Toast';
import { ConfirmProvider } from './components/ui/Confirm';
import DatePickerHost from './components/ui/DatePickerHost';
import EnterToSave from './components/ui/EnterToSave';
import FullPageLoader from './components/ui/FullPageLoader';
import PublicLayout from './components/layout/PublicLayout';
import Home from './pages/Home';
import { pageImports } from './pages/pageImports';
const CoursesPage = lazy(pageImports.courses);
const AboutPage = lazy(pageImports.about);
const InstructorsPage = lazy(pageImports.instructors);
const ContactPage = lazy(pageImports.contact);
const NotFound = lazy(pageImports.notFound);
const PrivacyPage = lazy(pageImports.privacy);
const TermsPage = lazy(pageImports.terms);

// The admin panel is split into its own bundle so visitors never download it.
const AdminLogin = lazy(() => import('./admin/AdminLogin'));
const ConnectionCheck = lazy(() => import('./pages/ConnectionCheck'));
const BanglaEditor = lazy(() => import('./admin/BanglaEditor'));
const ProtectedRoute = lazy(() => import('./admin/ProtectedRoute'));
const AdminLayout = lazy(() => import('./admin/AdminLayout'));
const ManagementPortal = lazy(() => import('./admin/portal/ManagementPortal'));
const RoleRoute = lazy(() => import('./admin/RoleRoute'));
const Dashboard = lazy(() => import('./admin/Dashboard'));
const CourseManager = lazy(() => import('./admin/CourseManager'));
const ContentEditor = lazy(() => import('./admin/ContentEditor'));
const PeopleManager = lazy(() => import('./admin/PeopleManager'));
const InquiryManager = lazy(() => import('./admin/InquiryManager'));
const PricingManager = lazy(() => import('./admin/PricingManager'));
const MessageGenerator = lazy(() => import('./admin/MessageGenerator'));
const StaffReview = lazy(() => import('./admin/staff/StaffReview'));

// Google sign-in return page and the Teacher Dashboard (own bundle too)
const AuthCallback = lazy(() => import('./pages/AuthCallback'));
const TeacherLogin = lazy(() => import('./teacher/TeacherLogin'));
const TeacherGate = lazy(() => import('./teacher/TeacherContext').then((m) => ({ default: m.TeacherGate })));
const TeacherLayout = lazy(() => import('./teacher/TeacherLayout'));
const Onboarding = lazy(() => import('./teacher/Onboarding'));
const MyStudents = lazy(() => import('./teacher/pages/MyStudents'));
const Schedule = lazy(() => import('./teacher/pages/Schedule'));
const MonthlyReport = lazy(() => import('./teacher/pages/MonthlyReport'));
const Salary = lazy(() => import('./teacher/pages/Salary'));
const Support = lazy(() => import('./teacher/pages/Support'));
const Attendance = lazy(() => import('./teacher/pages/Attendance'));
const Progress = lazy(() => import('./teacher/pages/Progress'));
const StudentHistory = lazy(() => import('./teacher/pages/StudentHistory'));
const CounselorApp = lazy(() => import('./counselor/CounselorApp'));
const AdminTeacherGate = lazy(() => import('./teacher/TeacherContext').then((m) => ({ default: m.AdminTeacherGate })));

function AppRoutes() {
  const { ready } = useSiteData();
  if (!ready) return <FullPageLoader />;

  return (
    <Suspense fallback={<FullPageLoader />}>
      <Routes>
        <Route element={<PublicLayout />}>
          <Route index element={<Home />} />
          <Route path="courses" element={<CoursesPage />} />
          <Route path="about" element={<AboutPage />} />
          <Route path="instructors" element={<InstructorsPage />} />
          <Route path="contact" element={<ContactPage />} />
          <Route path="privacy" element={<PrivacyPage />} />
          <Route path="terms" element={<TermsPage />} />
          <Route path="*" element={<NotFound />} />
        </Route>

        <Route path="/auth/callback" element={<AuthCallback />} />
        <Route path="/check" element={<ConnectionCheck />} />

        {/* Teacher Dashboard: Google (Gmail) sign-in, onboarding first */}
        <Route path="/teacher/login" element={<TeacherLogin />} />
        <Route path="/teacher" element={<TeacherGate />}>
          <Route path="onboarding" element={<Onboarding />} />
          <Route element={<TeacherLayout />}>
            <Route index element={<MyStudents />} />
            <Route path="schedule" element={<Schedule />} />
            {/* Direct link for teachers: /teacher/report (?student=ID&month=August&year=2026) */}
            <Route path="report" element={<MonthlyReport />} />
            <Route path="salary" element={<Salary />} />
            <Route path="support" element={<Support />} />
            <Route path="attendance" element={<Attendance />} />
            <Route path="progress" element={<Progress />} />
            <Route path="history" element={<StudentHistory />} />
            <Route path="*" element={<Navigate to="/teacher" replace />} />
          </Route>
        </Route>

        {/* Executives: any teacher's dashboard, fully editable */}
        <Route
          path="/admin/teachers/:teacherId"
          element={
            <ProtectedRoute>
              <AdminTeacherGate />
            </ProtectedRoute>
          }
        >
          <Route element={<TeacherLayout />}>
            <Route index element={<MyStudents />} />
            <Route path="attendance" element={<Attendance />} />
            <Route path="schedule" element={<Schedule />} />
            <Route path="report" element={<MonthlyReport />} />
            <Route path="progress" element={<Progress />} />
            <Route path="history" element={<StudentHistory />} />
            <Route path="salary" element={<Salary />} />
            <Route path="support" element={<Support />} />
          </Route>
        </Route>

        <Route path="/admin/login" element={<AdminLogin />} />
        {/* v188: Academic Counselors (own Gmail + own password) */}
        <Route path="/counselor" element={<CounselorApp />} />
        <Route
          path="/admin"
          element={
            <ProtectedRoute>
              <AdminLayout />
            </ProtectedRoute>
          }
        >
          {/* Junior Admins and Executives: teacher list + monthly reports */}
          <Route path="review" element={<StaffReview />} />
          {/* Executives only: the portal, inquiries and the website editor */}
          <Route path="portal" element={<RoleRoute allowJunior><ManagementPortal /></RoleRoute>} />
          <Route path="inquiries" element={<RoleRoute><InquiryManager /></RoleRoute>} />
          {/* v162: opening /admin directly (bookmark, home-screen app) lands on the Management Portal;
              the menu's Dashboard link still opens the website dashboard */}
          <Route index element={<AdminIndex />} />
          <Route path="courses" element={<RoleRoute><CourseManager /></RoleRoute>} />
          <Route path="content" element={<RoleRoute><ContentEditor /></RoleRoute>} />
          <Route path="bangla" element={<RoleRoute><BanglaEditor /></RoleRoute>} />
          <Route path="people" element={<RoleRoute><PeopleManager /></RoleRoute>} />
          <Route path="pricing" element={<RoleRoute><PricingManager /></RoleRoute>} />
          <Route path="assign" element={<RoleRoute><MessageGenerator /></RoleRoute>} />
          <Route path="*" element={<Navigate to="/admin" replace />} />
        </Route>
      </Routes>
    </Suspense>
  );
}

function AdminIndex() {
  const loc = useLocation();
  if (loc.key === 'default') return <Navigate to="/admin/portal" replace />;
  return <RoleRoute><Dashboard /></RoleRoute>;
}

export default function App() {
  return (
    <SiteDataProvider>
      <ToastProvider>
        <ConfirmProvider>
          <AppRoutes />
          {/* v166: the same calendar for every date box */}
          <DatePickerHost />
          {/* v172: Enter saves / confirms */}
          <EnterToSave />
        </ConfirmProvider>
      </ToastProvider>
    </SiteDataProvider>
  );
}
