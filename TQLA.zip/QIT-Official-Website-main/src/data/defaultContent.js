// Everything the admin panel can edit lives here. On first load this is the
// website's content; after that, edits saved in the admin panel take over.
//
// CONTENT_VERSION: bump it when the shape of this file changes. Saved content
// from an older version is replaced by these defaults on the next visit.
export const CONTENT_VERSION = 3;

export const INQUIRY_STATUSES = ['new', 'contacted', 'enrolled', 'closed'];

// Trial form choices. WhatsApp is deliberately listed before Zoom.
export const PLATFORMS = ['WhatsApp', 'Google Meet', 'Zoom', 'Microsoft Teams'];
export const TEACHER_OPTIONS = ['Male', 'Female'];
export const MEDIUM_OPTIONS = ['English', 'Bangla'];

export const BRAND_NAME = 'Quran International Institute';

export const defaultContent = {
  version: CONTENT_VERSION,
  // One-time content updates already included in these defaults (see migrate())
  appliedUpdates: ['board-members-2026-09', 'countries-20-plus', 'board-photos-jpg', 'hero-slide-4', 'board-portraits-v2', 'hr-number-1703', 'spotlight-v1', 'accounts-number-987261', 'board-photos-v3', 'ceo-number-1334059560', 'pricing-rules-v1', 'pricing-currency-auto', 'whyus-cards-v1', 'founder-number-1928', 'spotlight-v2', 'facebook-page', 'brand-name-v63'],

  site: {
    brand: {
      name: BRAND_NAME,
      shortName: 'QIT',
      subtitle: 'Online Quran Academy',
      tagline: 'One-to-one Quran and Islamic studies classes for children and adults, taught online by certified teachers.',
      closingLine: 'Assalamu alaikum — welcome, always.',
    },
    announcement: {
      enabled: false,
      text: 'New term enrolment is open. Your first class is free.',
      linkLabel: 'Book a free trial',
      linkHref: '/contact?type=trial',
    },
    hero: {
      badge: 'Trusted by families worldwide',
      headline: 'Certified Quran Learning for All Ages – Tajweed & Hifz from Home',
      highlight: 'Tajweed & Hifz',
      subheadline:
        'Learn one-to-one with certified Quran tutors who correct every letter, at your child’s pace. Fully flexible scheduling — live lessons on WhatsApp, Google Meet, Zoom or Microsoft Teams, around school, work and prayer times.',
      primaryCtaLabel: 'Book a Free Trial',
      secondaryCtaLabel: 'Explore Courses',
      platforms: ['WhatsApp', 'Google Meet', 'Zoom', 'Microsoft Teams'],
      // Slideshow at the top right. Add, remove or reorder in Admin → Site content → Hero.
      slides: ['/images/hero-qit-4.webp', '/images/hero-qit-1.webp', '/images/hero-qit-2.webp', '/images/hero-qit-3.webp'],
      slideSeconds: 2.5, // how long each photo stays before sliding on
      imageUrl: '/images/quran-live.webp',
      notifyTitle: 'Class update',
      notifyText: 'New one-to-one class groups open this week',
      trustTitle: 'Every tutor certified & vetted',
      trustText: 'Background-checked · female teachers available',
    },
    stats: {
      students: '1,200+',
      countries: '20+',
      rating: '4.9/5',
    },
    coursesSection: {
      eyebrow: 'Courses & fees',
      heading: 'Simple monthly plans',
      intro:
        'Every course starts with a free trial class and a placement check, so nobody sits in a class that bores or overwhelms them.',
      standardBullets: ['Live One-to-One Classes', 'Flexible Schedule', 'Qualified Teachers'],
      classLengthNote: 'Hifz classes are a minimum of 1.5 hours each. All other classes are 45–50 minutes.',
    },
    trial: {
      eyebrow: 'The trial class',
      heading: 'One dedicated group, so nothing gets lost',
      summary: 'One dedicated class group where One teacher, student & 2 admins will be present.',
      body: 'Every student gets their own class group with the teacher and two admins in it. Scheduling, reminders and progress all happen in that one place — and you can reach an admin at any time.',
      steps: [
        'A dedicated class group is created just for you',
        'One teacher, the student and two admins are in that group',
        'You get the class link for WhatsApp, Google Meet, Zoom or Microsoft Teams',
        'After the class you receive a short level report and a course suggestion',
      ],
      imageUrl: '/images/trial-class.webp',
    },
    whyUs: {
      eyebrow: 'Why us',
      heading: 'Consistency beats intensity when a child is learning to read',
      // The four benefit cards (Admin → Site content → Why us)
      cards: [
        { id: 'f1', icon: 'BadgeCheck', title: 'Certified, vetted teachers', description: 'Ijazah-holding teachers with background checks and years of classroom practice — not a marketplace of strangers.' },
        { id: 'f2', icon: 'Users', title: 'One-to-one, never crowded', description: 'Your child gets the whole lesson. A teacher tracks what they stumble on and comes back to it next week.' },
        { id: 'f3', icon: 'CalendarCheck', title: 'Fits your week', description: 'Pick the slots that suit your timezone, pause when exams come, and reschedule without losing your teacher.' },
        { id: 'f4', icon: 'MessagesSquare', title: 'Parents kept in the loop', description: 'A short written report after every four classes, plus an open line to your teacher between lessons.' },
      ],
      promiseLabel: 'Our promise',
      promiseQuote: 'Teach my child to read the Quran properly, and tell me honestly how they are doing.',
      promiseSub: 'That is the whole brief. Everything below is how we keep it.',
      promisePoints: ['Free trial class, no card', 'Sibling-friendly scheduling', 'Female teachers available on request'],
      imageUrl: '/images/why-us.webp',
    },
    // Rotating message strip at the top of the home page
    // Vimeo videos above the faculty ticker (one link per line in the admin panel)
    videoSection: {
      enabled: true,
      eyebrow: '',
      heading: '',
      videos: ['https://vimeo.com/1230464444'],
    },
    facultyTicker: {
      enabled: true,
      seconds: 4,
      messages: [
        'Learn from expert instructors from Al-Azhar University, Egypt!',
        'Top-tier scholars from Karachi, Pakistan!',
        'Dedicated Female Mentors from Australia, UAE, and Egypt!',
      ],
    },
    // "Global Expert Instructors" badges (Spotlight and Why us)
    globalFaculty: {
      title: 'Global Expert Instructors',
      text: 'Our teachers include graduates and scholars from around the Muslim world.',
      places: ['Al-Azhar University', 'Egypt', 'Karachi, Pakistan', 'Australia', 'UAE'],
    },
    featured: {
      enabled: true,
      imageUrl: '/images/spotlight-qit-v2.webp',
      eyebrow: 'Spotlight',
      heading: 'Quran online, one-to-one — personalised guidance for a brighter Hereafter',
      text: 'Your teacher, your pace, your schedule. Every class is live and one-to-one, with a certified teacher who corrects every letter.',
      ctaLabel: 'Book a Free Trial',
    },
    testimonialsSection: {
      eyebrow: 'Testimonials',
      heading: 'Families stay because the teaching is honest',
      scrollSeconds: 8, // seconds each review takes to scroll past (higher = slower)
    },
    boardSection: {
      eyebrow: 'Our leadership',
      heading: 'QIT Board Members',
      intro: 'The people who guide Quran International Institute and look after every student, teacher and family.',
    },
    faqSection: {
      eyebrow: 'FAQ',
      heading: 'Questions parents ask before the first class',
      intro: 'Anything missing? Ask during your free trial — teachers answer directly, not a sales desk.',
    },
    cta: {
      eyebrow: 'Book free trial',
      heading: 'One free lesson, and you will know if this is the right teacher',
      body: 'Fill in the short form and an admin will open your class group on WhatsApp with the teacher — or message us directly.',
      points: ['45 minutes', 'No card required', 'Slots this week'],
      imageUrl: '/images/cta-class.webp',
    },
    about: {
      heading: 'Quran education with a teacher, not a video',
      body:
        'Quran International Institute teaches children and adults one-to-one, online, with certified teachers who listen to every letter and correct it with patience.\n\nEvery student gets a dedicated class group with their teacher and two admins, a clear plan, and honest feedback on how they are doing.',
      mission: 'To make sound, personal Quran teaching available to every Muslim household, wherever they live.',
      values: [
        'Sincerity in teaching and learning',
        'Accuracy in recitation, checked verse by verse',
        'Patience with every age and pace',
        'Clear, regular communication with parents',
      ],
    },
    contact: {
      email: 'qitoffice.info@gmail.com',
      phone: '+880 1928-616108',
      phoneNote: 'Call & WhatsApp',
      whatsapp: '+8801928616108',
      address: '9/15, Junayed Complex, Delta Mor, Rajashon Road, Savar-1340, Dhaka',
      hours: 'Classes run 7 days a week. We reply to messages the same day.',
    },
    social: {
      facebook: 'https://www.facebook.com/share/1TUUevQ2Cp/?mibextid=wwXIfr',
      instagram: '',
      youtube: '',
    },
    whatsappMessages: {
      buy: 'Assalamu alaikum! I would like to enrol in {course} — {plan}. Price shown on the website: {price} / monthly.',
      general: 'Assalamu alaikum! I would like to know more about your Quran classes.',
    },
    // Buy Course and Book Trial form: which details a visitor must give
    forms: {
      buyNeedsForm: true,
      requireName: true,
      requireWhatsapp: true,
      requireCountry: true,
      requireCourse: false,
      requireTime: false,
      requireDate: false,
      // After Submit: the message that asks the visitor to send it on WhatsApp too.
      // Empty = the built-in wording (English and Bangla).
      afterTitle: '',
      afterText: '',
      afterButton: '',
    },
    // Student assignment message (Admin → Assignment message): mandatory fields
    assignment: {
      requireStudent: true,
      requireWhatsapp: true,
      requireCountry: false,
      requireCourse: false,
      requireTime: false,
      requireDate: false,
      requireDuration: false,
      requireDays: false,
      requirePayment: false,
      requireNotes: false,
    },
    settings: {
      autoCurrency: true,
      baseCurrency: 'USD',
    },
  },

  courses: [
    {
      id: 'quran-for-kids',
      title: 'Quran For Kids',
      subtitle: 'Ages 4+ · One-to-one',
      icon: 'BookOpen',
      bullets: ['Noorani Qaida, letters and sounds', 'Short surahs and gentle Tajweed'],
      // min/max: worldwide price in USD (converted for each visitor)
      // bdtMin/bdtMax: fixed price shown to visitors in Bangladesh
      plans: [
        { label: '2–3 days a week', min: 35, max: 40, bdtMin: 3000, bdtMax: 3500 },
        { label: '4–5 days a week', min: 50, max: 60, bdtMin: 4000, bdtMax: 5000 },
      ],
      classLength: '45–50 minutes per class',
      featured: true,
      published: true,
    },
    {
      id: 'quran-for-adults',
      title: 'Quran For Adults',
      subtitle: 'Beginner to advanced',
      icon: 'GraduationCap',
      bullets: ['Beginner to advanced recitation', 'Tajweed corrected live'],
      // min/max: worldwide price in USD (converted for each visitor)
      // bdtMin/bdtMax: fixed price shown to visitors in Bangladesh
      plans: [
        { label: '2–3 days a week', min: 35, max: 40, bdtMin: 3000, bdtMax: 3500 },
        { label: '4–5 days a week', min: 50, max: 60, bdtMin: 4000, bdtMax: 5000 },
      ],
      classLength: '45–50 minutes per class',
      featured: true,
      published: true,
    },
    {
      id: 'quran-hifz',
      title: 'Quran Hifz / Memorization',
      subtitle: 'Structured memorisation',
      icon: 'Moon',
      bullets: ['Daily new lesson and revision', 'Written plan for each Juz', 'Weekly progress reports'],
      plans: [{ label: '5–6 days a week', min: 85, max: 85, bdtMin: 10000, bdtMax: 10000 }],
      classLength: 'Minimum 1.5 hours per class',
      featured: true,
      published: true,
    },
    {
      id: 'islamic-studies-fiqh',
      title: 'Islamic Studies & Fiqh',
      subtitle: 'Essential knowledge · All ages',
      icon: 'Landmark',
      bullets: ['Islamic manners and character', 'Worship and everyday Fiqh'],
      plans: [
        { label: '2–3 days a week', min: 40, max: 40, bdtMin: 4000, bdtMax: 4000 },
        { label: '4–5 days a week', min: 50, max: 50, bdtMin: 5000, bdtMax: 5000 },
      ],
      classLength: '45–50 minutes per class',
      featured: true,
      published: true,
    },
  ],

  instructors: [
    {
      id: 'ustadh-yusuf',
      name: 'Ustadh Yusuf',
      title: 'Tajweed tutor',
      specialties: 'Tajweed, Nazra, Hifz revision',
      bio: 'Corrects every letter with patience and keeps parents updated after every class.',
      experience: '',
      languages: 'Arabic, English, Bangla',
      photoUrl: '',
    },
  ],

  testimonials: [
    {
      id: 't1',
      name: 'Samira N.',
      role: 'Manchester, UK',
      quote: 'My son used to dread Quran class. Now he asks for extra sessions. His teacher notices the small mistakes before I ever hear them.',
      rating: 5,
      course: 'Recitation & Tajweed',
    },
    {
      id: 't2',
      name: 'Ayesha R.',
      role: 'Toronto, Canada',
      quote: 'We tried two other academies. The difference here is the placement check — our daughter started where she actually was, not two pages behind.',
      rating: 5,
      course: 'Noorani Qaida',
    },
    {
      id: 't3',
      name: 'Mohamed K.',
      role: 'Kuala Lumpur, Malaysia',
      quote: 'The weekly revision plan kept my son honest. Two years in, he has completed six juz with his meaning lessons alongside.',
      rating: 5,
      course: 'Hifz Program',
    },
  ],

  features: [
    {
      id: 'f1',
      icon: 'BadgeCheck',
      title: 'Certified, vetted teachers',
      description: 'Ijazah-holding teachers with background checks and years of classroom practice — not a marketplace of strangers.',
    },
    {
      id: 'f2',
      icon: 'Users',
      title: 'One-to-one, never crowded',
      description: 'Your child gets the whole lesson. A teacher tracks what they stumble on and comes back to it next week.',
    },
    {
      id: 'f3',
      icon: 'CalendarCheck',
      title: 'Fits your week',
      description: 'Pick the slots that suit your timezone, pause when exams come, and reschedule without losing your teacher.',
    },
    {
      id: 'f4',
      icon: 'ShieldCheck',
      title: 'Parents kept in the loop',
      description: 'A short written report after every four classes, plus an open line to your teacher between lessons.',
    },
  ],

  // Board members. tier 1 = Founder row (side by side), 2 = CEO (on its own),
  // 3 = team row (four side by side). Edit in Admin → Board, teachers & reviews → Board.
  // A member without a photo shows a placeholder until one is added.
  board: [
    { id: 'b1', tier: 1, role: 'Founder & Chairman', name: 'MD. FOYZUL KARIM ABDULLAH', whatsapp: '+880 1928-616108', email: 'hafez.abdullah66@gmail.com', bio: '', photoUrl: '/images/board/md-foyzul-karim-abdullah.jpg?v=5' },
    { id: 'b2', tier: 1, role: 'Co-Founder', name: 'MD IBRAHIM SAMI', whatsapp: '+966 55 966 4257', email: 'ibrahimsami032@gmail.com', bio: '', photoUrl: '/images/board/md-ibrahim-sami.jpg?v=5' },
    { id: 'b3', tier: 2, role: 'Chief Executive Officer (CEO)', name: 'MD. GOLAM MUNTASIR MUHIT', whatsapp: '+880 133-4059560', email: 'gmmuhit1632@gmail.com', bio: '', photoUrl: '/images/board/md-golam-muntasir-muhit.jpg?v=5' },
    { id: 'b4', tier: 3, role: 'Head of Accounts', name: 'JUBAYER HOSSAIN', whatsapp: '+880 1851-987261', email: 'jubayer.hossainfm@gmail.com', bio: '', photoUrl: '/images/board/jubayer-hossain.jpg?v=5' },
    { id: 'b5', tier: 3, role: 'Head of Marketing', name: 'MD TAWFIQ RAHMAN', whatsapp: '+880 1405-208446', email: 'mdmahamud820240@gmail.com', bio: '', photoUrl: '/images/board/md-tawfiq-rahman.jpg?v=5' },
    { id: 'b6', tier: 3, role: 'HR Manager', name: 'MD FAISAL HOSSAIN', whatsapp: '+880 1703-788889', email: 'faisalhossain@gmail.com', bio: '', photoUrl: '/images/board/md-faisal-hossain.jpg?v=5' },
    { id: 'b7', tier: 3, role: 'Head of Logistics', name: 'HM ASHIKUR RAHMAN', whatsapp: '+880 1624-186720', email: 'abdullahalashik.12@gmail.com', bio: '', photoUrl: '/images/board/hm-ashikur-rahman.jpg?v=2' },
  ],

  // Answers are starting points — review them in Admin → Teachers & reviews → FAQ.
  faqs: [
    {
      id: 'q1',
      question: 'How does the free trial work?',
      answer:
        'Fill in the trial form or message us on WhatsApp. We create one dedicated class group where one teacher, the student and two admins are present, send you the class link, and after the 45-minute class you get a short level report and a course suggestion.',
    },
    {
      id: 'q2',
      question: 'What ages do you teach?',
      answer: 'Children from age 4 and adults of any age, from complete beginners to students polishing their Tajweed or memorising the Quran.',
    },
    {
      id: 'q3',
      question: 'How long is each class?',
      answer: 'Hifz classes are a minimum of 1.5 hours each. All other classes are 45–50 minutes.',
    },
    {
      id: 'q4',
      question: 'Are female teachers available?',
      answer: 'Yes. Choose "Female" as your preferred teacher on the trial form and we will match you with a female teacher.',
    },
    {
      id: 'q5',
      question: 'What do we need to join?',
      answer: 'A phone, tablet or computer with a stable internet connection and WhatsApp, Google Meet, Zoom or Microsoft Teams. A headset helps the teacher hear every letter clearly.',
    },
    {
      id: 'q6',
      question: 'Can we pause or change the schedule?',
      answer: 'Yes. Tell an admin in your class group and we will move your slots or pause classes, for example around exams or travel, while keeping the same teacher.',
    },
  ],
};

// Country-specific prices (Admin → Pricing & currency). Each rule gives, for a
// country, a currency and a price for every plan of every course (listed in
// the same order as the course's plans). Visitors from countries without a
// rule see the USD prices (or converted prices, if the fallback is "convert").
defaultContent.site.pricing = {
  rules: [
    {
      id: 'BD',
      country: 'BD',
      currency: 'BDT',
      prices: Object.fromEntries(
        defaultContent.courses.map((c) => [c.id, c.plans.map((p) => ({ min: p.bdtMin ?? '', max: p.bdtMax ?? '' }))]),
      ),
    },
  ],
};
