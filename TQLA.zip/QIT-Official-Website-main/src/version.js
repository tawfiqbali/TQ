// Shown in the footer and admin sidebar so you can confirm which version is live.
export const SITE_VERSION = '192';
// The database script (supabase/teacher-dashboard.sql) this version needs. Raise it
// together with qit_sql_version() in that file whenever the SQL changes.
export const SQL_VERSION = 158;
