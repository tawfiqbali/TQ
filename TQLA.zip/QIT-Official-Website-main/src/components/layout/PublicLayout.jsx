import { Suspense, useEffect } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { TrialModalProvider } from '../../context/TrialModalContext';
import { CurrencyProvider } from '../../context/CurrencyContext';
import { ThemeProvider } from '../../context/ThemeContext';
import AnnouncementBar from './AnnouncementBar';
import Navbar from './Navbar';
import Footer from './Footer';
import FloatingActions from './FloatingActions';
import { pageImports } from '../../pages/pageImports';
import useScrollEffects from '../../hooks/useScrollEffects';
import { LanguageProvider, useLanguage } from '../../i18n/LanguageContext';

// Fetch the inner pages in the background once the browser is idle, so
// clicking a link later feels instant.
function usePrefetchPages() {
  useEffect(() => {
    const run = () => Object.values(pageImports).forEach((load) => load().catch(() => {}));
    const idle = window.requestIdleCallback || ((cb) => setTimeout(cb, 1500));
    const id = idle(run);
    return () => (window.cancelIdleCallback || clearTimeout)(id);
  }, []);
}

function SkipLink() {
  const { t } = useLanguage();
  return (
    <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:rounded-lg focus:bg-surface focus:px-4 focus:py-2">
      {t('common.skipToContent')}
    </a>
  );
}

export default function PublicLayout() {
  const { pathname, hash } = useLocation();
  usePrefetchPages();
  useScrollEffects();

  // Scroll to #section links (e.g. /#courses), otherwise to the top
  useEffect(() => {
    if (!hash) {
      window.scrollTo(0, 0);
      return undefined;
    }
    // Sections lower on the page load a moment later, so keep trying briefly
    let tries = 0;
    let t;
    const go = () => {
      const el = document.getElementById(hash.slice(1));
      if (el) el.scrollIntoView({ behavior: 'smooth' });
      else if (tries++ < 40) t = setTimeout(go, 100);
    };
    t = setTimeout(go, 60);
    return () => clearTimeout(t);
  }, [pathname, hash]);

  return (
    <LanguageProvider>
    <ThemeProvider>
    <CurrencyProvider>
      <TrialModalProvider>
        <SkipLink />
        <AnnouncementBar />
        <Navbar />
        <main id="main">
          <Suspense fallback={<div className="min-h-[70vh]" aria-busy="true" />}>
            <Outlet />
          </Suspense>
        </main>
        <Footer />
        <FloatingActions />
      </TrialModalProvider>
    </CurrencyProvider>
    </ThemeProvider>
    </LanguageProvider>
  );
}
