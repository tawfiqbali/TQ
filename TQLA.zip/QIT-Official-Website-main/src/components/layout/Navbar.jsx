import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import useScrollSpy from '../../hooks/useScrollSpy';
import { Link, useLocation } from 'react-router-dom';
import { ChevronDown, LayoutDashboard, Menu, Moon, Sun, X } from 'lucide-react';
import useAdminSession from '../../hooks/useAdminSession';
import { useTrialModal } from '../../context/TrialModalContext';
import LogoMark from '../shared/LogoMark';
import { useTheme } from '../../context/ThemeContext';
import { useContent, useLanguage } from '../../i18n/LanguageContext';
import { BRAND_NAME } from '../../data/defaultContent';
import LanguageToggle from './LanguageToggle';

// Home-page sections, plus the contact page
// `spy` is the id of the home-page section that lights the link up
// `key` is the label in the language dictionaries (nav.*)
export const NAV_LINKS = [
  { to: '/#courses', key: 'nav.courses', spy: 'courses' },
  { to: '/#why-us', key: 'nav.whyUs', spy: 'why-us' },
  { to: '/#testimonials', key: 'nav.testimonials', spy: 'testimonials' },
  { to: '/#faq', key: 'nav.faq', spy: 'faq' },
  { to: '/#board', key: 'nav.board', spy: 'board' },
  { to: '/contact', key: 'nav.contact', spy: 'site-contact' },
];
// Shown directly under the header on phones (the rest sits under the menu button)
const QUICK = ['courses', 'why-us', 'testimonials', 'site-contact'].map((k) => NAV_LINKS.find((l) => l.spy === k));
const SPY_IDS = NAV_LINKS.map((l) => l.spy);

export default function Navbar() {
  const content = useContent();
  const { lang, t, bnAllowed } = useLanguage();
  const { openTrial } = useTrialModal();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { pathname: currentPath } = useLocation();

  // Scroll-spy: which nav link is "current"
  const spied = useScrollSpy(SPY_IDS, currentPath === '/');
  const activeKey = currentPath === '/contact' ? 'site-contact' : currentPath === '/courses' ? 'courses' : spied;
  const navRef = useRef(null);
  const linkRefs = useRef({});
  const [pill, setPill] = useState({ left: 0, width: 0 });
  const placePill = useCallback(() => {
    const el = linkRefs.current[activeKey];
    const nav = navRef.current;
    if (!el || !nav || !el.offsetWidth) return setPill((p) => (p.width ? { ...p, width: 0 } : p));
    setPill({ left: el.offsetLeft, width: el.offsetWidth });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeKey, lang]);
  useLayoutEffect(() => {
    placePill();
  }, [placePill]);
  useEffect(() => {
    window.addEventListener('resize', placePill);
    document.fonts?.ready.then(placePill);
    return () => window.removeEventListener('resize', placePill);
  }, [placePill]);
  const { pathname, hash } = useLocation();
  const { brand } = content.site;
  const { theme, toggleTheme } = useTheme();

  const adminEmail = useAdminSession();
  const roundBtn =
    'inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-ink/15 bg-surface text-brand shadow-sm transition hover:-translate-y-0.5 hover:border-ink/30';
  const quickActions = (
    <>
      {/* বাংলা is offered only in Bangladesh, Malaysia, Singapore and the Middle East */}
      {bnAllowed && <LanguageToggle />}
      <button
        type="button"
        onClick={toggleTheme}
        className={roundBtn}
        aria-label={theme === 'dark' ? t('header.toLight') : t('header.toDark')}
        aria-pressed={theme === 'dark'}
        title={theme === 'dark' ? t('header.lightMode') : t('header.darkMode')}
      >
        {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
      </button>
    </>
  );

  useEffect(() => setOpen(false), [pathname, hash]);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`sticky top-0 z-40 transition-colors ${
        scrolled ? 'border-b border-ink/10 bg-paper/85 shadow-sm backdrop-blur-md' : 'bg-paper/60 backdrop-blur'
      }`}
    >
      <div className="container-page flex h-[76px] items-center justify-between gap-2 sm:gap-6 xl:gap-3 2xl:gap-6">
        <Link to="/" className="flex min-w-0 items-center gap-1.5 min-[380px]:gap-2 sm:gap-3 xl:shrink-0" aria-label={t('header.home', { brand: brand.name })}>
          <LogoMark className="h-9 w-7 shrink-0 min-[380px]:h-11 min-[380px]:w-9" />
          <span className="min-w-0 leading-tight">
            <span className="block text-[12px] font-semibold min-[380px]:text-[14px] leading-tight text-heading sm:text-xl xl:whitespace-nowrap xl:text-lg 2xl:text-xl">{brand.name || BRAND_NAME}</span>
            <span className="hidden truncate text-[10px] font-semibold uppercase tracking-[0.22em] text-gold-500 sm:block">{brand.subtitle || 'Online Quran Academy'}</span>
          </span>
        </Link>

        <nav ref={navRef} className="qit-dock relative hidden items-center gap-1 whitespace-nowrap xl:flex 2xl:gap-2" aria-label="Main">
          {/* Sliding pill that follows the section in view */}
          <span
            aria-hidden="true"
            className="pointer-events-none absolute top-1/2 h-9 -translate-y-1/2 rounded-full bg-gradient-to-r from-pine-900 to-pine-700 shadow-[0_6px_16px_-6px_rgba(3,71,79,.6)] transition-all duration-300 ease-out dark:from-pine-700 dark:to-pine-500"
            style={{ left: pill.left, width: pill.width, opacity: pill.width ? 1 : 0 }}
          />
          {NAV_LINKS.map((l) => {
            const isActive = activeKey === l.spy;
            return (
              <Link
                key={l.to}
                to={l.to}
                ref={(el) => (linkRefs.current[l.spy] = el)}
                aria-current={isActive ? 'location' : undefined}
                className={`qit-dock-item relative z-10 rounded-full px-3 py-2 text-[14px] font-medium 2xl:px-3.5 2xl:text-[15px] ${
                  isActive ? 'text-white' : 'text-ink/75 hover:bg-tint hover:text-brand'
                }`}
              >
                {t(l.key)}
              </Link>
            );
          })}
        </nav>

        <div className="hidden items-center gap-2 xl:flex">
          {quickActions}
          {adminEmail && (
            <Link to="/admin" className="btn-outline btn-sm">
              <LayoutDashboard className="h-4 w-4" />
              {t('header.admin')}
            </Link>
          )}
          <button onClick={openTrial} className="btn-primary ml-1 whitespace-nowrap px-4 py-3 2xl:px-5">
            {t('header.bookFreeTrial')}
          </button>
        </div>

        <div className="flex shrink-0 items-center gap-1 sm:gap-1.5 xl:hidden">
          {quickActions}
          <button onClick={openTrial} className="btn-primary hidden whitespace-nowrap px-4 py-2.5 md:inline-flex">
            {t('header.bookFreeTrial')}
          </button>
          <button
            className="inline-flex h-10 w-10 items-center min-[380px]:h-11 min-[380px]:w-11 justify-center rounded-full border border-ink/15 bg-surface text-brand shadow-sm"
            onClick={() => setOpen((o) => !o)}
            aria-expanded={open}
            aria-controls="mobile-nav"
            aria-label={open ? t('header.closeMenu') : t('header.openMenu')}
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Phones and tablets: the most used sections stay one tap away; the rest is under the menu button */}
      <nav className="qit-quicknav xl:hidden" aria-label="Quick links" data-testid="quicknav">
        <div className="container-page flex items-center justify-between gap-1 overflow-x-auto py-1.5">
          {QUICK.map((l) => (
            <Link key={l.to} to={l.to} aria-current={activeKey === l.spy ? 'location' : undefined}
              className={`shrink-0 whitespace-nowrap rounded-full px-2.5 py-1.5 text-center text-[12.5px] min-[400px]:px-3 min-[400px]:text-[13px] font-semibold transition ${activeKey === l.spy ? 'bg-pine-900 text-white dark:bg-pine-700' : 'bg-tint text-brand hover:bg-pine-100 dark:hover:bg-white/10'}`}>
              {t(l.key)}
            </Link>
          ))}
          <button type="button" onClick={() => setOpen((o) => !o)} aria-expanded={open} aria-controls="mobile-nav"
            className="inline-flex shrink-0 items-center gap-0.5 whitespace-nowrap rounded-full border border-ink/15 px-2.5 py-1.5 text-[12.5px] font-semibold text-ink/75">
            {t('header.more')} <ChevronDown className={`h-3.5 w-3.5 transition ${open ? 'rotate-180' : ''}`} aria-hidden="true" />
          </button>
        </div>
      </nav>

      {open && (
        <div id="mobile-nav" className="border-t border-ink/10 bg-paper xl:hidden">
          <nav className="container-page flex flex-col py-3" aria-label="Mobile">
            {NAV_LINKS.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                aria-current={activeKey === l.spy ? 'location' : undefined}
                className={`rounded-xl px-3 py-3 text-base ${activeKey === l.spy ? 'bg-pine-900 font-semibold text-white dark:bg-pine-700' : 'text-ink/80 hover:bg-tint'}`}
              >
                {t(l.key)}
              </Link>
            ))}
            <div className="mt-3 flex flex-col gap-2 border-t border-ink/10 pt-4">
              <button onClick={openTrial} className="btn-primary py-3">
                {t('header.bookFreeTrial')}
              </button>
              {adminEmail && (
                <Link to="/admin" className="btn-outline py-3">
                  <LayoutDashboard className="h-4 w-4" />
                  {t('header.admin')}
                </Link>
              )}
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
