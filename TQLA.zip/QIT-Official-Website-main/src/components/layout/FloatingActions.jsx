import { Mail, Phone } from 'lucide-react';
import { CONTACT_COLORS, WhatsAppIcon } from '../shared/BrandIcons';
import { useContent, useLanguage } from '../../i18n/LanguageContext';
import { gmailLink, telLink, whatsappLink } from '../../lib/utils';

// Round Mail, Call and WhatsApp buttons fixed to the bottom-right corner
export default function FloatingActions() {
  const content = useContent();
  const { t } = useLanguage();
  const { contact, whatsappMessages } = content.site;
  const wa = whatsappLink(contact.whatsapp, whatsappMessages?.general);
  const tel = telLink(contact.phone);
  const base = 'qit-fab flex h-14 w-14 items-center justify-center rounded-full text-white shadow-float-lg transition hover:-translate-y-1';

  return (
    <div className="fixed bottom-5 right-5 z-30 flex flex-col items-center gap-3">
      {contact.email && (
        <a
          href={gmailLink(contact.email)}
          target="_blank"
          rel="noreferrer"
          aria-label={t('floating.email', { email: contact.email })}
          title={contact.email}
          className={`${base} h-12 w-12 ${CONTACT_COLORS.email}`}
        >
          <Mail className="h-5 w-5" />
        </a>
      )}
      {tel && (
        <a href={tel} aria-label={t('floating.call', { phone: contact.phone })} title={t('floating.callTitle')} className={`${base} h-12 w-12 ${CONTACT_COLORS.phone}`}>
          <Phone className="h-5 w-5" />
        </a>
      )}
      {wa && (
        <a href={wa} target="_blank" rel="noreferrer" aria-label={t('floating.whatsapp')} title="WhatsApp" className={`${base} ${CONTACT_COLORS.whatsapp}`}>
          <WhatsAppIcon className="h-7 w-7" />
        </a>
      )}
    </div>
  );
}
