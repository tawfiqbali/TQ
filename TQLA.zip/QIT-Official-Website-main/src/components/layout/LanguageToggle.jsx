import { useLanguage } from '../../i18n/LanguageContext';

// "English | বাংলা" switch for the header. The active language sits on a filled pill.
const OPTIONS = [
  { code: 'en', short: 'English', nameKey: 'header.english', htmlLang: 'en' },
  { code: 'bn', short: 'বাংলা', nameKey: 'header.bangla', htmlLang: 'bn' },
];

export default function LanguageToggle({ className = '' }) {
  const { lang, setLang, t } = useLanguage();
  return (
    <div role="group" aria-label={t('header.language')} className={`lang-toggle inline-flex h-10 shrink-0 items-center rounded-full border border-ink/15 bg-surface p-[3px] shadow-sm sm:p-1 ${className}`}>
      {OPTIONS.map((o) => {
        const active = lang === o.code;
        return (
          <button
            key={o.code}
            type="button"
            lang={o.htmlLang}
            onClick={() => setLang(o.code)}
            aria-pressed={active}
            aria-label={t(o.nameKey)}
            title={t(o.nameKey)}
            className={`flex h-8 min-w-[1.95rem] items-center justify-center rounded-full px-1 text-[12px] min-[400px]:px-1.5 min-[400px]:text-[13px] sm:min-w-[2.35rem] sm:px-2 font-semibold leading-none transition ${
              active ? 'bg-pine-900 text-white shadow dark:bg-pine-500' : 'text-ink/65 hover:text-brand'
            }`}
          >
            {o.short}
          </button>
        );
      })}
    </div>
  );
}
