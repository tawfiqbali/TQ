import { Link } from 'react-router-dom';
import { Mail, MapPin, Phone } from 'lucide-react';
import { WhatsAppIcon, FacebookIcon, InstagramIcon, YouTubeIcon, SOCIAL_STYLES } from '../shared/BrandIcons';
import { useSiteData } from '../../context/SiteDataContext';
import { useContent, useLanguage } from '../../i18n/LanguageContext';
import { gmailLink, mapsLink, telLink, whatsappLink } from '../../lib/utils';
import LogoMark from '../shared/LogoMark';
import { NAV_LINKS } from './Navbar';

export default function Footer() {
  const content = useContent();
  const raw = useSiteData().content; // untranslated address for the Maps link
  const { t, n } = useLanguage();
  const { brand, contact, social } = content.site;
  const courses = content.courses.filter((c) => c.published).slice(0, 6);
  const wa = whatsappLink(contact.whatsapp);
  const tel = telLink(contact.phone);

  const socials = [
    { key: 'facebook', href: social.facebook, label: 'Facebook', Icon: FacebookIcon },
    { key: 'instagram', href: social.instagram, label: 'Instagram', Icon: InstagramIcon },
    { key: 'youtube', href: social.youtube, label: 'YouTube', Icon: YouTubeIcon },
  ].filter((s) => s.href);

  const heading = 'mb-3 sm:mb-5 text-xs font-semibold uppercase tracking-[0.22em] text-gold-400';

  return (
    <footer id="site-contact" className="relative overflow-hidden bg-pine-950 text-pine-100/80">
      <div className="pointer-events-none absolute inset-0 dot-grid opacity-40" aria-hidden="true" />
      <div className="pointer-events-none absolute -right-40 -top-40 h-96 w-96 rounded-full bg-gold-400/10 blur-3xl" aria-hidden="true" />
      <div className="container-page relative grid grid-cols-2 gap-x-6 gap-y-8 py-10 sm:gap-10 sm:py-16 lg:grid-cols-[1.5fr_0.8fr_1fr_1.4fr]">
        <div className="col-span-2 lg:col-span-1">
          <Link to="/" className="flex items-center gap-3">
            <LogoMark variant="white" className="h-12 w-10" />
            <span className="leading-tight">
              <span className="block text-xl font-semibold text-white">{brand.name}</span>
              <span className="block text-[10px] font-semibold uppercase tracking-[0.22em] text-gold-400">{brand.subtitle}</span>
            </span>
          </Link>
          <p className="mt-5 max-w-sm text-[15px] leading-relaxed">{brand.tagline}</p>
          {socials.length > 0 && (
            <div className="mt-5 flex gap-2">
              {/* Each icon in its brand colour */}
              {socials.map(({ key, href, label, Icon }) => (
                <a
                  key={key}
                  href={href}
                  target="_blank"
                  rel="noreferrer"
                  aria-label={t('footer.social', { name: label })}
                  title={label}
                  className="flex h-10 w-10 items-center justify-center rounded-full text-white shadow-md ring-1 ring-white/20 transition hover:-translate-y-0.5 hover:brightness-110"
                  style={SOCIAL_STYLES[key]}
                >
                  <Icon className="h-5 w-5" />
                </a>
              ))}
            </div>
          )}
        </div>

        <nav aria-label="Footer">
          <h2 className={heading}>{t('footer.explore')}</h2>
          <ul className="space-y-2 text-sm sm:space-y-3 sm:text-[15px]">
            {NAV_LINKS.map((l) => (
              <li key={l.to}>
                <Link to={l.to} className="hover:text-white">
                  {t(l.key)}
                </Link>
              </li>
            ))}
            <li>
              <Link to="/about" className="hover:text-white">
                {t('nav.about')}
              </Link>
            </li>
          </ul>
        </nav>

        <div>
          <h2 className={heading}>{t('footer.classes')}</h2>
          <ul className="space-y-2 text-sm sm:space-y-3 sm:text-[15px]">
            {courses.map((c) => (
              <li key={c.id}>
                <Link to="/#courses" className="hover:text-white">
                  {c.title}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div className="col-span-2 lg:col-span-1">
          <h2 className={heading}>{t('footer.contact')}</h2>
          <ul className="space-y-4 text-[15px]">
            {contact.phone && (
              <li className="flex gap-3">
                <Phone className="mt-0.5 h-4 w-4 shrink-0 text-gold-400" aria-hidden="true" />
                <span>
                  <a href={tel} className="font-semibold text-white hover:underline">
                    {contact.phone}
                  </a>
                  {contact.phoneNote && <span className="mt-0.5 block text-xs text-pine-100/60">{contact.phoneNote}</span>}
                  {wa && (
                    <a href={wa} target="_blank" rel="noreferrer" className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-[#25D366] px-3 py-1 text-xs font-semibold text-white hover:bg-[#1DA851]">
                      <WhatsAppIcon className="h-3.5 w-3.5" /> {t('footer.whatsappUs')}
                    </a>
                  )}
                </span>
              </li>
            )}
            {contact.email && (
              <li className="flex gap-3">
                <Mail className="mt-0.5 h-4 w-4 shrink-0 text-gold-400" aria-hidden="true" />
                <a href={gmailLink(contact.email)} target="_blank" rel="noreferrer" className="break-all hover:text-white hover:underline" title={t('footer.emailTitle')}>
                  {contact.email}
                </a>
              </li>
            )}
            {contact.address && (
              <li className="flex gap-3">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-gold-400" aria-hidden="true" />
                <a href={mapsLink(raw.site.contact.address || contact.address)} target="_blank" rel="noreferrer" className="hover:text-white hover:underline" title={t('footer.mapsTitle')}>
                  {contact.address}
                </a>
              </li>
            )}
          </ul>
        </div>
      </div>
      <div className="relative border-t border-white/10">
        <div className="container-page flex flex-col gap-2 py-6 text-sm text-pine-100/60 sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {n(new Date().getFullYear())} {brand.name} ({brand.shortName})
          </p>
          <p className="flex flex-wrap items-center gap-x-4 gap-y-1">
            <span>{brand.closingLine}</span>
            <Link to="/privacy" className="hover:text-white hover:underline">Privacy Policy</Link>
            <Link to="/terms" className="hover:text-white hover:underline">Terms</Link>
          </p>
        </div>
      </div>
    </footer>
  );
}
