import { useState } from 'react';
import { Link } from 'react-router-dom';
import { X } from 'lucide-react';
import { useContent, useLanguage } from '../../i18n/LanguageContext';

export default function AnnouncementBar() {
  const content = useContent();
  const { t } = useLanguage();
  const { enabled, text, linkLabel, linkHref } = content.site.announcement;
  const [dismissedText, setDismissedText] = useState(() => sessionStorage.getItem('qii:announcement-dismissed'));

  if (!enabled || !text || dismissedText === text) return null;

  const dismiss = () => {
    sessionStorage.setItem('qii:announcement-dismissed', text);
    setDismissedText(text);
  };
  const isExternal = /^https?:\/\//.test(linkHref || '');

  return (
    <div className="bg-pine-950 text-pine-50">
      <div className="container-page flex items-center justify-center gap-3 py-2.5 text-center text-sm">
        <p>
          {text}{' '}
          {linkLabel && linkHref && (
            isExternal ? (
              <a href={linkHref} className="font-semibold text-gold-300 underline-offset-4 hover:underline">
                {linkLabel}
              </a>
            ) : (
              <Link to={linkHref} className="font-semibold text-gold-300 underline-offset-4 hover:underline">
                {linkLabel}
              </Link>
            )
          )}
        </p>
        <button onClick={dismiss} className="rounded-full p-1 text-pine-100/70 hover:text-white" aria-label={t('announcement.dismiss')}>
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
