import { Globe2 } from 'lucide-react';
import { useMemo } from 'react';
import { useCurrency } from '../../context/CurrencyContext';
import { countryName, countryOptions } from '../../lib/currency';

// Admin-only bar above the courses: which prices are showing, and a menu to
// preview the site as a visitor from any country.
export default function CurrencyNote() {
  const { loading, country, detectedCountry, currency, rule, baseCurrency, preview, choosePreview } = useCurrency();
  const options = useMemo(() => countryOptions(), []);
  const name = countryName(country) || 'this visitor';

  const status = loading
    ? 'Finding the visitor’s country…'
    : rule
      ? `${name}: custom prices in ${currency} (plans without a custom price are converted from ${baseCurrency}).`
      : currency !== baseCurrency
        ? `${name}: automatic prices, ${baseCurrency} converted to ${currency}.`
        : `${name}: ${baseCurrency} prices.`;

  return (
    <div className="flex flex-wrap items-center gap-x-3 gap-y-2 rounded-2xl border border-ink/10 bg-surface/80 px-4 py-2.5 text-sm text-ink/70 shadow-sm backdrop-blur">
      <Globe2 className="h-4 w-4 text-brand" aria-hidden="true" />
      <span className="rounded-full bg-gold-400/20 px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wider text-gold-700 dark:text-gold-300">Admin only</span>
      <span aria-live="polite">{status}</span>
      <label className="inline-flex items-center gap-2">
        <span className="text-ink/60">Preview as</span>
        <select className="max-w-[14rem] rounded-full border border-ink/15 bg-surface px-3 py-1 text-sm font-medium text-brand" value={preview} onChange={(e) => choosePreview(e.target.value)}>
          <option value="">Auto ({detectedCountry ? countryName(detectedCountry) : 'detected'})</option>
          {options.map((o) => (
            <option key={o.code} value={o.code}>
              {o.name} · {o.currency}
            </option>
          ))}
        </select>
      </label>
    </div>
  );
}
