export default function PageHeader({ title, intro, children }) {
  return (
    <section className="border-b border-ink/10 bg-gradient-to-br from-tint/90 via-surface/50 to-tint-gold/90">
      <div className="container-page py-5 md:py-7">
        <h1 className="max-w-3xl text-2xl leading-tight sm:text-3xl">{title}</h1>
        {intro && <p className="mt-1.5 max-w-2xl text-sm leading-snug text-ink/70 sm:text-base">{intro}</p>}
        {children}
      </div>
    </section>
  );
}
