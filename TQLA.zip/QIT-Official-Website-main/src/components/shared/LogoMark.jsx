// The QIT shield mark in its original colours. In dark mode it sits on a
// small cream tile so the dark-green mark stays clearly visible.
// variant="white" is for the always-dark footer.
export default function LogoMark({ className = 'h-10 w-10', variant = 'auto' }) {
  if (variant === 'white') {
    return <img src="/brand/logo-mark-white.png" alt="" aria-hidden="true" className={`object-contain ${className}`} width="206" height="256" />;
  }
  return (
    <img
      src="/brand/logo-mark.png"
      alt=""
      aria-hidden="true"
      className={`object-contain dark:rounded-lg dark:bg-[#F7F2E8] dark:p-1 dark:shadow-sm ${className}`}
      width="206"
      height="256"
    />
  );
}
