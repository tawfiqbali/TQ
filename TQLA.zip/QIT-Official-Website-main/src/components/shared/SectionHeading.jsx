export default function SectionHeading({ title, intro, action }) {
  return (
    <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
      <div className="max-w-2xl">
        <h2 className="text-2xl leading-snug">{title}</h2>
        {intro && <p className="mt-4 leading-relaxed text-ink/70">{intro}</p>}
      </div>
      {action}
    </div>
  );
}
