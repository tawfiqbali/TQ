import { Globe2 } from 'lucide-react';
import { useContent } from '../../i18n/LanguageContext';

// "Global Expert Instructors" title with a row of place badges.
// variant="light" is for dark backgrounds (the Why-us promise card).
export default function GlobalFacultyBadges({ variant = 'default', className = '' }) {
  const content = useContent();
  const g = content.site.globalFaculty;
  const places = (g?.places || []).filter(Boolean);
  if (!g || !places.length) return null;
  const onDark = variant === 'light';

  return (
    <div className={className}>
      <p className={`flex items-center gap-2 text-sm font-bold uppercase tracking-[0.12em] ${onDark ? 'text-gold-300' : 'text-brand'}`}>
        <Globe2 className="h-4 w-4" aria-hidden="true" />
        {g.title}
      </p>
      {g.text && <p className={`mt-1 text-sm ${onDark ? 'text-pine-100/80' : 'text-ink/65'}`}>{g.text}</p>}
      <ul className="mt-3 flex flex-wrap gap-2" aria-label={g.title}>
        {places.map((p) => (
          <li
            key={p}
            className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold ${
              onDark ? 'bg-white/10 text-white ring-1 ring-white/20' : 'bg-gradient-to-r from-tint-gold to-tint text-heading ring-1 ring-gold-300/60'
            }`}
          >
            <span className="h-1.5 w-1.5 rounded-full bg-gold-500" aria-hidden="true" />
            {p}
          </li>
        ))}
      </ul>
    </div>
  );
}
