import { memo, useId, useState } from 'react';
import { Check, Clock, ShoppingBag } from 'lucide-react';
import { useSiteData } from '../../context/SiteDataContext';
import { useCurrency } from '../../context/CurrencyContext';
import { useTrialModal } from '../../context/TrialModalContext';
import { FEATURE_ICONS } from './icons';
import { fillTemplate, whatsappLink } from '../../lib/utils';
import { formatMoney } from '../../lib/currency';
import { useContent, useLanguage } from '../../i18n/LanguageContext';

// Brand-matched accent colours ("R G B"), cycled across the course cards
export const COURSE_ACCENTS = ['10 97 104', '200 154 60', '31 127 128', '176 110 52'];

// Per-card colour themes (in course order): Kids = teal/cyan,
// Adults = peach/gold, Hifz = mint/green, Islamic Studies = earthy brown/tan.
// accent = borders, radio, icon; a/b = the pastel background in light mode.
export const COURSE_THEMES = [
  { name: 'teal', accent: '8 145 178', a: '236 254 255', b: '207 244 250' },
  { name: 'gold', accent: '202 124 32', a: '255 247 237', b: '254 226 196' },
  { name: 'mint', accent: '5 150 105', a: '236 253 245', b: '204 245 225' },
  { name: 'earth', accent: '146 98 57', a: '250 245 238', b: '236 222 202' },
];

// `course` arrives already in the visitor's language. Anything recorded for
// the admin (booking, trial form value) uses the original English course.
function CourseCard({ course, theme = COURSE_THEMES[0] }) {
  const { content: raw, addInquiry } = useSiteData();
  const content = useContent();
  const { t, money } = useLanguage();
  const rawCourse = raw.courses.find((c) => c.id === course.id) || course;
  const rawPlans = rawCourse.plans ?? [];
  const { openTrial, openBuy } = useTrialModal();
  const { formatPlan, currency, baseCurrency, rule, countryLabel } = useCurrency();
  const { coursesSection, contact, whatsappMessages } = content.site;
  const [selected, setSelected] = useState(0);
  const groupId = useId();
  const Icon = FEATURE_ICONS[course.icon] ?? FEATURE_ICONS.BookOpen;

  const plans = (course.plans ?? []).map((p) => ({ ...p, max: p.max === '' || p.max == null ? p.min : p.max }));
  const bullets = [...new Set([...(course.bullets ?? []), ...(coursesSection.standardBullets ?? [])])];
  const plan = plans[selected] ?? plans[0];

  const usdText = (p) => (p.max !== p.min ? `${formatMoney(p.min, baseCurrency)} – ${p.max}` : formatMoney(p.min, baseCurrency));
  // Price for plan number i: the visitor's country price, or the fallback
  const priceText = (p, i) => formatPlan(p, course.id, i);

  // Converted prices also mention the USD amount; country prices are exact
  const buyPrice = plan ? money(!rule && currency !== baseCurrency ? `${priceText(plan, selected)} (${usdText(plan)})` : priceText(plan, selected)) : '';
  const buyHref = whatsappLink(contact.whatsapp, fillTemplate(whatsappMessages.buy, { course: course.title, plan: plan?.label ?? '', price: buyPrice }));
  const needsForm = raw.site.forms?.buyNeedsForm !== false;

  // The card is a CSS subgrid spanning 5 rows of the courses grid, so the
  // header, class length, prices, points and buttons line up across cards.
  return (
    <article
      className="reveal card-3d course-card isolate row-span-5 grid grid-rows-subgrid gap-y-3 overflow-hidden p-4 sm:p-5"
      style={{ '--accent': theme.accent, '--pastel-a': theme.a, '--pastel-b': theme.b }}
    >
      <span className="card-band -z-10" aria-hidden="true" />
      <span className="absolute inset-x-0 top-0 h-1 bg-[rgb(var(--accent))]" aria-hidden="true" />

      {/* 1. Header */}
      <div className="flex items-center gap-3">
        <span className="icon-tile h-10 w-10 shrink-0">
          <Icon className="h-5 w-5" aria-hidden="true" />
        </span>
        <div className="min-w-0">
          <h3 className="text-lg leading-snug">{course.title}</h3>
          {course.subtitle && <p className="mt-0.5 text-[11px] font-semibold uppercase tracking-[0.16em] text-ink/55">{course.subtitle}</p>}
        </div>
      </div>

      {/* 2. Class length */}
      <div className="self-start">
        {course.classLength && (
          <p className="inline-flex items-center gap-1.5 rounded-full bg-tint-gold px-3 py-1 text-xs font-semibold text-gold-700 ring-1 ring-gold-300/60 dark:text-gold-300">
            <Clock className="h-3.5 w-3.5" aria-hidden="true" />
            {course.classLength}
          </p>
        )}
      </div>

      {/* 3. Prices */}
      <div className="space-y-2 self-start" role="radiogroup" aria-label={t('courses.plans', { course: course.title })}>
        {plans.map((p, i) => {
          const active = i === selected;
          return (
            <label
              key={`${p.label}-${i}`}
              className={`tier-pill block cursor-pointer rounded-2xl px-3.5 py-2.5 transition ${active ? 'is-active' : ''}`}
            >
              <input type="radio" name={groupId} className="sr-only" checked={active} onChange={() => setSelected(i)} />
              <span className="flex items-center justify-between gap-2 text-xs text-ink/60">
                {p.label}
                <span
                  className={`tier-radio ${active ? 'is-active' : ''}`}
                  aria-hidden="true"
                />
              </span>
              <span className="mt-0.5 block leading-tight">
                <span className="text-base font-semibold text-heading">{money(priceText(p, i))}</span>
                <span className="whitespace-nowrap text-xs text-ink/55"> {t('common.perMonth')}</span>
              </span>
            </label>
          );
        })}
      </div>

      {/* 4. Course points */}
      <ul className="space-y-2 self-start border-t border-ink/10 pt-4">
        {bullets.map((b) => (
          <li key={b} className="flex gap-2 text-sm leading-snug text-ink/80">
            <Check className="mt-0.5 h-4 w-4 shrink-0 text-[rgb(var(--accent))]" aria-hidden="true" />
            {b}
          </li>
        ))}
      </ul>

      {/* 5. Actions */}
      <div className="grid grid-cols-2 gap-2 self-end">
        {/* Buy Course: the visitor gives their details first (Site content → Buy Course & trial form),
            then WhatsApp opens with the course, plan, price and those details */}
        {needsForm ? (
          <button
            type="button"
            className="btn-buy gap-1.5 whitespace-nowrap px-2 py-2.5 text-sm"
            title={t('courses.buyTitle')}
            data-testid="buy-course"
            onClick={() => openBuy({
              course: rawCourse.title,
              courseLabel: course.title,
              plan: rawPlans[selected]?.label ?? plan?.label ?? '',
              planLabel: plan?.label ?? '',
              price: buyPrice,
            })}
          >
            <ShoppingBag className="h-4 w-4 shrink-0" aria-hidden="true" /> {t('courses.buy')}
          </button>
        ) : (
          <a
            href={buyHref}
            target="_blank"
            rel="noreferrer"
            className="btn-buy gap-1.5 whitespace-nowrap px-2 py-2.5 text-sm"
            title={t('courses.buyTitle')}
            onClick={() => {
              addInquiry({
                type: 'trial',
                name: 'Website visitor (Buy Course)',
                country: countryLabel || '',
                course: plan ? `${rawCourse.title} — ${rawPlans[selected]?.label ?? plan.label}` : rawCourse.title,
                message: `Buy Course · Monthly payment: ${plan ? priceText(plan, selected) : ''}`,
              }).catch(() => {});
            }}
          >
            <ShoppingBag className="h-4 w-4 shrink-0" aria-hidden="true" /> {t('courses.buy')}
          </a>
        )}
        <button type="button" onClick={() => openTrial(rawCourse.title)} className="btn-outline whitespace-nowrap px-2 py-2.5 text-sm">
          {t('courses.trial')}
        </button>
      </div>
    </article>
  );
}

// Re-renders only when its own course, colour or the shared contexts change
export default memo(CourseCard);
