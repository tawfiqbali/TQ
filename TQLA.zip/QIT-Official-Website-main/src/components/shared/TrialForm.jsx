import { useMemo, useState } from 'react';
import { CheckCircle2, Send, ShoppingBag, Users, X } from 'lucide-react';
import { WhatsAppIcon } from './BrandIcons';
import { useSiteData } from '../../context/SiteDataContext';
import { useCurrency } from '../../context/CurrencyContext';
import { MEDIUM_OPTIONS, PLATFORMS, TEACHER_OPTIONS } from '../../data/defaultContent';
import { deliverForm } from '../../lib/formDelivery';
import TimePicker from '../ui/TimePicker';
import { fillTemplate, whatsappLink } from '../../lib/utils';
import { useContent, useLanguage } from '../../i18n/LanguageContext';

function countryName(code, lang = 'en') {
  if (!code) return '';
  try {
    return new Intl.DisplayNames([lang], { type: 'region' }).of(code) || '';
  } catch {
    return '';
  }
}

const today = () => new Date().toISOString().slice(0, 10);

// Which details are mandatory (Admin → Site content → Buy Course & trial form)
const FORM_DEFAULTS = { buyNeedsForm: true, requireName: true, requireWhatsapp: true, requireCountry: true, requireCourse: false, requireTime: false, requireDate: false, afterTitle: '', afterText: '', afterButton: '' };

// buy = { course, courseLabel, planLabel, plan, price }: the Buy Course form
export default function TrialForm({ course = '', buy = null, onClose }) {
  const { content: raw, addInquiry } = useSiteData();
  const content = useContent();
  const { lang, t, n } = useLanguage();
  const { country } = useCurrency();
  const { contact, trial, brand, whatsappMessages } = content.site;
  const rules = { ...FORM_DEFAULTS, ...(raw.site.forms || {}) };
  const need = { name: rules.requireName, whatsapp: rules.requireWhatsapp, country: rules.requireCountry, course: rules.requireCourse && !buy, preferredTime: rules.requireTime, classDate: rules.requireDate };
  const inModal = Boolean(onClose);
  // Values stay the English course titles (what the admin sees); labels follow the language
  const courseOptions = raw.courses
    .filter((c) => c.published)
    .map((c) => ({ value: c.title, label: content.courses.find((x) => x.id === c.id)?.title || c.title }));
  const courseLabel = (value) => courseOptions.find((o) => o.value === value)?.label || value;
  // Male/Female and English/Bangla are translated; platform names stay as they are
  const optionLabel = (o) => {
    const key = `trialForm.options.${o}`;
    const label = t(key);
    return label === key ? o : label;
  };

  const [values, setValues] = useState(() => ({
    name: '',
    country: countryName(country, lang),
    whatsapp: '',
    preferredTime: '',
    classDate: '',
    teacher: TEACHER_OPTIONS[0],
    medium: MEDIUM_OPTIONS[0],
    platform: PLATFORMS[0],
    course,
    website: '', // honeypot
  }));
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('idle'); // idle | sending | sent
  const [waUrl, setWaUrl] = useState('');

  const set = (key) => (e) => setValues((v) => ({ ...v, [key]: e.target.value }));

  // The WhatsApp message is written in the visitor's language
  const buildMessage = (v) => {
    const m = (k) => t(`trialForm.message.${k}`);
    const details = [
      `${m('name')}: ${v.name}`,
      `${m('country')}: ${v.country}`,
      `${m('whatsapp')}: ${v.whatsapp}`,
      v.course && `${m('course')}: ${courseLabel(v.course)}`,
      v.preferredTime && `${m('time')}: ${v.preferredTime}`,
      v.classDate && `${m('date')}: ${n(v.classDate)}`,
      `${m('teacher')}: ${optionLabel(v.teacher)}`,
      `${m('medium')}: ${optionLabel(v.medium)}`,
      `${m('platform')}: ${v.platform}`,
    ].filter(Boolean);
    if (buy) {
      const intro = fillTemplate(whatsappMessages.buy, { course: buy.courseLabel || buy.course, plan: buy.planLabel || '', price: buy.price || '' });
      return [intro, '', ...details.filter((d) => !d.startsWith(`${m('course')}:`))].join('\n');
    }
    return [t('trialForm.message.intro', { brand: brand.name }), '', ...details].join('\n');
  };

  const submit = async (e) => {
    e.preventDefault();
    const v = Object.fromEntries(Object.entries(values).map(([k, val]) => [k, String(val).trim()]));
    if (v.website) return setStatus('sent'); // bots fill hidden fields

    const errs = {};
    if (need.course && !v.course) errs.course = t('trialForm.errRequired');
    if (need.name && !v.name) errs.name = t('trialForm.errName');
    if (need.country && !v.country) errs.country = t('trialForm.errCountry');
    // Accept Bengali numerals too when counting digits; a number that is typed must be complete
    const digits = (v.whatsapp.match(/[\d০-৯]/g) || []).length;
    if ((need.whatsapp || v.whatsapp) && digits < 7) errs.whatsapp = t('trialForm.errWhatsapp');
    if (need.preferredTime && !v.preferredTime) errs.preferredTime = t('trialForm.errRequired');
    if (need.classDate && !v.classDate) errs.classDate = t('trialForm.errRequired');
    setErrors(errs);
    if (Object.keys(errs).length) {
      document.getElementById(`trial-${Object.keys(errs)[0]}`)?.focus();
      return;
    }

    // The request is saved to Admin → Inquiries first; the next screen then
    // urges the visitor to send the same details on WhatsApp.
    setWaUrl(whatsappLink(contact.whatsapp, buildMessage(v)));

    setStatus('sending');
    const { website, ...data } = v;
    await Promise.allSettled([
      addInquiry({
        ...data, type: 'trial', phone: v.whatsapp, name: v.name || (buy ? 'Website visitor (Buy Course)' : 'Website visitor'),
        ...(buy ? { course: buy.plan ? `${buy.course} — ${buy.plan}` : buy.course, message: `Buy Course · Monthly payment: ${buy.price || ''}` } : {}),
      }),
      deliverForm(buy ? 'buy-course' : 'trial-request', buy ? { ...data, plan: buy.plan || '', price: buy.price || '' } : data),
    ]);
    setStatus('sent');
  };

  if (status === 'sent') {
    // Admin → Site content → Buy Course & trial form can replace these texts
    const own = (k, fallback) => (String(rules[k] || '').trim() ? rules[k] : fallback);
    return (
      <div className="relative p-7 text-center sm:p-10" role="status" data-testid="trial-sent">
        {inModal && (
          <button type="button" onClick={onClose} className="icon-btn absolute right-4 top-4" aria-label={t('common.close')}>
            <X className="h-5 w-5" />
          </button>
        )}
        <CheckCircle2 className="mx-auto h-12 w-12 text-pine-500" />
        <h2 id="trial-form-title" className="mt-3 text-2xl">
          {t('trialForm.sentTitle')}
        </h2>
        <p className="mt-1 text-sm text-ink/65">{buy ? t('trialForm.buySentOpened') : t('trialForm.sentOpened')}</p>
        {waUrl && (
          <div className="mx-auto mt-5 max-w-md rounded-2xl border-2 border-[#25D366]/50 bg-[#25D366]/[0.08] p-5" data-testid="wa-urge">
            <p className="text-lg font-bold leading-snug text-heading">{own('afterTitle', t('trialForm.waUrgeTitle'))}</p>
            <p className="mt-2 text-sm leading-relaxed text-ink/80">{own('afterText', t('trialForm.waUrge'))}</p>
            <a href={waUrl} target="_blank" rel="noreferrer" className="btn-whatsapp qit-wa-pulse mt-4 w-full justify-center px-6 py-3.5 text-base" data-testid="wa-send">
              <WhatsAppIcon className="h-5 w-5" /> {own('afterButton', t('trialForm.sendOnWhatsapp'))}
            </a>
            <p className="mt-3 text-xs text-ink/55">{t('trialForm.waSaved')}</p>
          </div>
        )}
      </div>
    );
  }

  const field = (key, label, input, tone = '') => (
    <div>
      <label htmlFor={`trial-${key}`} className="label-caps">
        {label}
        {need[key] && <span className="text-red-700" aria-hidden="true"> *</span>}
        {need[key] && <span className="sr-only"> ({t('trialForm.required')})</span>}
      </label>
      {input(`input ${tone}`)}
      {errors[key] && (
        <p className="mt-1 text-xs text-red-700" role="alert">
          {errors[key]}
        </p>
      )}
    </div>
  );

  const select = (key, options) => (cls) => (
    <select id={`trial-${key}`} className={cls} value={values[key]} onChange={set(key)}>
      {options.map((o) => (
        <option key={o} value={o}>
          {optionLabel(o)}
        </option>
      ))}
    </select>
  );

  return (
    <form onSubmit={submit} noValidate name="trial-request">
      {/* Header: title on the left, send button on the top right */}
      <div
        className={`flex flex-wrap items-center justify-between gap-3 border-b border-ink/10 bg-surface/95 px-5 py-4 backdrop-blur sm:px-7 ${
          inModal ? 'sticky top-0 z-10 rounded-t-3xl' : 'rounded-t-2xl'
        }`}
      >
        <div className="min-w-0">
          <h2 id="trial-form-title" className="text-xl sm:text-2xl">
            {buy ? t('trialForm.buyTitle') : t('trialForm.title')}
          </h2>
          <p className="text-xs text-ink/60">{buy ? t('trialForm.buySubtitle') : t('trialForm.subtitle')}</p>
        </div>
        <div className="flex items-center gap-2">
          <button type="submit" className="btn-primary px-5 py-2.5" disabled={status === 'sending'}>
            {buy ? <ShoppingBag className="h-4 w-4" /> : <Send className="h-4 w-4" />}
            {status === 'sending' ? t('common.sending') : buy ? t('trialForm.buySend') : t('trialForm.send')}
          </button>
          {inModal && (
            <button type="button" onClick={onClose} className="icon-btn" aria-label={t('common.close')} data-close>
              <X className="h-5 w-5" />
            </button>
          )}
        </div>
      </div>

      <div className="space-y-5 p-5 sm:p-7">
        {buy ? (
          /* What they are buying */
          <div className="flex gap-3 rounded-2xl border border-gold-300/60 bg-gradient-to-br from-tint-gold to-tint p-4" data-testid="buy-summary">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-pine-900 text-gold-300">
              <ShoppingBag className="h-5 w-5" aria-hidden="true" />
            </span>
            <div className="min-w-0 text-sm leading-relaxed text-ink/80">
              <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-brand">{t('trialForm.yourChoice')}</p>
              <p className="font-semibold text-heading">{buy.courseLabel || buy.course}</p>
              <p>{[buy.planLabel, buy.price && `${buy.price} / ${t('trialForm.perMonth')}`].filter(Boolean).join(' · ')}</p>
            </div>
          </div>
        ) : (
          /* The trial system in one sentence */
          <div className="flex gap-3 rounded-2xl border border-gold-300/60 bg-gradient-to-br from-tint-gold to-tint p-4">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-pine-900 text-gold-300">
              <Users className="h-5 w-5" aria-hidden="true" />
            </span>
            <p className="text-sm leading-relaxed text-ink/80">
              <strong className="font-semibold text-heading">{t('trialForm.howItWorks')}</strong>
              {trial.summary}
            </p>
          </div>
        )}

        <div className="grid gap-4 sm:grid-cols-2">
          {!buy && (
          <div className="sm:col-span-2">
            <label htmlFor="trial-course" className="label-caps">
              {t('trialForm.course')}
              {need.course && <span className="text-red-700" aria-hidden="true"> *</span>}
            </label>
            <select id="trial-course" className="input" value={values.course} onChange={set('course')}>
              <option value="">{t('trialForm.courseUnsure')}</option>
              {/* Keep a course that was pre-selected even if it has since been renamed */}
              {[...new Set([...courseOptions.map((o) => o.value), values.course].filter(Boolean))].map((v) => (
                <option key={v} value={v}>
                  {courseLabel(v)}
                </option>
              ))}
            </select>
            {errors.course && <p className="mt-1 text-xs text-red-700" role="alert">{errors.course}</p>}
          </div>
          )}
          {field('name', t('trialForm.name'), (cls) => (
            <input id="trial-name" className={cls} autoComplete="name" placeholder={t('trialForm.namePlaceholder')} value={values.name} onChange={set('name')} />
          ))}
          {field('country', t('trialForm.country'), (cls) => (
            <input id="trial-country" className={cls} autoComplete="country-name" placeholder={t('trialForm.countryPlaceholder')} value={values.country} onChange={set('country')} />
          ), 'input-warm')}
          {field('whatsapp', t('trialForm.whatsapp'), (cls) => (
            <input id="trial-whatsapp" type="tel" className={cls} autoComplete="tel" placeholder="+880 1XXX-XXXXXX" value={values.whatsapp} onChange={set('whatsapp')} />
          ))}
          {field('preferredTime', t('trialForm.time'), (cls) => (
            // v186: type the time or roll it; AM / PM must be chosen
            <TimePicker id="trial-preferredTime" className={cls} format="text" value={values.preferredTime} testId="trial-time"
              onChange={(x) => setValues((v) => ({ ...v, preferredTime: x }))} ariaLabel={t('trialForm.time')} placeholder="hh:mm"
              labels={lang === 'bn' ? { title: 'সময় বেছে নিন', hour: 'ঘণ্টা', minute: 'মিনিট', done: 'ঠিক আছে', clear: 'মুছুন', needAmPm: 'AM না PM — বেছে নিন' } : { needAmPm: 'Choose AM or PM' }} />
          ), 'input-warm')}
          {field('classDate', t('trialForm.date'), (cls) => (
            <input id="trial-classDate" type="date" min={today()} className={cls} value={values.classDate} onChange={set('classDate')} />
          ))}
          {field('teacher', t('trialForm.teacher'), select('teacher', TEACHER_OPTIONS), 'input-warm')}
          {field('medium', t('trialForm.medium'), select('medium', MEDIUM_OPTIONS))}
          {field('platform', t('trialForm.platform'), select('platform', PLATFORMS), 'input-warm')}
        </div>

        <div className="hidden" aria-hidden="true">
          <label>
            Website
            <input tabIndex={-1} autoComplete="off" value={values.website} onChange={set('website')} />
          </label>
        </div>

        {!buy && (
        <div className="rounded-2xl bg-gradient-to-b from-paper to-surface p-5 shadow-soft">
          <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-brand">{t('trialForm.stepsTitle')}</p>
          <ul className="mt-3 space-y-1.5">
            {trial.steps.map((s) => (
              <li key={s} className="flex gap-2.5 text-sm text-ink/75">
                <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-gold-500" aria-hidden="true" />
                {s}
              </li>
            ))}
          </ul>
        </div>
        )}
        <p className="text-xs text-ink/55">
          {t('trialForm.privacy', { phone: contact.phone })}
        </p>
      </div>
    </form>
  );
}
