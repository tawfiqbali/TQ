import { useLanguage } from '../../i18n/LanguageContext';
import { Clock, Languages } from 'lucide-react';
import { initialsOf } from '../../lib/utils';

export default function InstructorCard({ instructor }) {
  const { t } = useLanguage();
  const { name, title, specialties, bio, experience, languages, photoUrl } = instructor;
  return (
    <article className="flex flex-col">
      <div className="rounded-[2rem] dot-grid relative mb-5 aspect-[4/5] w-full max-w-[12rem] overflow-hidden bg-pine-900">
        {photoUrl ? (
          <img src={photoUrl} alt={`Portrait of ${name}`} className="h-full w-full object-cover" loading="lazy" />
        ) : (
          <span className="absolute inset-0 flex items-center justify-center font-display text-5xl text-gold-300" aria-hidden="true">
            {initialsOf(name)}
          </span>
        )}
      </div>
      <h3 className="text-xl">{name}</h3>
      <p className="mt-1 text-sm font-medium text-gold-700">{title}</p>
      {specialties && <p className="mt-3 text-sm text-ink/80">{specialties}</p>}
      {bio && <p className="mt-2 text-sm leading-relaxed text-ink/65">{bio}</p>}
      <div className="mt-4 space-y-1.5 text-xs text-ink/60">
        {experience && (
          <p className="flex items-center gap-2">
            <Clock className="h-3.5 w-3.5" aria-hidden="true" />
            {experience}
          </p>
        )}
        {languages && (
          <p className="flex items-center gap-2">
            <Languages className="h-3.5 w-3.5" aria-hidden="true" />
            <span>
              <span className="sr-only">{t('pages.languages')}</span>
              {languages}
            </span>
          </p>
        )}
      </div>
    </article>
  );
}
