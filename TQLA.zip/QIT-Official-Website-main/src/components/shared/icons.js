import {
  BadgeCheck,
  BookOpen,
  CalendarCheck,
  CalendarClock,
  Clock,
  GraduationCap,
  HeartHandshake,
  Landmark,
  LineChart,
  MessagesSquare,
  Moon,
  ShieldCheck,
  Sparkles,
  Star,
  Users,
  Video,
} from 'lucide-react';

// Icons the admin can choose for courses and "Why us" items.
export const FEATURE_ICONS = {
  BookOpen,
  GraduationCap,
  Moon,
  Landmark,
  BadgeCheck,
  Users,
  CalendarCheck,
  ShieldCheck,
  CalendarClock,
  Video,
  LineChart,
  HeartHandshake,
  MessagesSquare,
  Sparkles,
  Star,
  Clock,
};

export const FEATURE_ICON_NAMES = Object.keys(FEATURE_ICONS);
