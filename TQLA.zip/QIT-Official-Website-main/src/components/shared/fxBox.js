// Slight gradient box peeking out behind a panel (styles: .fx in index.css).
// Sections alternate sides: 'br' = bottom-right, 'bl' = bottom-left.
// kind: 'card' | 'panel' get the box; 'photo' does not (kept for easy switching).
export function fx(kind, side = 'br') {
  if (kind === 'photo') return '';
  return side === 'bl' ? 'fx fx-bl' : 'fx';
}
