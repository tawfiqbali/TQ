import { useState } from 'react';
import { CheckCircle2 } from 'lucide-react';
import { useSiteData } from '../../context/SiteDataContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { deliverForm } from '../../lib/formDelivery';

// General "send us a message" form. The free trial uses TrialForm.
const EMPTY = { name: '', email: '', whatsapp: '', message: '', website: '' };

export default function InquiryForm() {
  const { content, addInquiry } = useSiteData();
  const { t } = useLanguage();
  const [values, setValues] = useState(EMPTY);
  const [status, setStatus] = useState('idle');
  const [error, setError] = useState('');
  const set = (key) => (e) => setValues((v) => ({ ...v, [key]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    const v = Object.fromEntries(Object.entries(values).map(([k, val]) => [k, val.trim()]));
    if (v.website) return setStatus('sent');
    if (!v.name) return setError(t('contactForm.errName'));
    if (!v.email && !v.whatsapp) return setError(t('contactForm.errReach'));
    if (v.email && !/^\S+@\S+\.\S+$/.test(v.email)) return setError(t('contactForm.errEmail'));
    if (!v.message) return setError(t('contactForm.errMessage'));

    setStatus('sending');
    const { website, ...data } = v;
    const [saved, delivered] = await Promise.allSettled([
      addInquiry({ ...data, phone: v.whatsapp, type: 'contact' }),
      deliverForm('contact-message', data),
    ]);
    const ok = saved.status === 'fulfilled' || (delivered.status === 'fulfilled' && delivered.value.netlify);
    if (ok) return setStatus('sent');
    setStatus('idle');
    setError(t('contactForm.errSend', { email: content.site.contact.email }));
  };

  if (status === 'sent') {
    return (
      <div className="py-6 text-center" role="status">
        <CheckCircle2 className="mx-auto h-10 w-10 text-pine-500" />
        <h3 className="mt-4 text-xl">{t('contactForm.sentTitle')}</h3>
        <p className="mx-auto mt-2 max-w-sm text-sm leading-relaxed text-ink/70">{t('contactForm.sentText')}</p>
      </div>
    );
  }

  return (
    <form onSubmit={submit} noValidate className="grid gap-4 sm:grid-cols-2" name="contact-message">
      <div className="sm:col-span-2">
        <label htmlFor="contact-name" className="label-caps">{t('contactForm.name')}</label>
        <input id="contact-name" className="input" autoComplete="name" value={values.name} onChange={set('name')} />
      </div>
      <div>
        <label htmlFor="contact-email" className="label-caps">{t('contactForm.email')}</label>
        <input id="contact-email" type="email" className="input input-warm" autoComplete="email" value={values.email} onChange={set('email')} />
      </div>
      <div>
        <label htmlFor="contact-whatsapp" className="label-caps">{t('contactForm.whatsapp')}</label>
        <input id="contact-whatsapp" type="tel" className="input" autoComplete="tel" value={values.whatsapp} onChange={set('whatsapp')} />
      </div>
      <div className="sm:col-span-2">
        <label htmlFor="contact-message" className="label-caps">{t('contactForm.message')}</label>
        <textarea id="contact-message" rows={5} className="input input-warm" value={values.message} onChange={set('message')} />
      </div>
      <div className="hidden" aria-hidden="true">
        <label>
          Website
          <input tabIndex={-1} autoComplete="off" value={values.website} onChange={set('website')} />
        </label>
      </div>
      {error && (
        <p role="alert" className="rounded-xl bg-red-50 px-4 py-3 text-sm text-red-800 sm:col-span-2">
          {error}
        </p>
      )}
      <div className="sm:col-span-2">
        <button type="submit" className="btn-primary w-full py-3 text-base" disabled={status === 'sending'}>
          {status === 'sending' ? t('common.sending') : t('contactForm.send')}
        </button>
      </div>
    </form>
  );
}
