import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';

/**
 * v166: one calendar for every date box on the website, the admin panel and the
 * Teacher Dashboard. It opens on any <input type="date"> or <input type="month">
 * (no change needed where the box is used) and writes the picked day back into
 * that box, so the page's own onChange runs as before.
 *   - month + year header (press it to pick a year), < > for the month
 *   - S M T W T F S, round days, the picked day filled, today ringed
 *   - min / max of the box are respected; Today and Clear buttons
 *   - Bangla page → Bangla month names and numbers
 */
const pad = (n) => String(n).padStart(2, '0');
const iso = (y, m, d) => `${y}-${pad(m + 1)}-${pad(d)}`;
const parse = (v) => {
  const m = /^(\d{4})-(\d{2})(?:-(\d{2}))?$/.exec(v || '');
  return m ? { y: +m[1], m: +m[2] - 1, d: m[3] ? +m[3] : 1 } : null;
};
const isPickerInput = (el) => el instanceof HTMLInputElement && (el.type === 'date' || el.type === 'month') && !el.disabled;

// v172: data-filled="1" on date boxes that hold a date (coloured look + ×)
export function markDates() {
  if (typeof document === 'undefined') return;
  document.querySelectorAll('input[type="date"], input[type="month"]').forEach((el) => {
    const f = el.value ? '1' : '0';
    if (el.dataset.filled !== f) el.dataset.filled = f;
  });
}

// Writes a value the way typing would, so React's onChange sees it
function writeValue(input, value) {
  const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
  setter.call(input, value);
  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
}

function useLocaleText() {
  const bn = typeof document !== 'undefined' && document.documentElement.lang === 'bn';
  const loc = bn ? 'bn-BD' : 'en-GB';
  const month = (y, m, style = 'long') => new Intl.DateTimeFormat(loc, { month: style }).format(new Date(y, m, 15));
  const num = (n) => (bn ? new Intl.NumberFormat('bn-BD', { useGrouping: false }).format(n) : String(n));
  const days = bn ? ['র', 'সো', 'ম', 'বু', 'বৃ', 'শু', 'শ'] : ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
  const t = bn ? { today: 'আজ', clear: 'মুছুন', thisMonth: 'এই মাস' } : { today: 'Today', clear: 'Clear', thisMonth: 'This month' };
  return { month, num, days, t };
}

function Calendar({ input, onClose }) {
  const L = useLocaleText();
  const monthMode = input.type === 'month';
  const now = new Date();
  const val = parse(input.value);
  const min = parse(input.min);
  const max = parse(input.max);
  const [view, setView] = useState(() => ({ y: (val || { y: now.getFullYear() }).y, m: (val || { m: now.getMonth() }).m }));
  const [years, setYears] = useState(false);
  const box = useRef(null);
  const [pos, setPos] = useState({ top: -9999, left: 0, up: false });

  const place = useCallback(() => {
    const r = input.getBoundingClientRect();
    const w = Math.min(320, window.innerWidth - 16);
    const h = box.current?.offsetHeight || 380;
    const below = window.innerHeight - r.bottom;
    const up = below < h + 12 && r.top > below;
    const top = up ? Math.max(8, r.top - h - 6) : Math.min(r.bottom + 6, window.innerHeight - h - 8);
    const left = Math.max(8, Math.min(r.left, window.innerWidth - w - 8));
    setPos({ top, left, up, w });
  }, [input]);
  useLayoutEffect(place, [place, years, view]);
  useEffect(() => {
    const on = () => (document.contains(input) ? place() : onClose());
    window.addEventListener('resize', on);
    window.addEventListener('scroll', on, true);
    return () => { window.removeEventListener('resize', on); window.removeEventListener('scroll', on, true); };
  }, [input, place, onClose]);
  useEffect(() => { box.current?.querySelector('.dp-day.is-sel, .dp-mon.is-sel, .dp-day.is-today, .dp-day:not(:disabled)')?.focus({ preventScroll: true }); }, [years]);

  const cmp = (a, b) => (a.y - b.y) || (a.m - b.m) || ((a.d || 1) - (b.d || 1));
  const off = (d) => (min && cmp(d, min) < 0) || (max && cmp(d, max) > 0);
  const offMonth = (y, m) => (min && (y < min.y || (y === min.y && m < min.m))) || (max && (y > max.y || (y === max.y && m > max.m)));
  const pick = (value) => { writeValue(input, value); markDates(); onClose(true); };
  const step = (n) => setView((v) => { const d = new Date(v.y, v.m + n, 1); return { y: d.getFullYear(), m: d.getMonth() }; });

  const first = new Date(view.y, view.m, 1).getDay();
  const count = new Date(view.y, view.m + 1, 0).getDate();
  const cells0 = [...Array(first).fill(null), ...Array.from({ length: count }, (_, i) => i + 1)];
  // v188: always 6 week rows, so the calendar keeps one height and never jumps when the month changes
  const cells = [...cells0, ...Array(42 - cells0.length).fill(null)];
  const yearList = Array.from({ length: 101 }, (_, i) => now.getFullYear() + 5 - i).filter((y) => (!min || y >= min.y) && (!max || y <= max.y));

  const onKey = (e) => {
    if (e.key === 'Escape') { e.preventDefault(); onClose(true); return; }
    if (years || monthMode) return;
    const cur = document.activeElement?.dataset?.day;
    if (!cur || !['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key)) return;
    e.preventDefault();
    const n = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -7, ArrowDown: 7 }[e.key];
    const d = new Date(view.y, view.m, Number(cur) + n);
    if (d.getMonth() !== view.m) setView({ y: d.getFullYear(), m: d.getMonth() });
    requestAnimationFrame(() => box.current?.querySelector(`[data-day="${d.getDate()}"]`)?.focus());
  };

  return (
    <div ref={box} className={`dp-pop ${pos.up ? 'is-up' : ''}`} style={{ top: pos.top, left: pos.left, width: pos.w }} role="dialog" aria-label={monthMode ? 'Choose a month' : 'Choose a date'}
      onKeyDown={onKey} onMouseDown={(e) => e.preventDefault()} data-testid="date-picker">
      <div className="dp-head">
        <button type="button" className="dp-title" onClick={() => setYears((x) => !x)} aria-expanded={years} data-testid="dp-title">
          {monthMode ? L.num(view.y) : `${L.month(view.y, view.m)} ${L.num(view.y)}`}
          <svg viewBox="0 0 24 24" aria-hidden="true" className={years ? 'is-open' : ''}><path d="M7 10l5 5 5-5z" /></svg>
        </button>
        {!years && (
          <span className="dp-nav">
            <button type="button" onClick={() => (monthMode ? setView((v) => ({ ...v, y: v.y - 1 })) : step(-1))} aria-label={monthMode ? 'Previous year' : 'Previous month'} data-testid="dp-prev"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15.4 7.4L14 6l-6 6 6 6 1.4-1.4L10.8 12z" /></svg></button>
            <button type="button" onClick={() => (monthMode ? setView((v) => ({ ...v, y: v.y + 1 })) : step(1))} aria-label={monthMode ? 'Next year' : 'Next month'} data-testid="dp-next"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8.6 16.6L10 18l6-6-6-6-1.4 1.4 4.6 4.6z" /></svg></button>
          </span>
        )}
      </div>
      {years ? (
        <div className="dp-years" data-testid="dp-years">
          {yearList.map((y) => (
            <button key={y} type="button" className={`dp-year ${y === view.y ? 'is-sel' : ''}`} ref={y === view.y ? (el) => el?.scrollIntoView({ block: 'center' }) : undefined}
              onClick={() => { setView((v) => ({ ...v, y })); setYears(false); }}>{L.num(y)}</button>
          ))}
        </div>
      ) : monthMode ? (
        <div className="dp-months">
          {Array.from({ length: 12 }, (_, m) => (
            <button key={m} type="button" disabled={offMonth(view.y, m)} className={`dp-mon ${val && val.y === view.y && val.m === m ? 'is-sel' : ''} ${now.getFullYear() === view.y && now.getMonth() === m ? 'is-today' : ''}`}
              onClick={() => pick(`${view.y}-${pad(m + 1)}`)}>{L.month(view.y, m, 'short')}</button>
          ))}
        </div>
      ) : (
        <>
          <div className="dp-week" aria-hidden="true">{L.days.map((d, i) => <span key={i}>{d}</span>)}</div>
          <div className="dp-grid" role="grid">
            {cells.map((d, i) => (d ? (
              <button key={i} type="button" data-day={d} disabled={off({ y: view.y, m: view.m, d })}
                className={`dp-day ${val && val.y === view.y && val.m === view.m && val.d === d ? 'is-sel' : ''} ${now.getFullYear() === view.y && now.getMonth() === view.m && now.getDate() === d ? 'is-today' : ''}`}
                aria-label={new Date(view.y, view.m, d).toDateString()} onClick={() => pick(iso(view.y, view.m, d))}>{L.num(d)}</button>
            ) : <span key={i} />))}
          </div>
        </>
      )}
      <div className="dp-foot">
        {!input.required && input.value ? <button type="button" className="dp-link" onClick={() => pick('')} data-testid="dp-clear">{L.t.clear}</button> : <span />}
        {(() => {
          const v = monthMode ? `${now.getFullYear()}-${pad(now.getMonth() + 1)}` : iso(now.getFullYear(), now.getMonth(), now.getDate());
          const t = { y: now.getFullYear(), m: now.getMonth(), d: now.getDate() };
          return <button type="button" className="dp-link strong" disabled={monthMode ? offMonth(t.y, t.m) : off(t)} onClick={() => pick(v)} data-testid="dp-today">{monthMode ? L.t.thisMonth : L.t.today}</button>;
        })()}
      </div>
    </div>
  );
}

export default function DatePickerHost() {
  const [input, setInputState] = useState(null);
  const cur = useRef(null);
  const n = useRef(0);
  const setInput = useCallback((next) => {
    const v = typeof next === 'function' ? next(cur.current) : next;
    if (v && v !== cur.current) n.current += 1;
    cur.current = v;
    setInputState(v);
  }, []);
  useEffect(() => {
    // Phones: no keyboard or the phone's own picker — the calendar opens instead
    // (a computer keeps typing in the box too: only touch screens make it read-only)
    const pre = (e) => {
      if (!isPickerInput(e.target) || e.pointerType === 'mouse' || e.pointerType === 'pen') return;
      if (!e.target.readOnly) { e.target.readOnly = true; e.target.dataset.qitDp = '1'; }
    };
    const open = (e) => {
      if (!isPickerInput(e.target)) return;
      const box = e.target;
      // v172: the × on a filled date box clears it (then a new date can be picked)
      if (e.type === 'click' && box.value) {
        const r = box.getBoundingClientRect();
        const fromRight = r.right - e.clientX;
        if (fromRight >= 30 && fromRight <= 62) {
          e.preventDefault();
          writeValue(box, '');
          markDates();
          setInput(null);
          return;
        }
      }
      if (e.type === 'keydown' && box.readOnly && box.value && ['Backspace', 'Delete'].includes(e.key)) {
        e.preventDefault(); writeValue(box, ''); markDates(); return;
      }
      if (e.type === 'keydown' && !['Enter', ' ', 'ArrowDown'].includes(e.key)) return;
      e.preventDefault();
      setInput((c) => (c === e.target && e.type === 'click' ? null : e.target));
    };
    document.addEventListener('pointerdown', pre, true);
    document.addEventListener('click', open, true);
    document.addEventListener('keydown', open, true);
    // a filled date box gets its coloured look and the × (also when the page fills it)
    const onEdit = (e) => { if (isPickerInput(e.target)) markDates(); };
    document.addEventListener('input', onEdit, true);
    document.addEventListener('change', onEdit, true);
    markDates();
    const tick = setInterval(markDates, 700);
    return () => {
      clearInterval(tick);
      document.removeEventListener('input', onEdit, true);
      document.removeEventListener('change', onEdit, true);
      document.removeEventListener('pointerdown', pre, true);
      document.removeEventListener('click', open, true);
      document.removeEventListener('keydown', open, true);
    };
  }, [setInput]);
  useEffect(() => {
    if (!input) return undefined;
    const away = (e) => { if (e.target !== input && !e.target.closest?.('.dp-pop')) setInput(null); };
    document.addEventListener('pointerdown', away, true);
    return () => document.removeEventListener('pointerdown', away, true);
  }, [input, setInput]);
  const close = useCallback((refocus) => {
    const el = cur.current;
    setInput(null);
    if (refocus && el && document.contains(el)) el.focus({ preventScroll: true });
  }, [setInput]);
  if (!input) return null;
  return createPortal(<Calendar key={n.current} input={input} onClose={close} />, document.body);
}
