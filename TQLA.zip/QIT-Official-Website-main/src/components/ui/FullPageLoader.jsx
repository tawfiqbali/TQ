import LogoMark from '../shared/LogoMark';

export default function FullPageLoader({ label = 'Loading' }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-paper" role="status">
      <LogoMark className="h-12 w-12 animate-pulse" />
      <span className="text-sm text-ink/60">{label}…</span>
    </div>
  );
}
