import { useEffect, useState } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { setSounds, soundsOn } from '../../lib/uiFx';

/** Switches the soft press sounds of the panels on or off (remembered on this device). */
export default function SoundToggle({ className = '', label = true }) {
  const [on, setOn] = useState(soundsOn);
  useEffect(() => {
    const sync = () => setOn(soundsOn());
    window.addEventListener('qit:sounds', sync);
    return () => window.removeEventListener('qit:sounds', sync);
  }, []);
  const text = on ? 'Sounds on' : 'Sounds off';
  return (
    <button type="button" className={className} onClick={() => setSounds(!on)} aria-pressed={on} aria-label={on ? 'Turn press sounds off' : 'Turn press sounds on'} title={text} data-testid="sound-toggle">
      {on ? <Volume2 className="h-4 w-4" aria-hidden="true" /> : <VolumeX className="h-4 w-4" aria-hidden="true" />}
      {label && <span>{text}</span>}
    </button>
  );
}
