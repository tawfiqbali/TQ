import { useEffect, useRef, useState } from 'react';
import { Check } from 'lucide-react';

/**
 * Glossy sign-in screens (teacher password, admin sign-in).
 * GlassStage: dark teal stage with slow glows and a frosted card that turns
 * green when `success` is set.  GlassCode: the password as glowing boxes; when
 * `state` is "success" the boxes fold into one tick, "error" shakes them.
 * A real <input> sits on top (invisible), so typing, pasting, password
 * managers and screen readers work as usual.
 */
export function GlassStage({ children, success = false, below = null, testId, wide = false, variant = 'teacher' }) {
  // variant "office": the admin sign-in, a darker boardroom look with gold rules
  const office = variant === 'office';
  return (
    <main className={`glass-stage ${office ? 'glass-office' : ''}`}>
      {office && (
        <>
          <span className="office-grid" aria-hidden="true" />
          <span className="office-rule" aria-hidden="true" />
          <span className="office-bars" aria-hidden="true">{[38, 54, 46, 70, 62, 84, 76, 96].map((h, i) => <i key={i} style={{ '--h': `${h}%`, '--d': `${i * 0.12}s` }} />)}</span>
          <span className="office-seal" aria-hidden="true">QIT</span>
        </>
      )}
      <span className="glass-glow glass-glow-a" aria-hidden="true" />
      <span className="glass-glow glass-glow-b" aria-hidden="true" />
      <span className="glass-glow glass-glow-c" aria-hidden="true" />
      <div className={`glass-wrap ${wide ? 'glass-wide' : ''}`}>
        <div className={`glass-card ${success ? 'is-success' : ''}`} data-testid={testId}>
          <span className="glass-handle" aria-hidden="true" />
          {children}
        </div>
        {below}
      </div>
    </main>
  );
}

export function GlassCode({ value, onChange, show = false, state = 'idle', id, testId, autoFocus = false, minBoxes = 4, inputMode, ariaLabel, disabled = false, pin = 0 }) {
  const [focused, setFocused] = useState(false);
  const input = useRef(null);
  // v183: phones keep the keyboard they opened with — when it turns out to be a
  // PIN (or no longer one), open the keyboard again so it shows the right keys
  useEffect(() => {
    const el = input.current;
    if (!el || document.activeElement !== el) return undefined;
    el.blur();
    const t = setTimeout(() => el.focus(), 60);
    return () => clearTimeout(t);
  }, [pin, inputMode]);
  const chars = [...String(value || '')];
  // as many boxes as characters typed (never fewer than minBoxes)
  const count = Math.min(Math.max(minBoxes, chars.length), 14);
  const shown = chars.length > 14 ? chars.slice(-14) : chars;
  const size = count > 10 ? 'xs' : count > 7 ? 'sm' : 'md';
  return (
    <div className={`glass-code glass-code-${size} is-${state}`} onClick={() => input.current?.focus()}>
      <div className="glass-boxes" aria-hidden="true">
        {Array.from({ length: count }, (_, i) => {
          const ch = shown[i];
          const active = focused && state === 'idle' && i === Math.min(shown.length, count - 1);
          return (
            <span key={i} className={`glass-box ${ch ? 'is-filled' : ''} ${active ? 'is-active' : ''}`} style={{ '--i': i, '--mid': (count - 1) / 2 }}>
              {ch ? (show ? ch : <i className="glass-dot" />) : active ? <i className="glass-caret" /> : null}
            </span>
          );
        })}
        <span className="glass-tick"><Check strokeWidth={3} /></span>
      </div>
      <input
        ref={input}
        id={id}
        data-testid={testId}
        // v183: a PIN uses a number pad on every phone (iPhone ignores the number
        // setting on password boxes, so a PIN box is a hidden-text box instead)
        type={show || pin ? 'text' : 'password'}
        pattern={pin ? '[0-9]*' : undefined}
        style={pin && !show ? { WebkitTextSecurity: 'disc' } : undefined}
        className="glass-code-input"
        value={value}
        // pin: digits only, exactly that many boxes
        onChange={(e) => onChange(pin ? e.target.value.replace(/\D/g, '').slice(0, pin) : e.target.value)}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        autoFocus={autoFocus}
        autoComplete="current-password"
        inputMode={pin ? 'numeric' : inputMode || 'text'}
        aria-label={ariaLabel}
        disabled={disabled || state === 'success'}
        maxLength={pin || 72}
      />
    </div>
  );
}

// Lets the success animation play before the next screen opens
export const glassPause = () => new Promise((r) => setTimeout(r, window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ? 150 : 950));
