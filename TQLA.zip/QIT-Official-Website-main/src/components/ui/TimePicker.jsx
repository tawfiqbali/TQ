import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Clock, X } from 'lucide-react';

/**
 * v186: time box used on the website (Book a trial), the admin panel and the
 * Teacher Dashboard.
 *   - type the time straight into the box ("7", "730", "7:30", "19:30")
 *   - or press the clock: rolling wheels for the hour and the minute
 *   - AM / PM must be chosen (nothing is saved until it is)
 * value / onChange: "HH:MM" (24 hour, like <input type="time">), or with
 * format="text" a readable "7:30 PM".
 */
const pad = (n) => String(n).padStart(2, '0');
const HOURS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
const MINUTES = Array.from({ length: 60 }, (_, i) => i);
const ITEM = 40;

// "HH:MM" (24h) or "h:mm AM/PM" → { h (1–12), m, ap }
function parseValue(v) {
  const s = String(v || '').trim();
  let m = /^(\d{1,2})[:.](\d{2})\s*([AaPp])\.?[Mm]?\.?$/.exec(s);
  if (m) return { h: Math.min(12, Math.max(1, Number(m[1]) % 12 || 12)), m: Math.min(59, Number(m[2])), ap: /p/i.test(m[3]) ? 'PM' : 'AM' };
  m = /^(\d{1,2}):(\d{2})/.exec(s);
  if (m) {
    const H = Math.min(23, Number(m[1]));
    return { h: H % 12 || 12, m: Math.min(59, Number(m[2])), ap: H >= 12 ? 'PM' : 'AM' };
  }
  return null;
}
// what was typed → { h, m, ap? } (ap only when the hour says it: 13–23 or 0)
function parseTyped(t) {
  const s = String(t || '').trim().replace(/\s+/g, '');
  if (!s) return null;
  let h;
  let mi = 0;
  let m = /^(\d{1,2})[:.](\d{1,2})$/.exec(s);
  if (m) { h = Number(m[1]); mi = Number(m[2]); } else if ((m = /^(\d{1,4})$/.exec(s))) {
    const d = m[1];
    if (d.length <= 2) h = Number(d);
    else { h = Number(d.slice(0, d.length - 2)); mi = Number(d.slice(-2)); }
  } else return null;
  if (h > 23 || mi > 59) return null;
  if (h === 0) return { h: 12, m: mi, ap: 'AM' };
  if (h > 12) return { h: h - 12, m: mi, ap: 'PM' };
  return { h, m: mi, ap: null };
}
const to24 = ({ h, m, ap }) => `${pad((h % 12) + (ap === 'PM' ? 12 : 0))}:${pad(m)}`;
export const prettyTime = (v) => {
  const p = parseValue(v);
  return p ? `${p.h}:${pad(p.m)} ${p.ap}` : '';
};

// One rolling column (scroll, swipe or tap a number)
function Wheel({ items, value, onPick, label, fmt = String, testPrefix }) {
  const ref = useRef(null);
  const timer = useRef(null);
  const idx = Math.max(0, items.indexOf(value));
  useLayoutEffect(() => {
    const el = ref.current;
    if (el && Math.abs(el.scrollTop - idx * ITEM) > 2) el.scrollTop = idx * ITEM;
  }, [idx]);
  const onScroll = () => {
    clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      const el = ref.current;
      if (!el) return;
      const i = Math.min(items.length - 1, Math.max(0, Math.round(el.scrollTop / ITEM)));
      if (items[i] !== value) onPick(items[i]);
      if (Math.abs(el.scrollTop - i * ITEM) > 1) el.scrollTo({ top: i * ITEM, behavior: 'smooth' });
    }, 90);
  };
  useEffect(() => () => clearTimeout(timer.current), []);
  return (
    <div className="tw-col">
      <span className="tw-label">{label}</span>
      <div className="tw-wheel" ref={ref} onScroll={onScroll} role="listbox" aria-label={label} tabIndex={0}
        onKeyDown={(e) => {
          if (e.key !== 'ArrowUp' && e.key !== 'ArrowDown') return;
          e.preventDefault();
          const i = Math.min(items.length - 1, Math.max(0, idx + (e.key === 'ArrowDown' ? 1 : -1)));
          onPick(items[i]);
        }}>
        <div style={{ height: ITEM * 2 }} aria-hidden="true" />
        {items.map((x) => (
          <button key={x} type="button" role="option" aria-selected={x === value} className={`tw-item ${x === value ? 'is-sel' : ''}`}
            onClick={() => { onPick(x); ref.current?.scrollTo({ top: items.indexOf(x) * ITEM, behavior: 'smooth' }); }}
            data-testid={testPrefix ? `${testPrefix}-${x}` : undefined}>{fmt(x)}</button>
        ))}
        <div style={{ height: ITEM * 2 }} aria-hidden="true" />
      </div>
    </div>
  );
}

export default function TimePicker({ value, onChange, className = 'input', ariaLabel, placeholder = 'hh:mm', clearable = false, labels = {}, id, testId, format = 'hhmm', disabled = false }) {
  const L = { title: 'Choose time', hour: 'Hour', minute: 'Minute', done: 'Done', clear: 'Clear', am: 'AM', pm: 'PM', needAmPm: 'Choose AM or PM', ...labels };
  const init = parseValue(value);
  const [text, setText] = useState(init ? `${init.h}:${pad(init.m)}` : '');
  const [ap, setAp] = useState(init ? init.ap : null);
  const [focus, setFocus] = useState(false);
  const [open, setOpen] = useState(false);
  const [d, setD] = useState({ h: 5, m: 0, ap: null });

  // the value changed from outside (another screen, a reset): show it
  const last = useRef(value);
  useEffect(() => {
    if (value === last.current || focus) return;
    last.current = value;
    const p = parseValue(value);
    setText(p ? `${p.h}:${pad(p.m)}` : '');
    setAp(p ? p.ap : null);
  }, [value, focus]);

  const emit = useCallback((t, a) => {
    const p = parseTyped(t);
    if (!String(t || '').trim()) { last.current = ''; onChange?.(''); return; }
    if (!p) return;
    const amPm = p.ap || a;
    if (!amPm) return; // AM / PM is a must
    const out = format === 'text' ? `${p.h}:${pad(p.m)} ${amPm}` : to24({ ...p, ap: amPm });
    last.current = out;
    onChange?.(out);
  }, [format, onChange]);

  const typed = parseTyped(text);
  const needAp = Boolean(text.trim() && typed && !typed.ap && !ap);
  const bad = Boolean(text.trim() && !typed);

  const onText = (t) => {
    setText(t);
    const p = parseTyped(t);
    if (p?.ap) setAp(p.ap);
    emit(t, p?.ap || ap);
  };
  const pickAp = (a) => { setAp(a); emit(text, a); };
  const blur = () => {
    setFocus(false);
    const p = parseTyped(text);
    if (p) setText(`${p.h}:${pad(p.m)}`);
  };

  const show = () => {
    const p = parseTyped(text);
    setD(p ? { h: p.h, m: p.m, ap: p.ap || ap } : { h: 5, m: 0, ap });
    setOpen(true);
  };
  const done = () => {
    if (!d.ap) return;
    const t = `${d.h}:${pad(d.m)}`;
    setText(t);
    setAp(d.ap);
    emit(t, d.ap);
    setOpen(false);
  };
  useEffect(() => {
    if (!open) return undefined;
    const key = (e) => { if (e.key === 'Escape') { e.stopPropagation(); setOpen(false); } };
    document.addEventListener('keydown', key, true);
    return () => document.removeEventListener('keydown', key, true);
  }, [open]);

  return (
    <>
      <div className={`${className} tp-field ${needAp ? 'tp-need-ap' : ''} ${bad ? 'tp-bad' : ''}`} data-testid={testId} data-value={value || ''}>
        <input id={id} className="tp-text" type="text" inputMode="numeric" autoComplete="off" lang="en" placeholder={placeholder} value={text} disabled={disabled}
          onChange={(e) => onText(e.target.value.replace(/[^\d:.\s]/g, '').slice(0, 5))} onFocus={() => setFocus(true)} onBlur={blur}
          aria-label={ariaLabel ? `${ariaLabel} (hh:mm)` : 'Time (hh:mm)'} aria-invalid={needAp || bad || undefined} data-testid={testId ? `${testId}-text` : undefined} />
        <span className="tp-ap" role="radiogroup" aria-label="AM / PM">
          {[['AM', L.am], ['PM', L.pm]].map(([k, lbl]) => (
            <button key={k} type="button" role="radio" aria-checked={ap === k} className={ap === k ? 'on' : ''} disabled={disabled} onClick={() => pickAp(k)}
              data-testid={testId ? `${testId}-${k.toLowerCase()}` : undefined}>{lbl}</button>
          ))}
        </span>
        <button type="button" className="tp-clock" onClick={show} disabled={disabled} aria-label={L.title} aria-haspopup="dialog" data-testid={testId ? `${testId}-open` : undefined}>
          <Clock className="h-4 w-4" aria-hidden="true" />
        </button>
      </div>
      {needAp && <span className="tp-hint" role="alert">{L.needAmPm}</span>}
      {open && createPortal(
        <div className="tw-veil" onMouseDown={(e) => e.target === e.currentTarget && setOpen(false)} data-testid="time-picker">
          <div role="dialog" aria-modal="true" aria-label={L.title} className="tw-card">
            <div className="tw-head">
              <p>{L.title}</p>
              <button type="button" onClick={() => setOpen(false)} aria-label="Close" className="tw-x"><X className="h-5 w-5" aria-hidden="true" /></button>
            </div>
            <p className="tw-big" lang="en" aria-live="polite" data-testid="tp-value">{d.h}:{pad(d.m)} <span className={d.ap ? '' : 'is-missing'}>{d.ap || 'AM / PM'}</span></p>
            <div className="tw-cols" lang="en">
              <Wheel items={HOURS} value={d.h} onPick={(h) => setD((x) => ({ ...x, h }))} label={L.hour} testPrefix="tp-h" />
              <span className="tw-colon" aria-hidden="true">:</span>
              <Wheel items={MINUTES} value={d.m} onPick={(m) => setD((x) => ({ ...x, m }))} label={L.minute} fmt={pad} testPrefix="tp-m" />
              <div className="tw-col">
                <span className="tw-label">AM / PM</span>
                <div className="tw-ap" role="radiogroup" aria-label="AM / PM">
                  {[['AM', L.am], ['PM', L.pm]].map(([k, lbl]) => (
                    <button key={k} type="button" role="radio" aria-checked={d.ap === k} className={d.ap === k ? 'on' : ''} onClick={() => setD((x) => ({ ...x, ap: k }))} data-testid={`tp-${k.toLowerCase()}`}>{lbl}</button>
                  ))}
                </div>
              </div>
            </div>
            {!d.ap && <p className="tw-need" role="alert">{L.needAmPm}</p>}
            <div className="tw-foot">
              {clearable && value && (
                <button type="button" className="tw-clear" onClick={() => { setText(''); setAp(null); emit('', null); setOpen(false); }}>{L.clear}</button>
              )}
              <button type="button" className="tw-done" onClick={done} disabled={!d.ap} data-testid="tp-done">
                {L.done}{d.ap ? <> · <span lang="en">{d.h}:{pad(d.m)} {d.ap}</span></> : null}
              </button>
            </div>
          </div>
        </div>,
        document.body,
      )}
    </>
  );
}
