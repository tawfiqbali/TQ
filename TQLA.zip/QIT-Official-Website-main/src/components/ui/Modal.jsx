import { lockScroll } from '../../lib/scrollLock';
import { useLanguage } from '../../i18n/LanguageContext';
import { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';

const SIZES = { sm: 'sm:max-w-md', md: 'sm:max-w-lg', lg: 'sm:max-w-2xl' };

// `bare` skips the built-in title bar and padding so the child can draw its
// own header (the trial form puts its send button top right).
export default function Modal({ open, onClose, title, description, size = 'lg', bare = false, labelledBy = 'modal-title', children }) {
  const { t } = useLanguage();
  const panelRef = useRef(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;

  useEffect(() => {
    if (!open) return undefined;
    const previouslyFocused = document.activeElement;
    const onKey = (e) => e.key === 'Escape' && closeRef.current?.();
    document.addEventListener('keydown', onKey);
    const prevOverflow = lockScroll();
    const t = setTimeout(() => {
      panelRef.current?.querySelector('input:not([type=hidden]):not([tabindex="-1"]), select, textarea, button:not([data-close])')?.focus();
    }, 30);
    return () => {
      document.removeEventListener('keydown', onKey);
      prevOverflow();
      clearTimeout(t);
      previouslyFocused?.focus?.();
    };
  }, [open]);

  if (!open) return null;

  return createPortal(
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center sm:p-6">
      <div className="absolute inset-0 bg-pine-950/60" onClick={() => closeRef.current?.()} aria-hidden="true" />
      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={labelledBy}
        className={`relative max-h-[92vh] w-full overflow-y-auto rounded-t-3xl bg-surface shadow-2xl sm:rounded-3xl ${bare ? '' : 'p-6 sm:p-8'} ${SIZES[size]}`}
      >
        {!bare && (
        <div className="mb-5 flex items-start justify-between gap-4">
          <div>
            <h2 id="modal-title" className="text-2xl">
              {title}
            </h2>
            {description && <p className="mt-1.5 text-sm text-ink/65">{description}</p>}
          </div>
          <button data-close type="button" onClick={() => closeRef.current?.()} className="icon-btn -mr-2 -mt-1" aria-label={t('common.close')}>
            <X className="h-5 w-5" />
          </button>
        </div>
        )}
        {children}
      </div>
    </div>,
    document.body,
  );
}
