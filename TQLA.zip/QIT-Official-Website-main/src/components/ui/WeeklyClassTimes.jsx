import { useEffect, useMemo, useRef, useState } from 'react';
import { Plus, Save, Trash2, X } from 'lucide-react';
import TimePicker, { prettyTime } from './TimePicker';
import { useConfirm } from './Confirm';

// Bangladesh week order: Saturday first
export const WEEK = [6, 0, 1, 2, 3, 4, 5];
const SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const DURATIONS = [30, 45, 60, 75, 90, 120];
const hhmm = (v) => String(v || '').slice(0, 5);
const byWeek = (a, b) => WEEK.indexOf(a) - WEEK.indexOf(b);
let uid = 0;
const blank = () => ({ key: `n${(uid += 1)}`, days: [], start: '17:00', duration: 45, note: '' });

// Saved rows -> one box per class time: the days that share a time, length and note
export function groupRows(rows) {
  const map = new Map();
  (rows || []).forEach((r) => {
    const k = `${hhmm(r.start_time)}|${r.duration_min}|${r.note || ''}`;
    if (!map.has(k)) map.set(k, { key: k, days: [], start: hhmm(r.start_time), duration: Number(r.duration_min) || 45, note: r.note || '' });
    map.get(k).days.push(r.weekday);
  });
  return [...map.values()].map((g) => ({ ...g, days: g.days.sort(byWeek) })).sort((a, b) => a.start.localeCompare(b.start));
}
const flat = (sets) =>
  sets.flatMap((g) => g.days.map((d) => ({ weekday: d, start_time: g.start, duration_min: Number(g.duration), note: (g.note || '').trim() || null })))
    .sort((a, b) => a.weekday - b.weekday || a.start_time.localeCompare(b.start_time));
const sig = (sets) => JSON.stringify(flat(sets));

const EN = {
  addTitle: 'Add class time', editTitle: 'Edit class time', days: 'Days', start: 'Start time', length: 'Class length', min: '{n} min',
  note: 'Note (optional)', another: 'Add a different time', removeSet: 'Remove this time', deleteAll: 'Delete schedule',
  deleteQ: 'Delete the whole weekly schedule?', deleteMsg: 'All weekly class times of this student will be removed.', deleteYes: 'Delete schedule', cancel: 'Cancel',
  save: 'Save class times', saving: 'Saving…', pickDay: 'Pick at least one day.', clash: '{day} at {time} is in the list twice.',
  hint: 'Times are Bangladesh time.', applyHint: 'Press Save changes to apply.', unsaved: 'Not saved yet',
};

/**
 * One student's weekly class times as a single "Add / Edit class time" box:
 * the saved days are already selected; change the days, the time or the
 * length and save. A second box holds days that have a different time.
 *
 * rows: saved class_schedules rows · onSave(slots): saves the whole timetable
 * (throws on error) · pendingRef: lets a surrounding form save this on its own
 * Save button (then no Save button is shown here).
 */
export default function WeeklyClassTimes({ rows, onSave, pendingRef, labels, weekdayLabel, weekdayLong, timeLabel, inputClass = 'input', showNote = true, disabled = false }) {
  const L = { ...EN, ...labels };
  const confirm = useConfirm();
  const saved = useMemo(() => groupRows(rows), [rows]);
  const savedSig = sig(saved);
  const [sets, setSets] = useState(() => (saved.length ? saved : [blank()]));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  // The saved timetable changed (after a save, or from another screen): show it
  const last = useRef(savedSig);
  useEffect(() => {
    if (last.current === savedSig) return;
    last.current = savedSig;
    setSets(saved.length ? saved : [blank()]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [savedSig]);

  const has = (rows || []).length > 0;
  const dirty = sig(sets) !== savedSig;
  const dayShort = (d) => (weekdayLabel ? weekdayLabel(d) : SHORT[d]);
  const dayLong = (d) => (weekdayLong ? weekdayLong(d) : SHORT[d]);
  const patch = (key, p) => {
    setError('');
    setSets((list) => list.map((g) => (g.key === key ? { ...g, ...p } : g)));
  };
  const toggle = (g, d) => patch(g.key, { days: g.days.includes(d) ? g.days.filter((x) => x !== d) : [...g.days, d].sort(byWeek) });

  // true = saved (or nothing to save), false = stopped with a message
  const save = async (next = sets) => {
    if (busy) return false;
    const slots = flat(next);
    const seen = new Set();
    for (const s of slots) {
      const k = `${s.weekday}|${s.start_time}`;
      if (seen.has(k)) {
        setError(L.clash.replace('{day}', dayLong(s.weekday)).replace('{time}', timeLabel ? timeLabel(s.start_time) : prettyTime(s.start_time)));
        return false;
      }
      seen.add(k);
    }
    if (!slots.length && !has) {
      setError(L.pickDay);
      return false;
    }
    setBusy(true);
    setError('');
    try {
      await onSave(slots);
      setBusy(false);
      return true;
    } catch (e) {
      setError(e.message || 'Could not save the class times. Please try again.');
      setBusy(false);
      return false;
    }
  };
  const removeAll = async () => {
    if (!(await confirm({ title: L.deleteQ, message: L.deleteMsg, confirmText: L.deleteYes, cancelText: L.cancel, tone: 'danger' }))) return;
    if (await save([])) setSets([blank()]);
  };
  useEffect(() => {
    if (!pendingRef) return undefined;
    // a new student box with no day picked is simply "nothing to save"
    pendingRef.current = async () => (dirty && (flat(sets).length || has) ? ((await save()) ? 'saved' : false) : true);
    return () => {
      pendingRef.current = null;
    };
  });

  const chip = (on) =>
    `min-w-[3.1rem] rounded-lg border px-2.5 py-1.5 text-sm font-semibold transition-colors duration-150 ${on ? 'border-[#034751] bg-[#034751] text-white shadow-sm' : 'border-black/15 bg-transparent opacity-80 hover:border-[#034751] hover:opacity-100 dark:border-white/20'}`;
  return (
    <div data-testid="weekly-times" onKeyDown={(e) => {
      // Enter in these fields never submits a surrounding form
      if (e.key === 'Enter' && e.target.tagName !== 'BUTTON') e.preventDefault();
    }}>
      <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
        <p className="text-xs font-bold uppercase tracking-wider opacity-70" data-testid="wt-title">{has ? L.editTitle : L.addTitle}</p>
        {dirty && <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[11px] font-bold text-amber-900" data-testid="wt-unsaved">{L.unsaved}</span>}
      </div>
      <div className="space-y-3">
        {sets.map((g, i) => (
          <div key={g.key} className="rounded-xl border border-black/10 p-3 dark:border-white/15" data-testid={`wt-set-${i}`}>
            <div className="flex flex-wrap gap-1.5" role="group" aria-label={L.days}>
              {WEEK.map((d) => (
                <button key={d} type="button" aria-pressed={g.days.includes(d)} aria-label={dayLong(d)} disabled={disabled || busy} onClick={() => toggle(g, d)} className={chip(g.days.includes(d))} data-testid={`wt-day-${i}-${d}`}>
                  {dayShort(d)}
                </button>
              ))}
            </div>
            <div className={`mt-2.5 grid gap-2 ${showNote ? 'sm:grid-cols-[1fr_auto_1.4fr_auto]' : 'grid-cols-[1fr_auto_auto]'}`}>
              <TimePicker className={inputClass} value={g.start} onChange={(x) => patch(g.key, { start: x })} ariaLabel={L.start} testId={`wt-time-${i}`}
                labels={{ title: L.pickTime, hour: L.hour, minute: L.minute, done: L.done, ...(L.needAmPm ? { needAmPm: L.needAmPm } : {}) }} />
              <select className={inputClass} style={{ width: 'auto' }} value={g.duration} onChange={(e) => patch(g.key, { duration: Number(e.target.value) })} aria-label={L.length} disabled={disabled || busy}>
                {[...new Set([...DURATIONS, Number(g.duration)])].sort((a, b) => a - b).map((m) => <option key={m} value={m}>{L.min.replace('{n}', m)}</option>)}
              </select>
              {showNote && <input className={inputClass} maxLength={300} placeholder={L.note} aria-label={L.note} value={g.note} onChange={(e) => patch(g.key, { note: e.target.value })} disabled={disabled || busy} />}
              {sets.length > 1 && (
                <button type="button" onClick={() => { setError(''); setSets((list) => list.filter((x) => x.key !== g.key)); }} disabled={disabled || busy} aria-label={L.removeSet} title={L.removeSet}
                  className="flex h-10 w-10 items-center justify-center justify-self-end rounded-lg border border-black/10 text-red-700 hover:bg-red-50 dark:border-white/15" data-testid={`wt-remove-${i}`}>
                  <X className="h-4 w-4" aria-hidden="true" />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
      {error && <p role="alert" className="mt-2 rounded-lg bg-red-50 px-3 py-2 text-sm font-semibold text-red-800" data-testid="wt-error">{error}</p>}
      <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
          <button type="button" onClick={() => setSets((list) => [...list, blank()])} disabled={disabled || busy} className="inline-flex items-center gap-1 text-sm font-semibold text-[#005359] hover:underline dark:text-teal-300" data-testid="wt-another">
            <Plus className="h-4 w-4" aria-hidden="true" /> {L.another}
          </button>
          {has && (
            <button type="button" onClick={removeAll} disabled={disabled || busy} className="inline-flex items-center gap-1 text-sm font-semibold text-red-700 hover:underline" data-testid="wt-delete-all">
              <Trash2 className="h-4 w-4" aria-hidden="true" /> {L.deleteAll}
            </button>
          )}
        </div>
        {!pendingRef && (
          <button type="button" onClick={() => save()} disabled={disabled || busy || !dirty}
            className="inline-flex items-center gap-2 rounded-xl bg-[#034751] px-4 py-2.5 text-sm font-bold text-white shadow-md transition hover:bg-[#005359] disabled:opacity-50" data-testid="wt-save">
            <Save className="h-4 w-4" aria-hidden="true" /> {busy ? L.saving : L.save}
          </button>
        )}
      </div>
      <p className="mt-2 text-xs opacity-70">{L.hint}{pendingRef ? ` ${L.applyHint}` : ''}</p>
    </div>
  );
}
