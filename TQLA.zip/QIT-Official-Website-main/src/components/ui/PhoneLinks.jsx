import { Phone } from 'lucide-react';
import { WhatsAppIcon } from '../shared/BrandIcons';

// A Bangladeshi number written the local way (017…) needs the country code for WhatsApp
export function waDigits(number) {
  const d = String(number || '').replace(/\D/g, '');
  if (!d) return '';
  if (d.length === 11 && d.startsWith('01')) return `88${d}`;
  return d.replace(/^00/, '');
}
export const splitNumbers = (text) =>
  (/^\s*n\/?a\s*$/i.test(String(text ?? '')) ? '' : String(text ?? '')).split(/\s*[,;\n|]\s*/).map((p) => p.trim()).filter((p) => p && /\d{5}/.test(p.replace(/\D/g, '')));

// Every phone number on the site: always on one line, the number opens WhatsApp
// and the small handset beside it starts a call. `value` may hold several numbers.
export default function PhoneLinks({ value, empty = '—', className = '' }) {
  const list = splitNumbers(value);
  if (!list.length) return <span className="ph-none">{value && !/^\s*n\/?a\s*$/i.test(value) && String(value).trim() ? String(value) : empty}</span>;
  return (
    <span className={`ph-list ${className}`} lang="en" onClick={(e) => e.stopPropagation()} onKeyDown={(e) => e.stopPropagation()}>
      {list.map((n) => {
        const d = waDigits(n);
        const tel = `tel:${n.trim().startsWith('+') || d.length < 11 ? n.replace(/[^\d+]/g, '') : `+${d}`}`;
        return (
          <span key={n} className="ph">
            <a className="ph-wa" href={`https://wa.me/${d}`} target="_blank" rel="noreferrer" title={`WhatsApp ${n}`} aria-label={`WhatsApp ${n}`}>
              <WhatsAppIcon className="ph-i" aria-hidden="true" /><span className="ph-n">{n}</span>
            </a>
            <a className="ph-call" href={tel} title={`Call ${n}`} aria-label={`Call ${n}`}><Phone className="ph-i" aria-hidden="true" /></a>
          </span>
        );
      })}
    </span>
  );
}
