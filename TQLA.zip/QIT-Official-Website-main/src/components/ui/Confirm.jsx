import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { AlertTriangle, HelpCircle } from 'lucide-react';

/**
 * In-app confirmation dialog, replacing window.confirm().
 *
 *   const confirm = useConfirm();
 *   if (!(await confirm({ title: 'Delete student?', message: '…', confirmText: 'Delete', tone: 'danger' }))) return;
 *
 * Esc or the backdrop cancels, Enter confirms; focus returns to where it was.
 */
const ConfirmContext = createContext(async () => false);

export function ConfirmProvider({ children }) {
  const [dialog, setDialog] = useState(null);
  const resolver = useRef(null);
  const lastFocus = useRef(null);

  const confirm = useCallback((opts = {}) => {
    lastFocus.current = document.activeElement;
    return new Promise((resolve) => {
      resolver.current = resolve;
      setDialog(typeof opts === 'string' ? { message: opts } : opts);
    });
  }, []);

  const close = useCallback((answer) => {
    resolver.current?.(answer);
    resolver.current = null;
    setDialog(null);
    setTimeout(() => lastFocus.current?.focus?.(), 0);
  }, []);

  return (
    <ConfirmContext.Provider value={confirm}>
      {children}
      {dialog && <ConfirmDialog {...dialog} onClose={close} />}
    </ConfirmContext.Provider>
  );
}

function ConfirmDialog({ title = 'Are you sure?', message, confirmText = 'Confirm', cancelText = 'Cancel', tone = 'primary', onClose }) {
  const okRef = useRef(null);
  const boxRef = useRef(null);
  const danger = tone === 'danger';

  useEffect(() => {
    okRef.current?.focus();
    const onKey = (e) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        onClose(false);
      }
      // Keep Tab inside the dialog
      if (e.key === 'Tab' && boxRef.current) {
        const items = boxRef.current.querySelectorAll('button');
        const first = items[0];
        const last = items[items.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener('keydown', onKey, true);
    return () => document.removeEventListener('keydown', onKey, true);
  }, [onClose]);

  return createPortal(
    <div data-sfx className="fixed inset-0 z-[80] flex items-end justify-center p-4 sm:items-center" role="presentation">
      <div className="qit-fade-in absolute inset-0 bg-pine-950/55 backdrop-blur-[2px]" onClick={() => onClose(false)} aria-hidden="true" />
      <div
        ref={boxRef}
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="qit-confirm-title"
        aria-describedby={message ? 'qit-confirm-msg' : undefined}
        className="qit-pop-in relative w-full max-w-md rounded-2xl bg-white p-6 text-pine-950 shadow-2xl dark:bg-[#12302e] dark:text-pine-50"
      >
        <div className="flex gap-4">
          <span className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full ${danger ? 'bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-200' : 'bg-pine-50 text-pine-800 dark:bg-pine-900/60 dark:text-pine-100'}`}>
            {danger ? <AlertTriangle className="h-5 w-5" aria-hidden="true" /> : <HelpCircle className="h-5 w-5" aria-hidden="true" />}
          </span>
          <div className="min-w-0">
            <h2 id="qit-confirm-title" className="text-lg font-bold leading-snug">{title}</h2>
            {message && <p id="qit-confirm-msg" className="mt-1.5 whitespace-pre-line text-sm leading-relaxed opacity-80">{message}</p>}
          </div>
        </div>
        <div className="mt-6 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
          <button type="button" onClick={() => onClose(false)} className="rounded-xl border border-pine-950/15 px-4 py-2.5 text-sm font-semibold transition hover:bg-pine-50 dark:border-white/20 dark:hover:bg-white/10">
            {cancelText}
          </button>
          <button
            ref={okRef}
            type="button"
            onClick={() => onClose(true)}
            className={`rounded-xl px-4 py-2.5 text-sm font-semibold text-white shadow transition ${danger ? 'bg-red-700 hover:bg-red-800' : 'bg-pine-800 hover:bg-pine-900'}`}
          >
            {confirmText}
          </button>
        </div>
      </div>
    </div>,
    document.body,
  );
}

export const useConfirm = () => useContext(ConfirmContext);
