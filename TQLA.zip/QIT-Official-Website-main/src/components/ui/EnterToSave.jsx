import { useEffect } from 'react';

/**
 * v172: pressing Enter after typing in a box saves / confirms, everywhere
 * (website, admin, Management Portal, Teacher Dashboard):
 *  - in a <form>: the form is sent (as its Save / Submit button does)
 *  - in a pop-up or a pay-out bar without a form: the main button that comes
 *    after the box (Save, Disburse, Assign…) is pressed
 * Not for: long text boxes (Enter = new line; Ctrl/⌘+Enter saves there), search
 * boxes, lists that are open (they pick the item), buttons and links.
 * A part of a page can opt out with data-no-enter, or name its button with data-enter-save.
 */
const PRIMARY = 'button[data-enter-save], button[type="submit"], button.btn-teal, button.btn-primary, button.btn-gold';
const visible = (b) => !b.disabled && b.offsetParent !== null && b.getAttribute('aria-disabled') !== 'true';

export default function EnterToSave() {
  useEffect(() => {
    const onKey = (e) => {
      if (e.key !== 'Enter' || e.defaultPrevented || e.shiftKey || e.altKey || e.isComposing) return;
      const el = e.target;
      if (!(el instanceof HTMLElement) || el.closest('[data-no-enter]')) return;
      const tag = el.tagName;
      if (tag === 'TEXTAREA' && !(e.ctrlKey || e.metaKey)) return;
      if (tag === 'INPUT' && ['search', 'checkbox', 'radio', 'button', 'submit', 'reset', 'file', 'image', 'range', 'color'].includes(el.type)) return;
      if (!['INPUT', 'SELECT', 'TEXTAREA'].includes(tag)) return;
      if (el.getAttribute('aria-expanded') === 'true') return; // an open list picks its item
      const form = el.closest('form');
      if (form) {
        e.preventDefault();
        if (typeof form.requestSubmit === 'function') form.requestSubmit();
        else form.querySelector('button[type="submit"]')?.click();
        return;
      }
      const scope = el.closest('[data-enter-scope], .payout-bar, .modal-card, [role="dialog"], [role="alertdialog"]');
      if (!scope) return;
      const buttons = [...scope.querySelectorAll(PRIMARY)].filter(visible);
      if (!buttons.length) return;
      // the main button at the bottom (Save under the fields)
      const pick = buttons.find((b) => b.matches('[data-enter-save]')) || buttons[buttons.length - 1];
      e.preventDefault();
      pick.click();
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, []);
  return null;
}
