import { useEffect, useState } from 'react';
import { ArrowUp, Pin, PinOff } from 'lucide-react';

// v153: "Go to top" for every long list, plus an on/off switch that keeps
// the search bars fixed at the top while scrolling (remembered on this device).
const KEY = 'qit:sticky-search';
export const stickyOn = () => { try { return localStorage.getItem(KEY) !== 'off'; } catch { return true; } };
export function applySticky(on) { document.documentElement.classList.toggle('qit-sticky-on', on); }

export default function ScrollTools({ className = '' }) {
  const [show, setShow] = useState(false);
  const [sticky, setSticky] = useState(stickyOn);
  useEffect(() => { applySticky(sticky); }, [sticky]);
  useEffect(() => () => document.documentElement.classList.remove('qit-sticky-on'), []);
  useEffect(() => {
    let raf = 0;
    const on = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => setShow(window.scrollY > 420)); };
    on();
    window.addEventListener('scroll', on, { passive: true });
    return () => { window.removeEventListener('scroll', on); cancelAnimationFrame(raf); };
  }, []);
  const toggle = () => setSticky((s) => { const n = !s; try { localStorage.setItem(KEY, n ? 'on' : 'off'); } catch { /* not remembered */ } return n; });
  return (
    <div className={`scroll-tools ${show ? 'is-on' : ''} ${className}`} data-testid="scroll-tools">
      <button type="button" className="scroll-tool" onClick={toggle} aria-pressed={sticky} title={sticky ? 'Search bar stays at the top — tap to turn off' : 'Search bar scrolls away — tap to keep it at the top'} data-testid="sticky-toggle">
        {sticky ? <Pin className="h-4 w-4" /> : <PinOff className="h-4 w-4" />}<span className="sr-only">Keep search bar at the top</span>
      </button>
      <button type="button" className="scroll-tool is-top" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} aria-label="Go to top" title="Go to top" data-testid="go-top">
        <ArrowUp className="h-5 w-5" />
      </button>
    </div>
  );
}
