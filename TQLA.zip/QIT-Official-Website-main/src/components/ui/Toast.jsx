import { createContext, useCallback, useContext, useState } from 'react';
import { AlertCircle, CheckCircle2, Info, X } from 'lucide-react';

/**
 * Floating messages (replace window.alert):
 *   const toast = useToast();
 *   toast('Student deleted');            // success
 *   toast('Could not save', 'error');    // error (stays longer)
 *   toast('Copied', 'info');
 */
const ToastContext = createContext(() => {});

const STYLE = {
  success: { box: 'bg-pine-900 text-white', Icon: CheckCircle2, icon: 'text-gold-300' },
  error: { box: 'bg-red-700 text-white', Icon: AlertCircle, icon: 'text-white' },
  info: { box: 'bg-slate-800 text-white', Icon: Info, icon: 'text-sky-300' },
};

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const dismiss = useCallback((id) => setToasts((t) => t.filter((x) => x.id !== id)), []);

  const push = useCallback(
    (message, tone = 'success') => {
      const id = Math.random().toString(36).slice(2);
      setToasts((t) => [...t.slice(-3), { id, message: String(message ?? ''), tone: STYLE[tone] ? tone : 'success' }]);
      setTimeout(() => dismiss(id), tone === 'error' ? 7000 : 3800);
    },
    [dismiss],
  );

  return (
    <ToastContext.Provider value={push}>
      {children}
      <div aria-live="polite" className="pointer-events-none fixed inset-x-4 bottom-4 z-[90] flex flex-col items-end gap-2 sm:left-auto">
        {toasts.map((t) => {
          const { box, Icon, icon } = STYLE[t.tone];
          return (
            <div key={t.id} role={t.tone === 'error' ? 'alert' : 'status'} className={`qit-pop-in pointer-events-auto flex max-w-sm items-start gap-2.5 rounded-xl px-4 py-3 text-sm shadow-lg ${box}`}>
              <Icon className={`mt-0.5 h-4 w-4 shrink-0 ${icon}`} aria-hidden="true" />
              <span className="min-w-0 flex-1">{t.message}</span>
              <button type="button" onClick={() => dismiss(t.id)} className="-mr-1 rounded p-0.5 opacity-70 hover:opacity-100" aria-label="Close message">
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          );
        })}
      </div>
    </ToastContext.Provider>
  );
}

export const useToast = () => useContext(ToastContext);
