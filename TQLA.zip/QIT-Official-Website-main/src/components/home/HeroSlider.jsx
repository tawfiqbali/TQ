import { useCallback, useEffect, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, Pause, Play } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';
import { responsiveImg } from '../../lib/images';

const DEFAULT_SECONDS = 2.5; // time each photo stays (admin can change it)
const SLIDE_MS = 420; // length of the quick slide animation

// Photos slide sideways automatically, one after another, in an endless loop.
// Arrows, dots and swipe move it by hand; the pause button stops it.
export default function HeroSlider({ slides, seconds }) {
  const { t, n } = useLanguage();
  const count = slides.length;
  const s = Number(seconds);
  const interval = Math.round((Number.isFinite(s) && s > 0 ? Math.min(10, Math.max(1, s)) : DEFAULT_SECONDS) * 1000);
  // The track holds the photos plus a copy of the first one at the end, so the
  // last -> first step still slides forward instead of rewinding.
  const [pos, setPos] = useState(0);
  const [animate, setAnimate] = useState(true);
  const [paused, setPaused] = useState(false);
  const [hovered, setHovered] = useState(false);
  const touchX = useRef(null);
  const busy = useRef(false);

  const active = count ? pos % count : 0;

  const goTo = useCallback(
    (next) => {
      if (count < 2 || busy.current) return;
      busy.current = true;
      setAnimate(true);
      setPos(next);
      setTimeout(() => {
        busy.current = false;
      }, SLIDE_MS);
    },
    [count],
  );

  const next = useCallback(() => goTo(pos + 1), [goTo, pos]);
  const prev = useCallback(() => {
    if (count < 2 || busy.current) return;
    if (pos === 0) {
      // Jump (without animation) to the copy at the end, then slide back one
      setAnimate(false);
      setPos(count);
      requestAnimationFrame(() => requestAnimationFrame(() => goTo(count - 1)));
    } else goTo(pos - 1);
  }, [count, pos, goTo]);

  // After sliding onto the copy of the first photo, snap back to the real one
  useEffect(() => {
    if (pos !== count || count < 2 || !animate) return undefined;
    const t = setTimeout(() => {
      setAnimate(false);
      setPos(0);
    }, SLIDE_MS);
    return () => clearTimeout(t);
  }, [pos, count, animate]);

  // Autoplay
  useEffect(() => {
    if (count < 2 || paused || hovered) return undefined;
    const t = setTimeout(() => {
      if (!document.hidden) next();
    }, interval);
    return () => clearTimeout(t);
  }, [pos, count, paused, hovered, next, interval]);

  useEffect(() => {
    if (pos > count) setPos(0);
  }, [count, pos]);

  if (!count) return null;

  // Only real mouse pointers pause on hover (touch screens fire fake hovers)
  const canHover = typeof window !== 'undefined' && window.matchMedia?.('(hover: hover) and (pointer: fine)').matches;
  const track = count > 1 ? [...slides, slides[0]] : slides;
  const btn = 'flex h-10 w-10 items-center justify-center rounded-full bg-surface/90 text-brand shadow-md transition hover:bg-surface';

  return (
    <div
      className="group relative overflow-hidden rounded-2xl bg-pine-950"
      role="region"
      aria-roledescription="carousel"
      aria-label={t('slider.label')}
      onMouseEnter={() => canHover && setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onKeyDown={(e) => {
        if (e.key === 'ArrowRight') next();
        if (e.key === 'ArrowLeft') prev();
      }}
      onTouchStart={(e) => {
        touchX.current = e.touches[0].clientX;
      }}
      onTouchEnd={(e) => {
        if (touchX.current == null) return;
        const dx = e.changedTouches[0].clientX - touchX.current;
        if (Math.abs(dx) > 40) (dx < 0 ? next : prev)();
        touchX.current = null;
      }}
    >
      <div className="aspect-[3/2] overflow-hidden">
        <div
          className="slider-track flex h-full"
          style={{
            transform: `translateX(-${pos * 100}%)`,
            transition: animate ? `transform ${SLIDE_MS}ms cubic-bezier(.4,0,.2,1)` : 'none',
          }}
        >
          {track.map((src, i) => (
            <img
              key={`${src}-${i}`}
              {...responsiveImg(src, '(min-width: 1024px) 560px, 92vw')}
              alt={i < count ? `Online one-to-one Quran class, photo ${i + 1} of ${count}` : ''}
              aria-hidden={i % count !== active || i >= count}
              className="h-full w-full shrink-0 object-cover"
              width="1440"
              height="960"
              loading={i === 0 ? 'eager' : 'lazy'}
              fetchpriority={i === 0 ? 'high' : 'low'}
              decoding="async"
              draggable="false"
            />
          ))}
        </div>
      </div>

      {count > 1 && (
        <>
          <div className="absolute inset-y-0 left-3 flex items-center opacity-0 transition group-hover:opacity-100 max-md:opacity-100">
            <button type="button" onClick={prev} className={btn} aria-label={t('slider.prev')}>
              <ChevronLeft className="h-5 w-5" />
            </button>
          </div>
          <div className="absolute inset-y-0 right-3 flex items-center opacity-0 transition group-hover:opacity-100 max-md:opacity-100">
            <button type="button" onClick={next} className={btn} aria-label={t('slider.next')}>
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>
          <div className="absolute bottom-3 right-3 flex items-center gap-2 rounded-full bg-pine-950/60 px-3 py-1.5">
            {slides.map((_, i) => (
              <button
                key={i}
                type="button"
                onClick={() => goTo(i)}
                aria-label={t('slider.show', { n: n(i + 1) })}
                aria-current={i === active}
                className={`h-2 rounded-full transition-all ${i === active ? 'w-6 bg-gold-400' : 'w-2 bg-white/60 hover:bg-white'}`}
              />
            ))}
            <button
              type="button"
              onClick={() => setPaused((p) => !p)}
              className="ml-1 text-white/80 hover:text-white"
              aria-label={paused ? t('slider.play') : t('slider.pause')}
            >
              {paused ? <Play className="h-3.5 w-3.5" /> : <Pause className="h-3.5 w-3.5" />}
            </button>
          </div>
        </>
      )}
    </div>
  );
}
