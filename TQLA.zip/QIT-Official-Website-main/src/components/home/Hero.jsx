import { Link } from "react-router-dom";
import { BadgeCheck, Bell, Star } from "lucide-react";
import { useContent, useLanguage } from "../../i18n/LanguageContext";
import { useTrialModal } from "../../context/TrialModalContext";
import { splitHighlight } from "../../lib/utils";
import HeroSlider from "./HeroSlider";
import HeroVideos from "./VideoShowcase";
import { ACCENT, FRAME } from "./heroFrame";

export default function Hero() {
  const content = useContent();
  const { t, n } = useLanguage();
  const { openTrial } = useTrialModal();
  const { hero, stats } = content.site;
  const [before, highlight, after] = splitHighlight(
    hero.headline,
    hero.highlight,
  );
  const slides = (hero.slides?.length ? hero.slides : [hero.imageUrl]).filter(
    Boolean,
  );

  // Labels are fixed and capitalised; an empty value hides that figure
  const figures = [
    { value: stats.students, label: t("hero.studentsTaught"), highlight: true },
    { value: stats.countries, label: t("hero.countries"), highlight: true },
    { value: stats.rating, label: t("hero.parentRating"), highlight: true },
  ].filter((f) => f.value);

  return (
    <section className="relative overflow-x-clip">
      <div
        className="pointer-events-none absolute inset-0 dot-grid [mask-image:linear-gradient(to_bottom,black,transparent_85%)]"
        aria-hidden="true"
      />
      <div
        className="parallax-slow pointer-events-none absolute -left-32 top-10 h-80 w-80 rounded-full bg-pine-300/25 blur-3xl"
        aria-hidden="true"
      />
      <div
        className="parallax-fast pointer-events-none absolute -right-20 top-40 h-96 w-96 rounded-full bg-gold-300/30 blur-3xl"
        aria-hidden="true"
      />

      <div className="container-page relative grid items-center gap-12 pb-8 pt-12 md:pb-12 md:pt-16 lg:grid-cols-[1.12fr_0.88fr] lg:items-start lg:gap-14 xl:gap-16">
        <div>
          {hero.badge && (
            <p className="inline-flex items-center gap-2 rounded-full border border-gold-300/70 bg-gradient-to-r from-tint-gold to-surface px-4 py-1.5 text-sm font-medium text-heading shadow-sm">
              <Star
                className="h-4 w-4 fill-gold-500 text-gold-500"
                aria-hidden="true"
              />
              {hero.badge}
            </p>
          )}
          <h1 className="mt-6 lg:mt-7 text-3xl leading-[1.12] sm:text-4xl lg:text-[2.75rem]">
            {before}
            {highlight && (
              <span className="relative whitespace-nowrap text-brand">
                {highlight}
                <svg
                  className="absolute -bottom-2 left-0 w-full"
                  viewBox="0 0 300 12"
                  preserveAspectRatio="none"
                  aria-hidden="true"
                >
                  <path
                    d="M2 8 C 80 2, 220 2, 298 7"
                    fill="none"
                    stroke="#C89A3C"
                    strokeWidth="3.5"
                    strokeLinecap="round"
                  />
                </svg>
              </span>
            )}
            {after}
          </h1>
          <p className="mt-6 max-w-xl text-base leading-relaxed text-ink/70 lg:mt-7 lg:text-[1.05rem]">
            {hero.subheadline}
          </p>

          <div className="mt-9 flex flex-wrap gap-3 lg:mt-10">
            <button
              onClick={openTrial}
              className="btn-primary px-7 py-3.5 text-base"
            >
              {hero.primaryCtaLabel}
            </button>
            <Link to="/#courses" className="btn-outline px-7 py-3.5 text-base">
              {hero.secondaryCtaLabel}
            </Link>
          </div>

          {hero.platforms?.length > 0 && (
            <ul
              className="mt-7 flex flex-wrap gap-2 lg:mt-8"
              aria-label={t("hero.platforms")}
            >
              {hero.platforms.map((p) => (
                <li
                  key={p}
                  className="inline-flex items-center gap-2 rounded-full border border-ink/10 bg-surface/80 px-3.5 py-1.5 text-sm text-ink/75 shadow-sm"
                >
                  <span
                    className="h-1.5 w-1.5 rounded-full bg-gold-500"
                    aria-hidden="true"
                  />
                  {p}
                </li>
              ))}
            </ul>
          )}

          {figures.length > 0 && (
            <dl className="mt-10 grid max-w-lg grid-cols-3 gap-2 border-t border-ink/10 pt-7 sm:gap-3 lg:mt-12 lg:pt-8">
              {figures.map((f) => (
                <div
                  key={f.label}
                  className={`flex flex-col ${f.highlight ? "-my-2 rounded-2xl bg-gradient-to-br from-tint-gold to-surface px-2 py-2 ring-1 sm:px-3 ring-gold-300/70 shadow-sm" : ""}`}
                >
                  <dt
                    className={`order-2 mt-1 text-[11px] font-semibold uppercase tracking-[0.16em] sm:text-xs ${f.highlight ? "text-gold-700 dark:text-gold-300" : "text-ink/60"}`}
                  >
                    {f.label}
                  </dt>
                  <dd
                    className={`order-1 whitespace-nowrap text-xl font-semibold min-[400px]:text-2xl sm:text-3xl ${f.highlight ? "text-gold-500" : "text-brand"}`}
                  >
                    {n(f.value)}
                  </dd>
                </div>
              ))}
            </dl>
          )}
        </div>

        <div className="mx-auto w-full max-w-xl lg:mr-0 lg:max-w-[30rem] xl:max-w-[31rem]">
          {/* Vimeo video(s), same size as the slideshow card below */}
          <HeroVideos />

          {/* Photo slideshow */}
          <div className="relative w-full pb-6">
            {/* Thin frame: no border band, just a hairline and a soft shadow */}
            <div className={ACCENT}>
            <div className={FRAME}>
              <HeroSlider slides={slides} seconds={hero.slideSeconds} />

              {/* Class update notification, kept inside the frame so it is never cut off */}
              {hero.notifyTitle && (
                <div className="animate-float pointer-events-none absolute left-3 top-3 z-10 flex max-w-[62%] items-center gap-2.5 rounded-xl bg-surface/95 px-3 py-2 shadow-md ring-1 ring-black/5 backdrop-blur-sm sm:left-4 sm:top-4">
                  <span className="relative flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-tint text-brand">
                    <Bell className="h-4 w-4" aria-hidden="true" />
                    <span
                      className="absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full bg-gold-500 ring-2 ring-surface"
                      aria-hidden="true"
                    >
                      <span className="absolute inset-0 animate-ping rounded-full bg-gold-500/70" />
                    </span>
                  </span>
                  <span className="min-w-0 leading-tight">
                    <span className="block text-sm font-semibold text-heading">
                      {hero.notifyTitle}
                    </span>
                    <span className="block text-[11px] leading-snug text-ink/65">
                      {hero.notifyText}
                    </span>
                  </span>
                </div>
              )}
            </div>
            </div>

            {hero.trustTitle && (
              <div className="relative mt-3 flex items-center gap-3 rounded-xl sm:absolute sm:-bottom-1 sm:left-4 sm:mt-0 bg-surface px-4 py-2.5 shadow-md ring-1 ring-black/5">
                <span className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-pine-900 text-gold-300">
                  <BadgeCheck className="h-5 w-5" aria-hidden="true" />
                </span>
                <span className="leading-tight">
                  <span className="block font-semibold text-heading">
                    {hero.trustTitle}
                  </span>
                  <span className="text-xs text-ink/60">{hero.trustText}</span>
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
