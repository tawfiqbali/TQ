import { useEffect, useRef, useState } from 'react';
import { Play } from 'lucide-react';
import { useContent, useLanguage } from '../../i18n/LanguageContext';
import { ACCENT, FRAME } from './heroFrame';

/**
 * Vimeo videos in the hero, right above the photo slideshow card, as
 * "lite embeds". Each video sits in the same frame style as the slideshow card,
 * in a 16:9 box (the video's own shape) so it fills the frame edge to edge.
 *
 * Why it is fast: the page loads NO Vimeo player code. Each video shows only a
 * poster image (a few KB, sized for the screen) and a play button. The real
 * Vimeo player (~1 MB of scripts) is created only when the visitor clicks play.
 * Hovering or touching the button first "warms up" the connection to Vimeo,
 * so playback starts quickly.
 *
 * Videos are set in Admin → Page content → "Videos" (one Vimeo link per line).
 * With more than one link, the videos are shown one under another.
 */

// Details of known videos, so the page needs no lookup for them.
// For any other link the poster and title are fetched once from Vimeo
// (a ~1 KB request) and remembered in the browser.
const KNOWN = {
  1230464444: {
    title: 'QIT Promotional Video - Ibrahim',
    thumb: 'https://i.vimeocdn.com/video/2205373635-8829192cc7b9e5e529f72472e237f184e86fdcaefaf7e7498c553324c6b9b295',
    duration: 156,
  },
};

// https://vimeo.com/123, https://vimeo.com/123/abcdef (unlisted), https://player.vimeo.com/video/123?h=abcdef
export function parseVimeo(url) {
  const s = String(url || '').trim();
  const m = s.match(/vimeo\.com\/(?:video\/|channels\/[^/]+\/|groups\/[^/]+\/videos\/|showcase\/\d+\/video\/)?(\d{5,})(?:\/([0-9a-f]{6,}))?/i);
  if (!m) return null;
  const hash = m[2] || (s.match(/[?&]h=([0-9a-f]+)/i) || [])[1] || '';
  return { id: m[1], hash, url: s };
}

const cacheKey = (id) => `qit:vimeo:${id}`;
function useVimeoMeta(video) {
  const [meta, setMeta] = useState(() => {
    if (KNOWN[video.id]) return KNOWN[video.id];
    try {
      return JSON.parse(localStorage.getItem(cacheKey(video.id))) || null;
    } catch {
      return null;
    }
  });
  useEffect(() => {
    if (meta) return undefined;
    let alive = true;
    const src = video.hash ? `https://vimeo.com/${video.id}/${video.hash}` : `https://vimeo.com/${video.id}`;
    fetch(`https://vimeo.com/api/oembed.json?url=${encodeURIComponent(src)}`)
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (!alive || !d) return;
        const m = { title: d.title || '', thumb: String(d.thumbnail_url || '').replace(/-d_[^?]*.*$/, ''), duration: d.duration || 0 };
        setMeta(m);
        try {
          localStorage.setItem(cacheKey(video.id), JSON.stringify(m));
        } catch {
          /* storage blocked: fetched again next visit */
        }
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, [video.id, video.hash, meta]);
  return meta;
}

// Opens the connections the Vimeo player needs, once, just before a click
let warmed = false;
function warmUpVimeo() {
  if (warmed || typeof document === 'undefined') return;
  warmed = true;
  ['https://player.vimeo.com', 'https://i.vimeocdn.com', 'https://f.vimeocdn.com', 'https://fresnel.vimeocdn.com'].forEach((href) => {
    const l = document.createElement('link');
    l.rel = 'preconnect';
    l.href = href;
    l.crossOrigin = 'anonymous';
    document.head.appendChild(l);
  });
}

const clock = (secs) => `${Math.floor(secs / 60)}:${String(Math.round(secs % 60)).padStart(2, '0')}`;

function LiteVimeo({ video, priority, sizes }) {
  const { t, n, phrase } = useLanguage();
  const meta = useVimeoMeta(video);
  const [playing, setPlaying] = useState(false);
  const frame = useRef(null);
  // Title in the chosen language (bn.json → phrases can translate it)
  const title = phrase(meta?.title) || t('videos.untitled');

  useEffect(() => {
    if (playing) frame.current?.focus();
  }, [playing]);

  const params = new URLSearchParams({ autoplay: '1', dnt: '1', title: '0', byline: '0', portrait: '0', badge: '0', autopause: '1' });
  if (video.hash) params.set('h', video.hash);

  return (
    <figure className="group relative overflow-hidden rounded-2xl bg-pine-950">
      {/* 16:9 box = the video's own shape, so the poster and the playing
          video fill it edge to edge with no bars above or below */}
      <div className="relative aspect-video w-full overflow-hidden bg-black">
        {playing ? (
          <iframe
            ref={frame}
            src={`https://player.vimeo.com/video/${video.id}?${params}`}
            title={title}
            allow="autoplay; fullscreen; picture-in-picture; encrypted-media"
            allowFullScreen
            className="absolute inset-0 block h-full w-full border-0"
          />
        ) : (
          <button
            type="button"
            onClick={() => setPlaying(true)}
            onPointerEnter={warmUpVimeo}
            onFocus={warmUpVimeo}
            onTouchStart={warmUpVimeo}
            aria-label={t('videos.play', { title })}
            className="absolute inset-0 block h-full w-full cursor-pointer text-left focus-visible:outline-none"
          >
            {meta?.thumb ? (
              <img
                src={`${meta.thumb}-d_960`}
                srcSet={`${meta.thumb}-d_480 480w, ${meta.thumb}-d_640 640w, ${meta.thumb}-d_960 960w, ${meta.thumb}-d_1280 1280w`}
                sizes={sizes}
                alt=""
                width="1280"
                height="720"
                loading={priority ? 'eager' : 'lazy'}
                fetchpriority={priority ? 'high' : 'auto'}
                decoding="async"
                className="absolute inset-0 h-full w-full object-cover transition duration-500 group-hover:scale-[1.03]"
              />
            ) : (
              <span className="absolute inset-0 bg-gradient-to-br from-pine-800 to-pine-950" />
            )}
            {/* Light shade so the play button stands out on any poster */}
            <span className="absolute inset-0 bg-black/10 transition group-hover:bg-black/20" />
            <span className="absolute left-1/2 top-1/2 flex h-11 w-11 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-white/90 text-pine-900 shadow-lg ring-4 ring-white/25 backdrop-blur-sm transition duration-300 group-hover:scale-110 group-hover:bg-white group-focus-visible:scale-110 group-focus-visible:ring-gold-400 sm:h-12 sm:w-12">
              <Play className="ml-0.5 h-4 w-4 fill-current sm:h-5 sm:w-5" aria-hidden="true" />
            </span>
            {meta?.duration > 0 && (
              <span className="absolute bottom-3 right-3 rounded-full bg-black/55 px-2 py-0.5 text-[11px] font-medium tabular-nums text-white">{n(clock(meta.duration))}</span>
            )}
          </button>
        )}
      </div>
    </figure>
  );
}

// Rendered by Hero.jsx inside the right-hand column, above the slideshow
export default function HeroVideos() {
  const content = useContent();
  const section = content.site.videoSection;
  const videos = (section?.videos || []).map(parseVimeo).filter(Boolean);
  if (!section?.enabled || !videos.length) return null;
  // Poster width the browser should pick: the hero column is at most ~560 px
  const sizes = '(min-width: 1024px) 470px, (min-width: 640px) 560px, 92vw';

  return (
    <div className="mb-5 space-y-5">
      {videos.map((v, i) => (
        // Thin frame: no border band, just a hairline and a soft shadow
        <div key={`${v.id}-${i}`} className={ACCENT}>
          <div className={FRAME}>
            <LiteVimeo video={v} priority={i === 0} sizes={sizes} />
          </div>
        </div>
      ))}
    </div>
  );
}
