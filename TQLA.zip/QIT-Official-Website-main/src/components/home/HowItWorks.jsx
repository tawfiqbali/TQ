import { useContent, useLanguage } from '../../i18n/LanguageContext';
import { useTrialModal } from '../../context/TrialModalContext';
import { responsiveImg } from '../../lib/images';
import { fx } from '../shared/fxBox';

// "The trial class" section
export default function HowItWorks() {
  const content = useContent();
  const { t, n } = useLanguage();
  const { openTrial } = useTrialModal();
  const { trial } = content.site;

  return (
    <section id="trial" className="pb-10 md:pb-14">
      <div className="container-page">
        <div className={`reveal ${fx('card')}`} style={{ '--fx-r': '1.5rem' }}>
        <div className="card-3d bg-surface card-teal grid overflow-hidden p-0 md:grid-cols-[0.8fr_1.2fr] md:items-center md:gap-0 md:p-5 lg:grid-cols-[0.62fr_1fr_1fr]">
          {trial.imageUrl && (
            <div className={`${fx('photo')} fx-md hidden md:block md:self-center`} style={{ '--fx-r': '1rem' }}>
            <img
              {...responsiveImg(trial.imageUrl, '(min-width: 768px) 400px, 100vw')}
              decoding="async"
              alt={t('trialSection.imageAlt')}
              className="aspect-[5/2] w-full object-cover object-top md:aspect-square md:self-center md:rounded-2xl md:shadow-float"
              width="1000"
              height="1000"
              loading="lazy"
            />
            </div>
          )}
          <div className="p-4 sm:p-7">
            <p className="eyebrow reveal">{trial.eyebrow}</p>
            <h2 className="mt-1.5 text-lg leading-snug sm:mt-3 sm:text-2xl">{trial.heading}</h2>
            <p className="mt-2.5 rounded-xl border border-gold-300/60 bg-gradient-to-r from-tint-gold to-surface px-3 py-2 text-sm font-semibold leading-snug text-heading sm:mt-4 sm:rounded-2xl sm:px-4 sm:py-3 sm:text-base sm:leading-relaxed">
              {trial.summary}
            </p>
            <p className="mt-2.5 text-[13px] leading-snug text-ink/70 sm:mt-4 sm:text-sm sm:leading-relaxed">{trial.body}</p>
            <button onClick={openTrial} className="btn-primary mt-3 px-5 py-2.5 text-sm sm:mt-6 sm:px-6 sm:py-3 sm:text-base">
              {t('trialSection.cta')}
            </button>
          </div>
          <ol className="space-y-2.5 border-t border-ink/10 p-4 sm:space-y-4 sm:p-7 md:col-span-2 lg:col-span-1 lg:border-l lg:border-t-0">
            {trial.steps.map((s, i) => (
              <li key={s} className="flex gap-3 sm:gap-4">
                <span className="flex h-6 w-6 shrink-0 sm:h-8 sm:w-8 items-center justify-center rounded-full bg-gradient-to-b from-pine-800 to-pine-950 text-xs font-semibold text-gold-300 shadow-md">
                  {n(i + 1)}
                </span>
                <span className="pt-0.5 text-sm leading-snug text-ink/80 sm:pt-1 sm:text-base">{s}</span>
              </li>
            ))}
          </ol>
        </div>
        </div>
      </div>
    </section>
  );
}
