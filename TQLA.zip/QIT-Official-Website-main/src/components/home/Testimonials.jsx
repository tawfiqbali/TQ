import { useState } from 'react';
import { Pause, Play, Quote, Star } from 'lucide-react';
import { useContent, useLanguage } from '../../i18n/LanguageContext';
import { initialsOf } from '../../lib/utils';

/**
 * Reviews marquee: the review cards drift slowly from right to left in an
 * endless loop, with no arrows to click.
 *
 * How it stays smooth and light on the CPU:
 * - The whole row moves with one CSS transform animation (`animate-marquee`,
 *   defined in tailwind.config.js). The browser runs it on the GPU, and React
 *   does not re-render while it scrolls.
 * - The list is drawn twice, back to back. The row moves exactly half its width
 *   (one full copy) and then restarts, so the seam is never visible.
 * - When there are only a few reviews, each copy repeats them so that it is
 *   always wider than the screen and no empty gap appears.
 *
 * Speed: Admin → Board, teachers & reviews → Reviews → "Scrolling speed" is the
 * number of seconds each review takes to pass (default 8; higher = slower).
 *
 * The row pauses while the mouse is over it, while a finger holds it and while
 * keyboard focus is inside. The pause button stops it for good. Visitors who
 * ask for "reduce motion" get a still row they can swipe through.
 */
const MIN_CARDS_PER_COPY = 8; // enough for one copy to fill very wide screens

function ReviewCard({ t, gold }) {
  const { t: tr, n: num } = useLanguage();
  return (
    <figure className={`card-3d ${gold ? 'card-gold card-top-gold' : 'card-teal card-top-teal'} flex h-full flex-col p-6 hover:translate-y-0 sm:p-7`}>
      <Quote className={`h-7 w-7 ${gold ? 'text-gold-500' : 'text-gold-400'}`} aria-hidden="true" />
      <blockquote className="mt-4 flex-1 text-sm leading-relaxed text-ink/80">{t.quote}</blockquote>
      <div className="mt-5 flex gap-1" aria-label={tr('reviews.stars', { n: num(t.rating) })}>
        {Array.from({ length: 5 }, (_, k) => (
          <Star key={k} className={`h-5 w-5 ${k < t.rating ? 'fill-gold-500 text-gold-500' : 'text-ink/15'}`} aria-hidden="true" />
        ))}
      </div>
      <figcaption className="mt-5 flex items-center gap-3 border-t border-ink/10 pt-5">
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-gradient-to-b from-pine-800 to-pine-950 text-sm font-semibold text-gold-300">
          {initialsOf(t.name)}
        </span>
        <span className="leading-tight">
          <span className="block text-base font-semibold text-heading">{t.name}</span>
          <span className="text-sm text-ink/60">{[t.role, t.course].filter(Boolean).join(' · ')}</span>
        </span>
      </figcaption>
    </figure>
  );
}

export default function Testimonials() {
  const content = useContent();
  const { t } = useLanguage();
  const { testimonialsSection } = content.site;
  const items = content.testimonials;
  const n = items.length;
  const [stopped, setStopped] = useState(false);

  if (!n) return null;

  // Seconds each review takes to scroll past (2–60, default 8)
  const secs = Number(testimonialsSection?.scrollSeconds);
  const perCard = Number.isFinite(secs) && secs > 0 ? Math.min(60, Math.max(2, secs)) : 8;

  // One copy = the reviews repeated until there are at least MIN_CARDS_PER_COPY
  const repeats = Math.ceil(MIN_CARDS_PER_COPY / n);
  const copy = Array.from({ length: repeats }, () => items).flat();
  const duration = `${copy.length * perCard}s`;

  // `gold` alternates by position in the original list, so the colours stay
  // consistent however many times the list repeats.
  const renderCopy = (hidden) =>
    copy.map((item, i) => {
      const repeat = hidden || i >= n; // decorative copy: skipped by screen readers
      return (
        <li
          key={`${hidden ? 'b' : 'a'}-${i}`}
          aria-hidden={repeat ? 'true' : undefined}
          // Padding (not `gap`) keeps both copies exactly the same width, so
          // moving by -50% lands precisely on the start of the second copy.
          className={`flex w-[82vw] max-w-[21rem] shrink-0 pr-5 sm:w-[21rem] sm:max-w-none sm:pr-6 lg:w-[23rem] motion-reduce:snap-start ${repeat ? 'motion-reduce:hidden' : ''}`}
        >
          <div className="w-full">
            <ReviewCard t={item} gold={(i % n) % 2 === 1} />
          </div>
        </li>
      );
    });

  return (
    <section id="testimonials" className="bg-gradient-to-b from-transparent via-tint-gold/80 to-transparent py-10 md:py-14">
      <div className="container-page">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="eyebrow reveal">{testimonialsSection.eyebrow}</p>
            <h2 className="mt-3 max-w-3xl text-2xl leading-snug">{testimonialsSection.heading}</h2>
          </div>
          <button
            type="button"
            className="icon-btn border border-ink/15 bg-surface motion-reduce:hidden"
            onClick={() => setStopped((s) => !s)}
            aria-label={stopped ? t('reviews.play') : t('reviews.pause')}
            aria-pressed={stopped}
          >
            {stopped ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {/* Full-width track; the edges fade out so cards glide in and out softly */}
      <div
        className="marquee-mask group reveal mt-8 overflow-x-clip motion-reduce:overflow-x-auto motion-reduce:[scroll-snap-type:x_mandatory]"
        role="region"
        aria-roledescription="carousel"
        aria-label={t('reviews.carousel')}
      >
        <ul
          className={`flex w-max items-stretch py-2 animate-marquee group-hover:[animation-play-state:paused] group-focus-within:[animation-play-state:paused] group-active:[animation-play-state:paused] motion-reduce:animate-none motion-reduce:px-4 ${stopped ? '[animation-play-state:paused]' : ''}`}
          style={{ '--marquee-duration': duration }}
        >
          {renderCopy(false)}
          {renderCopy(true)}
        </ul>
      </div>
    </section>
  );
}
