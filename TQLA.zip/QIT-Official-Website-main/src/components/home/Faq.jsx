import { ChevronDown } from 'lucide-react';
import { useContent } from '../../i18n/LanguageContext';

export default function Faq() {
  const content = useContent();
  const { faqSection } = content.site;
  const faqs = content.faqs ?? [];
  if (!faqs.length) return null;

  return (
    <section id="faq" className="py-10 md:py-14">
      <div className="container-page grid gap-10 lg:grid-cols-[0.8fr_1.2fr]">
        <div>
          <p className="eyebrow reveal">{faqSection.eyebrow}</p>
          <h2 className="mt-3 text-2xl leading-snug">{faqSection.heading}</h2>
          <p className="mt-5 leading-relaxed text-ink/70">{faqSection.intro}</p>
        </div>
        <div className="reveal card-3d card-teal divide-y divide-ink/10 px-6 py-2 hover:translate-y-0">
          {faqs.map((f) => (
            <details key={f.id} className="group py-1">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 py-4 text-base font-semibold text-heading [&::-webkit-details-marker]:hidden">
                {f.question}
                <ChevronDown className="h-5 w-5 shrink-0 text-ink/50 transition group-open:rotate-180" aria-hidden="true" />
              </summary>
              <p className="pb-5 pr-8 text-sm leading-relaxed text-ink/70">{f.answer}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}
