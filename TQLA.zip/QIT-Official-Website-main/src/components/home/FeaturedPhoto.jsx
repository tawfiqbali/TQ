import { useContent, useLanguage } from '../../i18n/LanguageContext';
import { useTrialModal } from '../../context/TrialModalContext';
import { responsiveImg } from '../../lib/images';
import GlobalFacultyBadges from '../shared/GlobalFacultyBadges';
import { fx } from '../shared/fxBox';

// Spotlight: large banner photo with a short message and a trial button
export default function FeaturedPhoto() {
  const content = useContent();
  const { t } = useLanguage();
  const { openTrial } = useTrialModal();
  const f = content.site.featured;
  if (!f?.enabled || !f.imageUrl) return null;

  return (
    <section id="spotlight" className="py-8 md:py-12">
      <div className="container-page">
        {/* The banner carries its own text, so it gets the full width */}
        <div className={`reveal ${fx('card', 'bl')}`} style={{ '--fx-r': '1.5rem' }}>
        <div className="card-3d bg-surface card-gold overflow-hidden p-3 hover:translate-y-0 sm:p-4 lg:p-5">
          {/* Shown at 70% of the card width on tablets/computers, uncropped */}
          <div className={`${fx('photo', 'bl')} mx-auto w-full md:w-[70%]`} style={{ '--fx-r': '1.6rem' }}>
          <div className="relative w-full overflow-hidden rounded-[1.6rem] shadow-float-lg ring-1 ring-gold-300/60">
            <img
              {...responsiveImg(f.imageUrl, '(min-width: 1280px) 830px, (min-width: 768px) 68vw, 94vw')}
              alt={t('spotlight.imageAlt')}
              className="block h-auto w-full object-contain"
              width="1400"
              height="933"
              loading="lazy"
              decoding="async"
            />
          </div>
          </div>
          <div className="flex flex-col gap-4 px-2 pb-2 pt-6 sm:px-4 md:flex-row md:items-center md:justify-between md:gap-8">
            <div className="max-w-2xl">
              {f.eyebrow && <p className="eyebrow">{f.eyebrow}</p>}
              <h2 className="mt-2 text-2xl leading-snug">{f.heading}</h2>
              {f.text && <p className="mt-3 leading-relaxed text-ink/70">{f.text}</p>}
              <GlobalFacultyBadges className="mt-5" />
            </div>
            <button type="button" onClick={openTrial} className="btn-primary shrink-0 self-start px-6 py-3 md:self-center">
              {f.ctaLabel || 'Book a Free Trial'}
            </button>
          </div>
        </div>
        </div>
      </div>
    </section>
  );
}
