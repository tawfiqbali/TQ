import { CalendarCheck, Clock, ShieldCheck } from 'lucide-react';
import { WhatsAppIcon } from '../shared/BrandIcons';
import { useContent, useLanguage } from '../../i18n/LanguageContext';
import { useTrialModal } from '../../context/TrialModalContext';
import { telLink, whatsappLink } from '../../lib/utils';
import { responsiveImg } from '../../lib/images';
import { fx } from '../shared/fxBox';

const POINT_ICONS = [Clock, ShieldCheck, CalendarCheck];

export default function CtaBand() {
  const content = useContent();
  const { t } = useLanguage();
  const { openTrial } = useTrialModal();
  const { cta, contact, whatsappMessages } = content.site;
  const wa = whatsappLink(contact.whatsapp, whatsappMessages?.general);

  return (
    <section className="py-10 md:py-14">
      <div className="container-page">
        <div className={`reveal ${fx('panel')}`} style={{ '--fx-r': '2rem' }}>
        <div className="relative overflow-hidden rounded-[2rem] bg-gradient-to-br from-pine-700 via-pine-900 to-pine-950 px-5 py-7 text-center sm:px-8 sm:py-9 text-white shadow-float-lg ">
          {cta.imageUrl && (
            <>
              <img {...responsiveImg(cta.imageUrl, '(min-width: 1280px) 1200px, 100vw')} alt="" aria-hidden="true" loading="lazy" decoding="async" className="pointer-events-none absolute inset-0 h-full w-full object-cover" />
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-br from-pine-800/85 via-pine-900/85 to-pine-950/90" aria-hidden="true" />
            </>
          )}
          <div className="pointer-events-none absolute inset-0 dot-grid opacity-30" aria-hidden="true" />
          <div className="pointer-events-none absolute -left-24 -top-24 h-72 w-72 rounded-full bg-pine-300/20 blur-3xl" aria-hidden="true" />
          <div className="pointer-events-none absolute -bottom-24 -right-24 h-72 w-72 rounded-full bg-gold-400/25 blur-3xl" aria-hidden="true" />
          <div className="relative mx-auto max-w-3xl">
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold-400">{cta.eyebrow}</p>
            <h2 className="mt-3 text-xl leading-snug text-white sm:mt-3 sm:text-2xl">{cta.heading}</h2>
            <p className="mx-auto mt-3 max-w-2xl text-sm text-pine-100/85 sm:mt-4 sm:text-base">
              {cta.body} {contact.phone && <a href={telLink(contact.phone)} className="whitespace-nowrap font-semibold text-white underline decoration-gold-400/70 underline-offset-4">{contact.phone}</a>}
            </p>
            <div className="mt-5 flex flex-wrap justify-center gap-2.5 sm:mt-6 sm:gap-3">
              <button onClick={openTrial} className="btn-gold px-5 py-2.5 text-sm sm:px-6 sm:py-3">
                {t('cta.book')}
              </button>
              {wa && (
                <a href={wa} target="_blank" rel="noreferrer" className="btn border border-white/30 px-5 py-2.5 text-sm text-white hover:bg-white/10 sm:px-6 sm:py-3">
                  <WhatsAppIcon className="h-5 w-5" /> {t('cta.chat')}
                </a>
              )}
            </div>
            {cta.points?.length > 0 && (
              <ul className="mt-6 flex flex-wrap justify-center gap-x-5 gap-y-2 border-t border-white/15 pt-5 text-xs font-medium sm:mt-6 sm:gap-x-8 sm:pt-5 sm:text-sm">
                {cta.points.map((p, i) => {
                  const Icon = POINT_ICONS[i % POINT_ICONS.length];
                  return (
                    <li key={p} className="flex items-center gap-2">
                      <Icon className="h-4 w-4 text-gold-400" aria-hidden="true" />
                      {p}
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </div>
        </div>
      </div>
    </section>
  );
}
