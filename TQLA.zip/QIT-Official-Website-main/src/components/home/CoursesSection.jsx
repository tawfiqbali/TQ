import { Clock } from 'lucide-react';
import { useContent, useLanguage } from '../../i18n/LanguageContext';
import CourseCard, { COURSE_THEMES } from '../shared/CourseCard';
import CurrencyNote from '../shared/CurrencyNote';
import useAdminRole from '../../hooks/useAdminRole';

export default function CoursesSection({ onlyFeatured = true }) {
  const content = useContent();
  const { t } = useLanguage();
  const { coursesSection } = content.site;
  const isAdmin = useAdminRole().isSuper; // currency preview is an executive setting
  const courses = content.courses.filter((c) => c.published && (!onlyFeatured || c.featured));

  return (
    <section id="courses" className="py-10 md:py-14">
      <div className="container-page">
        <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr] lg:items-end">
          <div>
            <p className="eyebrow reveal">{coursesSection.eyebrow}</p>
            <h2 className="mt-3 text-2xl leading-snug">{coursesSection.heading}</h2>
          </div>
          <p className="leading-relaxed text-ink/70">{coursesSection.intro}</p>
        </div>

        {/* Currency preview is for signed-in admins only */}
        {isAdmin && (
          <div className="mt-8">
            <CurrencyNote />
          </div>
        )}

        {courses.length ? (
          <div className="mt-10 grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
            {courses.map((c, i) => (
              <CourseCard key={c.id} course={c} theme={COURSE_THEMES[i % COURSE_THEMES.length]} />
            ))}
          </div>
        ) : (
          <p className="mt-10 rounded-2xl border border-dashed border-ink/20 p-10 text-center text-ink/70">{t('courses.empty')}</p>
        )}

        {coursesSection.classLengthNote && (
          <p className="mt-8 flex items-start gap-2 text-sm text-ink/70">
            <Clock className="mt-0.5 h-4 w-4 shrink-0 text-gold-500" aria-hidden="true" />
            {coursesSection.classLengthNote}
          </p>
        )}
      </div>
    </section>
  );
}
