import { useEffect, useState } from 'react';
import { GraduationCap } from 'lucide-react';
import { useContent } from '../../i18n/LanguageContext';

// Slim strip that cycles through the faculty messages, one at a time.
export default function FacultyTicker() {
  const content = useContent();
  const t = content.site.facultyTicker;
  const messages = (t?.messages || []).filter(Boolean);
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);
  const ms = Math.max(2, Number(t?.seconds) || 4) * 1000;

  useEffect(() => {
    if (messages.length < 2 || paused) return undefined;
    const id = setInterval(() => setI((n) => (n + 1) % messages.length), ms);
    return () => clearInterval(id);
  }, [messages.length, paused, ms]);

  if (!t?.enabled || !messages.length) return null;

  return (
    <div
      className="relative overflow-hidden border-b border-gold-300/40 bg-gradient-to-r from-pine-900 via-pine-800 to-pine-900 text-white"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      <div className="container-page flex min-h-[42px] items-center justify-center gap-2.5 py-2 text-center text-sm font-medium sm:text-[15px]">
        <GraduationCap className="h-4 w-4 shrink-0 text-gold-300" aria-hidden="true" />
        {/* Every message sits in the same cell, so the strip is always as tall as the longest one */}
        <p aria-live="polite" className="ticker-stack relative" data-testid="ticker">
          {messages.map((m, n) => (
            <span key={n} aria-hidden={n !== i % messages.length}>{m}</span>
          ))}
        </p>
        {messages.length > 1 && (
          <span className="ml-1 hidden gap-1 sm:flex" aria-hidden="true">
            {messages.map((_, n) => (
              <span key={n} className={`h-1.5 rounded-full transition-all ${n === i % messages.length ? 'w-4 bg-gold-300' : 'w-1.5 bg-white/35'}`} />
            ))}
          </span>
        )}
      </div>
    </div>
  );
}
