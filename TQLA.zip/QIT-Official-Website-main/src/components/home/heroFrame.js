// Shared class strings for the hero video + slideshow frames.
export const FRAME =
  'relative overflow-hidden rounded-2xl shadow-[0_1px_2px_rgba(0,0,0,0.06),0_12px_28px_-14px_rgba(3,71,81,0.35)] ring-1 ring-black/5 dark:ring-white/10';

// Soft teal-to-gold box peeking out behind the bottom-right edge (index.css → .hero-fx)
export const ACCENT = 'hero-fx';
