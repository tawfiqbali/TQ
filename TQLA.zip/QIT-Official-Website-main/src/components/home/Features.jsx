import { useContent } from '../../i18n/LanguageContext';
import { FEATURE_ICONS } from '../shared/icons';
import { COURSE_ACCENTS } from '../shared/CourseCard';
import { responsiveImg } from '../../lib/images';
import GlobalFacultyBadges from '../shared/GlobalFacultyBadges';
import { fx } from '../shared/fxBox';

// "Why us" section
export default function Features() {
  const content = useContent();
  const { whyUs } = content.site;

  return (
    <section id="why-us" className="bg-gradient-to-b from-transparent via-tint/70 to-transparent py-10 md:py-14">
      <div className="container-page grid gap-12 lg:grid-cols-[1.05fr_0.95fr] lg:items-center">
        <div>
          <p className="eyebrow reveal">{whyUs.eyebrow}</p>
          <h2 className="mt-3 text-2xl leading-snug">{whyUs.heading}</h2>
          <ul className="mt-10 grid gap-4">
            {(whyUs.cards ?? content.features).map((f, i) => {
              const Icon = FEATURE_ICONS[f.icon] ?? FEATURE_ICONS.Star;
              return (
                <li key={f.id} className={`reveal ${fx('card', i % 2 ? 'bl' : 'br')}`} style={{ '--fx-r': '1rem' }}>
                <div
                  className={`card-3d bg-surface ${i % 2 ? 'card-gold' : 'card-teal'} flex h-full gap-4 rounded-2xl p-5`}
                  style={{ '--accent': COURSE_ACCENTS[i % COURSE_ACCENTS.length] }}
                >
                  <span className="icon-tile h-12 w-12 shrink-0">
                    <Icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <div>
                    <h3 className="text-lg">{f.title}</h3>
                    <p className="mt-1.5 text-sm leading-relaxed text-ink/70">{f.description}</p>
                  </div>
                </div>
                </li>
              );
            })}
          </ul>
        </div>

        <div className={`reveal ${fx('panel', 'bl')}`} style={{ '--fx-r': '2rem' }}>
        <div className="relative overflow-hidden rounded-[2rem] bg-gradient-to-br from-pine-800 via-pine-900 to-pine-950 p-5 text-white shadow-float-lg sm:p-7">
          {whyUs.imageUrl && (
            <>
              <img {...responsiveImg(whyUs.imageUrl, '(min-width: 1024px) 600px, 100vw')} alt="" aria-hidden="true" loading="lazy" decoding="async" className="pointer-events-none absolute inset-0 h-full w-full object-cover" />
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-br from-pine-900/80 via-pine-900/85 to-pine-950/95" aria-hidden="true" />
            </>
          )}
          <div className="pointer-events-none absolute -right-16 -top-16 h-56 w-56 rounded-full bg-gold-400/20 blur-3xl" aria-hidden="true" />
          <img src="/brand/logo-mark-white.png" alt="" aria-hidden="true" className="pointer-events-none absolute -bottom-10 -right-6 h-56 opacity-[0.07]" />
          <p className="relative text-xs font-semibold uppercase tracking-[0.16em] text-gold-400">{whyUs.promiseLabel}</p>
          <blockquote className="relative mt-3 text-lg font-semibold leading-snug sm:text-xl">“{whyUs.promiseQuote}”</blockquote>
          <p className="relative mt-2.5 text-sm text-pine-100/80">{whyUs.promiseSub}</p>
          <ul className="relative mt-5 grid gap-x-4 gap-y-2.5 border-t border-white/15 pt-5 text-sm sm:grid-cols-2">
            {whyUs.promisePoints.map((p) => (
              <li key={p} className="flex items-center gap-2.5 font-medium">
                <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-white/10" aria-hidden="true">
                  <span className="h-2 w-2 rounded-full bg-gold-400" />
                </span>
                {p}
              </li>
            ))}
          </ul>
          <GlobalFacultyBadges variant="light" className="relative mt-5 border-t border-white/15 pt-4" />
        </div>
        </div>
      </div>
    </section>
  );
}
