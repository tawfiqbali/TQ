import { useContent, useLanguage } from '../../i18n/LanguageContext';
import { Mail } from 'lucide-react';
import { WhatsAppIcon } from '../shared/BrandIcons';
import { gmailLink, whatsappLink } from '../../lib/utils';

const PLACEHOLDER = '/images/board/placeholder.svg';

// Colours: gold (Founder, Co-Founder), terracotta (CEO), and the team row
// alternates emerald · blue · emerald · blue. Each colour has one fixed accent.
const ACCENT = { gold: '200 154 60', terracotta: '190 96 58', emerald: '21 128 88', blue: '37 88 160' };
// Slightly deeper shade for the post-title label, so white text stands out
const LABEL = { gold: '160 112 28', terracotta: '176 82 44', emerald: '18 112 76', blue: '32 76 145' };

function MemberCard({ member, color = 'gold', large = false, wideLabel = false }) {
  const { t } = useLanguage();
  return (
    <article
      className={`reveal card-3d board-card isolate flex w-full flex-col items-center overflow-hidden ${large ? 'px-5' : 'px-4'} pb-5 pt-5 text-center`}
      style={{ '--accent': ACCENT[color], '--label': LABEL[color] }}
    >
      <span className="card-band -z-10" aria-hidden="true" />
      <span className="absolute inset-x-0 top-0 h-1.5 bg-[rgb(var(--accent))]" aria-hidden="true" />
      {/* Portrait photo in a rounded rectangle with a thin gold-to-teal frame */}
      {/* v158: no photo = a small initials badge, so the card gets shorter */}
      {!member.photoUrl || /placeholder\.svg$/i.test(member.photoUrl) ? (
        <span className="board-initials" aria-hidden="true">{String(member.name || '?').trim().split(/\s+/).filter((w) => !/^(md|mohammad|muhammad|mohammed)\.?$/i.test(w)).slice(0, 2).map((w) => w[0]).join('').toUpperCase() || '?'}</span>
      ) : (
      <div className={`board-photo relative aspect-[1/1] rounded-[1.4rem] bg-gradient-to-br from-gold-300 via-gold-400 to-pine-700 p-[4px] shadow-float-lg w-full`}>
        <img
          src={member.photoUrl}
          alt={[member.name, member.role].filter(Boolean).join(', ')}
          className="h-full w-full rounded-[1.15rem] border-[3px] border-surface bg-surface object-cover object-top"
          width="540"
          height="600"
          decoding="async"
          loading="lazy"
          onError={(e) => {
            e.currentTarget.src = PLACEHOLDER;
          }}
        />
      </div>
      )}
      {/* Position title: larger, bold, in a highlighted pill */}
      {/* Post title: solid colour label so it catches the eye */}
      {/* wideLabel: full-width label of equal height (Founder and Co-Founder match) */}
      {member.role && <p className={`board-role mt-4 ${wideLabel ? 'flex min-h-[3.25rem] w-full justify-center' : 'inline-flex'} items-center gap-2 rounded-full bg-[linear-gradient(135deg,rgb(var(--label)),rgb(var(--accent)))] px-4 py-1.5 text-center text-[13px] font-extrabold uppercase leading-snug tracking-[0.12em] text-white shadow-[0_8px_18px_-8px_rgb(var(--label)/0.9)] ring-2 ring-white/80 [text-wrap:balance] sm:text-sm dark:ring-white/20`} data-testid="board-role">
        {!wideLabel && <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-white/90" aria-hidden="true" />}
        {member.role}
      </p>}
      {member.name && <h3 className={`mt-3 tracking-wide ${large ? 'text-lg' : 'text-base'}`}>{member.name}</h3>}
      {member.bio && <p className="mt-2 max-w-sm text-sm leading-relaxed text-ink/70">{member.bio}</p>}
      {(member.whatsapp || member.email) && (
        <div className={`board-contacts flex w-full flex-col items-stretch gap-2 pt-3 ${large ? 'text-[13px]' : 'text-[12px]'}`}>
          {member.whatsapp && (
            <a
              href={whatsappLink(member.whatsapp)}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center justify-center gap-2 rounded-full border border-[#1DA851]/30 bg-surface/60 px-3 py-2 font-semibold text-[#128C4B] shadow-sm backdrop-blur transition hover:-translate-y-0.5 hover:border-[#1DA851]/60 hover:bg-[#1DA851]/10 dark:text-[#6EE7A1]"
              aria-label={t('board.whatsapp', { name: member.name })}
            >
              <WhatsAppIcon className="h-4 w-4 shrink-0" />
              <span className="whitespace-nowrap">{member.whatsapp}</span>
            </a>
          )}
          {member.email && (
            <a
              href={gmailLink(member.email)}
              target="_blank"
              rel="noreferrer"
              className="inline-flex min-w-0 items-center justify-center gap-2 rounded-full border border-ink/15 bg-surface/60 px-2.5 py-2 font-medium text-ink/80 backdrop-blur transition hover:-translate-y-0.5 hover:border-ink/30"
              aria-label={t('board.email', { name: member.name })}
            >
              <Mail className="h-3.5 w-3.5 shrink-0 text-[#EA4335]" />
              <span className="truncate">{member.email}</span>
            </a>
          )}
        </div>
      )}
    </article>
  );
}

// QIT Board Members: Founder + Co-Founder side by side, the CEO on their own,
// then Accounts, Marketing, HR and Logistics. All cards the same size.
// Colours: Founder + Co-Founder gold, CEO terracotta, team emerald · blue · emerald · blue.
export default function BoardSection() {
  const content = useContent();
  const { boardSection } = content.site;
  const board = content.board ?? [];
  if (!board.length) return null;

  const tier = (n) => board.filter((m) => Number(m.tier) === n);
  const founders = tier(1);
  const ceo = tier(2);
  const team = tier(3);

  return (
    <section id="board" className="relative py-10 md:py-14">
      {/* Soft cream band behind the section */}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-transparent via-tint-gold/70 to-transparent" aria-hidden="true" />
      <div className="container-page relative">
        <div className="mx-auto max-w-2xl text-center">
          <p className="eyebrow reveal">{boardSection.eyebrow}</p>
          {/* Highlighted section title: teal-to-gold text with a gold underline */}
          <h2 className="relative mt-3 inline-block pb-3 text-2xl font-bold leading-snug">
            <span className="bg-gradient-to-r from-pine-900 via-pine-700 to-gold-500 bg-clip-text text-transparent dark:from-pine-300 dark:via-white dark:to-gold-300">
              {boardSection.heading}
            </span>
            <span className="absolute inset-x-8 bottom-0 h-1 rounded-full bg-gradient-to-r from-transparent via-gold-400 to-transparent" aria-hidden="true" />
          </h2>
          {boardSection.intro && <p className="mt-4 leading-relaxed text-ink/70">{boardSection.intro}</p>}
        </div>

        {/* Every card is the same size; rows are centred */}
        {[founders, ceo, team].map((row, r) =>
          row.length ? (
            <div key={r} className={`board-row mx-auto flex max-w-[76rem] flex-wrap items-start justify-center gap-x-3 gap-y-3 sm:gap-x-5 sm:gap-y-2 ${r === 0 ? 'mt-6 sm:mt-10' : 'mt-3 sm:mt-2'}`}>
              {row.map((m, k) => (
                <div key={m.id} className="flex w-[calc(50%-0.375rem)] items-start sm:w-full sm:max-w-[17.5rem]">
                  <MemberCard member={m} wideLabel={r < 2} color={r === 0 ? 'gold' : r === 1 ? 'terracotta' : k % 2 ? 'blue' : 'emerald'} />
                </div>
              ))}
            </div>
          ) : null,
        )}
      </div>
    </section>
  );
}
