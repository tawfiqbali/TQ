import { useEffect, useState } from 'react';

// Returns the id of the section currently in the middle band of the screen.
// Sections are looked up by id; ones that are not on the page are ignored.
export default function useScrollSpy(ids, enabled = true) {
  const [active, setActive] = useState('');

  useEffect(() => {
    if (!enabled) {
      setActive('');
      return undefined;
    }
    let observer;
    let retry;
    const visible = new Map();

    const pick = () => {
      // The section with the most of itself inside the watch band wins
      let best = '';
      let bestRatio = 0;
      visible.forEach((ratio, id) => {
        if (ratio > bestRatio) {
          bestRatio = ratio;
          best = id;
        }
      });
      // Above the first section (the hero) nothing is highlighted
      setActive(best);
    };

    const start = () => {
      const els = ids.map((id) => document.getElementById(id)).filter(Boolean);
      if (!els.length) {
        retry = setTimeout(start, 300); // sections render after content loads
        return;
      }
      observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((e) => {
            if (e.isIntersecting) visible.set(e.target.id, e.intersectionRatio);
            else visible.delete(e.target.id);
          });
          pick();
        },
        // Watch a band around the upper-middle of the screen, below the header
        { rootMargin: '-35% 0px -45% 0px', threshold: [0, 0.1, 0.25, 0.5, 0.75, 1] },
      );
      els.forEach((el) => observer.observe(el));
    };
    start();
    return () => {
      clearTimeout(retry);
      observer?.disconnect();
    };
  }, [ids, enabled]);

  return active;
}
