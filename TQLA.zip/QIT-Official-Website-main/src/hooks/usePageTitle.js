import { useEffect } from 'react';
import { useSiteData } from '../context/SiteDataContext';
import { useLanguage } from '../i18n/LanguageContext';

// Pass a dictionary key (e.g. 'pages.aboutTitle') or plain text
export default function usePageTitle(title) {
  const { content } = useSiteData();
  const { t } = useLanguage();
  const brand = content?.site.brand.name ?? '';
  const text = title && /^[a-z]+\.[A-Za-z]+$/.test(title) ? t(title) : title;
  useEffect(() => {
    document.title = text ? `${text} | ${brand}` : brand;
  }, [text, brand]);
}
