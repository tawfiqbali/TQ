import useAdminRole from './useAdminRole';

// null while checking, '' when nobody is signed in, the admin's email otherwise.
export default function useAdminSession() {
  return useAdminRole().email;
}
