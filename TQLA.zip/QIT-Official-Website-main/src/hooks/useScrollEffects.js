import { useEffect } from 'react';

// 1) Cards and headings marked `.reveal` float up into place as they scroll
//    into view (once each).
// 2) A --sy variable (page scroll in px) drives gentle parallax on the hero's
//    background glows. Only updated near the top of the page.
// Visitors who ask for reduced motion see everything immediately.
export default function useScrollEffects() {
  useEffect(() => {
    const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    const root = document.documentElement;

    const io =
      !reduce && 'IntersectionObserver' in window
        ? new IntersectionObserver(
            (entries) => {
              // Items appearing together float in left-to-right, top-to-bottom
              entries
                .filter((e) => e.isIntersecting)
                .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top || a.boundingClientRect.left - b.boundingClientRect.left)
                .forEach((e, i) => {
                  e.target.style.setProperty('--reveal-delay', `${Math.min(i, 5) * 90}ms`);
                  e.target.classList.add('is-visible');
                  io.unobserve(e.target);
                });
            },
            { rootMargin: '0px 0px -8% 0px', threshold: 0.12 },
          )
        : null;

    const watch = () => {
      document.querySelectorAll('.reveal:not(.is-visible):not([data-reveal-watched])').forEach((el) => {
        el.setAttribute('data-reveal-watched', '');
        if (!io) return el.classList.add('is-visible');
        io.observe(el);
      });
    };
    watch();
    // Content arrives after the first paint (and on route changes)
    const mo = new MutationObserver(() => watch());
    mo.observe(document.body, { childList: true, subtree: true });

    let frame = 0;
    const onScroll = () => {
      if (reduce || frame) return;
      frame = requestAnimationFrame(() => {
        frame = 0;
        const y = window.scrollY;
        if (y < 1400) root.style.setProperty('--sy', String(y));
      });
    };
    window.addEventListener('scroll', onScroll, { passive: true });

    return () => {
      io?.disconnect();
      mo.disconnect();
      window.removeEventListener('scroll', onScroll);
      cancelAnimationFrame(frame);
    };
  }, []);
}
