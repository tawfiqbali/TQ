import { useEffect, useState } from 'react';
import { getAdminSession, onAuthChange, ROLES } from '../lib/auth';

// { email, role, isSuper, isJunior } for the signed-in admin.
// email is null while checking and '' when nobody is signed in.
export default function useAdminRole() {
  const [session, setSession] = useState(undefined);
  useEffect(() => {
    let alive = true;
    const check = () =>
      getAdminSession()
        .then((s) => alive && setSession(s))
        .catch(() => alive && setSession(null));
    check();
    const off = onAuthChange(check);
    return () => {
      alive = false;
      off();
    };
  }, []);
  const role = session?.role || '';
  return {
    email: session === undefined ? null : session?.email || '',
    role,
    isSuper: role === ROLES.SUPER,
    isJunior: role === ROLES.JUNIOR,
  };
}
