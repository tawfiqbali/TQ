/**
 * Bilingual support (English / বাংলা) for the public website.
 *
 *   const { lang, setLang, t, n, money } = useLanguage();
 *   t('nav.courses')                  -> "Courses" | "কোর্সসমূহ"
 *   t('board.email', { name })        -> fills {name}
 *   n('1,200+')                       -> "১,২০০+" in Bengali
 *   const content = useContent();     -> site content in the chosen language
 *
 * Interface text lives in ./locales/en.json and ./locales/bn.json.
 * bn.json also has a "content" section: Bengali versions of the site's
 * editable text (courses, FAQ, hero…). A Bengali string is only used while
 * the English text in the admin panel still matches the original, so an
 * admin edit is never hidden behind an out-of-date translation.
 *
 * The choice is saved in localStorage ('qit:lang'). The admin panel always
 * stays in English.
 */
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import en from './locales/en.json';
import { useSiteData } from '../context/SiteDataContext';
import { defaultContent } from '../data/defaultContent';
import { detectLocation } from '../lib/currency';
import { translateCourse, translatePlace } from './autoTranslate';

export const LANGUAGES = ['en', 'bn'];

/**
 * Who sees the বাংলা option: visitors in Bangladesh, Malaysia, Singapore and
 * the Middle East (where English is not the main language). Everyone else
 * gets the English site with no language switch.
 * A visitor qualifies if EITHER their device time zone OR their IP country is
 * on the list, so the switch shows instantly for most visitors (time zone is
 * known without a network request) and still appears for the rest once the
 * IP lookup finishes. Edit these two lists to change the countries.
 */
export const BANGLA_COUNTRIES = [
  'BD', // Bangladesh
  'MY', // Malaysia
  'SG', // Singapore
  'SA', // Saudi Arabia
  'AE', // United Arab Emirates (Dubai)
  'OM', // Oman
  'QA', // Qatar
  'KW', // Kuwait
  'BH', // Bahrain
  'JO', // Jordan
  'LB', // Lebanon
  'IQ', // Iraq
  'SY', // Syria
  'YE', // Yemen
  'PS', // Palestine
  'IL', // Israel
  'EG', // Egypt
  'IR', // Iran
  'TR', // Türkiye
];
// Device time zones for the same countries (also used by index.html)
export const BANGLA_TIMEZONES = [
  'Asia/Dhaka',
  'Asia/Kuala_Lumpur',
  'Asia/Kuching',
  'Asia/Singapore',
  'Asia/Riyadh',
  'Asia/Dubai',
  'Asia/Muscat',
  'Asia/Qatar',
  'Asia/Kuwait',
  'Asia/Bahrain',
  'Asia/Amman',
  'Asia/Beirut',
  'Asia/Baghdad',
  'Asia/Damascus',
  'Asia/Aden',
  'Asia/Gaza',
  'Asia/Hebron',
  'Asia/Jerusalem',
  'Asia/Tel_Aviv',
  'Africa/Cairo',
  'Asia/Tehran',
  'Europe/Istanbul',
  'Asia/Istanbul',
];

export function banglaAllowedByTimezone() {
  try {
    return BANGLA_TIMEZONES.includes(Intl.DateTimeFormat().resolvedOptions().timeZone);
  } catch {
    return false;
  }
}
// English ships with the site. Bengali (~8 KB) is downloaded only for
// visitors who choose it; see loadLanguage().
const DICTS = { en };
const LOADERS = { bn: () => import('./locales/bn.json') };

// Loads a language's dictionary once. Resolves immediately when ready.
export function loadLanguage(lang) {
  if (DICTS[lang]) return Promise.resolve(DICTS[lang]);
  const load = LOADERS[lang];
  if (!load) return Promise.resolve(en);
  return load().then((m) => {
    DICTS[lang] = m.default || m;
    BASE[lang] = DICTS[lang];
    if (lang === 'bn') applyBanglaEdits(pendingBnEdits);
    return DICTS[lang];
  });
}

/* v160: Bangla text edited in the admin panel (Website → Bangla text).
   Saved in site content as site.bnText = { '["hero","title"]': "…", … }
   (each key is the JSON path inside bn.json). Applied on top of bn.json. */
const BASE = {};
let pendingBnEdits = null;
let appliedBnSig = '';
export const banglaBase = () => BASE.bn || null;
export function applyBanglaEdits(edits) {
  pendingBnEdits = edits || null;
  if (!BASE.bn) return false;
  const sig = JSON.stringify(edits || {});
  if (sig === appliedBnSig) return false;
  const d = JSON.parse(JSON.stringify(BASE.bn));
  Object.entries(edits || {}).forEach(([k, v]) => {
    let path;
    try { path = JSON.parse(k); } catch { return; }
    if (!Array.isArray(path) || !path.length || typeof v !== 'string') return;
    let o = d;
    for (let i = 0; i < path.length - 1; i += 1) {
      if (o[path[i]] == null || typeof o[path[i]] !== 'object') o[path[i]] = {};
      o = o[path[i]];
    }
    o[path[path.length - 1]] = v;
  });
  DICTS.bn = d;
  phraseMap = null;
  appliedBnSig = sig;
  return true;
}
const STORAGE_KEY = 'qit:lang';
// Bangla fonts, see the @font-face rules in src/index.css:
// Hind Siliguri Light for text, Aikya for bold, Noto Sans Bengali for digits
const BN_FONTS = [
  ['qit-bn-font', '/fonts/HindSiliguri-Regular.woff2'],
  ['qit-bn-font-bold', '/fonts/Aikya.woff2'],
  ['qit-bn-font-digits', '/fonts/NotoSansBengali-Variable.woff2'],
];
const BN_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];

export function readSavedLanguage() {
  try {
    const v = localStorage.getItem(STORAGE_KEY);
    if (LANGUAGES.includes(v)) return v;
  } catch {
    /* storage blocked */
  }
  return 'en';
}

// The Bangla fonts are only downloaded once someone chooses বাংলা: this
// starts both downloads immediately, before the page re-renders.
function loadBengaliFont() {
  if (typeof document === 'undefined') return;
  BN_FONTS.forEach(([id, href]) => {
    if (document.getElementById(id)) return;
    const link = document.createElement('link');
    link.id = id;
    link.rel = 'preload';
    link.as = 'font';
    link.type = 'font/woff2';
    link.crossOrigin = 'anonymous';
    link.href = href;
    document.head.appendChild(link);
  });
}

const lookup = (dict, key) => key.split('.').reduce((o, k) => (o == null ? undefined : o[k]), dict);
const fill = (s, vars) => (vars ? s.replace(/\{(\w+)\}/g, (m, k) => (vars[k] ?? m)) : s);

/**
 * Tolerant text matching. The saved (cloud) content can differ slightly from
 * the original English: different capitals, -ize/-ise spelling, punctuation,
 * straight vs curly quotes, a few changed words. A Bengali translation is used
 * when the live English is at least this similar to the original; a
 * rewritten text (e.g. a new address) stays in English until it is translated.
 */
const SIMILAR = 0.6;
const clean = (s) =>
  String(s ?? '')
    .normalize('NFKC')
    .toLowerCase()
    .replace(/[\u2018\u2019`\u00b4]/g, "'")
    .replace(/iz(?=e|ed|es|ing|ation)/g, 'is')
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .trim();
function trigrams(s) {
  const t = ` ${s} `;
  const m = new Map();
  for (let i = 0; i < t.length - 2; i++) {
    const g = t.slice(i, i + 3);
    m.set(g, (m.get(g) || 0) + 1);
  }
  return m;
}
// 1 = same text, 0 = nothing in common (Dice coefficient on letter trigrams)
export function similarity(a, b) {
  const x = clean(a);
  const y = clean(b);
  if (!x || !y) return 0;
  if (x === y) return 1;
  const A = trigrams(x);
  const B = trigrams(y);
  let shared = 0;
  let total = 0;
  A.forEach((v, g) => {
    shared += Math.min(v, B.get(g) || 0);
    total += v;
  });
  B.forEach((v) => (total += v));
  return (2 * shared) / total;
}
const TEXT_FIELDS = ['quote', 'question', 'title', 'role', 'answer', 'description', 'name'];
function itemSimilarity(a, b) {
  let best = 0;
  TEXT_FIELDS.forEach((k) => {
    if (typeof a?.[k] === 'string' && typeof b?.[k] === 'string') best = Math.max(best, similarity(a[k], b[k]));
  });
  return best;
}

/**
 * Walks the live content alongside the original defaults and the translation.
 * - text: translated if the live English is the original or close to it
 * - list of texts (bullets, steps…): each item is matched to the most similar
 *   original item, so reordered or removed items still get the right Bengali
 * - list of objects (plans): by position
 * - list of records with ids (courses, FAQ, reviews, board…): by id, or by
 *   similar text if a record was re-added under a new id
 */
function localizeValue(current, original, tr) {
  if (tr == null || current == null) return current;
  if (typeof tr === 'string') {
    if (typeof current !== 'string') return current;
    return current === original || similarity(current, original) >= SIMILAR ? tr : current;
  }
  if (Array.isArray(tr)) {
    if (!Array.isArray(current)) return current;
    const defs = Array.isArray(original) ? original : [];
    if (tr.every((x) => typeof x === 'string')) {
      return current.map((c) => {
        if (typeof c !== 'string') return c;
        let best = -1;
        let score = 0;
        defs.forEach((d, j) => {
          const sc = similarity(c, d);
          if (sc > score) {
            score = sc;
            best = j;
          }
        });
        return best >= 0 && score >= SIMILAR && tr[best] != null ? tr[best] : c;
      });
    }
    return current.map((c, i) => localizeValue(c, defs[i], tr[i]));
  }
  if (typeof tr === 'object') {
    if (Array.isArray(current)) {
      const defs = Array.isArray(original) ? original : [];
      return current.map((item) => {
        if (!item || typeof item !== 'object') return item;
        let key = item.id && tr[item.id] ? item.id : null;
        let def = key ? defs.find((o) => o && o.id === key) : null;
        if (!key) {
          let score = 0;
          defs.forEach((d) => {
            if (!d || !tr[d.id]) return;
            const sc = itemSimilarity(item, d);
            if (sc > score) {
              score = sc;
              key = d.id;
              def = d;
            }
          });
          if (score < SIMILAR) return item;
        }
        return localizeValue(item, def, tr[key]);
      });
    }
    if (typeof current === 'object') {
      const out = { ...current };
      Object.keys(tr).forEach((k) => {
        if (k in current) out[k] = localizeValue(current[k], original?.[k], tr[k]);
      });
      return out;
    }
  }
  return current;
}

/**
 * Reviews in Bangla, in this order of preference:
 *   1. the Bangla the admin typed (Admin → Reviews → "Bangla" fields),
 *   2. the translation in bn.json (for the original reviews),
 *   3. automatic Bangla for the place and course tag (see autoTranslate.js).
 * The review text itself can only come from 1 or 2; otherwise it stays English.
 */
function localizeReviews(raw, out) {
  if (!Array.isArray(raw?.testimonials) || !Array.isArray(out?.testimonials)) return out;
  const courses = (raw.courses || []).map((c, i) => ({ en: c?.title, bn: out.courses?.[i]?.title }));
  const own = (v) => (typeof v === 'string' && v.trim() ? v.trim() : null);
  return {
    ...out,
    testimonials: out.testimonials.map((item, i) => {
      const src = raw.testimonials[i];
      if (!item || !src) return item;
      return {
        ...item,
        quote: own(src.quoteBn) || item.quote,
        role: own(src.roleBn) || (item.role === src.role ? translatePlace(src.role) : item.role),
        course: own(src.courseBn) || (item.course === src.course ? translateCourse(src.course, courses, similarity) : item.course),
      };
    }),
  };
}

/**
 * Last pass: any text still in English that is listed in bn.json → "phrases"
 * (e.g. a bullet or course name added later in the admin panel) is replaced.
 * Exact matches only (ignoring capitals and punctuation), so nothing is
 * guessed. Contact details, names, links and ids are never touched.
 */
const PHRASE_SKIP = new Set(['id', 'name', 'email', 'phone', 'whatsapp', 'address', 'imageUrl', 'photoUrl', 'url', 'href', 'linkHref', 'icon', 'slug', 'platforms', 'videos']);
let phraseMap = null;
function applyPhrases(value, key) {
  if (key && PHRASE_SKIP.has(key)) return value;
  if (typeof value === 'string') return /[A-Za-z]/.test(value) ? phraseMap.get(clean(value)) ?? value : value;
  if (Array.isArray(value)) return value.map((v) => applyPhrases(v));
  if (value && typeof value === 'object') {
    const out = {};
    Object.keys(value).forEach((k) => (out[k] = applyPhrases(value[k], k)));
    return out;
  }
  return value;
}

export function localizeContent(content, lang) {
  if (!content || lang === 'en' || !DICTS[lang]?.content) return content;
  let out = localizeReviews(content, localizeValue(content, defaultContent, DICTS[lang].content));
  out = buildPhrases(lang) ? applyPhrases(out) : out;
  return lang === 'bn' ? applyContentEdits(out, content?.site?.bnContent) : out;
}

/* v160: Bangla for any website content, edited in the admin panel
   (Website → Bangla text). Keys are JSON paths in the content; an array item
   with an id is addressed as "#<id>", so edits stay with the right course,
   teacher or review even when the list is re-ordered. */
export function contentPathGet(obj, path) {
  let o = obj;
  for (const seg of path) {
    if (o == null) return undefined;
    if (typeof seg === 'string' && seg.startsWith('#') && Array.isArray(o)) o = o.find((x) => x && String(x.id) === seg.slice(1));
    else o = o[seg];
  }
  return o;
}
function applyContentEdits(content, edits) {
  if (!edits || typeof edits !== 'object') return content;
  const out = JSON.parse(JSON.stringify(content));
  Object.entries(edits).forEach(([k, v]) => {
    let path;
    try { path = JSON.parse(k); } catch { return; }
    if (!Array.isArray(path) || path.length < 2 || typeof v !== 'string' || !v.trim()) return;
    const parent = contentPathGet(out, path.slice(0, -1));
    const last = path[path.length - 1];
    if (parent && typeof parent === 'object' && typeof parent[last] === 'string') parent[last] = v;
  });
  return out;
}
function buildPhrases(lang) {
  const phrases = DICTS[lang]?.phrases;
  if (!phrases) return false;
  if (!phraseMap) {
    phraseMap = new Map();
    Object.entries(phrases).forEach(([en, bn]) => !en.startsWith('_') && phraseMap.set(clean(en), bn));
  }
  return true;
}

// Converts 0-9 to Bengali numerals when Bengali is active
export function toLangDigits(value, lang) {
  if (lang !== 'bn' || value == null) return value;
  return String(value).replace(/[0-9]/g, (d) => BN_DIGITS[d]);
}

function makeApi(lang) {
  const dict = DICTS[lang] || en;
  const t = (key, vars) => {
    const v = lookup(dict, key) ?? lookup(en, key);
    return typeof v === 'string' ? fill(v, vars) : key;
  };
  const n = (value) => toLangDigits(value, lang);
  // Prices: Bengali numerals, and ৳ for Taka ("BDT 3,000" -> "৳৩,০০০")
  const money = (text) => (lang === 'bn' ? n(String(text ?? '').replace(/\bBDT\s*/g, '৳')) : text);
  // Free text from elsewhere (e.g. a Vimeo title): Bangla from bn.json → phrases if listed
  const phrase = (text) => (lang !== 'en' && typeof text === 'string' && buildPhrases(lang) ? phraseMap.get(clean(text)) ?? text : text);
  return { t, n, money, phrase };
}

// Used when a component renders outside the provider (e.g. the admin panel)
const FALLBACK = { lang: 'en', setLang: () => {}, toggle: () => {}, bnAllowed: false, ...makeApi('en') };
const LanguageContext = createContext(FALLBACK);

export function LanguageProvider({ children }) {
  // The visitor's saved preference, and whether বাংলা is offered where they are
  const [choice, setChoice] = useState(readSavedLanguage);
  const [bnAllowed, setBnAllowed] = useState(banglaAllowedByTimezone);
  const [, setDictsLoaded] = useState(0); // re-render once a dictionary arrives

  // Time zone not on the list? Check the IP country too (shared, cached lookup)
  useEffect(() => {
    if (bnAllowed) return undefined;
    let alive = true;
    detectLocation()
      .then((g) => alive && BANGLA_COUNTRIES.includes(g.country) && setBnAllowed(true))
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, [bnAllowed]);

  // A saved Bengali choice confirmed only by IP: fetch the Bengali text now
  useEffect(() => {
    if (choice !== 'en' && bnAllowed && !DICTS[choice]) {
      loadLanguage(choice)
        .then(() => setDictsLoaded((v) => v + 1))
        .catch(() => {});
    }
  }, [choice, bnAllowed]);

  // Bangla text edited in the admin panel
  const { content: siteContent } = useSiteData();
  const bnEdits = siteContent?.site?.bnText;
  useEffect(() => {
    if (applyBanglaEdits(bnEdits)) setDictsLoaded((v) => v + 1);
  }, [bnEdits]);

  // What is actually shown: English unless Bengali is chosen, allowed and loaded
  const lang = choice === 'bn' && bnAllowed && DICTS.bn ? 'bn' : 'en';

  const setLang = useCallback((next) => {
    if (!LANGUAGES.includes(next)) return;
    try {
      localStorage.setItem(STORAGE_KEY, next);
    } catch {
      /* the choice still applies for this visit */
    }
    if (next === 'bn') loadBengaliFont(); // start the font while the text loads
    loadLanguage(next)
      .then(() => {
        setDictsLoaded((v) => v + 1);
        setChoice(next);
      })
      .catch(() => {});
  }, []);
  const toggle = useCallback(() => setLang(lang === 'bn' ? 'en' : 'bn'), [lang, setLang]);

  // <html lang>, the Bengali font and typography rules follow the language.
  // Leaving the public site (e.g. for the admin panel) switches back to English.
  useEffect(() => {
    const root = document.documentElement;
    root.lang = lang;
    if (lang === 'bn') loadBengaliFont();
    return () => {
      root.lang = 'en';
    };
  }, [lang]);

  const value = useMemo(
    () => ({ lang, setLang, toggle, bnAllowed, ...makeApi(lang) }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [lang, setLang, toggle, bnAllowed, DICTS.bn],
  );
  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export const useLanguage = () => useContext(LanguageContext);

// Site content in the visitor's language (memoised per content + language)
export function useContent() {
  const { content } = useSiteData();
  const api = useLanguage();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  return useMemo(() => localizeContent(content, api.lang), [content, api.lang, api]);
}
