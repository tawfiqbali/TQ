/**
 * Automatic Bangla for short labels that admins type in English, so a new
 * review still shows its place and course in Bangla even when nobody has filled
 * in the Bangla fields:
 *
 *   translatePlace('Toronto, Canada')   -> 'টরন্টো, কানাডা'
 *   translateCourse('Noorani Qaida')    -> 'নূরানী কায়দা'
 *
 * - Country names come from the browser's own Bangla list (Intl.DisplayNames),
 *   so every country works without a glossary.
 * - Cities, regions and course words come from the small glossaries below. A
 *   place part that is not in the list stays in English (e.g. a small town).
 * - A course name is only replaced when EVERY word can be translated;
 *   otherwise the English name is kept, so no half-English course names appear.
 * Add more entries to the glossaries at any time (lowercase English on the left).
 */

// Cities and regions (lowercase English -> Bangla)
const PLACES = {
  // Bangladesh
  dhaka: 'ঢাকা', savar: 'সাভার', gazipur: 'গাজীপুর', narayanganj: 'নারায়ণগঞ্জ', chittagong: 'চট্টগ্রাম', chattogram: 'চট্টগ্রাম',
  sylhet: 'সিলেট', rajshahi: 'রাজশাহী', khulna: 'খুলনা', barisal: 'বরিশাল', barishal: 'বরিশাল', rangpur: 'রংপুর', mymensingh: 'ময়মনসিংহ',
  comilla: 'কুমিল্লা', cumilla: 'কুমিল্লা', bogura: 'বগুড়া', bogra: 'বগুড়া', "cox's bazar": 'কক্সবাজার', feni: 'ফেনী', noakhali: 'নোয়াখালী',
  jessore: 'যশোর', jashore: 'যশোর', tangail: 'টাঙ্গাইল', uttara: 'উত্তরা', mirpur: 'মিরপুর', dhanmondi: 'ধানমন্ডি', gulshan: 'গুলশান',
  // Middle East
  dubai: 'দুবাই', 'abu dhabi': 'আবুধাবি', sharjah: 'শারজাহ', ajman: 'আজমান', 'al ain': 'আল আইন', riyadh: 'রিয়াদ', jeddah: 'জেদ্দা',
  makkah: 'মক্কা', mecca: 'মক্কা', madinah: 'মদিনা', medina: 'মদিনা', dammam: 'দাম্মাম', 'al khobar': 'আল খোবার', khobar: 'খোবার',
  doha: 'দোহা', muscat: 'মাসকাট', salalah: 'সালালাহ', 'kuwait city': 'কুয়েত সিটি', manama: 'মানামা', amman: 'আম্মান',
  cairo: 'কায়রো', alexandria: 'আলেকজান্দ্রিয়া', istanbul: 'ইস্তাম্বুল', ankara: 'আঙ্কারা', beirut: 'বৈরুত', baghdad: 'বাগদাদ',
  // Asia
  'kuala lumpur': 'কুয়ালালামপুর', penang: 'পেনাং', 'johor bahru': 'জোহর বাহরু', selangor: 'সেলাঙ্গর', karachi: 'করাচি', lahore: 'লাহোর',
  islamabad: 'ইসলামাবাদ', delhi: 'দিল্লি', 'new delhi': 'নয়াদিল্লি', kolkata: 'কলকাতা', mumbai: 'মুম্বাই', jakarta: 'জাকার্তা',
  tokyo: 'টোকিও', seoul: 'সিউল', 'hong kong': 'হংকং', bangkok: 'ব্যাংকক', maldives: 'মালদ্বীপ', male: 'মালে',
  // Europe
  london: 'লন্ডন', manchester: 'ম্যানচেস্টার', birmingham: 'বার্মিংহাম', bradford: 'ব্র্যাডফোর্ড', leeds: 'লিডস', luton: 'লুটন',
  oldham: 'ওল্ডহ্যাম', leicester: 'লেস্টার', glasgow: 'গ্লাসগো', edinburgh: 'এডিনবরা', cardiff: 'কার্ডিফ', liverpool: 'লিভারপুল',
  sheffield: 'শেফিল্ড', 'tower hamlets': 'টাওয়ার হ্যামলেটস', england: 'ইংল্যান্ড', scotland: 'স্কটল্যান্ড', wales: 'ওয়েলস',
  paris: 'প্যারিস', berlin: 'বার্লিন', rome: 'রোম', milan: 'মিলান', madrid: 'মাদ্রিদ', barcelona: 'বার্সেলোনা', lisbon: 'লিসবন',
  amsterdam: 'আমস্টারডাম', brussels: 'ব্রাসেলস', stockholm: 'স্টকহোম', oslo: 'অসলো', copenhagen: 'কোপেনহেগেন', vienna: 'ভিয়েনা',
  dublin: 'ডাবলিন', athens: 'এথেন্স', helsinki: 'হেলসিঙ্কি',
  // Americas & Oceania
  'new york': 'নিউ ইয়র্ক', 'new jersey': 'নিউ জার্সি', 'los angeles': 'লস অ্যাঞ্জেলেস', chicago: 'শিকাগো', houston: 'হিউস্টন',
  dallas: 'ডালাস', detroit: 'ডেট্রয়েট', michigan: 'মিশিগান', texas: 'টেক্সাস', california: 'ক্যালিফোর্নিয়া', florida: 'ফ্লোরিডা',
  virginia: 'ভার্জিনিয়া', atlanta: 'আটলান্টা', boston: 'বোস্টন', washington: 'ওয়াশিংটন', philadelphia: 'ফিলাডেলফিয়া',
  toronto: 'টরন্টো', ontario: 'অন্টারিও', montreal: 'মন্ট্রিয়াল', vancouver: 'ভ্যাঙ্কুভার', calgary: 'ক্যালগারি', ottawa: 'অটোয়া',
  sydney: 'সিডনি', melbourne: 'মেলবোর্ন', brisbane: 'ব্রিসবেন', perth: 'পার্থ', adelaide: 'অ্যাডিলেড', auckland: 'অকল্যান্ড',
  // Words people put next to a place
  parent: 'অভিভাবক', parents: 'অভিভাবক', mother: 'মা', mom: 'মা', mum: 'মা', father: 'বাবা', dad: 'বাবা', student: 'শিক্ষার্থী',
  'adult student': 'প্রাপ্তবয়স্ক শিক্ষার্থী', teacher: 'শিক্ষক',
};

// Short country names people type that the browser list does not use
const COUNTRY_ALIASES = {
  uk: 'GB', 'u.k.': 'GB', britain: 'GB', 'great britain': 'GB', usa: 'US', 'u.s.a.': 'US', us: 'US', 'u.s.': 'US', america: 'US',
  'united states of america': 'US', uae: 'AE', 'u.a.e.': 'AE', emirates: 'AE', ksa: 'SA', saudi: 'SA', 'saudi arabia': 'SA',
  turkey: 'TR', holland: 'NL', 'south korea': 'KR', korea: 'KR', russia: 'RU', 'czech republic': 'CZ', palestine: 'PS',
};

let countryIndex = null; // lowercase English country name -> region code
function countryCode(name) {
  const key = name.toLowerCase();
  if (COUNTRY_ALIASES[key]) return COUNTRY_ALIASES[key];
  if (!countryIndex) {
    countryIndex = {};
    try {
      const enNames = new Intl.DisplayNames(['en'], { type: 'region' });
      const A = 65;
      for (let i = 0; i < 26; i++)
        for (let j = 0; j < 26; j++) {
          const code = String.fromCharCode(A + i, A + j);
          const label = enNames.of(code);
          if (label && label !== code) countryIndex[label.toLowerCase()] = code;
        }
    } catch {
      /* very old browser: countries stay in English */
    }
  }
  return countryIndex[key] || null;
}
let bnRegions = null;
function countryBn(name) {
  const code = countryCode(name);
  if (!code) return null;
  try {
    bnRegions = bnRegions || new Intl.DisplayNames(['bn'], { type: 'region' });
    const label = bnRegions.of(code);
    return label && label !== code ? label : null;
  } catch {
    return null;
  }
}

const hasLatin = (s) => /[A-Za-z]/.test(s);

// "Toronto, Canada" -> "টরন্টো, কানাডা". Unknown parts stay as typed.
export function translatePlace(text) {
  if (typeof text !== 'string' || !hasLatin(text)) return text;
  return text
    .split(/(\s*[,·|/]\s*)/)
    .map((part) => {
      const word = part.trim();
      if (!word || !hasLatin(word)) return part.includes(',') ? ', ' : part;
      const key = word.toLowerCase().replace(/\.$/, '');
      return PLACES[key] || countryBn(word) || part;
    })
    .join('');
}

// Course words, longest phrases first (lowercase English -> Bangla)
const COURSE_TERMS = [
  ['recitation & tajweed', 'তিলাওয়াত ও তাজবীদ'], ['recitation and tajweed', 'তিলাওয়াত ও তাজবীদ'],
  ['noorani qaida', 'নূরানী কায়দা'], ['nurani qaida', 'নূরানী কায়দা'], ['noorani qaidah', 'নূরানী কায়দা'], ['qaida', 'কায়দা'],
  ['hifz program', 'হিফজ প্রোগ্রাম'], ['hifz programme', 'হিফজ প্রোগ্রাম'], ['quran hifz', 'হিফজুল কুরআন'], ['hifz', 'হিফজ'],
  ['memorization', 'হিফজ'], ['memorisation', 'হিফজ'], ['nazra', 'নাজেরা'], ['nazera', 'নাজেরা'], ['nazira', 'নাজেরা'],
  ['tajweed', 'তাজবীদ'], ['tajwid', 'তাজবীদ'], ['recitation', 'তিলাওয়াত'], ['tafseer', 'তাফসীর'], ['tafsir', 'তাফসীর'],
  ['islamic studies', 'ইসলামি শিক্ষা'], ['fiqh', 'ফিকহ'], ['hadith', 'হাদিস'], ['seerah', 'সীরাত'], ['aqeedah', 'আকিদা'],
  ['arabic language', 'আরবি ভাষা'], ['arabic', 'আরবি'], ['quran for kids', 'শিশুদের কুরআন শিক্ষা'],
  ['quran for adults', 'প্রাপ্তবয়স্কদের কুরআন শিক্ষা'], ['quran reading', 'কুরআন পাঠ'], ['quran', 'কুরআন'], ['qur’an', 'কুরআন'],
  ['for kids', 'শিশুদের জন্য'], ['for adults', 'প্রাপ্তবয়স্কদের জন্য'], ['kids', 'শিশু'], ['adults', 'প্রাপ্তবয়স্ক'],
  ['beginners', 'নতুনদের জন্য'], ['beginner', 'প্রাথমিক'], ['advanced', 'উচ্চতর'], ['course', 'কোর্স'], ['program', 'প্রোগ্রাম'],
  ['programme', 'প্রোগ্রাম'], ['class', 'ক্লাস'], ['classes', 'ক্লাস'], ['and', 'ও'], ['&', 'ও'],
];
const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const COURSE_RE = COURSE_TERMS.map(([en, bn]) => [new RegExp(`(^|[^\\p{L}])${esc(en)}(?=$|[^\\p{L}])`, 'giu'), bn]);

/**
 * "Noorani Qaida" -> "নূরানী কায়দা".
 * `courses` = [{ en: 'Quran For Kids', bn: 'শিশুদের কুরআন শিক্ষা' }, …] from the
 * site's own courses: a review tagged with a course title gets that course's
 * Bangla title.
 */
export function translateCourse(text, courses = [], similarity) {
  if (typeof text !== 'string' || !hasLatin(text)) return text;
  if (similarity) {
    let best = null;
    let score = 0;
    courses.forEach((c) => {
      const sc = similarity(text, c.en);
      if (sc > score) {
        score = sc;
        best = c;
      }
    });
    if (best && score >= 0.75 && best.bn && !hasLatin(best.bn)) return best.bn;
  }
  let out = text;
  COURSE_RE.forEach(([re, bn]) => {
    out = out.replace(re, (m, pre) => `${pre}${bn}`);
  });
  out = out.replace(/\s*\/\s*/g, ' / ').replace(/\s{2,}/g, ' ').trim();
  return hasLatin(out) ? text : out; // all or nothing
}
