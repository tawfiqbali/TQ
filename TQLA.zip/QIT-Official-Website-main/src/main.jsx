import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App.jsx';
import { banglaAllowedByTimezone, loadLanguage, readSavedLanguage } from './i18n/LanguageContext';
import './index.css';
import { initUiFx } from './lib/uiFx';

initUiFx(); // delete-button animation everywhere; soft press sounds in the panels

const render = () =>
  ReactDOM.createRoot(document.getElementById('root')).render(
    <React.StrictMode>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </React.StrictMode>,
  );

// Visitors who chose বাংলা before (and are in a country where it is offered):
// fetch the Bengali text first (from the browser cache after the first visit),
// so the page opens directly in Bengali. The admin panel is always English.
const wantsBengali = !location.pathname.startsWith('/admin') && readSavedLanguage() === 'bn' && banglaAllowedByTimezone();
if (wantsBengali) loadLanguage('bn').catch(() => {}).finally(render);
else render();
