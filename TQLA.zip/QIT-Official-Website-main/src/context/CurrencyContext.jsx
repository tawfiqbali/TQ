import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { useSiteData } from './SiteDataContext';
import { builtInBangladeshRule, countryName, currencyForCountry, detectLocation, formatPriceRange, getOverride, loadRates, roundNicely, setOverride } from '../lib/currency';
import useAdminRole from '../hooks/useAdminRole';

/**
 * Prices for this visitor:
 *  1. Detect the visitor's country (IP address, with the device time zone as backup).
 *  2. The country's currency is picked automatically (Canada → CAD, …).
 *  3. For each plan: if the admin set a custom price for that country
 *     (Admin → Pricing & currency) it is shown exactly. Otherwise the USD base
 *     price is converted to the local currency at today's rate and rounded.
 *     Bangladesh always uses its fixed BDT prices.
 *  4. If no exchange rate is available, the USD price is shown.
 */
const CurrencyContext = createContext(null);

export function CurrencyProvider({ children }) {
  const { content } = useSiteData();
  const { baseCurrency = 'USD' } = content.site.settings;
  const rules = useMemo(() => content.site.pricing?.rules || [], [content.site.pricing]);

  const [geo, setGeo] = useState({ country: '', loading: true });
  const [rates, setRates] = useState(null);
  const isAdmin = useAdminRole().isSuper;
  const [savedPreview, setSavedPreview] = useState(getOverride);
  // A previewed country applies only while an Executive is signed in
  const preview = isAdmin ? savedPreview : '';

  useEffect(() => {
    let alive = true;
    detectLocation().then((g) => alive && setGeo({ country: g.country || '', loading: false }));
    return () => {
      alive = false;
    };
  }, []);

  const country = preview || geo.country;
  const currency = currencyForCountry(country, baseCurrency);
  // Bangladesh always has its fixed BDT prices, even if its rule was removed
  const rule = rules.find((r) => r.country === country) || (country === 'BD' ? builtInBangladeshRule(content.courses) : null);

  // Exchange rates: only fetched when the visitor's currency differs from USD
  useEffect(() => {
    if (currency === baseCurrency || rates) return undefined;
    let alive = true;
    loadRates(baseCurrency).then((r) => alive && setRates(r));
    return () => {
      alive = false;
    };
  }, [currency, baseCurrency, rates]);
  const rate = currency !== baseCurrency ? rates?.[currency] : null;

  // Automatic price for a plan: USD converted to the local currency, rounded
  const autoPrice = useCallback(
    (plan) => {
      if (!rate) return formatPriceRange(plan.min, plan.max, baseCurrency);
      const conv = (v) => (v === '' || v == null ? v : roundNicely(Number(v) * rate));
      return formatPriceRange(conv(plan.min), conv(plan.max), currency);
    },
    [rate, currency, baseCurrency],
  );

  // Price text for plan number `index` of a course
  const formatPlan = useCallback(
    (plan, courseId, index) => {
      if (!plan) return '';
      const own = rule?.prices?.[courseId]?.[index];
      if (own && own.min !== '' && own.min != null) return formatPriceRange(own.min, own.max, currency);
      return autoPrice(plan);
    },
    [rule, currency, autoPrice],
  );

  const choosePreview = useCallback((code) => {
    setOverride(code);
    setSavedPreview(code);
  }, []);

  const shownCurrency = rule || rate ? currency : baseCurrency;
  const value = useMemo(
    () => ({
      loading: geo.loading,
      country,
      detectedCountry: geo.country,
      countryLabel: countryName(country),
      currency: shownCurrency,
      baseCurrency,
      rule,
      rules,
      isConverted: shownCurrency !== baseCurrency,
      formatPlan,
      preview,
      choosePreview,
    }),
    [geo, country, shownCurrency, baseCurrency, rule, rules, formatPlan, preview, choosePreview],
  );

  return <CurrencyContext.Provider value={value}>{children}</CurrencyContext.Provider>;
}

export function useCurrency() {
  const ctx = useContext(CurrencyContext);
  if (!ctx) throw new Error('useCurrency must be used inside <CurrencyProvider>');
  return ctx;
}
