import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { storage } from '../lib/storage';
import { defaultContent, CONTENT_VERSION, BRAND_NAME } from '../data/defaultContent';
import { createId } from '../lib/utils';

const SiteDataContext = createContext(null);

const clone = (v) => JSON.parse(JSON.stringify(v));

// Fill in any fields added to defaultContent after the data was first saved,
// so new versions of the site never crash on older saved data.
// Content saved by an older version of the site (different shape) is
// replaced by the new defaults instead of being patched.
function mergeWithDefaults(stored) {
  if (!stored || typeof stored !== 'object' || (stored.version ?? 1) < CONTENT_VERSION) return clone(defaultContent);
  const site = { ...clone(defaultContent.site) };
  for (const [key, value] of Object.entries(stored.site ?? {})) {
    const def = defaultContent.site[key];
    const bothObjects =
      def && typeof def === 'object' && !Array.isArray(def) && value && typeof value === 'object' && !Array.isArray(value);
    site[key] = bothObjects ? { ...def, ...value } : value;
  }
  // appliedUpdates comes only from the saved copy, so older copies get the updates
  return migrate({ ...clone(defaultContent), ...stored, site, version: CONTENT_VERSION, appliedUpdates: stored.appliedUpdates || [] });
}

// Small fixes applied to content saved by earlier versions, without wiping
// the admin's other edits.
const PHOTO_NAMES = ['hero-slide-1', 'hero-slide-2', 'hero-slide-3', 'quran-live', 'trial-class', 'why-us', 'cta-class'];
function migrate(content) {
  let json = JSON.stringify(content);
  // The institute's name is "Quran International Institute" everywhere. Any
  // saved copy of the old name (in any text the admin saved) is replaced.
  json = json
    .replace(/\b(?:the\s+)?q[\s\-\u2011]*light\s+academy\b/gi, BRAND_NAME)
    .replace(/(?:দ্য\s*)?কিউ[\s\-]*লাইট\s*একাডেমি/g, 'কুরআন ইন্টারন্যাশনাল ইনস্টিটিউট');
  // Trial class is now 45 minutes
  json = json.replace(/\b30( |-)minute/g, '45$1minute');
  // Photos are now served as smaller WebP files
  PHOTO_NAMES.forEach((n) => {
    json = json.split(`/images/${n}.jpg`).join(`/images/${n}.webp`);
  });
  // New branded QIT slideshow photos replace the earlier set
  [1, 2, 3].forEach((k) => {
    json = json.split(`/images/hero-slide-${k}.webp`).join(`/images/hero-qit-${k}.webp`);
  });
  const out = JSON.parse(json);
  // One-time updates. Each runs once on content saved before it existed and is
  // then recorded in `appliedUpdates`, so later admin edits are never undone.
  const applied = new Set(out.appliedUpdates || []);
  const once = (id, fn) => {
    if (!applied.has(id)) {
      fn();
      applied.add(id);
    }
  };
  // The six real board members (replaces whatever board was saved before)
  once('board-members-2026-09', () => {
    out.board = clone(defaultContent.board);
  });
  // "20+ Countries"
  once('countries-20-plus', () => {
    if (out.site?.stats) out.site.stats.countries = '20+';
  });
  // Real photos for each board member (matched by name)
  once('board-photos-jpg', () => {
    const photoFor = Object.fromEntries(defaultContent.board.map((m) => [String(m.name).toUpperCase(), m.photoUrl]));
    (out.board || []).forEach((m) => {
      const photo = photoFor[String(m.name).trim().toUpperCase()];
      const old = String(m.photoUrl || '');
      if (photo && (!old || /placeholder|\/images\/board\/(founder-chairman|co-founder|ceo|head-of-accounts|head-of-marketing|hr-manager)\.webp/.test(old))) m.photoUrl = photo;
    });
  });
  // New live-class photo shown first in the hero slideshow
  once('hero-slide-4', () => {
    const hero = out.site?.hero;
    if (hero && Array.isArray(hero.slides) && !hero.slides.includes('/images/hero-qit-4.webp')) hero.slides = ['/images/hero-qit-4.webp', ...hero.slides];
  });
  // New portrait photos (same file names; ?v=2 makes browsers fetch the new ones)
  once('board-portraits-v2', () => {
    const photoFor = Object.fromEntries(defaultContent.board.map((m) => [String(m.photoUrl).split('?')[0], m.photoUrl]));
    (out.board || []).forEach((m) => {
      const base = String(m.photoUrl || '').split('?')[0];
      if (photoFor[base]) m.photoUrl = photoFor[base];
    });
  });
  // HR Manager's new WhatsApp number
  once('hr-number-1703', () => {
    (out.board || []).forEach((m) => {
      if (String(m.whatsapp).replace(/\D/g, '') === '8801403788889') m.whatsapp = '+880 1703-788889';
    });
  });
  // Featured photo section is now the "Spotlight" with the new banner
  once('spotlight-v1', () => {
    const f = out.site?.featured;
    if (!f) return;
    if (!f.imageUrl || /featured-qit/.test(f.imageUrl)) f.imageUrl = '/images/spotlight-qit.webp';
    if (!f.eyebrow || /^featured$/i.test(String(f.eyebrow).trim())) f.eyebrow = 'Spotlight';
  });
  // Head of Accounts' corrected WhatsApp number
  once('accounts-number-987261', () => {
    (out.board || []).forEach((m) => {
      if (String(m.whatsapp).replace(/\D/g, '') === '8801851981261') m.whatsapp = '+880 1851-987261';
    });
  });
  // Wider re-cropped photos (?v=3 so browsers fetch the new files)
  once('board-photos-v3', () => {
    (out.board || []).forEach((m) => {
      const url = String(m.photoUrl || '');
      if (/^\/images\/board\/[a-z-]+\.jpg(\?v=\d+)?$/.test(url)) m.photoUrl = `${url.split('?')[0]}?v=3`;
    });
  });
  // CEO's new WhatsApp number (the office number stays in the footer)
  once('ceo-number-1334059560', () => {
    (out.board || []).forEach((m) => {
      if (/ceo|chief executive/i.test(String(m.role)) && String(m.whatsapp).replace(/\D/g, '') === '8801928616108') m.whatsapp = '+880 133-4059560';
    });
  });
  // Country pricing rules: turn the old per-plan BDT prices into a Bangladesh rule
  once('pricing-rules-v1', () => {
    if (!out.site) return;
    const hasOwnRules = Array.isArray(out.site.pricing?.rules) && out.site.pricing.rules.some((r) => r.country !== 'BD');
    if (hasOwnRules) return;
    const bd = {
      id: 'BD',
      country: 'BD',
      currency: 'BDT',
      prices: Object.fromEntries(
        (out.courses || []).map((c) => [c.id, (c.plans || []).map((p) => ({ min: p.bdtMin ?? '', max: p.bdtMax ?? '' }))]),
      ),
    };
    out.site.pricing = { fallback: out.site.pricing?.fallback || 'usd', rules: [bd] };
  });
  // Currencies now follow the country automatically (fixes e.g. a BD rule saved as AUD)
  once('pricing-currency-auto', () => {
    (out.site?.pricing?.rules || []).forEach((r) => {
      if (r.country === 'BD') r.currency = 'BDT';
    });
  });
  // Why-us benefit cards now live in Site content → Why us
  once('whyus-cards-v1', () => {
    if (!out.site?.whyUs) return;
    const defs = defaultContent.site.whyUs;
    out.site.whyUs.heading = defs.heading;
    out.site.whyUs.cards = clone(defs.cards);
  });
  // Founder & Chairman's WhatsApp number
  once('founder-number-1928', () => {
    (out.board || []).forEach((m) => {
      if (/founder\s*&\s*chairman|^chairman$/i.test(String(m.role).trim())) m.whatsapp = '+880 1928-616108';
    });
  });
  // New featured (Spotlight) photo
  once('spotlight-v2', () => {
    const f = out.site?.featured;
    if (f && (!f.imageUrl || /\/images\/(spotlight-qit|featured-qit)\.webp/.test(f.imageUrl))) f.imageUrl = '/images/spotlight-qit-v2.webp';
  });
  // QIT Facebook page (only filled in if no link was saved yet)
  once('facebook-page', () => {
    if (out.site?.social && !String(out.site.social.facebook || '').trim()) out.site.social.facebook = defaultContent.site.social.facebook;
  });
  // Header branding: name + "Online Quran Academy" underneath
  once('brand-name-v63', () => {
    if (out.site?.brand) {
      out.site.brand.name = BRAND_NAME;
      out.site.brand.subtitle = defaultContent.site.brand.subtitle;
    }
  });
  // Co-Founder's new portrait (Sept 2026): replaces the saved photo
  once('cofounder-photo-v4', () => {
    (out.board || []).forEach((m) => {
      if (/co-?founder/i.test(String(m.role)) || String(m.name).trim().toUpperCase() === 'MD IBRAHIM SAMI') m.photoUrl = '/images/board/md-ibrahim-sami.jpg?v=4';
    });
  });
  // New board member: Head of Logistics & Welfare (third row, after the HR Manager)
  once('board-logistics-welfare', () => {
    const add = defaultContent.board.find((m) => m.id === 'b7');
    const board = out.board || (out.board = []);
    if (add && !board.some((m) => String(m.name).trim().toUpperCase() === add.name)) board.push(clone(add));
  });
  // Post renamed to "Head of Logistics"
  once('board-head-of-logistics', () => {
    (out.board || []).forEach((m) => {
      if (/^head of logistics\s*&\s*welfare$/i.test(String(m.role).trim())) m.role = 'Head of Logistics';
    });
  });
  // New, evenly framed board portraits (Sept 2026): same files, ?v=5
  once('board-portraits-v5', () => {
    const files = ['md-foyzul-karim-abdullah', 'md-ibrahim-sami', 'md-golam-muntasir-muhit', 'jubayer-hossain', 'md-tawfiq-rahman', 'md-faisal-hossain'];
    (out.board || []).forEach((m) => {
      const base = String(m.photoUrl || '').split('?')[0];
      const f = files.find((x) => base === `/images/board/${x}.jpg`);
      if (f) m.photoUrl = `/images/board/${f}.jpg?v=5`;
    });
  });
  // New Head of Logistics portrait (Sept 2026)
  once('board-logistics-photo-v2', () => {
    (out.board || []).forEach((m) => {
      const base = String(m.photoUrl || '').split('?')[0];
      if (base === '/images/board/hm-ashikur-rahman.jpg') m.photoUrl = '/images/board/hm-ashikur-rahman.jpg?v=2';
    });
  });
  out.appliedUpdates = [...applied];
  // Co-Founder's own email (earlier copies repeated the Founder's)
  (out.board || []).forEach((m) => {
    if (/co-?founder/i.test(String(m.role)) && String(m.email).trim().toLowerCase() === 'hafez.abdullah66@gmail.com') m.email = 'ibrahimsami032@gmail.com';
  });
  // First board card is "Founder & Chairman"
  const first = (out.board || []).find((m) => Number(m.tier) === 1);
  if (first && ['founder', 'chairman'].includes(String(first.role).trim().toLowerCase())) first.role = 'Founder & Chairman';
  return out;
}

export function SiteDataProvider({ children }) {
  const [content, setContentState] = useState(null);
  const [inquiries, setInquiriesState] = useState([]);
  const [ready, setReady] = useState(false);
  const [loadError, setLoadError] = useState(null);
  const contentRef = useRef(null);
  const inquiriesRef = useRef([]);
  const pendingSaves = useRef(0); // saves still travelling to the cloud
  const saveChain = useRef(Promise.resolve()); // saves go out one at a time, in order

  const applyContent = useCallback((raw) => {
    const merged = mergeWithDefaults(raw);
    contentRef.current = merged;
    setContentState(merged);
  }, []);

  const applyInquiries = useCallback((list) => {
    inquiriesRef.current = list;
    setInquiriesState(list);
  }, []);

  useEffect(() => {
    let alive = true;
    // Cloud mode: paint instantly from the last copy seen, then refresh
    // Show the page immediately: from this browser's last copy if there is
    // one, otherwise from the content built into the site. The cloud copy
    // replaces it a moment later if anything differs.
    const cached = storage.getCachedContent?.();
    if (cached) applyContent(cached);
    else if (storage.mode === 'supabase') applyContent(null);
    if (cached || storage.mode === 'supabase') setReady(true);
    (async () => {
      try {
        const c = await storage.loadContent();
        if (alive && pendingSaves.current === 0) applyContent(c);
      } catch (err) {
        console.error('Could not load site content', err);
        if (!alive) return;
        setLoadError(err);
        if (!cached) applyContent(null); // offline: keep the cached copy if we have one
      } finally {
        if (alive) setReady(true);
      }
      // Inquiries are only readable by signed-in executives; failures here
      // must never stop the website from showing.
      storage
        .loadInquiries()
        .then((i) => alive && applyInquiries(i ?? []))
        .catch(() => {});
    })();

    const unsubscribe = storage.subscribe((change) => {
      // While this browser is still saving, ignore echoes of older versions
      if ('content' in change && pendingSaves.current === 0) applyContent(change.content);
      if ('inquiries' in change) applyInquiries(change.inquiries);
    });
    return () => {
      alive = false;
      unsubscribe?.();
    };
  }, [applyContent, applyInquiries]);

  /* ---------- content ---------- */
  const commitContent = useCallback(async (updater) => {
    const prev = contentRef.current;
    const next = typeof updater === 'function' ? updater(prev) : updater;
    contentRef.current = next;
    setContentState(next); // optimistic: the UI updates instantly
    pendingSaves.current += 1;
    const job = saveChain.current.catch(() => {}).then(() => storage.saveContent(next));
    saveChain.current = job;
    try {
      await job;
    } catch (err) {
      if (contentRef.current === next) {
        contentRef.current = prev;
        setContentState(prev);
      }
      throw err;
    } finally {
      pendingSaves.current -= 1;
    }
    return next;
  }, []);

  const updateSite = useCallback(
    (section, value) => commitContent((c) => ({ ...c, site: { ...c.site, [section]: value } })),
    [commitContent],
  );

  const saveItem = useCallback(
    (collection, item) =>
      commitContent((c) => {
        const list = c[collection] ?? [];
        const exists = item.id && list.some((x) => x.id === item.id);
        const record = exists ? item : { ...item, id: item.id || createId() };
        return { ...c, [collection]: exists ? list.map((x) => (x.id === item.id ? record : x)) : [...list, record] };
      }),
    [commitContent],
  );

  const deleteItem = useCallback(
    (collection, id) => commitContent((c) => ({ ...c, [collection]: (c[collection] ?? []).filter((x) => x.id !== id) })),
    [commitContent],
  );

  const moveItem = useCallback(
    (collection, id, direction) =>
      commitContent((c) => {
        const list = [...(c[collection] ?? [])];
        const i = list.findIndex((x) => x.id === id);
        const j = i + direction;
        if (i < 0 || j < 0 || j >= list.length) return c;
        [list[i], list[j]] = [list[j], list[i]];
        return { ...c, [collection]: list };
      }),
    [commitContent],
  );

  const resetContent = useCallback(() => commitContent(clone(defaultContent)), [commitContent]);

  const importBackup = useCallback(
    async (backup) => {
      if (!backup || typeof backup !== 'object' || !backup.content) {
        throw new Error('That file is not a Quran International Institute backup.');
      }
      await commitContent(mergeWithDefaults(backup.content));
      if (Array.isArray(backup.inquiries)) {
        await storage.replaceInquiries(backup.inquiries);
        applyInquiries(await storage.loadInquiries());
      }
    },
    [commitContent, applyInquiries],
  );

  /* ---------- inquiries ---------- */
  const addInquiry = useCallback(
    async (data) => {
      const inquiry = {
        type: 'contact',
        name: '',
        email: '',
        phone: '',
        country: '',
        course: '',
        preferredTime: '',
        classDate: '',
        teacher: '',
        medium: '',
        platform: '',
        message: '',
        ...data,
        id: createId(),
        status: 'new',
        createdAt: new Date().toISOString(),
      };
      await storage.addInquiry(inquiry);
      if (storage.mode === 'local') applyInquiries([inquiry, ...inquiriesRef.current]);
      return inquiry;
    },
    [applyInquiries],
  );

  const updateInquiry = useCallback(
    async (id, patch) => {
      const prev = inquiriesRef.current;
      applyInquiries(prev.map((i) => (i.id === id ? { ...i, ...patch } : i)));
      try {
        await storage.updateInquiry(id, patch);
      } catch (err) {
        applyInquiries(prev);
        throw err;
      }
    },
    [applyInquiries],
  );

  const deleteInquiry = useCallback(
    async (id) => {
      const prev = inquiriesRef.current;
      applyInquiries(prev.filter((i) => i.id !== id));
      try {
        await storage.deleteInquiry(id);
      } catch (err) {
        applyInquiries(prev);
        throw err;
      }
    },
    [applyInquiries],
  );

  const refreshInquiries = useCallback(async () => {
    applyInquiries(await storage.loadInquiries());
  }, [applyInquiries]);

  const value = useMemo(
    () => ({
      content,
      inquiries,
      ready,
      loadError,
      storageMode: storage.mode,
      updateSite,
      saveItem,
      deleteItem,
      moveItem,
      resetContent,
      importBackup,
      addInquiry,
      updateInquiry,
      deleteInquiry,
      refreshInquiries,
    }),
    [content, inquiries, ready, loadError, updateSite, saveItem, deleteItem, moveItem, resetContent, importBackup, addInquiry, updateInquiry, deleteInquiry, refreshInquiries],
  );

  return <SiteDataContext.Provider value={value}>{children}</SiteDataContext.Provider>;
}

export function useSiteData() {
  const ctx = useContext(SiteDataContext);
  if (!ctx) throw new Error('useSiteData must be used inside <SiteDataProvider>');
  return ctx;
}
