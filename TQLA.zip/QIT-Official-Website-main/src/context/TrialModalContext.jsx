import { createContext, lazy, Suspense, useCallback, useContext, useMemo, useState } from 'react';
import Modal from '../components/ui/Modal';
import { useLanguage } from '../i18n/LanguageContext';

function LoadingForm() {
  const { t } = useLanguage();
  return <div className="p-10 text-center text-sm text-ink/60">{t('common.loadingForm')}</div>;
}

// The form's code loads the first time someone opens it
const TrialForm = lazy(() => import('../components/shared/TrialForm'));

const TrialModalContext = createContext({ openTrial: () => {}, openBuy: () => {} });

export function TrialModalProvider({ children }) {
  const [state, setState] = useState({ open: false, course: '', buy: null, key: 0 });

  // Safe to pass directly as onClick: a click event is ignored.
  const openTrial = useCallback((course) => {
    setState((s) => ({ open: true, course: typeof course === 'string' ? course : '', buy: null, key: s.key + 1 }));
  }, []);
  // Buy Course: the same form, with the chosen course, plan and price
  // buy = { course (English title), courseLabel, plan, planLabel, price }
  const openBuy = useCallback((buy) => {
    setState((s) => ({ open: true, course: buy?.course || '', buy: buy || null, key: s.key + 1 }));
  }, []);
  const close = useCallback(() => setState((s) => ({ ...s, open: false })), []);
  const value = useMemo(() => ({ openTrial, openBuy }), [openTrial, openBuy]);

  return (
    <TrialModalContext.Provider value={value}>
      {children}
      <Modal open={state.open} onClose={close} bare labelledBy="trial-form-title">
        <Suspense fallback={<LoadingForm />}>
          <TrialForm key={state.key} course={state.course} buy={state.buy} onClose={close} />
        </Suspense>
      </Modal>
    </TrialModalContext.Provider>
  );
}

export const useTrialModal = () => useContext(TrialModalContext);
