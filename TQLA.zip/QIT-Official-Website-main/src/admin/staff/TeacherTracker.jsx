import { profileAttr } from '../portal/components/ProfileOpener';
import { matchSearch } from '../../lib/search';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { byTeacherOrder } from '../portal/lib/constants';
import { Pencil, RefreshCw, Search, Trash2 } from 'lucide-react';
import useAdminRole from '../../hooks/useAdminRole';
import { useConfirm } from '../../components/ui/Confirm';
import { useToast } from '../../components/ui/Toast';
import { usePortalOptional } from '../portal/PortalContext';
import { EditTeacherModal } from '../portal/panels/common';
import Combobox from '../portal/components/Combobox';
import { MONTHS, listReports, reportMonth, staffTeacherList, whatsappLinks } from '../../lib/teacherData';
import './staff.css';


/**
 * Teacher list with the monthly-report submission tracker.
 * Shows who has a Teacher Dashboard account and how many of their students'
 * reports are in for the chosen month, so missing reports are easy to chase.
 * No salary, fee or bank information is included (the database never sends it).
 */
export default function TeacherTracker() {
  const last = reportMonth();
  const [month, setMonth] = useState(last.month);
  const [year, setYear] = useState(String(last.year));
  const [teachers, setTeachers] = useState(null);
  const [reports, setReports] = useState([]);
  const [error, setError] = useState('');
  const [q, setQ] = useState('');
  const [only, setOnly] = useState('all');
  const { isSuper } = useAdminRole();
  const portal = usePortalOptional(); // teacher records + edit/delete (Executives)
  const canManage = Boolean(isSuper && portal?.status === 'ready');
  const confirm = useConfirm();
  const toast = useToast();
  const [editing, setEditing] = useState(null);

  const load = useCallback(async () => {
    setError('');
    setTeachers(null);
    try {
      const [list, reps] = await Promise.all([staffTeacherList(), listReports({ month, year })]);
      setTeachers(list || []);
      setReports(reps || []);
    } catch (e) {
      setError(e.message);
      setTeachers([]);
    }
  }, [month, year]);
  useEffect(() => {
    load();
    // follow live updates from the Management Portal
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [load, portal?.liveTick]);

  const record = (id) => portal?.db.teachers.find((x) => x.id === id);
  const removeTeacher = async (t) => {
    if (t.students > 0) {
      toast(`${t.name} still has ${t.students} student${t.students > 1 ? 's' : ''}. Reassign or remove them first (Students tab).`, 'error');
      return;
    }
    const ok = await confirm({
      title: `Delete ${t.name} (${t.id})?`,
      message: `${t.name} is removed from the Teachers List and the Salary Directory.${t.email ? ` Their Google account (${t.email}) is unlinked.` : ''} Their Teacher ID sign-in is switched off at once.\n\nPast monthly reports and support requests are kept. This cannot be undone.`,
      confirmText: 'Delete teacher',
      tone: 'danger',
    });
    if (!ok) return;
    await portal.deleteTeacher(t.id);
    load();
  };

  const rows = useMemo(() => {
    const byTeacher = reports.reduce((m, r) => ({ ...m, [r.teacher_id]: (m[r.teacher_id] || 0) + 1 }), {});
    const term = q.trim().toLowerCase();
    return (teachers || [])
      .map((t) => ({ ...t, done: byTeacher[t.id] || 0 }))
      .filter((t) => !term || matchSearch([t.name, t.id, t.email, t.whatsapp, t.department].join(' '), term))
      .filter((t) => (only === 'missing' ? t.students > 0 && t.done < t.students : only === 'noAccount' ? !t.hasAccount : true))
      .sort(byTeacherOrder);
  }, [teachers, reports, q, only]);

  const totals = useMemo(() => {
    const list = teachers || [];
    const withStudents = list.filter((t) => t.students > 0);
    const expected = withStudents.reduce((a, t) => a + t.students, 0);
    return { teachers: list.length, accounts: list.filter((t) => t.hasAccount).length, expected, received: reports.length };
  }, [teachers, reports]);

  return (
    <div className="box-card">
      <div className="card-header-bar">
        <h2 className="card-title">Teacher list</h2>
        <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={load}>
          <RefreshCw className="h-3.5 w-3.5" /> Refresh
        </button>
      </div>

      <div className="metrics-bar mb-4">
        <div className="metric-col"><span className="metric-lbl">Teachers</span><span className="metric-val">{totals.teachers}</span></div>
        <div className="metric-col"><span className="metric-lbl">Dashboard accounts</span><span className="metric-val">{totals.accounts}</span></div>
        <div className="metric-col"><span className="metric-lbl">Reports in ({month})</span><span className="metric-val">{totals.received} / {totals.expected}</span></div>
      </div>

      <div className="rv-toolbar">
        <div>
          <label>Reports for</label>
          <Combobox value={month} onChange={setMonth} options={MONTHS.map((m) => ({ value: m, label: m }))} aria-label="Tracker month" />
        </div>
        <div style={{ minWidth: 110 }}>
          <label>Year</label>
          <Combobox value={year} onChange={setYear} options={[0, 1, 2].map((d) => String(new Date().getFullYear() - d)).map((v) => ({ value: v, label: v }))} aria-label="Tracker year" />
        </div>
        <div className="flex-1" style={{ minWidth: 220 }}>
          <label htmlFor="tt-search">Search</label>
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2" style={{ color: 'var(--text-muted)' }} aria-hidden="true" />
            <input id="tt-search" className="m-input" style={{ paddingLeft: 34 }} placeholder="Name, ID, Gmail, WhatsApp, department" value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
        </div>
      </div>
      <div className="rv-counts" role="group" aria-label="Show">
        {[['all', 'All teachers'], ['missing', 'Reports missing'], ['noAccount', 'No dashboard account']].map(([k, label]) => (
          <button key={k} type="button" className="rv-count" aria-pressed={only === k} onClick={() => setOnly(k)}>{label}</button>
        ))}
      </div>

      {error && <p className="setup-box mb-4 text-sm font-bold" role="alert">{error}</p>}
      {teachers === null ? (
        <p className="rv-empty">Loading teachers…</p>
      ) : !rows.length ? (
        <p className="rv-empty">No teachers match.</p>
      ) : (
        <div className="table-wrap">
          <table className="tl-table tt-fit">
            <thead>
              <tr>
                <th>Teacher · ID · Gmail</th><th>WhatsApp</th><th>Dashboard</th><th>Students</th><th>{month.slice(0, 3)} reports</th><th>Last report</th>{canManage && <th style={{ textAlign: 'right' }}>Action</th>}
              </tr>
            </thead>
            <tbody>
              {rows.map((t) => {
                const state = t.students === 0 ? '' : t.done >= t.students ? 'yes' : t.done > 0 ? 'part' : 'no';
                const phones = whatsappLinks(t.whatsapp);
                return (
                  <tr key={t.id}>
                    <td className="tt-name">
                      <strong {...profileAttr('teacher', t.id)}>{t.name}</strong> <span className="id-tag">{t.id}</span>
                      <div className="rv-sub tt-gmail">{t.email || 'no Gmail yet'}</div>
                      <div className="rv-sub">{[t.department, t.category].filter(Boolean).join(' · ')}{t.selfRegistered ? ' · signed up online' : ''}</div>
                    </td>
                    <td>{phones.length ? phones.map((ph) => <div key={ph.label}>{ph.href ? <a className="tl-link" href={ph.href} target="_blank" rel="noreferrer">{ph.label}</a> : ph.label}</div>) : <span className="rv-sub">—</span>}</td>
                    <td><span className={`st-badge ${t.hasAccount ? 'yes' : 'no'}`}>{t.hasAccount ? 'Signed up' : 'Not yet'}</span></td>
                    <td>{t.students}</td>
                    <td>{state ? <span className={`st-badge ${state}`}>{t.done} / {t.students}</span> : <span className="rv-sub">—</span>}</td>
                    <td className="rv-sub">{t.lastReport ? new Date(t.lastReport).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '—'}</td>
                    {canManage && (
                      <td className="whitespace-nowrap text-right">
                        <button type="button" className="tt-act" disabled={!record(t.id)} onClick={() => setEditing(record(t.id))} aria-label={`Edit ${t.name} (${t.id})`} title="Edit">
                          <Pencil className="h-4 w-4" aria-hidden="true" />
                        </button>
                        <button type="button" className="tt-act is-del" onClick={() => removeTeacher(t)} aria-label={`Delete ${t.name} (${t.id})`} title="Delete">
                          <Trash2 className="h-4 w-4" aria-hidden="true" />
                        </button>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
      {editing && canManage && (
        <EditTeacherModal teacher={editing} onClose={() => { setEditing(null); load(); }} onDeleted={() => load()} />
      )}
    </div>
  );
}
