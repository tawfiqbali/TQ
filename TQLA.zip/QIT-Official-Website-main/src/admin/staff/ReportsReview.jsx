import { matchSearch } from '../../lib/search';
import { profileAttr } from '../portal/components/ProfileOpener';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { byTeacherOrder } from '../portal/lib/constants';
import { BookOpenCheck, ChevronDown, ChevronRight, ChevronsDownUp, ChevronsUpDown, RefreshCw, Search, Trash2, X } from 'lucide-react';
import useAdminRole from '../../hooks/useAdminRole';
import { useConfirm } from '../../components/ui/Confirm';
import Combobox from '../portal/components/Combobox';
import { PortalModal } from '../portal/panels/common';
import { MONTHS, deleteMonthlyReport, levelLabel, listReports, listTeacherReports, reportMonth, reviewReport, staffTeacherList } from '../../lib/teacherData';
import './staff.css';
import { useToast } from '../../components/ui/Toast';

const STATUS = { submitted: 'New', needs_changes: 'Needs changes', reviewed: 'Reviewed' };

// Teacher categories, each with its own colour (see staff.css .rr-cat-*)
const CATS = [
  { key: 'res', label: 'Residential', match: (c) => /^residential/i.test(c) },
  { key: 'male', label: 'Non-Residential Male', match: (c) => /non.?residential.*\bmale/i.test(c) && !/female/i.test(c) },
  { key: 'female', label: 'Non-Residential Female', match: (c) => /female/i.test(c) },
  { key: 'other', label: 'Other / category not set', match: () => true },
];
const catKey = (category) => {
  const c = String(category || '').trim();
  return (c && CATS.find((x) => x.key !== 'other' && x.match(c))?.key) || 'other';
};

const years = () => {
  const y = new Date().getFullYear();
  return [y + 1, y, y - 1, y - 2].map((v) => ({ value: String(v), label: String(v) }));
};
const initials = (name) => {
  const w = String(name || '').replace(/\b(mr|mrs|md|hafez|hafeza|sheikh)\.?\s+/gi, '').split(/\s+/).filter(Boolean);
  return ((w[0]?.[0] || '?') + (w.length > 1 ? w[w.length - 1][0] : '')).toUpperCase();
};
const monthRank = (r) => Number(r.year) * 12 + MONTHS.indexOf(r.month);

// One report, with the review buttons
function ReportCard({ r, onReview, onRemove, onUse, isSuper, busy, showTeacher = true, showMonth = false }) {
  const [noteOpen, setNoteOpen] = useState(false);
  const [note, setNote] = useState(r.review_note || '');
  const pct = r.total_classes ? Math.round(((r.present || 0) / r.total_classes) * 100) : null;
  return (
    <article className={`rv-card ${r.review_status}`} aria-label={`Report for ${r.student_name}`}>
      <div className="rv-head">
        <div>
          <div className="rv-name">{showMonth ? `${r.month} ${r.year}` : <span className="p-link" {...profileAttr('student', r.student_id)}>{r.student_name || r.student_id}</span>}</div>
          <div className="rv-sub">
            {showMonth ? `${r.student_name || r.student_id} · ${r.student_id}` : r.student_id}
            {showTeacher ? <> · by <span className="p-link" {...profileAttr('teacher', r.teacher_id)}>{r.teacher_name || r.teacher_id}</span> ({r.teacher_id})</> : ''}
          </div>
        </div>
        <span className={`st-badge ${r.review_status}`}>{STATUS[r.review_status]}</span>
      </div>
      {(r.medium || r.class_start) && <div className="rv-row" data-testid="rv-medium"><b>Class</b><span>{r.medium || '—'}{r.class_start ? ` · started ${r.class_start}${(() => { const d = Number(String(r.class_start).slice(8, 10)); return d <= 3 ? ' (full month)' : ` (${Math.max(0, 30 - d)} days)`; })()}` : ''}</span></div>}
      <div className="rv-row"><b>Attendance</b><span>{r.present ?? '—'} / {r.total_classes ?? '—'} classes{pct != null ? ` · ${pct}%` : ''}{r.absent ? ` · ${r.absent} absent` : ''}</span></div>
      {r.absence_reason && <div className="rv-row"><b>Absence reason</b><span>{r.absence_reason}</span></div>}
      <div className="rv-row">
        <b>Status</b>
        <span>
          {r.status_level && <span className={`level-chip ${r.status_level === 'veryGood' ? 'good' : r.status_level}`} style={{ marginLeft: 0, marginRight: 6 }}>{levelLabel(r.status_level)}</span>}
          {r.status_note}
        </span>
      </div>
      {r.current_lesson && <div className="rv-row"><b>Current lesson</b><span>{r.current_lesson}</span></div>}
      {r.taught && <div className="rv-row"><b>Taught</b><span>{r.taught}</span></div>}
      {r.next_target && <div className="rv-row"><b>Next target</b><span>{r.next_target}</span></div>}
      <div className="rv-row"><b>Remarks</b><span>{r.remarks}</span></div>
      <div className="rv-sub">Submitted {new Date(r.submitted_at).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' })}</div>
      {r.review_note && <div className="rv-note">Note to teacher: {r.review_note}</div>}

      {noteOpen ? (
        <div>
          <label className="rv-sub" htmlFor={`note-${r.id}`}>What should the teacher change?</label>
          <textarea id={`note-${r.id}`} className="m-input mt-1" rows={2} value={note} onChange={(e) => setNote(e.target.value)} autoFocus />
          <div className="rv-actions">
            <button type="button" className="btn-danger" disabled={!note.trim() || busy} onClick={async () => { if (await onReview(r, 'needs_changes', note)) setNoteOpen(false); }}>Send back to teacher</button>
            <button type="button" className="btn-muted" onClick={() => setNoteOpen(false)}>Cancel</button>
          </div>
        </div>
      ) : (
        <div className="rv-actions">
          {r.review_status !== 'reviewed' && <button type="button" className="btn-teal" disabled={busy} onClick={() => onReview(r, 'reviewed')}>✓ Mark reviewed</button>}
          <button type="button" className="btn-add-row" onClick={() => { setNote(r.review_note || ''); setNoteOpen(true); }}>Needs changes…</button>
          {r.review_status === 'reviewed' && <button type="button" className="btn-muted" disabled={busy} onClick={() => onReview(r, 'submitted')}>Reopen</button>}
          {onUse && <button type="button" className="btn-outline-sm" data-testid="make-report" onClick={() => onUse(r)}>Make progress report →</button>}
          {isSuper && (
            <button type="button" className="btn-danger ml-auto inline-flex items-center gap-1" disabled={busy} onClick={() => onRemove(r)}
              aria-label={`Delete report for ${r.student_name || r.student_id}`} title="Delete report">
              <Trash2 className="h-3.5 w-3.5" aria-hidden="true" /> Delete
            </button>
          )}
        </div>
      )}
    </article>
  );
}

const Counts = ({ list }) => {
  const c = { submitted: 0, needs_changes: 0, reviewed: 0 };
  list.forEach((r) => (c[r.review_status] += 1));
  return (
    <span className="rr-counts">
      {c.submitted > 0 && <span className="st-badge submitted">{c.submitted} new</span>}
      {c.needs_changes > 0 && <span className="st-badge needs_changes">{c.needs_changes} to fix</span>}
      {c.reviewed > 0 && <span className="st-badge reviewed">{c.reviewed} reviewed</span>}
    </span>
  );
};

// All of one teacher's student reports, every month, student by student
function StudentReportsModal({ teacher, cat, onClose, actions }) {
  const [rows, setRows] = useState(null);
  const [error, setError] = useState('');
  const [student, setStudent] = useState('');
  const [q, setQ] = useState('');
  useEffect(() => {
    listTeacherReports(teacher.id).then((r) => setRows(r || [])).catch((e) => { setError(e.message); setRows([]); });
  }, [teacher.id]);
  const students = useMemo(() => {
    const m = new Map();
    (rows || []).forEach((r) => {
      if (!m.has(r.student_id)) m.set(r.student_id, { id: r.student_id, name: r.student_name || r.student_id, list: [] });
      m.get(r.student_id).list.push(r);
    });
    return [...m.values()].map((s) => ({ ...s, list: s.list.sort((a, b) => monthRank(b) - monthRank(a)) })).sort((a, b) => a.name.localeCompare(b.name));
  }, [rows]);
  const term = q.trim().toLowerCase();
  const visible = students.filter((s) => !term || matchSearch(`${s.name} ${s.id}`, term));
  const sel = students.find((s) => s.id === student) || visible[0];
  const update = (id, patch) => setRows((list) => (patch ? list.map((x) => (x.id === id ? { ...x, ...patch } : x)) : list.filter((x) => x.id !== id)));

  return (
    <PortalModal onClose={onClose} className={`wide rr-cat-${cat}`} labelledBy="rr-modal-title">
      <div className={`rr-modal-head rr-cat-${cat}`}>
        <span className="rr-avatar">{initials(teacher.name)}</span>
        <div className="min-w-0 flex-1">
          <h3 id="rr-modal-title" className="text-lg font-extrabold">Student Progress Reports</h3>
          <p className="rr-modal-sub"><span className="p-link" {...profileAttr('teacher', teacher.id)}>{teacher.name}</span> · {teacher.id}{teacher.department ? ` · ${teacher.department}` : ''} · {CATS.find((c) => c.key === cat).label}</p>
        </div>
        <button type="button" className="rr-x" onClick={onClose} aria-label="Close"><X className="h-5 w-5" /></button>
      </div>
      {error && <p className="setup-box mb-3 text-sm font-bold" role="alert">{error}</p>}
      {rows === null ? <p className="rv-empty">Loading reports…</p> : !students.length ? <p className="rv-empty">{teacher.name} has not sent any reports yet.</p> : (
        <div className="rr-split">
          <aside className="rr-students" aria-label="Students">
            <div className="relative mb-2">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2" style={{ color: 'var(--text-muted)' }} aria-hidden="true" />
              <input className="m-input" style={{ paddingLeft: 34 }} placeholder="Find a student" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Find a student" />
            </div>
            <ul>
              {visible.map((s) => (
                <li key={s.id}>
                  <button type="button" className={`rr-stu ${sel?.id === s.id ? 'is-on' : ''}`} aria-pressed={sel?.id === s.id} onClick={() => setStudent(s.id)}>
                    <span className="rr-stu-name" {...(sel?.id === s.id ? profileAttr('student', s.id) : {})}>{s.name}</span>
                    <span className="rr-stu-meta">{s.id} · {s.list.length} report{s.list.length === 1 ? '' : 's'} · latest {s.list[0].month.slice(0, 3)} {s.list[0].year}</span>
                    <span className={`st-badge ${s.list[0].review_status}`}>{STATUS[s.list[0].review_status]}</span>
                  </button>
                </li>
              ))}
              {!visible.length && <li className="rv-sub p-2">No student matches.</li>}
            </ul>
          </aside>
          <section className="rr-history" aria-label={sel ? `${sel.name}’s reports` : 'Reports'}>
            {sel && (
              <>
                <div className="rr-history-head">
                  <div>
                    <div className="rv-name"><span className="p-link" {...profileAttr('student', sel.id)}>{sel.name}</span></div>
                    <div className="rv-sub">{sel.id} · {sel.list.length} monthly report{sel.list.length === 1 ? '' : 's'}, newest first</div>
                  </div>
                  <div className="rr-trend" aria-label="Attendance by month">
                    {sel.list.slice(0, 6).reverse().map((r) => {
                      const p = r.total_classes ? Math.round(((r.present || 0) / r.total_classes) * 100) : 0;
                      return <span key={r.id} title={`${r.month} ${r.year}: ${p}%`}><i style={{ height: `${Math.max(8, p)}%` }} /><small>{r.month.slice(0, 3)}</small></span>;
                    })}
                  </div>
                </div>
                <div className="rv-grid">
                  {sel.list.map((r) => (
                    <ReportCard key={`${r.id}-${r.review_status}`} r={r} showTeacher={false} showMonth isSuper={actions.isSuper} busy={actions.busy === r.id}
                      onReview={async (x, st, note) => { const ok = await actions.review(x, st, note); if (ok) update(x.id, { review_status: st, review_note: note || null }); return ok; }}
                      onRemove={async (x) => { if (await actions.remove(x)) update(x.id, null); }}
                      onUse={actions.onUse ? (x) => { onClose(); actions.onUse(x); } : null} />
                  ))}
                </div>
              </>
            )}
          </section>
        </div>
      )}
    </PortalModal>
  );
}

/**
 * Monthly reports sent from the Teacher Dashboard, grouped by teacher
 * category (Residential / Non-Residential Male / Female) in coloured
 * sections. Each teacher row opens that month's reports, and "Student
 * Progress Reports" shows every report of every student of that teacher.
 */
export default function ReportsReview({ onUse }) {
  const toast = useToast();
  const confirm = useConfirm();
  const { isSuper } = useAdminRole();
  const last = reportMonth();
  const [month, setMonth] = useState(last.month);
  const [year, setYear] = useState(String(last.year));
  const [rows, setRows] = useState(null);
  const [dir, setDir] = useState({});
  const [error, setError] = useState('');
  const [filter, setFilter] = useState('all');
  const [cat, setCat] = useState('');
  // v176: ?teacher=QIT-R001 (the Reports button on a teacher's profile) opens that teacher's reports
  const [params] = useSearchParams();
  const wanted = params.get('teacher') || '';
  const [teacher, setTeacher] = useState(wanted);
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState('');
  const [open, setOpen] = useState({});
  const [modal, setModal] = useState(null);

  // Teacher list gives category, department and student count
  useEffect(() => {
    staffTeacherList().then((list) => setDir(Object.fromEntries((list || []).map((t) => [t.id, t])))).catch(() => {});
  }, []);
  useEffect(() => {
    if (!wanted) return;
    setTeacher(wanted);
    const t = dir[wanted];
    if (t) setModal({ id: wanted, name: t.name || wanted, department: t.department || '', category: t.category || '', students: t.students, cat: catKey(t.category) });
  }, [wanted, dir]);

  const load = useCallback(async () => {
    setError('');
    setRows(null);
    try {
      setRows(await listReports({ month, year }));
    } catch (e) {
      setError(e.message);
      setRows([]);
    }
  }, [month, year]);
  useEffect(() => {
    load();
  }, [load]);

  const info = useCallback((r) => {
    const t = dir[r.teacher_id] || {};
    return { id: r.teacher_id, name: t.name || r.teacher_name || r.teacher_id, department: t.department || '', category: t.category || '', students: t.students, cat: catKey(t.category) };
  }, [dir]);

  const term = q.trim().toLowerCase();
  const base = useMemo(() => (rows || []).filter((r) => (!cat || info(r).cat === cat) && (!teacher || r.teacher_id === teacher)
    && (!term || matchSearch([r.student_name, r.student_id, r.teacher_name, r.teacher_id, info(r).name].join(' '), term))), [rows, cat, teacher, term, info]);
  const counts = useMemo(() => {
    const c = { all: base.length, submitted: 0, needs_changes: 0, reviewed: 0 };
    base.forEach((r) => (c[r.review_status] += 1));
    return c;
  }, [base]);
  const shown = base.filter((r) => filter === 'all' || r.review_status === filter);

  // category -> teacher -> reports
  const groups = useMemo(() => CATS.map((c) => {
    const m = new Map();
    shown.filter((r) => info(r).cat === c.key).forEach((r) => {
      const t = info(r);
      if (!m.has(t.id)) m.set(t.id, { ...t, list: [] });
      m.get(t.id).list.push(r);
    });
    const teachers = [...m.values()].map((t) => ({ ...t, list: t.list.sort((a, b) => String(a.student_name).localeCompare(String(b.student_name))) }))
      .sort(byTeacherOrder);
    return { ...c, teachers, total: teachers.reduce((n, t) => n + t.list.length, 0) };
  }).filter((g) => g.teachers.length), [shown, info]);

  const catCounts = useMemo(() => {
    const c = {};
    (rows || []).forEach((r) => { const k = info(r).cat; c[k] = (c[k] || 0) + 1; });
    return c;
  }, [rows, info]);
  const teacherOpts = useMemo(() => {
    const m = new Map();
    (rows || []).filter((r) => !cat || info(r).cat === cat).forEach((r) => m.set(r.teacher_id, info(r).name));
    return [{ value: '', label: 'All teachers' }, ...[...m].sort(([a], [b]) => byTeacherOrder(a, b)).map(([value, name]) => ({ value, label: `${name} (${value})` }))];
  }, [rows, cat, info]);

  const review = async (r, status, text = '') => {
    setBusy(r.id);
    try {
      await reviewReport(r.id, status, text);
      setRows((list) => (list || []).map((x) => (x.id === r.id ? { ...x, review_status: status, review_note: text || null, reviewed_at: new Date().toISOString() } : x)));
      toast(status === 'reviewed' ? 'Marked as reviewed.' : status === 'needs_changes' ? 'Sent back to the teacher.' : 'Report reopened.');
      return true;
    } catch (e) {
      toast(e.message, 'error');
      return false;
    } finally {
      setBusy('');
    }
  };
  // Executives only: remove a report (e.g. a test, a duplicate, the wrong student)
  const remove = async (r) => {
    const ok = await confirm({
      title: 'Delete this report?',
      message: `${r.student_name || r.student_id}’s ${r.month} ${r.year} report by ${r.teacher_name || r.teacher_id} is deleted for good. Its points are removed, and the teacher can send the report again.`,
      confirmText: 'Delete report',
      tone: 'danger',
    });
    if (!ok) return false;
    setBusy(r.id);
    try {
      await deleteMonthlyReport(r.id);
      setRows((list) => (list || []).filter((x) => x.id !== r.id));
      toast('Report deleted.');
      return true;
    } catch (e) {
      toast(e.message, 'error');
      return false;
    } finally {
      setBusy('');
    }
  };
  const actions = { review, remove, isSuper, busy, onUse };

  // Searching or picking one teacher opens the rows automatically
  const autoOpen = Boolean(term || teacher);
  const isOpen = (id) => (open[id] ?? autoOpen);
  const allIds = groups.flatMap((g) => g.teachers.map((t) => t.id));
  const setAll = (v) => setOpen(Object.fromEntries(allIds.map((id) => [id, v])));

  return (
    <div className="box-card">
      <div className="card-header-bar">
        <h2 className="card-title">Teachers’ monthly reports</h2>
        <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={load}>
          <RefreshCw className="h-3.5 w-3.5" /> Refresh
        </button>
      </div>

      <div className="rv-toolbar">
        <div>
          <label htmlFor="rv-month">Month</label>
          <Combobox id="rv-month" value={month} onChange={setMonth} options={MONTHS.map((m) => ({ value: m, label: m }))} aria-label="Report month" />
        </div>
        <div style={{ minWidth: 110 }}>
          <label>Year</label>
          <Combobox value={year} onChange={setYear} options={years()} aria-label="Report year" />
        </div>
        <div style={{ minWidth: 230 }}>
          <label>Teacher</label>
          <Combobox value={teacher} onChange={setTeacher} options={teacherOpts} aria-label="Filter by teacher" />
        </div>
        <div className="flex-1" style={{ minWidth: 200 }}>
          <label htmlFor="rv-search">Search</label>
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2" style={{ color: 'var(--text-muted)' }} aria-hidden="true" />
            <input id="rv-search" className="m-input" style={{ paddingLeft: 34 }} placeholder="Student or teacher name / ID" value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
        </div>
      </div>

      <div className="rr-catbar" role="group" aria-label="Teacher category">
        <button type="button" className="rr-catbtn" aria-pressed={!cat} onClick={() => { setCat(''); setTeacher(''); }}>All categories · {(rows || []).length}</button>
        {CATS.map((c) => (catCounts[c.key] || c.key !== 'other') && (
          <button key={c.key} type="button" className={`rr-catbtn rr-cat-${c.key}`} aria-pressed={cat === c.key} onClick={() => { setCat(cat === c.key ? '' : c.key); setTeacher(''); }}>
            <i aria-hidden="true" />{c.label} · {catCounts[c.key] || 0}
          </button>
        ))}
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="rv-counts" role="group" aria-label="Filter by review status">
          {[['all', 'All'], ['submitted', STATUS.submitted], ['needs_changes', STATUS.needs_changes], ['reviewed', STATUS.reviewed]].map(([k, label]) => (
            <button key={k} type="button" className="rv-count" aria-pressed={filter === k} onClick={() => setFilter(k)}>{label} · {counts[k]}</button>
          ))}
        </div>
        {groups.length > 0 && (
          <div className="mb-3 flex gap-2">
            <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={() => setAll(true)}><ChevronsUpDown className="h-3.5 w-3.5" /> Open all</button>
            <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={() => setAll(false)}><ChevronsDownUp className="h-3.5 w-3.5" /> Close all</button>
          </div>
        )}
      </div>

      {error && <p className="setup-box mb-4 text-sm font-bold" role="alert">{error}</p>}
      {rows === null && <p className="rv-empty">Loading reports…</p>}
      {rows && !groups.length && !error && (
        <p className="rv-empty">No reports for {month} {year}{filter !== 'all' ? ` with status “${STATUS[filter]}”` : ''}{cat ? ` in ${CATS.find((c) => c.key === cat).label}` : ''} yet.</p>
      )}

      {groups.map((g) => (
        <section key={g.key} className={`rr-cat rr-cat-${g.key}`} aria-label={g.label}>
          <header className="rr-cat-head">
            <h3>{g.label}</h3>
            <span>{g.teachers.length} teacher{g.teachers.length === 1 ? '' : 's'} · {g.total} report{g.total === 1 ? '' : 's'}</span>
          </header>
          <div className="rr-teachers">
            {g.teachers.map((t) => {
              const o = isOpen(t.id);
              return (
                <div key={t.id} className={`rr-teacher ${o ? 'is-open' : ''}`}>
                  {/* v161: the name or the box opens the reports; the name, once open, opens the teacher's profile */}
                  <div className="rr-trow" onClick={(e) => { if (!o && !e.target.closest('button, a, [data-profile]')) setOpen((x) => ({ ...x, [t.id]: true })); }}>
                    <button type="button" className="rr-toggle" onClick={() => setOpen((x) => ({ ...x, [t.id]: !o }))} aria-expanded={o}>
                      {o ? <ChevronDown className="h-4 w-4" aria-hidden="true" /> : <ChevronRight className="h-4 w-4" aria-hidden="true" />}
                      <span className="rr-avatar">{initials(t.name)}</span>
                      <span className="min-w-0 text-left">
                        <span className="rr-tname" data-testid={`rr-tname-${t.id}`} {...(o ? profileAttr('teacher', t.id) : {})}>{t.name}</span>
                        <span className="rr-tmeta">
                          <span className="rr-id">{t.id}</span>
                          {t.department && <span className="rr-dept">{t.department}</span>}
                          <span>{t.list.length}{t.students ? ` of ${t.students}` : ''} student report{t.list.length === 1 ? '' : 's'} · {month} {year}</span>
                        </span>
                      </span>
                    </button>
                    <Counts list={t.list} />
                    <button type="button" className="rr-spr" onClick={() => setModal(t)}>
                      <BookOpenCheck className="h-4 w-4" aria-hidden="true" /> Student Progress Reports
                    </button>
                  </div>
                  {o && (
                    <div className="rv-grid rr-body">
                      {t.list.map((r) => (
                        <ReportCard key={`${r.id}-${r.review_status}`} r={r} showTeacher={false} isSuper={isSuper} busy={busy === r.id} onReview={review} onRemove={remove} onUse={onUse} />
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>
      ))}

      {modal && <StudentReportsModal teacher={modal} cat={modal.cat} onClose={() => { setModal(null); load(); }} actions={actions} />}
    </div>
  );
}

/**
 * v179: one teacher's reports in a pop-up, right where you are (Salary Directory
 * or Teacher List profile) — every student, every month — with Mark reviewed /
 * Needs changes / Delete, without leaving the page.
 */
export function TeacherReportsModal({ teacher, onClose }) {
  const toast = useToast();
  const confirm = useConfirm();
  const { isSuper } = useAdminRole();
  const [busy, setBusy] = useState('');
  const review = async (r, status, text = '') => {
    setBusy(r.id);
    try {
      await reviewReport(r.id, status, text);
      toast(status === 'reviewed' ? 'Marked as reviewed.' : status === 'needs_changes' ? 'Sent back to the teacher.' : 'Report reopened.');
      return true;
    } catch (e) { toast(e.message, 'error'); return false; } finally { setBusy(''); }
  };
  const remove = async (r) => {
    if (!(await confirm({ title: 'Delete this report?', message: `${r.student_name || r.student_id}’s ${r.month} ${r.year} report is deleted for good. The teacher can send it again.`, confirmText: 'Delete report', tone: 'danger' }))) return false;
    setBusy(r.id);
    try { await deleteMonthlyReport(r.id); toast('Report deleted.'); return true; } catch (e) { toast(e.message, 'error'); return false; } finally { setBusy(''); }
  };
  const t = { id: teacher.id, name: teacher.name || teacher.id, department: teacher.department || '', category: teacher.category || '', cat: catKey(teacher.category) };
  return <StudentReportsModal teacher={t} cat={t.cat} onClose={onClose} actions={{ review, remove, isSuper, busy, onUse: null }} />;
}
