import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { ClipboardCheck, FileText, Users } from 'lucide-react';
import useAdminRole from '../../hooks/useAdminRole';
import TeacherTracker from './TeacherTracker';
import ReportsReview from './ReportsReview';
import ProgressReports from '../portal/panels/ProgressReports';
import ProfileOpener from '../portal/components/ProfileOpener';
import { PortalProvider, usePortal } from '../portal/PortalContext';
import '../portal/portal.css';
import './staff.css';

const TABS = [
  { key: 'reports', label: 'Teacher Reports', Icon: ClipboardCheck },
  { key: 'progress', label: 'Progress Reports', Icon: FileText },
  { key: 'teachers', label: 'Teacher List', Icon: Users },
];

// The Progress Report engine needs the portal records first
function ProgressGate({ incoming, onDone }) {
  const { status, error, load } = usePortal();
  if (status === 'ready') return <ProgressReports incoming={incoming} onIncomingDone={onDone} />;
  if (status === 'error') return <div className="box-card text-center"><p className="font-bold text-red-700">{error || 'Could not load the records.'}</p><button type="button" className="btn-teal mt-3" onClick={() => load()}>Try again</button></div>;
  if (status === 'locked') return <div className="box-card text-center">Open the Management Portal once to unlock the records, then come back.</div>;
  return <div className="box-card text-center">Loading records…</div>;
}

/**
 * Teachers & Reports (left menu): the teachers' monthly reports, the
 * Progress Report engine and the teacher list. Junior Admins and Executives.
 */
export default function StaffReview() {
  const { email, isSuper } = useAdminRole();
  const [params, setParams] = useSearchParams();
  const want = params.get('tab');
  const [tab, setTabState] = useState(TABS.some((t) => t.key === want) ? want : 'reports');
  const [incoming, setIncoming] = useState(() => {
    try {
      const saved = sessionStorage.getItem('qit:incoming-report');
      sessionStorage.removeItem('qit:incoming-report');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  useEffect(() => { if (want && want !== tab && TABS.some((t) => t.key === want)) setTabState(want); }, [want]); // eslint-disable-line react-hooks/exhaustive-deps
  const setTab = (k) => { setTabState(k); setParams({ tab: k }, { replace: true }); };
  // "Make progress report": the teacher's report opens in the Progress Report engine here
  const useReport = (r) => { setIncoming(r); setTab('progress'); };
  return (
    <PortalProvider>
      <div className="qit-portal">
        <header className="p-header">
          <div className="flex items-center gap-4">
            <div className="logo-badge">QIT</div>
            <div>
              <h1 className="text-xl font-extrabold sm:text-2xl" style={{ color: 'var(--c-teal-dark)' }}>Teachers &amp; Reports</h1>
              <p className="text-sm" style={{ color: 'var(--text-muted)' }}>Signed in as {email}</p>
            </div>
          </div>
          <span className="id-tag" style={{ background: isSuper ? 'var(--qit-teal)' : 'var(--qit-gold)' }}>{isSuper ? 'Super Admin / Executive' : 'Junior Admin'}</span>
        </header>
        <nav className="main-nav" aria-label="Teachers and reports" data-testid="review-tabs">
          {TABS.map(({ key, label, Icon }) => (
            <button key={key} type="button" className={`nav-btn ${tab === key ? 'active' : ''}`} aria-current={tab === key ? 'page' : undefined} onClick={() => setTab(key)} data-testid={`review-tab-${key}`}>
              <Icon className="h-4 w-4" aria-hidden="true" /> {label}
            </button>
          ))}
        </nav>
        {tab === 'reports' && <ReportsReview onUse={useReport} />}
        {tab === 'progress' && <ProgressGate incoming={incoming} onDone={() => setIncoming(null)} />}
        {tab === 'teachers' && <TeacherTracker />}
      </div>
      <ProfileOpener />
    </PortalProvider>
  );
}
