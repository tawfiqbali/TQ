import { useEffect, useMemo, useState } from 'react';
import { ExternalLink, RotateCcw, Save, Search } from 'lucide-react';
import AdminPageHeader from './components/AdminPageHeader';
import { useSiteData } from '../context/SiteDataContext';
import { useToast } from '../components/ui/Toast';
import en from '../i18n/locales/en.json';
import { banglaBase, contentPathGet, loadLanguage, localizeContent } from '../i18n/LanguageContext';

/**
 * v160: Website → Bangla text. Every Bangla word of the public website can be
 * changed here:
 *  - Website content: courses, teachers, reviews, board, FAQ, hero, footer…
 *    (also items added later in the admin panel)
 *  - Interface text: menus, buttons, form labels, messages
 * Changes are saved with the site content and show at once for visitors who
 * chose বাংলা. "Original" brings back the built-in translation.
 */
const SKIP_KEYS = /^(id|slug|photoUrl|image|imageUrl|img|url|href|link|email|whatsapp|phone|icon|color|tier|videoId|vimeoId|price|amount|currency|order|rating|bnText|bnContent|_note|logo|src|poster|map|embed)$/i;
const looksText = (v) => typeof v === 'string' && /[A-Za-zঀ-৿]/.test(v) && !/^(https?:|\/|mailto:|tel:)/.test(v.trim()) && v.trim().length > 1;
const SECTION_LABEL = { site: 'Home & site text', courses: 'Courses', instructors: 'Teachers', testimonials: 'Reviews', board: 'Board', faqs: 'FAQ' };

function flattenContent(content) {
  const out = [];
  const walk = (v, path) => {
    if (Array.isArray(v)) v.forEach((x, i) => walk(x, [...path, x && typeof x === 'object' && x.id != null ? `#${x.id}` : i]));
    else if (v && typeof v === 'object') Object.entries(v).forEach(([k, x]) => !SKIP_KEYS.test(k) && walk(x, [...path, k]));
    else if (looksText(v)) out.push({ path, en: v });
  };
  Object.entries(content || {}).forEach(([k, v]) => SECTION_LABEL[k] && walk(v, [k]));
  return out;
}
function flattenDict(d, enDict) {
  const out = [];
  const walk = (v, path) => {
    if (v && typeof v === 'object' && !Array.isArray(v)) Object.entries(v).forEach(([k, x]) => !k.startsWith('_') && walk(x, [...path, k]));
    else if (Array.isArray(v)) v.forEach((x, i) => walk(x, [...path, i]));
    else if (typeof v === 'string') {
      const enText = path[0] === 'phrases' ? path[1] : contentPathGet(enDict, path);
      out.push({ path, bn: v, en: typeof enText === 'string' ? enText : '' });
    }
  };
  Object.entries(d || {}).forEach(([k, v]) => k !== 'content' && walk(v, [k]));
  return out;
}
const label = (path) => path.filter((p) => typeof p === 'string').map((p) => (p.startsWith('#') ? p.slice(1) : p)).join(' › ');
const PAGE = 40;

export default function BanglaEditor() {
  const { content, updateSite } = useSiteData();
  const toast = useToast();
  const [tab, setTab] = useState('content');
  const [base, setBase] = useState(banglaBase());
  const [q, setQ] = useState('');
  const [section, setSection] = useState('');
  const [limit, setLimit] = useState(PAGE);
  const [draft, setDraft] = useState({});
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (!base) loadLanguage('bn').then(() => setBase(banglaBase())); }, [base]);
  useEffect(() => { setLimit(PAGE); }, [tab, q, section]);

  const savedContent = content?.site?.bnContent || {};
  const savedText = content?.site?.bnText || {};

  // Website content: English now, the Bangla shown now (built-in or edited)
  const contentRows = useMemo(() => {
    if (!base) return [];
    const plainContent = { ...content, site: { ...content.site, bnContent: undefined } };
    const bnNow = localizeContent(plainContent, 'bn');
    return flattenContent(content).map((r) => {
      const key = JSON.stringify(r.path);
      const builtIn = contentPathGet(bnNow, r.path);
      return { key, path: r.path, en: r.en, original: typeof builtIn === 'string' && builtIn !== r.en ? builtIn : '', saved: savedContent[key] };
    });
  }, [content, base]); // eslint-disable-line react-hooks/exhaustive-deps
  const textRows = useMemo(() => (base ? flattenDict(base, en).map((r) => {
    const key = JSON.stringify(r.path);
    return { key, path: r.path, en: r.en, original: r.bn, saved: savedText[key] };
  }) : []), [base, savedText]);

  const rows = tab === 'content' ? contentRows : textRows;
  const sections = useMemo(() => [...new Set(rows.map((r) => String(r.path[0])))], [rows]);
  const term = q.trim().toLowerCase();
  const shown = rows.filter((r) => (!section || String(r.path[0]) === section)
    && (!term || `${r.en} ${r.original} ${r.saved || ''} ${label(r.path)}`.toLowerCase().includes(term)));
  const current = (r) => (draft[r.key] !== undefined ? draft[r.key] : r.saved !== undefined ? r.saved : r.original);
  const changed = Object.keys(draft).length;
  const missing = tab === 'content' ? contentRows.filter((r) => !r.original && !r.saved).length : 0;

  const save = async () => {
    setBusy(true);
    try {
      const store = tab === 'content' ? { ...savedContent } : { ...savedText };
      const list = tab === 'content' ? contentRows : textRows;
      Object.entries(draft).forEach(([k, v]) => {
        const r = list.find((x) => x.key === k);
        if (!r) return;
        if (!v.trim() || v === r.original) delete store[k];
        else store[k] = v;
      });
      await updateSite(tab === 'content' ? 'bnContent' : 'bnText', store);
      setDraft({});
      toast('Bangla text saved. Visitors who chose বাংলা see it now.');
    } catch (e) {
      toast(e.message || 'Could not save.', 'error');
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <AdminPageHeader
        title="Bangla text"
        description="Every Bangla word on the website: change it here. English stays as it is."
        actions={<a href="/" target="_blank" rel="noreferrer" className="btn-outline"><ExternalLink className="h-4 w-4" /> View website</a>}
      />
      <div className="bn-ed" data-testid="bangla-editor">
        <div className="bn-ed-bar">
          <div className="bn-ed-tabs" role="tablist">
            {[['content', `Website content (${contentRows.length})`], ['text', `Menus, buttons & messages (${textRows.length})`]].map(([k, l]) => (
              <button key={k} type="button" role="tab" aria-selected={tab === k} className={tab === k ? 'on' : ''} onClick={() => { if (changed && !window.confirm('Leave without saving your changes?')) return; setDraft({}); setTab(k); setSection(''); }}>{l}</button>
            ))}
          </div>
          <label className="bn-ed-search"><Search className="h-4 w-4" aria-hidden="true" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search English or Bangla…" aria-label="Search text" /></label>
          <select value={section} onChange={(e) => setSection(e.target.value)} aria-label="Section">
            <option value="">All sections</option>
            {sections.map((s) => <option key={s} value={s}>{SECTION_LABEL[s] || s}</option>)}
          </select>
        </div>
        {tab === 'content' && missing > 0 && <p className="bn-ed-note">{missing} text(s) have no Bangla yet (shown in English to Bangla visitors) — they are marked “No Bangla yet”.</p>}
        {!base ? <p className="bn-ed-note">Loading…</p> : (
          <ul className="bn-ed-list">
            {shown.slice(0, limit).map((r) => {
              const v = current(r);
              const edited = draft[r.key] !== undefined || r.saved !== undefined;
              return (
                <li key={r.key} className={edited ? 'is-edited' : !r.original && !r.saved ? 'is-missing' : ''}>
                  <div className="bn-ed-meta"><span>{label(r.path)}</span>{!r.original && !r.saved && <b>No Bangla yet</b>}{r.saved !== undefined && draft[r.key] === undefined && <b className="ok">Edited</b>}</div>
                  {r.en && <p className="bn-ed-en" lang="en">{r.en}</p>}
                  <textarea lang="bn" rows={Math.min(6, Math.max(1, Math.ceil(((v || r.en).length || 1) / 70)))} value={v} placeholder={r.en} onChange={(e) => setDraft((d) => ({ ...d, [r.key]: e.target.value }))} aria-label={`Bangla for ${label(r.path)}`} />
                  {(r.saved !== undefined || draft[r.key] !== undefined) && (
                    <button type="button" className="bn-ed-reset" onClick={() => setDraft((d) => ({ ...d, [r.key]: r.original }))}><RotateCcw className="h-3.5 w-3.5" /> Original</button>
                  )}
                </li>
              );
            })}
            {!shown.length && <li className="bn-ed-note">Nothing matches.</li>}
          </ul>
        )}
        {shown.length > limit && <button type="button" className="btn-outline mt-3" onClick={() => setLimit((l) => l + PAGE)}>Show more ({shown.length - limit} left)</button>}
        <div className={`bn-ed-save ${changed ? 'show' : ''}`}>
          <span>{changed} change{changed === 1 ? '' : 's'} not saved</span>
          <button type="button" className="btn-ghost" onClick={() => setDraft({})} disabled={busy}>Discard</button>
          <button type="button" className="btn-primary" onClick={save} disabled={busy || !changed} data-testid="bn-save"><Save className="h-4 w-4" /> {busy ? 'Saving…' : 'Save'}</button>
        </div>
      </div>
    </>
  );
}
