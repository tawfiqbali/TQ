// Colour themes of the Executive admin panel (remembered on this device)
export const ADMIN_THEMES = [
  {
    "key": "teal",
    "label": "QIT Teal",
    "swatch": [
      "#002B29",
      "#05535B",
      "#1F7F80",
      "#C8943F",
      "#475569"
    ]
  },
  {
    "key": "sundown",
    "label": "Sundown Spark",
    "swatch": [
      "#A23438",
      "#BB5E61",
      "#D99C97",
      "#F3C9AF",
      "#FBE3D0"
    ]
  },
  {
    "key": "coastal",
    "label": "Coastal Retreat",
    "swatch": [
      "#335765",
      "#74A8A4",
      "#B6D9E0",
      "#DBE2DC",
      "#7F543D"
    ]
  },
  {
    "key": "hues",
    "label": "Hues",
    "swatch": [
      "#FCFAEE",
      "#035A52",
      "#D8E267",
      "#BDF806"
    ]
  },
  {
    "key": "midnight",
    "label": "Midnight Slate",
    "swatch": [
      "#1A2D42",
      "#2E4156",
      "#AAB7B7",
      "#C0C8CA",
      "#D4D8DD"
    ]
  },
  {
    "key": "evergreen",
    "label": "Evergreen",
    "swatch": [
      "#0F2A1D",
      "#375534",
      "#6B9071",
      "#AEC3B0",
      "#E3EED4"
    ]
  },
  {
    "key": "caramel",
    "label": "Caramel",
    "swatch": [
      "#3E2522",
      "#8C6E63",
      "#D3A376",
      "#FFE0B2",
      "#FFF2DF"
    ]
  },
  {
    "key": "cocoa",
    "label": "Cocoa",
    "swatch": [
      "#291C0E",
      "#6E473B",
      "#A78D78",
      "#BEB5A9",
      "#E1D4C2"
    ]
  },
  {
    "key": "juniper",
    "label": "Juniper & Coral",
    "swatch": [
      "#343723",
      "#7D2826",
      "#898861",
      "#EFE9D7"
    ]
  },
  {
    "key": "apricot",
    "label": "Apricot & Organic",
    "swatch": [
      "#3F422E",
      "#D78B30",
      "#9F886F",
      "#F5E6C5"
    ]
  },
  {
    "key": "tangerine",
    "label": "Electric Tangerine",
    "swatch": [
      "#222222",
      "#FF6D1F",
      "#F5E7C6",
      "#FAF3E1"
    ]
  },
  {
    "key": "emerald",
    "label": "Dark Emerald",
    "swatch": [
      "#0D4C3C",
      "#2D5A4A",
      "#7AA05A",
      "#F4F1EB"
    ]
  },
  {
    "key": "harbor",
    "label": "Navy & Orange",
    "swatch": [
      "#092634",
      "#004E72",
      "#FF6E42",
      "#F9F9F9"
    ]
  }
];
const KEY = 'qit:admin-theme';
export const getAdminTheme = () => { try { return localStorage.getItem(KEY) || 'teal'; } catch { return 'teal'; } };
export function applyAdminTheme(key) {
  const k = ADMIN_THEMES.some((t) => t.key === key) ? key : 'teal';
  if (k === 'teal') delete document.documentElement.dataset.adminTheme; else document.documentElement.dataset.adminTheme = k;
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', ADMIN_THEMES.find((t) => t.key === k).swatch[0]);
}
export function setAdminTheme(key) { try { localStorage.setItem(KEY, key); } catch { /* not remembered */ } applyAdminTheme(key); }
export const clearAdminTheme = () => applyAdminTheme('teal');
