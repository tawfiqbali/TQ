import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Link } from 'react-router-dom';
import { Copy, Database, Send, Sparkles, Trash2, X } from 'lucide-react';
import { QIT_CONTEXT, askAI } from '../lib/ai';
import { loadPortalData } from './portal/lib/api';
import { listReports } from '../lib/teacherData';

const IDEAS = ['Find the student with number 017…', 'Which students are on Hold, with their teachers?', 'List the teachers who have no active students', 'Who has not sent the monthly report for last month?', 'Write a polite WhatsApp reminder to a parent whose fee is late, in Bangla and English'];
const pick = (o, keys) => Object.fromEntries(keys.filter((k) => o[k] !== undefined && o[k] !== null && o[k] !== '' && o[k] !== 'N/A').map((k) => [k, o[k]]));

// The office records the signed-in person may already see, in a compact form.
// Junior Admins never receive fees, salaries, payments or bank details from the
// database, so those are not here for them either.
async function loadRecords() {
  const [db, monthly] = await Promise.all([loadPortalData(), listReports().catch(() => [])]);
  // No real salary figures arrived (a Junior Admin): leave the money fields out
  // altogether, so the assistant says "not visible" instead of reading zeros.
  const money = (db.payments || []).length > 0 || (db.students || []).some((x) => Number(x.cut) > 0) || (db.teachers || []).some((x) => Number(x.packageAmount) > 0);
  const tKeys = ['id', 'name', 'category', 'department', 'whatsapp', 'email', 'status', ...(money ? ['salaryType', 'packageAmount', 'method'] : [])];
  const sKeys = ['id', 'name', 'phone', 'teacherId', 'status', 'classTime', 'scheduleType', 'course', 'country', 'fee', ...(money ? ['cut'] : []), 'since', 'statusChangedAt'];
  // v160: compact tables (column names once, then rows) — about half the size,
  // so the assistant answers faster
  const table = (list, keys) => ({ cols: keys, rows: list.map((x) => keys.map((k) => (x[k] === undefined || x[k] === '' ? null : x[k]))) });
  const tK = tKeys;
  const sK = sKeys.filter((k) => !['since', 'statusChangedAt'].includes(k));
  return {
    today: new Date().toISOString().slice(0, 10),
    teachers: table(db.teachers || [], tK),
    students: table(db.students || [], sK),
    salaryPayments: table(db.payments || [], ['teacherId', 'month', 'year', 'amount', 'date']),
    progressReports: table((db.reports || []).slice(0, 300), ['studentId', 'teacherId', 'month', 'year']),
    teacherMonthlyReports: table((monthly || []).slice(0, 400), ['student_id', 'teacher_id', 'month', 'year', 'review_status']),
  };
}
const SYSTEM = (records) => `${QIT_CONTEXT}

You can now SEE the office records below (JSON tables: "cols" names the columns, each row lists the values in that order), loaded live from the QIT database for the person asking. Use them to find students, teachers, reports and payments and to answer questions about them.
- Answer only from these records. If something is not in them, say it was not found; never guess.
- When you show a person, give the ID, name, WhatsApp number, teacher (name and ID for a student), status and class time when present. For several results use a short list.
- Match names loosely (spelling varies, বাংলা or English) and phone numbers by their digits, ignoring spaces, dashes and country code.
- "Left to pay" for a teacher in a month = the salary minus salaryPayments for that month; a per-student teacher's salary is the sum of "cut" of their Active students.
- If salary, fee or payment fields are missing, this person may not see money: say so instead of estimating.
- You still cannot change any record; say where in the Management Portal it is done.

RECORDS:
${JSON.stringify(records)}`;

// QIT-R001 style Teacher IDs in an answer open that teacher's dashboard
function withLinks(text) {
  return String(text).split(/(QIT-[RMF]\d{3,})/g).map((part, i) => (/^QIT-[RMF]\d{3,}$/.test(part) ? <Link key={i} to={`/admin/teachers/${part}`} className="ai-link">{part}</Link> : part));
}

// AI assistant for the admin panel: finds records and writes by instruction
export default function AiAssistant({ className = '', label }) {
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState([]);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [info, setInfo] = useState(null);
  const records = useRef({ at: 0, data: null });
  const end = useRef(null);
  useEffect(() => { end.current?.scrollIntoView({ block: 'end' }); }, [msgs, busy]);
  const getRecords = async (force = false) => {
    if (!force && records.current.data && Date.now() - records.current.at < 120000) return records.current.data;
    const data = await loadRecords();
    records.current = { at: Date.now(), data };
    setInfo({ students: data.students.rows.length, teachers: data.teachers.rows.length });
    return data;
  };
  useEffect(() => {
    if (!open) return undefined;
    getRecords().catch(() => setInfo(null));
    const esc = (e) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('keydown', esc);
    return () => document.removeEventListener('keydown', esc);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const send = async (q = text) => {
    const ask = q.trim();
    if (!ask || busy) return;
    const next = [...msgs, { role: 'user', text: ask }];
    setMsgs(next); setText(''); setError(''); setBusy(true);
    try {
      const data = await getRecords().catch(() => null);
      const answer = await askAI({ system: data ? SYSTEM(data) : QIT_CONTEXT, messages: next });
      setMsgs([...next, { role: 'assistant', text: answer }]);
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };
  const copy = (t) => navigator.clipboard?.writeText(t).catch(() => {});

  return (
    <>
      <button type="button" className={className} onClick={() => setOpen(true)} title="AI assistant" data-testid="ai-open"><Sparkles className="h-4 w-4" aria-hidden="true" />{label}</button>
      {/* drawn on the page itself, above everything (never inside the side menu) */}
      {open && createPortal(
        <div className="ai-wrap" onMouseDown={(e) => e.target === e.currentTarget && setOpen(false)}>
          <section className="ai-panel" role="dialog" aria-label="AI assistant" data-testid="ai-panel">
            <header className="ai-head">
              <span className="inline-flex items-center gap-2 font-extrabold"><Sparkles className="h-4 w-4" aria-hidden="true" /> AI assistant <small>Gemini</small></span>
              <span className="inline-flex gap-1">
                {msgs.length > 0 && <button type="button" className="ai-ico" onClick={() => { setMsgs([]); setError(''); }} title="Clear the chat" aria-label="Clear the chat"><Trash2 className="h-4 w-4" /></button>}
                <button type="button" className="ai-ico" onClick={() => setOpen(false)} aria-label="Close"><X className="h-4 w-4" /></button>
              </span>
            </header>
            <p className="ai-info" data-testid="ai-info"><Database className="h-3.5 w-3.5" aria-hidden="true" /> {info ? `Sees ${info.students} students and ${info.teachers} teachers, with reports` : 'Loading the records…'}</p>
            <div className="ai-body">
              {msgs.length === 0 && (
                <div className="ai-empty">
                  <p>Ask it to find any student, teacher or report, or to write something, in বাংলা or English. It reads the records; it cannot change them.</p>
                  {IDEAS.map((i) => <button key={i} type="button" className="ai-idea" onClick={() => (i.endsWith('…') ? setText(i.replace('…', '')) : send(i))}>{i}</button>)}
                </div>
              )}
              {msgs.map((m, n) => (
                <div key={n} className={`ai-msg ${m.role}`}>
                  <div className="ai-bubble">{m.role === 'assistant' ? withLinks(m.text) : m.text}</div>
                  {m.role === 'assistant' && <button type="button" className="ai-copy" onClick={() => copy(m.text)}><Copy className="h-3 w-3" /> Copy</button>}
                </div>
              ))}
              {busy && <div className="ai-msg assistant"><div className="ai-bubble ai-typing"><span /><span /><span /></div></div>}
              {error && <p role="alert" className="ai-error" data-testid="ai-error">{error}</p>}
              <div ref={end} />
            </div>
            <form className="ai-form" onSubmit={(e) => { e.preventDefault(); send(); }}>
              <textarea rows={2} value={text} onChange={(e) => setText(e.target.value)} placeholder="Find a student, teacher or report, or say what to write…" aria-label="Your question or instruction"
                onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }} data-testid="ai-input" />
              <button type="submit" disabled={busy || !text.trim()} aria-label="Send"><Send className="h-4 w-4" /></button>
            </form>
          </section>
        </div>,
        document.body,
      )}
    </>
  );
}
