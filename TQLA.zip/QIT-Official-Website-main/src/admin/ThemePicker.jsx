import { useEffect, useRef, useState } from 'react';
import { Check, Palette } from 'lucide-react';
import { ADMIN_THEMES, getAdminTheme, setAdminTheme } from './themes';

// Colour theme of the Executive admin panel (remembered on this device)
export default function ThemePicker({ className = '', label = 'Theme', up = false }) {
  const [open, setOpen] = useState(false);
  const [cur, setCur] = useState(getAdminTheme);
  const box = useRef(null);
  useEffect(() => {
    if (!open) return undefined;
    const close = (e) => { if (!box.current?.contains(e.target)) setOpen(false); };
    const esc = (e) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('mousedown', close);
    document.addEventListener('keydown', esc);
    const sync = () => setCur(getAdminTheme());
    window.addEventListener('qit-admin-theme', sync);
    return () => { document.removeEventListener('mousedown', close); document.removeEventListener('keydown', esc); window.removeEventListener('qit-admin-theme', sync); };
  }, [open]);
  const pick = (k) => { setAdminTheme(k); setCur(k); window.dispatchEvent(new Event('qit-admin-theme')); };
  return (
    <span ref={box} className="theme-picker" data-testid="theme-picker">
      <button type="button" className={className} onClick={() => { setCur(getAdminTheme()); setOpen((o) => !o); }} aria-expanded={open} aria-haspopup="true" title="Change the colour theme">
        <Palette className="h-4 w-4" aria-hidden="true" /> {label}
      </button>
      {open && (
        <div className={`theme-pop ${up ? 'is-up' : ''}`} role="menu" aria-label="Colour theme">
          <p className="theme-pop-title">Colour theme</p>
          {ADMIN_THEMES.map((t) => (
            <button key={t.key} type="button" role="menuitemradio" aria-checked={cur === t.key} className="theme-opt" onClick={() => pick(t.key)} data-testid={`theme-${t.key}`}>
              <span className="theme-sw" aria-hidden="true">{t.swatch.map((c) => <i key={c} style={{ background: c }} />)}</span>
              <span className="flex-1 text-left">{t.label}</span>
              {cur === t.key && <Check className="h-4 w-4" aria-hidden="true" />}
            </button>
          ))}
          <p className="theme-pop-note">Saved on this device.</p>
        </div>
      )}
    </span>
  );
}
