import { useCallback, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Bell, BellOff, BellRing, CheckCircle2, Send, Smartphone, X } from 'lucide-react';
import { useToast } from '../components/ui/Toast';
import { removePushSubscription, saveStaffPushSubscription, staffAlerts, pushStatus, staffPushDevices, staffPushRemove, staffPushTest } from '../lib/teacherData';
import { currentSub, deviceName, isIos, pushSupported, standalone, subscribeDevice } from '../lib/webPush';

/**
 * v157: what is waiting for the office — new website inquiries, teacher
 * requests, monthly reports to review, recovery classes to approve and delete
 * requests. Counts show as unread badges until handled. With "Alerts" on, the
 * device shows a notification for anything new, also when it comes back
 * online (Wi-Fi / mobile data) or the browser tab is opened again.
 */
const SEEN = 'qit:alerts-seen';
const ON = 'qit:alerts-on';
// v180: this device gets office notifications from the server (also when Chrome is closed)
const PUSH = 'qit:alerts-push';
const pushOn = () => { try { return localStorage.getItem(PUSH) === '1'; } catch { return false; } };
const readSeen = () => { try { return new Set(JSON.parse(localStorage.getItem(SEEN) || '[]')); } catch { return new Set(); } };
const canNotify = () => typeof window !== 'undefined' && 'Notification' in window;

const registerSw = () => navigator.serviceWorker?.register?.('/sw.js').catch(() => null);

async function notify(title, body, url) {
  try {
    const reg = (await navigator.serviceWorker?.getRegistration?.()) || (await registerSw());
    if (reg?.showNotification) return reg.showNotification(title, { body, icon: '/icon-192.png', badge: '/icon-192.png', data: { url }, tag: url });
    const n = new Notification(title, { body, icon: '/icon-192.png', tag: url });
    n.onclick = () => { window.focus(); window.location.assign(url); };
  } catch { /* not supported here */ }
}

export function useStaffAlerts({ exec, inquiries = [] }) {
  const [data, setData] = useState({ reports: [], support: [], approvals: [], deletes: [] });
  const first = useRef(true);
  const load = useCallback(async () => {
    try {
      const d = await staffAlerts({ exec });
      setData(d);
      // the portal menu shows the same counts on its sections
      window.__qitAlerts = { support: d.support.length, attendance: d.approvals.length, students: d.deletes.length };
      window.dispatchEvent(new Event('qit-alerts'));
    } catch { /* offline: try again later */ }
  }, [exec]);
  useEffect(() => {
    load();
    const id = setInterval(load, 60000);
    const vis = () => document.visibilityState === 'visible' && load();
    document.addEventListener('visibilitychange', vis);
    window.addEventListener('online', load);
    // a notification arrived on this device → refresh the counts now
    const fromSw = (e) => e.data?.type === 'qit-alert' && load();
    navigator.serviceWorker?.addEventListener?.('message', fromSw);
    return () => { clearInterval(id); document.removeEventListener('visibilitychange', vis); window.removeEventListener('online', load); navigator.serviceWorker?.removeEventListener?.('message', fromSw); };
  }, [load]);

  // Native notifications for anything not seen before
  const newInq = (inquiries || []).filter((i) => i.status === 'new');
  useEffect(() => {
    const items = [
      ...newInq.map((i) => ({ key: `inq:${i.id}`, title: 'New inquiry', body: `${i.name || 'Visitor'}${i.course ? ` · ${i.course}` : ''}`, url: '/admin/inquiries' })),
      ...data.support.map((i) => ({ key: `sup:${i.id}`, title: 'Teacher request', body: `${i.teacher_name || ''}: ${i.subject}`, url: `/admin/portal?tab=support&inquiry=${i.id}` })),
      ...data.reports.map((r) => ({ key: `rep:${r.id}`, title: 'New monthly report', body: `${r.student_name || ''} · by ${r.teacher_name || ''}`, url: '/admin/review?tab=reports' })),
      ...data.approvals.map((r) => ({ key: `apr:${r.id}`, title: 'Recovery class needs approval', body: `${r.student_id} · ${r.day}`, url: '/admin/portal?tab=attendance' })),
      ...data.deletes.map((s) => ({ key: `del:${s.id}`, title: 'Delete request', body: `${s.name || s.id}`, url: '/admin/portal?tab=students' })),
    ];
    const seen = readSeen();
    const fresh = items.filter((x) => !seen.has(x.key));
    if (!fresh.length) return;
    // the first load after opening only marks what is there (no flood of notifications)
    let enabled = false;
    try { enabled = localStorage.getItem(ON) === '1'; } catch { /* off */ }
    // with server notifications on, the phone already got them (no doubles)
    if (!first.current && enabled && !pushOn() && canNotify() && Notification.permission === 'granted') {
      if (fresh.length > 3) notify(`${fresh.length} new items for the office`, fresh.slice(0, 3).map((x) => x.title).join(', '), fresh[0].url);
      else fresh.forEach((x) => notify(x.title, x.body, x.url));
    }
    try { localStorage.setItem(SEEN, JSON.stringify([...seen, ...fresh.map((x) => x.key)].slice(-1500))); } catch { /* fine */ }
    first.current = false;
  }, [data, newInq.length]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (first.current && (data.reports.length || data.support.length)) first.current = false; }, [data]);

  return { ...data, reload: load, counts: { reports: data.reports.length, support: data.support.length, approvals: data.approvals.length, deletes: data.deletes.length } };
}

// v188: this device's office notifications — one place to turn them on, test
// them and see which phones / computers get them. On an iPhone they only work
// in the app opened from the Home Screen (Apple's rule), so that is explained.
async function linkThisDevice() {
  if (!pushSupported() || Notification.permission !== 'granted') return false;
  try {
    const sub = await subscribeDevice();
    await saveStaffPushSubscription(sub.toJSON(), deviceName());
    localStorage.setItem(PUSH, '1');
    localStorage.setItem(ON, '1');
    return true;
  } catch {
    try { localStorage.setItem(PUSH, '0'); } catch { /* fine */ }
    return false;
  }
}
const isMobile = () => /Android|iPhone|iPad|iPod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
const isSamsung = () => /SamsungBrowser|SM-|Samsung/i.test(navigator.userAgent);

export function useDeviceAlerts() {
  const [perm, setPerm] = useState(() => (canNotify() ? Notification.permission : 'unsupported'));
  const [linked, setLinked] = useState(() => pushOn());
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  // permission given on this device: keep it registered every time the admin opens
  // (an iPhone Home Screen app has its own storage, so this also repairs that case)
  useEffect(() => {
    if (!canNotify() || Notification.permission !== 'granted') return;
    registerSw();
    linkThisDevice().then(setLinked);
  }, []);
  const turnOn = async () => {
    setError('');
    if (!canNotify()) { setError('This browser cannot show notifications.'); return false; }
    setBusy(true);
    try {
      const p = Notification.permission === 'granted' ? 'granted' : await Notification.requestPermission();
      setPerm(p);
      if (p !== 'granted') {
        setError(p === 'denied' ? 'Notifications are blocked for this site. Allow them in the phone’s settings (see below), then press the button again.' : 'Notifications were not allowed.');
        return false;
      }
      registerSw();
      try { localStorage.setItem(ON, '1'); } catch { /* fine */ }
      const ok = await linkThisDevice();
      setLinked(ok);
      if (!ok) setError(pushSupported() ? 'This device could not be registered with the server. Check the internet and try again.' : 'This browser shows alerts only while the admin page is open.');
      return ok;
    } finally {
      setBusy(false);
    }
  };
  const turnOff = async () => {
    try { localStorage.setItem(ON, '0'); localStorage.setItem(PUSH, '0'); } catch { /* fine */ }
    const sub = await currentSub();
    if (sub) { await staffPushRemove(sub.endpoint).catch(() => null); await removePushSubscription(sub.endpoint).catch(() => null); await sub.unsubscribe().catch(() => null); }
    setLinked(false);
  };
  return { perm, linked, busy, error, turnOn, turnOff, on: perm === 'granted' && linked };
}

// v189: the test result in plain words
function explainTest(r) {
  if (!r || r.reason === 'no function') return { bad: true, text: 'The website’s notification service did not answer. Deploy the latest version from GitHub (Netlify → Deploys), then try again.' };
  if (r.reason === 'not set up') return { bad: true, text: `Netlify is missing: ${(r.missing || []).join(', ') || 'the notification keys'}. Add them in Netlify → Site configuration → Environment variables, then Trigger deploy.` };
  if (r.reason === 'secret mismatch') return { bad: true, text: 'PUSH_SECRET in Netlify is not the same as the one saved in the database. In Supabase → SQL Editor run: select public.set_push_secret(\'the PUSH_SECRET value from Netlify\', \'https://quraninternational.academy\'); then try again.' };
  if (r.reason === 'database' || r.reason === 'no test') return { bad: true, text: 'The database is not updated yet. Run the latest SQL (teacher-dashboard-SQL-copy-all.txt) in Supabase, then try again.' };
  if (r.error) return { bad: true, text: `The notification service had an error: ${r.error}` };
  if (r.sent > 0 && !r.errors?.length) return { bad: false, text: `Sent to ${r.sent} device${r.sent === 1 ? '' : 's'} ✓ If it does not appear within a minute, the phone is holding it back — see “Not getting them?” below.` };
  const e = r.errors?.[0] || {};
  const why = e.status === 403 || e.status === 401 ? 'the notification keys in Netlify do not match the ones this device was registered with (VAPID_PUBLIC_KEY / VAPID_PRIVATE_KEY must be a pair). Fix the keys, then press “Turn off on this device” and “Turn on notifications” again'
    : e.status === 404 || e.status === 410 ? 'the device’s registration had expired, so it was removed. Press “Turn on notifications” again'
      : e.status === 400 ? 'the notification keys in Netlify look wrong (VAPID_PRIVATE_KEY / VAPID_SUBJECT)'
        : `the phone service (${e.host || 'unknown'}) said ${e.status || 'no answer'}${e.body ? `: ${e.body}` : ''}`;
  return { bad: true, text: `Sent to ${r.sent || 0} of ${r.devices || 0} device(s). Not delivered because ${why}.` };
}

function CheckList({ check }) {
  if (!check) return null;
  const { server, db } = check;
  const rows = [
    ['Website notification service', server.ready === true, server.notFound ? 'not found — deploy the latest version from GitHub' : server.offline ? 'no answer (offline?)' : server.ready ? 'ready' : `missing in Netlify: ${(server.missing || []).join(', ') || 'keys'} (then Trigger deploy)`],
    ['Database updated', !db.error, db.error ? 'run the latest SQL in Supabase' : 'yes'],
    ['Push secret saved in the database', db.secretSet === true, db.secretSet ? 'yes' : 'no — run select public.set_push_secret(…) in Supabase'],
    ['Instant sending (pg_net)', db.pgNet === true, db.pgNet ? 'on' : 'off — notifications come within 1 minute instead of at once (Supabase → Database → Extensions → pg_net → enable)'],
    ['Your registered devices', (db.devices || 0) > 0, String(db.devices ?? 0)],
  ];
  return (
    <div className="al-check" data-testid="alerts-check">
      <p className="al-label">Check</p>
      <ul>
        {rows.map(([k, ok, v]) => <li key={k} className={ok ? 'is-ok' : 'is-bad'}><span aria-hidden="true">{ok ? '✓' : '✗'}</span> <strong>{k}:</strong> {v}</li>)}
      </ul>
    </div>
  );
}

function AlertsSheet({ onClose, dev }) {
  const toast = useToast();
  const [devices, setDevices] = useState(null);
  const [mine, setMine] = useState('');
  const [testing, setTesting] = useState(false);
  const loadDevices = useCallback(() => {
    staffPushDevices().then((d) => setDevices(d || [])).catch(() => setDevices([]));
    currentSub().then((x) => setMine(x?.endpoint || '')).catch(() => {});
  }, []);
  useEffect(() => { loadDevices(); }, [loadDevices, dev.linked]);
  const ios = isIos();
  const app = standalone();
  const iosOutside = ios && !app;
  // v189: what the website and the database say (shown as a checklist)
  const [check, setCheck] = useState(null);
  const [result, setResult] = useState(null);
  const runCheck = useCallback(async () => {
    const server = await fetch('/.netlify/functions/push', { cache: 'no-store' })
      .then(async (r) => ((r.headers.get('content-type') || '').includes('json') ? r.json() : { notFound: true })).catch(() => ({ offline: true }));
    const db = await pushStatus().catch((e) => ({ error: e.message }));
    setCheck({ server, db });
  }, []);
  useEffect(() => { runCheck(); }, [runCheck, dev.linked]);
  const test = async () => {
    setTesting(true);
    setResult(null);
    try {
      const t = await staffPushTest();
      if (!t?.devices) { setResult({ bad: true, text: 'No device of yours is registered yet. Press “Turn on notifications” first (on iPhone: inside the Home Screen app).' }); return; }
      const r = await fetch('/.netlify/functions/push', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ testId: t.id }) })
        .then((x) => x.json()).catch(() => ({ ok: false, reason: 'no function' }));
      setResult(explainTest(r));
      if (r?.removed) loadDevices();
    } catch (e) {
      setResult({ bad: true, text: e.message || 'Could not send the test.' });
    } finally {
      setTesting(false);
    }
  };
  return createPortal(
    <div className="al-veil" onMouseDown={(e) => e.target === e.currentTarget && onClose()} data-testid="alerts-sheet">
      <div className="al-card" role="dialog" aria-modal="true" aria-labelledby="al-title">
        <div className="al-head">
          <h2 id="al-title"><BellRing className="h-5 w-5" aria-hidden="true" /> Office notifications</h2>
          <button type="button" onClick={onClose} aria-label="Close" className="al-x"><X className="h-5 w-5" /></button>
        </div>
        <p className="al-sub">New inquiries, trial requests, teacher requests, monthly reports and counselor cases arrive on this device, also when the app or Chrome is closed.</p>

        <div className={`al-state ${dev.on ? 'is-on' : 'is-off'}`} data-testid="alerts-state">
          {dev.on ? <><CheckCircle2 className="h-5 w-5" aria-hidden="true" /> This device gets notifications.</> : iosOutside ? <><Smartphone className="h-5 w-5" aria-hidden="true" /> On iPhone, open QIT from the Home Screen first.</> : <><BellOff className="h-5 w-5" aria-hidden="true" /> Not on for this device yet.</>}
        </div>

        {iosOutside ? (
          <ol className="al-steps">
            <li>In Safari, tap the <strong>Share</strong> button (square with an arrow).</li>
            <li>Choose <strong>Add to Home Screen</strong> → <strong>Add</strong>.</li>
            <li>Close Safari. Open <strong>QIT</strong> from the Home Screen icon and sign in.</li>
            <li>Open this panel again there and press <strong>Turn on notifications</strong>. Apple allows notifications only inside the Home Screen app (iOS 16.4 or newer).</li>
          </ol>
        ) : (
          <div className="al-actions">
            {!dev.on && <button type="button" className="al-btn" onClick={dev.turnOn} disabled={dev.busy} data-testid="alerts-turn-on"><Bell className="h-4 w-4" aria-hidden="true" /> {dev.busy ? 'Turning on…' : 'Turn on notifications'}</button>}
            <button type="button" className="al-btn is-ghost" onClick={test} disabled={testing} data-testid="alerts-test"><Send className="h-4 w-4" aria-hidden="true" /> {testing ? 'Sending…' : 'Send a test notification'}</button>
            {dev.on && <button type="button" className="al-link" onClick={dev.turnOff} data-testid="alerts-turn-off">Turn off on this device</button>}
          </div>
        )}
        {dev.error && <p className="al-error" role="alert">{dev.error}</p>}
        {result && <p className={result.bad ? 'al-error' : 'al-ok'} role="status" data-testid="alerts-result">{result.text}</p>}
        <CheckList check={check} />

        <details className="al-help" open={dev.perm === 'denied' || undefined}>
          <summary>Not getting them?</summary>
          <ul>
            {ios ? (
              <>
                <li>iPhone: <strong>Settings → Notifications → QIT</strong> → Allow Notifications, and choose <strong>Banners</strong> + <strong>Lock Screen</strong>.</li>
                <li>Focus / Do Not Disturb hides them: allow QIT in the Focus settings.</li>
                <li>If QIT was added to the Home Screen before, delete the icon, add it again, and turn notifications on inside it.</li>
              </>
            ) : (
              <>
                <li>Android: <strong>Settings → Apps → {isSamsung() ? 'Samsung Internet / Chrome / QIT' : 'Chrome / QIT'} → Notifications</strong> → Allow, and turn on <strong>Pop-up / Show as pop-up</strong>.</li>
                <li>Samsung: <strong>Settings → Apps → {isSamsung() ? 'Samsung Internet' : 'Chrome'} → Battery → Unrestricted</strong>, otherwise the phone holds notifications while it sleeps.</li>
                <li>In the browser: the lock icon beside the address → <strong>Permissions → Notifications → Allow</strong>.</li>
              </>
            )}
            <li>Then press <strong>Send a test notification</strong>. If the test arrives, everything works.</li>
          </ul>
        </details>

        <div className="al-devices">
          <p className="al-label">Devices getting your notifications</p>
          {devices === null ? <p className="al-muted">Loading…</p> : !devices.length ? <p className="al-muted">None yet.</p> : (
            <ul>
              {devices.map((d) => (
                <li key={d.endpoint}>
                  <span><Smartphone className="h-4 w-4" aria-hidden="true" /> {d.device || 'Device'}{d.endpoint === mine ? <em> · this device</em> : null}</span>
                  <button type="button" className="al-link" onClick={async () => { await staffPushRemove(d.endpoint).catch(() => null); loadDevices(); }} aria-label={`Remove ${d.device || 'device'}`}>Remove</button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>,
    document.body,
  );
}

export function AlertsToggle({ className = '' }) {
  const dev = useDeviceAlerts();
  const [open, setOpen] = useState(false);
  if (!canNotify() && !isIos()) return null;
  return (
    <>
      <button type="button" className={className} onClick={() => setOpen(true)} aria-pressed={dev.on} title="Office notifications on this device" data-testid="alerts-toggle">
        {dev.on ? <Bell className="h-4 w-4" aria-hidden="true" /> : <BellOff className="h-4 w-4" aria-hidden="true" />}<span>Alerts</span>
      </button>
      {open && <AlertsSheet dev={dev} onClose={() => setOpen(false)} />}
    </>
  );
}

// v188: phones are asked once (and again a week later) to turn office notifications on
const LATER = 'qit:alerts-later';
export function AlertsInvite() {
  const dev = useDeviceAlerts();
  const [open, setOpen] = useState(false);
  const [hidden, setHidden] = useState(() => { try { return Date.now() - Number(localStorage.getItem(LATER) || 0) < 7 * 864e5; } catch { return false; } });
  if (!isMobile() || dev.on || hidden || (!canNotify() && !isIos())) return open ? <AlertsSheet dev={dev} onClose={() => setOpen(false)} /> : null;
  const later = () => { try { localStorage.setItem(LATER, String(Date.now())); } catch { /* fine */ } setHidden(true); };
  return (
    <>
      <div className="al-invite" role="region" aria-label="Office notifications" data-testid="alerts-invite">
        <BellRing className="h-5 w-5 shrink-0" aria-hidden="true" />
        <p>{isIos() && !standalone() ? 'Get office alerts on this iPhone: add QIT to the Home Screen.' : 'Get new inquiries and requests as phone notifications.'}</p>
        <button type="button" className="al-btn" onClick={() => (isIos() && !standalone() ? setOpen(true) : dev.turnOn().then((ok) => !ok && setOpen(true)))} disabled={dev.busy}>{isIos() && !standalone() ? 'How?' : 'Turn on'}</button>
        <button type="button" className="al-link" onClick={later}>Later</button>
      </div>
      {open && <AlertsSheet dev={dev} onClose={() => setOpen(false)} />}
    </>
  );
}
