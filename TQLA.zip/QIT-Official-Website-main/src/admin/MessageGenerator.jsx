import { forwardRef, useEffect, useMemo, useRef, useState } from 'react';
import {
  BookOpen, CalendarDays, CalendarRange, ClipboardCheck, Clock, Copy, CreditCard, Globe2, Hourglass, Inbox, MessageSquareText, Pin, Send, Phone, Smartphone, StickyNote, UserRound, Wand2,
} from 'lucide-react';
import { useSiteData } from '../context/SiteDataContext';
import { useToast } from '../components/ui/Toast';
import AdminPageHeader from './components/AdminPageHeader';

/**
 * Student assignment messages.
 * - Every booking from the website (trial form or Buy Course) is drafted
 *   automatically here as an assignment message ("New bookings").
 * - Every field is optional; only filled fields go into the message.
 * - Teacher category "Others" leaves the category out of the heading
 *   ("New Student Assignment"); all the student details are still included.
 * - "Generate & Send" (1) copies the message with the Clipboard API, then
 *   (2) opens the Student Group QIT chat straight in the installed WhatsApp
 *   Desktop app through the whatsapp:// link (not the https web link, so the
 *   browser skips WhatsApp Web and its "open app?" landing page). Paste
 *   (Ctrl+V) and send. If the app does not open (not installed, or the
 *   browser blocked it), a button to open the group on WhatsApp Web appears.
 *   (WhatsApp does not let a website post into a group by itself.)
 */
const SENDER = '+880 1403-291872';
const GROUP_CODE = 'EQ0kFWnBGgCFjRlubw81UT';
// Desktop app deep link: opens the group directly in the installed WhatsApp app
const GROUP_APP_LINK = `whatsapp://chat?code=${GROUP_CODE}`;
// Fallback when the app is not installed
const GROUP_WEB_LINK = `https://chat.whatsapp.com/${GROUP_CODE}`;
const CATEGORIES = [
  { key: 're', label: 'Re. Teachers' },
  { key: 'ma', label: 'Ma. Teachers' },
  { key: 'fe', label: 'Fe. Teachers' },
  { key: 'others', label: 'Others' },
];
// icon = emoji used in the WhatsApp text (WhatsApp shows text only);
// Icon = the line icon used in the on-screen preview
const FIELDS = [
  { key: 'student', label: 'Student name', icon: '👤', Icon: UserRound },
  { key: 'whatsapp', label: 'WhatsApp number', icon: '📱', type: 'tel', placeholder: '+880 1XXX-XXXXXX', Icon: Phone },
  { key: 'country', label: 'Country', icon: '🌍', Icon: Globe2 },
  { key: 'course', label: 'Course details', icon: '📚', Icon: BookOpen },
  { key: 'time', label: 'Class time', icon: '🕒', Icon: Clock },
  { key: 'date', label: 'Date', icon: '📅', type: 'date', Icon: CalendarDays },
  { key: 'duration', label: 'Duration', icon: '⏱', placeholder: 'e.g. 45 minutes', Icon: Hourglass },
  { key: 'days', label: 'Days / week', icon: '🗓', placeholder: 'e.g. 5 days', Icon: CalendarRange },
  { key: 'payment', label: 'Monthly payment', icon: '💳', placeholder: 'e.g. BDT 4,000', Icon: CreditCard },
  { key: 'notes', label: 'Notes', icon: '📝', textarea: true, Icon: StickyNote },
];
const EMPTY = Object.fromEntries(FIELDS.map((f) => [f.key, '']));
const ONLY_TITLE = 'New Student Assignment';
const REQUIRED_DEFAULTS = { requireStudent: true, requireWhatsapp: true };

function formatDate(v) {
  if (!v) return '';
  const d = new Date(`${v}T00:00:00`);
  return Number.isNaN(d.getTime()) ? v : d.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
}
const isoDate = (v) => (/^\d{4}-\d{2}-\d{2}$/.test(String(v || '')) ? v : '');

// Turn a website booking into form values
function fromBooking(q) {
  const buy = String(q.message || '').startsWith('Buy Course');
  const payment = buy ? String(q.message).split('Monthly payment:')[1]?.trim() || '' : '';
  const planMatch = String(q.course || '').match(/(\d+\s*[–-]\s*\d+|\d+)\s*days a week/i);
  const notes = [
    q.teacher && `Preferred teacher: ${q.teacher}`,
    q.medium && `Medium: ${q.medium}`,
    q.platform && `Platform: ${q.platform}`,
    !buy && q.message,
  ]
    .filter(Boolean)
    .join(' · ');
  return {
    ...EMPTY,
    student: buy ? '' : q.name || '',
    whatsapp: q.phone || q.whatsapp || '',
    country: q.country || '',
    course: q.course || '',
    time: q.preferredTime || '',
    date: isoDate(q.classDate),
    days: planMatch ? `${planMatch[1]} days` : '',
    payment,
    notes,
  };
}

// WhatsApp text in the same layout as the preview card: title, category,
// then each detail as a bold label with the value on the next line.
// (WhatsApp shows plain text only: *bold*, _italic_ — no icons or boxes.)
// "Others" leaves the teacher category out; everything else stays.
const RULE = '────────────────';
function buildMessage(values, category) {
  const blocks = FIELDS.filter((f) => String(values[f.key]).trim()).map((f) => {
    const v = f.type === 'date' ? formatDate(values[f.key]) : String(values[f.key]).trim();
    return `*${f.label}*\n${v}`;
  });
  if (!blocks.length) return '';
  const head = [`📌 *${ONLY_TITLE}*`, category.key !== 'others' ? `_${category.label}_` : null].filter(Boolean).join('\n');
  return [head, RULE, blocks.join('\n\n'), RULE, '_Quran International Institute (QIT)_'].join('\n');
}

// The image library is loaded from a CDN only when an admin copies the card,
// so the site build never depends on it being installed.
const HTML_TO_IMAGE_URL = 'https://cdn.jsdelivr.net/npm/html-to-image@1.11.11/+esm';

// Picture of the preview card as PNG (for pasting into WhatsApp as an image)
async function cardToPng(node) {
  const { toBlob } = await import(/* @vite-ignore */ HTML_TO_IMAGE_URL);
  const blob = await toBlob(node, { pixelRatio: 2, backgroundColor: '#ffffff', cacheBust: true });
  if (!blob) throw new Error('Could not draw the card');
  return blob;
}
// Put the card on the clipboard as an image. The promise form keeps the
// browser's permission from the click while the picture is being drawn.
async function copyCardImage(node) {
  if (!node || !window.ClipboardItem || !navigator.clipboard?.write) return false;
  try {
    await navigator.clipboard.write([new window.ClipboardItem({ 'image/png': cardToPng(node) })]);
    return true;
  } catch {
    return false;
  }
}

// On-screen preview of the assignment (the copied WhatsApp text keeps emojis,
// because WhatsApp can only show plain text)
const AssignmentPreview = forwardRef(function AssignmentPreview({ values, category, empty }, ref) {
  if (empty) {
    return (
      <div className="flex min-h-[10rem] items-center justify-center rounded-2xl border border-dashed border-ink/15 bg-slate-50 p-6 text-center text-sm text-ink/50">
        Your message appears here as you fill in the form.
      </div>
    );
  }
  const rows = FIELDS.filter((f) => String(values[f.key]).trim());
  return (
    <div ref={ref} className="rounded-2xl border border-slate-200 bg-white p-5 text-slate-800 shadow-[0_1px_2px_rgba(15,23,42,.04),0_8px_24px_-12px_rgba(15,23,42,.18)]">
      <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
        <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-pine-50 text-pine-700">
          <Pin className="h-4 w-4" aria-hidden="true" />
        </span>
        <div className="leading-tight">
          <p className="text-[15px] font-semibold text-slate-900">{ONLY_TITLE}</p>
          {category.key !== 'others' && <p className="text-xs font-medium text-pine-700">{category.label}</p>}
        </div>
      </div>
      <ul className="mt-4 space-y-3.5">
        {rows.map((f) => {
          const v = f.type === 'date' ? formatDate(values[f.key]) : String(values[f.key]).trim();
          return (
            <li key={f.key} className="flex items-start gap-3">
              <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-pine-50 text-pine-700">
                <f.Icon className="h-4 w-4" strokeWidth={1.8} aria-hidden="true" />
              </span>
              <div className="min-w-0 leading-snug">
                <p className="text-xs font-medium uppercase tracking-wide text-slate-500">{f.label}</p>
                <p className="whitespace-pre-wrap break-words text-[15px] text-slate-800">{v}</p>
              </div>
            </li>
          );
        })}
      </ul>
      <p className="mt-5 border-t border-slate-100 pt-3 text-xs font-medium text-slate-500">Quran International Institute (QIT)</p>
    </div>
  );
});

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand('copy');
    ta.remove();
    return ok;
  }
}

export default function MessageGenerator() {
  const toast = useToast();
  const { inquiries, updateInquiry, content } = useSiteData();
  // Mandatory fields: Admin → Site content → Assignment message
  const rules = { ...REQUIRED_DEFAULTS, ...(content?.site?.assignment || {}) };
  const isRequired = (key) => Boolean(rules[`require${key[0].toUpperCase()}${key.slice(1)}`]);
  const [missing, setMissing] = useState([]);
  const [values, setValues] = useState(EMPTY);
  const [category, setCategory] = useState('re');
  const [bookingId, setBookingId] = useState('');
  const [copied, setCopied] = useState(false);
  const [sendState, setSendState] = useState('idle'); // idle | copied
  const previewRef = useRef(null);
  // How the assignment goes to WhatsApp: 'image' = the preview card as a
  // picture (looks exactly like the preview), 'text' = formatted text
  const [sendAs, setSendAs] = useState(() => {
    try {
      return localStorage.getItem('qit:assign-send-as') || 'image';
    } catch {
      return 'image';
    }
  });
  const chooseSendAs = (v) => {
    setSendAs(v);
    try {
      localStorage.setItem('qit:assign-send-as', v);
    } catch {
      /* ignore */
    }
  };
  const [appMissing, setAppMissing] = useState(false);
  const cat = CATEGORIES.find((c) => c.key === category);
  const message = useMemo(() => buildMessage(values, cat), [values, cat]);

  // Website bookings not yet handled, newest first — each is a ready draft
  const bookings = useMemo(
    () => inquiries.filter((q) => q.type === 'trial' && q.status === 'new').sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt))).slice(0, 12),
    [inquiries],
  );

  // Automatically draft the newest booking when the page opens with an empty form
  const autoLoaded = useRef(false);
  useEffect(() => {
    if (autoLoaded.current || !bookings.length) return;
    autoLoaded.current = true;
    setValues(fromBooking(bookings[0]));
    setBookingId(bookings[0].id);
  }, [bookings]);

  const loadBooking = (q) => {
    setValues(fromBooking(q));
    setBookingId(q.id);
    setCopied(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const generateAndSend = async () => {
    if (!message) return toast('Fill in at least one field first.', 'error');
    const lacking = FIELDS.filter((f) => isRequired(f.key) && !String(values[f.key]).trim());
    const digits = (String(values.whatsapp).match(/\d/g) || []).length;
    if (!lacking.some((f) => f.key === 'whatsapp') && String(values.whatsapp).trim() && digits < 7) lacking.push(FIELDS.find((f) => f.key === 'whatsapp'));
    setMissing(lacking.map((f) => f.key));
    if (lacking.length) {
      document.getElementById(`msg-${lacking[0].key}`)?.focus();
      return toast(`Fill in: ${lacking.map((f) => f.label).join(', ')}.`, 'error');
    }
    setAppMissing(false);
    // Step 1: copy — the preview card as a picture, or the formatted text
    let ok = false;
    let kind = sendAs;
    if (sendAs === 'image') ok = await copyCardImage(previewRef.current);
    if (!ok) {
      if (sendAs === 'image') kind = 'text'; // picture not supported here → text instead
      ok = await copyText(message);
    }
    setCopied(ok);
    setSendState(ok ? 'copied' : 'idle');
    toast(
      ok
        ? `Copied ${kind === 'image' ? 'the assignment card (picture)' : 'the message'}! Opening the QIT group in WhatsApp — press Ctrl+V and send.`
        : 'Could not copy automatically. Use the Copy buttons.',
      ok ? undefined : 'error',
    );
    // Step 2: open the group in the WhatsApp Desktop app (whatsapp:// link).
    // When the app opens, this page loses focus; if it does not within a
    // couple of seconds, the app is probably not installed → offer the web link.
    let left = false;
    const onBlur = () => {
      left = true;
    };
    window.addEventListener('blur', onBlur, { once: true });
    window.location.href = GROUP_APP_LINK;
    setTimeout(() => {
      window.removeEventListener('blur', onBlur);
      if (!left && document.hasFocus()) setAppMissing(true);
      setSendState('idle');
    }, 2500);
    // The booking has now been assigned
    if (bookingId) updateInquiry(bookingId, { status: 'contacted' }).catch(() => {});
  };

  const set = (k) => (e) => setValues((v) => ({ ...v, [k]: e.target.value }));

  return (
    <div>
      <AdminPageHeader
        title="Student assignment message"
        description="Website bookings are drafted here automatically. Fill in or adjust the fields (those marked * are mandatory — change this in Site content → Assignment message), choose the teacher category, then send to Student Group QIT."
      />

      <div className="mb-6 flex gap-3 rounded-2xl border border-gold-300/60 bg-gold-100/50 p-4 text-sm text-ink/80">
        <Smartphone className="mt-0.5 h-5 w-5 shrink-0 text-gold-700" />
        <p>
          Use this page on the phone or WhatsApp Web logged in as <strong>{SENDER}</strong>: WhatsApp sends from whichever account is logged in. The button copies
          the message and opens <strong>Student Group QIT</strong>; paste it there (Ctrl+V or long-press → Paste) and send.
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
        <section className="panel p-5">
          {bookingId && (
            <p className="mb-4 flex items-center gap-2 rounded-xl bg-pine-50 px-3 py-2 text-sm text-pine-900">
              <Wand2 className="h-4 w-4" /> Drafted from a website booking. Check it, then send.
            </p>
          )}
          <div className="grid gap-4 sm:grid-cols-2">
            {FIELDS.map((f) => (
              <div key={f.key} className={f.textarea ? 'sm:col-span-2' : ''}>
                <label className="label" htmlFor={`msg-${f.key}`}>
                  {f.label} {isRequired(f.key) ? <span className="text-red-700" title="Mandatory">*</span> : <span className="font-normal text-ink/45">(optional)</span>}
                </label>
                {f.textarea ? (
                  <textarea id={`msg-${f.key}`} rows={3} className={`input ${missing.includes(f.key) ? '!border-red-500' : ''}`} value={values[f.key]} onChange={set(f.key)} />
                ) : (
                  <input id={`msg-${f.key}`} type={f.type || 'text'} className={`input ${missing.includes(f.key) ? '!border-red-500' : ''}`} placeholder={f.placeholder} value={values[f.key]} onChange={set(f.key)} aria-required={isRequired(f.key)} aria-invalid={missing.includes(f.key)} />
                )}
                {missing.includes(f.key) && (
                  <p className="mt-1 text-xs text-red-700" role="alert">{f.key === 'whatsapp' && String(values.whatsapp).trim() ? 'Enter the full WhatsApp number.' : 'This is mandatory.'}</p>
                )}
              </div>
            ))}
            <div className="sm:col-span-2">
              <label className="label" htmlFor="msg-category">
                Teacher category
              </label>
              <select id="msg-category" className="input" value={category} onChange={(e) => setCategory(e.target.value)}>
                {CATEGORIES.map((c) => (
                  <option key={c.key} value={c.key}>
                    {c.label}
                    {c.key === 'others' ? ' (no teacher category in the message)' : ''}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="mt-5 flex flex-wrap gap-2">
            <button type="button" className={`btn-primary ${sendState === 'copied' ? '!bg-emerald-700' : ''}`} onClick={generateAndSend} aria-live="polite">
              {sendState === 'copied' ? (
                <>
                  <ClipboardCheck className="h-4 w-4" /> Copied! Opening WhatsApp…
                </>
              ) : (
                <>
                  <Send className="h-4 w-4" /> Generate &amp; Send Message
                </>
              )}
            </button>
            <button
              type="button"
              className="btn-outline"
              onClick={() => {
                setValues(EMPTY);
                setBookingId('');
              }}
            >
              Clear form
            </button>
          </div>
          {appMissing && (
            <div className="mt-3 rounded-xl border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-900" role="status">
              WhatsApp Desktop didn’t open. The message is still copied — open the group another way and paste it:
              <div className="mt-2 flex flex-wrap gap-2">
                <a className="btn-outline btn-sm" href={GROUP_APP_LINK}>Try the app again</a>
                <a className="btn-outline btn-sm" href={GROUP_WEB_LINK} target="_blank" rel="noreferrer">Open on WhatsApp Web</a>
              </div>
            </div>
          )}
        </section>

        <section className="space-y-6">
          <div className="panel p-5">
            <div className="mb-3 flex items-center justify-between gap-2">
              <h2 className="flex items-center gap-2 text-lg">
                <MessageSquareText className="h-5 w-5 text-pine-700" /> Preview
              </h2>
              <button
                type="button"
                className="btn-outline btn-sm"
                disabled={!message}
                onClick={async () => {
                  const img = sendAs === 'image' && (await copyCardImage(previewRef.current));
                  const ok = img || (await copyText(message));
                  setCopied(ok);
                  toast(ok ? (img ? 'Card copied as a picture' : 'Message copied') : 'Could not copy', ok ? undefined : 'error');
                }}
              >
                {copied ? <ClipboardCheck className="h-4 w-4" /> : <Copy className="h-4 w-4" />} {sendAs === 'image' ? 'Copy picture' : 'Copy text'}
              </button>
            </div>
            <AssignmentPreview ref={previewRef} values={values} category={cat} empty={!message} />
            <div className="mt-4">
              <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-ink/55">Send to WhatsApp as</p>
              <div className="inline-flex rounded-full border border-pine-900/15 bg-pine-50 p-1" role="radiogroup" aria-label="Send to WhatsApp as">
                {[
                  ['image', 'Picture of this card'],
                  ['text', 'Text message'],
                ].map(([v, l]) => (
                  <button
                    key={v}
                    type="button"
                    role="radio"
                    aria-checked={sendAs === v}
                    onClick={() => chooseSendAs(v)}
                    className={`rounded-full px-3.5 py-1.5 text-sm font-semibold transition ${sendAs === v ? 'bg-pine-900 text-white shadow' : 'text-pine-900 hover:bg-white'}`}
                  >
                    {l}
                  </button>
                ))}
              </div>
              <p className="mt-1.5 text-xs text-ink/55">
                {sendAs === 'image'
                  ? 'WhatsApp receives exactly this card as a picture.'
                  : 'WhatsApp receives text with bold labels (WhatsApp cannot show icons or boxes in text).'}
              </p>
            </div>
          </div>

          <div className="panel p-5">
            <h2 className="flex items-center gap-2 text-lg">
              <Inbox className="h-5 w-5 text-pine-700" /> New bookings ({bookings.length})
            </h2>
            <p className="mt-1 text-xs text-ink/60">Trial requests and Buy Course clicks from the website, drafted automatically. Sending marks a booking as contacted.</p>
            {bookings.length ? (
              <ul className="mt-3 divide-y divide-pine-900/10">
                {bookings.map((q) => (
                  <li key={q.id} className={`flex items-center justify-between gap-3 py-2.5 ${q.id === bookingId ? 'rounded-lg bg-pine-50 px-2' : ''}`}>
                    <span className="min-w-0 text-sm">
                      <span className="block truncate font-semibold text-pine-950">{q.name || 'Website visitor'}</span>
                      <span className="block truncate text-ink/60">
                        {[q.course, q.country, new Date(q.createdAt).toLocaleDateString('en-GB')].filter(Boolean).join(' · ')}
                      </span>
                    </span>
                    <button type="button" className="btn-outline btn-sm shrink-0" onClick={() => loadBooking(q)}>
                      {q.id === bookingId ? 'Loaded' : 'Use draft'}
                    </button>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="mt-3 text-sm text-ink/55">No new bookings right now.</p>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
