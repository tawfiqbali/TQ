import { renumberStudents } from '../../lib/teacherData';
import { kickPush } from '../../lib/pushKick';
import { useSalarySync } from './lib/salarySync';
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { byTeacherOrder } from './lib/constants';
import { useToast } from '../../components/ui/Toast';
import useAdminRole from '../../hooks/useAdminRole';
import { getPortalSession, loadPortalData, portalApi, portalLogin, portalLogout, portalMode } from './lib/api';

// Which portal panels each role may open
export const PANELS = [
  { key: 'dashboard', label: 'Dashboard', superOnly: true },
  { key: 'salary', label: 'Salary Directory', superOnly: true },
  // junior: Junior Admins may open these (never salaries, payments or shares)
  { key: 'students', label: 'Students', junior: true },
  { key: 'reports', label: 'Progress Reports', junior: true },
  { key: 'teacherList', label: 'Teacher List', junior: true },
  { key: 'enrollTeacher', label: 'Enroll Teacher', junior: true },
  { key: 'enrollStudent', label: 'Enroll Student', junior: true },
  { key: 'contents', label: 'Portal Contents', superOnly: true },
  // Cloud (Supabase) only: the Teacher Dashboard side of the portal
  { key: 'teacherDash', label: 'Teacher Dashboards', superOnly: true, cloudOnly: true },
  { key: 'teacherReports', label: 'Teacher Reports', junior: true, cloudOnly: true },
  { key: 'attendance', label: 'Attendance Log', superOnly: true, cloudOnly: true },
  { key: 'points', label: 'Points & Rewards', superOnly: true, cloudOnly: true },
  { key: 'dashEditor', label: 'Dashboard Editor', superOnly: true, cloudOnly: true },
  { key: 'notices', label: 'Notice Maker', superOnly: true },
  { key: 'support', label: 'Teacher Support', superOnly: true, cloudOnly: true },
  { key: 'counseling', label: 'Academic Counseling', superOnly: true, cloudOnly: true },
  { key: 'security', label: 'Security', superOnly: true, cloudOnly: true },
  { key: 'team', label: 'Team & Roles', superOnly: true, cloudOnly: true },
  { key: 'import', label: 'Import Data', superOnly: true, cloudOnly: true },
];

const PortalContext = createContext(null);

// A reload that brought nothing new keeps the lists it already had, so the
// screens (tables, charts) are not rebuilt for no reason.
const sameList = (a, b) => a === b || (a.length === b.length && JSON.stringify(a) === JSON.stringify(b));
function keepSame(prev, next) {
  const out = { ...next };
  let changed = false;
  ['teachers', 'students', 'payments', 'reports'].forEach((k) => {
    if (prev[k] && next[k] && sameList(prev[k], next[k])) out[k] = prev[k];
    else changed = true;
  });
  return changed ? out : prev;
}

// Only the fields the admin actually changed are sent, so an edit made
// meanwhile by a teacher (name, number, class time…) is never overwritten by
// an older copy of the record that this screen had loaded.
function changedFields(before, after) {
  if (!before) return after;
  const patch = { id: after.id };
  Object.keys(after).forEach((k) => {
    if (k !== 'id' && JSON.stringify(after[k] ?? null) !== JSON.stringify(before[k] ?? null)) patch[k] = after[k];
  });
  return patch;
}
const EMPTY = { teachers: [], students: [], payments: [], reports: [] };

export function PortalProvider({ children }) {
  const toast = useToast();
  const { email: adminEmail, role: adminRole } = useAdminRole();
  const [session, setSession] = useState(getPortalSession);
  const [db, setDb] = useState(EMPTY);
  const [status, setStatus] = useState('loading'); // loading | locked | ready | error
  const [error, setError] = useState('');
  const dbRef = useRef(db);
  dbRef.current = db;

  const role = session?.role || '';
  const isSuper = role === 'super';
  const isSuperRef = useRef(isSuper);
  isSuperRef.current = isSuper;
  const canOpen = useCallback((key) => {
    const p = PANELS.find((x) => x.key === key);
    return Boolean(p) && (isSuper || p.junior) && (!p.cloudOnly || portalMode === 'supabase');
  }, [isSuper]);

  // only = ['students'] reloads just that list (used by live updates)
  const load = useCallback(async (only = null) => {
    if (!Array.isArray(only) || !only.length) only = null;
    // Refreshing keeps the current screen; only the first load shows a loader
    setStatus((st) => (st === 'ready' ? st : 'loading'));
    setError('');
    try {
      const data = await loadPortalData(only);
      if (only && portalMode === 'supabase' && data && data.authenticated !== false) {
        setDb((d) => keepSame(d, { ...d, ...data }));
        setStatus('ready');
        return;
      }
      if (data && data.authenticated === false) {
        setSession(null);
        setStatus('locked');
        return;
      }
      let next = { ...EMPTY, ...data };
      // First time the portal has no teachers: load the starting directory.
      // (Supabase: the Import Data panel does this, so a Google Sheet import
      // isn't mixed with the standard list.)
      if (!next.teachers.length && portalMode !== 'supabase') {
        try {
          await portalApi.seedTeachers();
          next = { ...EMPTY, ...(await loadPortalData()) };
        } catch {
          /* keep the empty list; teachers can still be added by hand */
        }
      }
      setDb((d) => keepSame(d, next));
      setStatus('ready');
    } catch (e) {
      if (!getPortalSession()) {
        setSession(null);
        setStatus('locked');
      } else {
        setError(e.message);
        setStatus('error');
      }
    }
  }, []);

  // A session for a different admin (e.g. after switching accounts) is dropped
  useEffect(() => {
    if (adminEmail === null) return;
    if (session && adminEmail && (session.email !== adminEmail || (adminRole && session.role !== adminRole))) {
      portalLogout();
      setSession(null);
      return;
    }
    if (session) load();
    else if ((portalMode === 'demo' || portalMode === 'supabase') && adminEmail) {
      portalLogin(adminEmail, '', adminRole).then(() => setSession(getPortalSession())).catch((e) => {
        setError(e.message);
        setStatus('error');
      });
    } else setStatus('locked');
  }, [session, adminEmail, adminRole, load]);

  // Live updates (cloud): a new teacher sign-up or any change by another admin
  // shows up at once, without reloading the page. Also refreshes when the tab
  // comes back into view, and every 2 minutes as a safety net.
  const [liveTick, setLiveTick] = useState(0);
  const ready = status === 'ready';
  useEffect(() => {
    if (portalMode !== 'supabase' || !ready) return undefined;
    let timer = null;
    // Changes that arrive close together are loaded once; only the lists that
    // changed are read again (a teacher's edit to one student doesn't reload
    // every teacher, payment and report)
    const KEY = { portal_teachers: 'teachers', portal_students: 'students', portal_payments: 'payments', portal_reports: 'reports' };
    let pending = new Set();
    let all = false;
    const refresh = (table) => {
      if (typeof table === 'string' && KEY[table]) pending.add(KEY[table]);
      else if (typeof table === 'string' && Object.values(KEY).includes(table)) pending.add(table);
      else if (typeof table === 'string' && table === 'teacher_profiles') pending.add('teachers');
      else all = true;
      clearTimeout(timer);
      timer = setTimeout(async () => {
        const only = all ? null : [...pending];
        pending = new Set();
        all = false;
        if (document.visibilityState !== 'visible') { all = true; return; } // catch up when the tab is shown again
        await load(only);
        setLiveTick((n) => n + 1);
      }, 500);
    };
    let stop = () => {};
    let cancelled = false;
    import('../../lib/teacherData')
      .then(({ watchPortal }) => watchPortal(refresh))
      .then((unsub) => {
        if (cancelled) unsub();
        else stop = unsub;
      })
      .catch(() => {});
    // v188: a tiny check every 4 seconds — another admin's save shows here within
    // seconds even where the live connection is blocked (some mobile networks)
    let seen = null;
    let checking = false;
    const check = async () => {
      if (checking || document.visibilityState !== 'visible') return;
      checking = true;
      try {
        const { portalChanges } = await import('../../lib/teacherData');
        const now = (await portalChanges()) || {};
        if (seen) Object.keys(now).filter((k) => now[k] !== seen[k] && Object.values(KEY).includes(k)).forEach((k) => refresh(k));
        seen = now;
      } catch { /* offline: next time */ }
      checking = false;
    };
    check();
    const fast = setInterval(check, 4000);
    const onVisible = () => document.visibilityState === 'visible' && refresh();
    
    document.addEventListener('visibilitychange', onVisible);
    const poll = setInterval(refresh, 120000);
    return () => {
      cancelled = true;
      stop();
      clearTimeout(timer);
      clearInterval(poll);
      clearInterval(fast);
      document.removeEventListener('visibilitychange', onVisible);
    };
  }, [ready, load]);

  const unlock = useCallback(async (password) => {
    await portalLogin(adminEmail, password, adminRole);
    setSession(getPortalSession());
  }, [adminEmail, adminRole]);

  // Runs an optimistic local change, then the server call; on failure the
  // data is reloaded so the screen matches the sheet again.
  const run = useCallback(
    async (local, remote, okMsg, { reload = false } = {}) => {
      if (local) setDb((d) => local(d));
      try {
        const res = await remote();
        if (portalMode === 'supabase' || portalMode === 'live') kickPush(); // v179: teacher's phone notification now
        if (okMsg) toast(okMsg);
        if (reload && portalMode === 'live') await load();
        return res;
      } catch (e) {
        toast(e.message || 'Could not save. Please try again.', 'error');
        await load();
        return null;
      }
    },
    [toast, load],
  );

  const actions = useMemo(
    () => ({
      addTeachers: (rows) =>
        run(
          (d) => ({ ...d, teachers: [...d.teachers, ...rows] }),
          async () => {
            const saved = await portalApi.addTeachers(rows);
            if (portalMode === 'supabase') await load();
            else if (portalMode !== 'live') setDb((d) => ({ ...d, teachers: [...d.teachers.filter((t) => !rows.includes(t)), ...saved] }));
            return saved;
          },
          `${rows.length} teacher(s) enrolled!`,
          { reload: true },
        ),
      addStudents: (students, teacherUpdates) =>
        run(
          (d) => ({
            ...d,
            students: [...d.students, ...students],
            teachers: d.teachers.map((t) => {
              const u = teacherUpdates.find((x) => x.id === t.id);
              return u ? { ...t, salaryType: 'Package', packageAmount: u.packageAmount } : t;
            }),
          }),
          async () => {
            const before = dbRef.current.students.filter((s) => !students.includes(s));
            const saved = await portalApi.addStudents({ students, teacherUpdates });
            if (portalMode !== 'live') setDb((d) => ({ ...d, students: [...d.students.filter((s) => !students.includes(s)), ...saved] }));
            // v156: a brother / sister (same WhatsApp number) gets the Student ID right after
            if (portalMode === 'supabase') {
              const key = (p) => String(p || '').replace(/\D/g, '').slice(-10);
              const keysOf = (p) => String(p || '').split(/\s*(?:,|\/|;|\||\s+or\s+)\s*/).map(key).filter((k) => k.length >= 7);
              const old = new Set(before.flatMap((s) => keysOf(s.phone)));
              if (students.some((s) => keysOf(s.phone).some((k) => old.has(k)))) {
                try {
                  const moved = await renumberStudents();
                  if (moved?.length) toast(`Student IDs re-ordered: same-number students are now one after another (${moved.length} ID${moved.length === 1 ? '' : 's'} changed).`);
                } catch { /* keeps the IDs as they are */ }
                await load(['students']);
              }
            }
            return saved;
          },
          `${students.length} student(s) registered!`,
          { reload: true },
        ),
      updateTeacher: async (data) => {
        const before = dbRef.current.teachers.find((t) => t.id === data.id);
        const patch = changedFields(before, data);
        const ok = await run((d) => ({ ...d, teachers: d.teachers.map((t) => (t.id === data.id ? { ...t, ...data } : t)) }), () => portalApi.updateTeacher(portalMode === 'supabase' ? patch : data), 'Teacher updated!');
        // The Teacher ID follows the category: QIT-R… / QIT-M… / QIT-F…
        const letter = /female/i.test(data.category || '') ? 'F' : /non.?resid/i.test(data.category || '') ? 'M' : /^\s*resid/i.test(data.category || '') ? 'R' : '';
        // Junior Admins: the database call has already given the new Teacher ID
        if (ok !== null && portalMode === 'supabase' && !isSuperRef.current) {
          await load(['teachers', 'students']);
          if (ok?.id && ok.id !== data.id) toast(`Teacher ID changed to match the category: ${data.id} → ${ok.id}. Tell the teacher; their password is the same.`);
          return ok;
        }
        if (ok !== null && portalMode === 'supabase' && letter && !new RegExp(`^QIT-${letter}\\d{3,}$`).test(data.id)) {
          try {
            const { changeTeacherId } = await import('../../lib/teacherData');
            const r = await changeTeacherId(data.id, data.category);
            toast(`Teacher ID changed to match the category: ${r.oldId} → ${r.teacherId}. Tell the teacher; their password is the same.`);
          } catch (e) {
            toast(e.message, 'error');
          }
          await load();
        }
        return ok;
      },
      deleteTeacher: (id) =>
        run((d) => ({ ...d, teachers: d.teachers.filter((t) => t.id !== id) }), () => portalApi.deleteTeacher(id), 'Teacher deleted.'),
      updateStudent: (data) => {
        const patch = changedFields(dbRef.current.students.find((s) => s.id === data.id), data);
        return run((d) => ({ ...d, students: d.students.map((s) => (s.id === data.id ? { ...s, ...data } : s)) }), () => portalApi.updateStudent(portalMode === 'supabase' ? patch : data), data.name ? `Saved ✓ ${data.name} (${data.id})` : 'Student updated!');
      },
      deleteStudent: (id) =>
        run((d) => ({ ...d, students: d.students.filter((s) => s.id !== id) }), () => portalApi.deleteStudent(id), 'Student deleted.'),
      recordPayment: (p) => run((d) => ({ ...d, payments: [...d.payments, p] }), () => portalApi.recordPayment(p), 'Payment disbursed!'),
      cancelPayment: (id) =>
        run((d) => ({ ...d, payments: d.payments.filter((p) => p.id !== id) }), () => portalApi.cancelPayment(id), 'Payment cancelled.'),
      saveReport: (report) =>
        run(
          (d) => ({
            ...d,
            reports: [
              { id: 'REP-new', studentId: report.studentId, studentName: report.studentName, month: report.month, year: report.year, reportType: report.reportType, overallScore: report.overallScore },
              ...d.reports,
            ],
          }),
          () => portalApi.saveReport(report),
          'Report saved to records.',
        ),
    }),
    [run, load, toast],
  );

  // Every list and drop-down reads teachers in the one standard order
  const dbOrdered = useMemo(() => ({ ...db, teachers: [...db.teachers].sort(byTeacherOrder) }), [db]);
  // v187: each month's salary goes to the teachers' dashboards
  useSalarySync(db, isSuper && portalMode === 'supabase' && status === 'ready');
  const value = { db: dbOrdered, status, error, role, isSuper, canOpen, load, unlock, adminEmail, mode: portalMode, liveTick, ...actions };
  return <PortalContext.Provider value={value}>{children}</PortalContext.Provider>;
}

// For screens that also work outside the Management Portal
export const usePortalOptional = () => useContext(PortalContext);

// v165: the portal data when inside the portal, otherwise null (no error)
export function usePortalMaybe() {
  return useContext(PortalContext);
}

export function usePortal() {
  const ctx = useContext(PortalContext);
  if (!ctx) throw new Error('usePortal must be used inside <PortalProvider>');
  return ctx;
}
