import { useState, useRef } from 'react';
import { usePortal } from '../PortalContext';
import { joinPhones } from '../lib/constants';
import Combobox from '../components/Combobox';
import { MEDIUMS, PhoneListInput, SameNumberPick, assignHint, findByPhone, sameNumberProblem, teacherOptions } from './common';
import { useToast } from '../../../components/ui/Toast';

const blank = () => ({ key: Math.random().toString(36).slice(2), name: '', phones: [''], classTime: '', teacherId: '', medium: '', link: '', linkTo: '', fee: '', cut: '', isPkg: false, pkgVal: 0 });

// Bulk student entry with teacher cut or fixed-salary mode. All fields optional.
export default function EnrollStudents() {
  const { db, addStudents, isSuper } = usePortal();
  const toast = useToast();
  const options = teacherOptions(db.teachers);
  const [rows, setRows] = useState([blank(), blank()]);
  const [busy, setBusy] = useState(false);
  const [tried, setTried] = useState(false);
  // v183: while saving, compare with the list as it was before Save — the new
  // students already appear in the list then, and must not "match" themselves
  const before = useRef(null);
  // v169: other students on this number (already saved, or an earlier row here)
  const matchesOf = (r, i) => {
    const phone = joinPhones(r.phones);
    if (phone === 'N/A') return [];
    const earlier = rows.slice(0, i).filter((x) => x.name.trim()).map((x, j) => ({ id: `row ${j + 1}`, name: x.name, phone: joinPhones(x.phones), teacherId: x.teacherId }));
    return findByPhone([...(busy && before.current ? before.current : db.students), ...earlier], phone);
  };
  const patch = (key, changes) => setRows((rs) => rs.map((r) => (r.key === key ? { ...r, ...changes } : r)));

  const onTeacher = (r, teacherId) => {
    const t = db.teachers.find((x) => x.id === teacherId);
    if (isSuper && t && t.salaryType === 'Package') patch(r.key, { teacherId, isPkg: true, pkgVal: t.packageAmount || 0, cut: '0' });
    else patch(r.key, { teacherId });
  };

  const togglePkg = (r) => {
    if (r.isPkg) return patch(r.key, { isPkg: false, pkgVal: 0, cut: '' });
    const t = db.teachers.find((x) => x.id === r.teacherId);
    const amount = t && t.salaryType === 'Package' ? t.packageAmount : t && t.category === 'Residential' ? 17000 : 15000;
    patch(r.key, { isPkg: true, pkgVal: amount, cut: '0' });
  };

  const pctOf = (r) => {
    if (r.isPkg) return { text: 'Fixed', cls: 'med' };
    const fee = Number(r.fee) || 0;
    const cut = Number(r.cut) || 0;
    if (!fee) return { text: '0.0%', cls: 'low' };
    const p = (cut / fee) * 100;
    return { text: `${p.toFixed(1)}%`, cls: p >= 50 ? 'high' : p >= 30 ? 'med' : 'low' };
  };

  const submit = async (e) => {
    e.preventDefault();
    const students = [];
    const teacherUpdates = [];
    const isEmpty = (r) => !r.name.trim() && joinPhones(r.phones) === 'N/A' && !r.classTime.trim() && !r.teacherId && !Number(r.fee) && !Number(r.cut) && !r.isPkg && !r.medium;
    // v161: Bangla / English Medium is required for every student
    if (rows.some((r) => !isEmpty(r) && !MEDIUMS.includes(r.medium))) {
      setTried(true);
      toast('Choose Bangla Medium or English Medium for every student.', 'error');
      return;
    }
    if (rows.some((r, i) => r.name.trim() && sameNumberProblem(matchesOf(r, i), r.name, r))) {
      setTried(true);
      toast('This WhatsApp number is already used — choose "Relative" (with a different name) or "Same student, different class".', 'error');
      return;
    }
    rows.forEach((r, i) => {
      const fee = Number(r.fee) || 0;
      // Junior Admins don't set the teacher's share; a Super Admin adds it later
      const cut = !isSuper || r.isPkg ? 0 : Number(r.cut) || 0;
      const phone = joinPhones(r.phones);
      const empty = !r.name.trim() && phone === 'N/A' && !r.classTime.trim() && !r.teacherId && !fee && !cut && !r.isPkg;
      if (empty) return;
      students.push({
        id: `NEW-S${Date.now()}-${i}`,
        name: r.name.trim() || 'Unnamed Student',
        phone,
        teacherId: r.teacherId,
        fee,
        cut,
        course: 'Quran & Tajweed',
        status: 'Active',
        classTime: r.classTime.trim(),
        medium: r.medium,
        ...(r.link === 'same' && db.students.some((x) => x.id === r.linkTo) ? { sameStudentOf: r.linkTo } : {}),
        ...(r.link === 'relative' ? { relative: true } : {}),
        ...(r.assignDate ? { assignDate: r.assignDate } : {}),
      });
      if (isSuper && r.isPkg && r.teacherId && !teacherUpdates.some((u) => u.id === r.teacherId)) teacherUpdates.push({ id: r.teacherId, packageAmount: Number(r.pkgVal) || 0 });
    });
    if (!students.length) return;
    before.current = db.students;
    // v188: the form is ready for the next student at once; the save finishes in
    // the background (the students show in the lists straight away). If the save
    // fails, the entries come back into the form.
    const typed = rows;
    setRows([blank(), blank()]);
    setTried(false);
    toast(`Saving ${students.length} student${students.length === 1 ? '' : 's'}…`);
    addStudents(students, teacherUpdates).then((res) => {
      before.current = null;
      if (res === null) {
        setRows(typed);
        toast('Not saved — your entries are back in the form. Please try again.', 'error');
      }
    });
  };

  return (
    <div className="box-card">
      <div className="card-header-bar">
        <h2 className="card-title">Enroll student(s) &amp; assign salary cut</h2>
        <span className="text-sm font-bold" style={{ color: 'var(--c-teal-mid)' }}>
          {isSuper ? 'Assign Cut or Convert to Fixed Salary — Bangla / English Medium is required' : 'Bangla / English Medium is required'}
        </span>
      </div>
      <form onSubmit={submit}>
        <div className="table-wrap">
          <table className="dynamic-table" style={{ minWidth: isSuper ? 1390 : 1150 }}>
            <thead>
              <tr>
                <th>Student Full Name</th><th>Medium *</th><th>WhatsApp Number(s)</th><th>Class Time</th><th>Assigned Teacher</th><th>Assignment date</th><th>Monthly Fee (BDT)</th>
                {isSuper && <><th>Teacher Cut / Model</th><th>Teacher %</th></>}
                <th>Same number?</th>
                <th aria-label="Remove" />
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => {
                const pct = pctOf(r);
                const matches = matchesOf(r, i);
                return (
                  <tr key={r.key}>
                    <td style={{ minWidth: 180 }}><input className="m-input" placeholder="Student Name" value={r.name} onChange={(e) => patch(r.key, { name: e.target.value })} aria-label="Student name" /></td>
                    <td>
                      <select className={`m-input ${tried && !r.medium && (r.name.trim() || r.teacherId || Number(r.fee)) ? "is-missing" : ""}`} value={r.medium} onChange={(e) => patch(r.key, { medium: e.target.value })} aria-label="Bangla or English Medium (required)" data-testid="enroll-medium">
                        <option value="">Choose…</option>{MEDIUMS.map((m) => <option key={m}>{m}</option>)}
                      </select>
                    </td>
                    <td><PhoneListInput compact value={r.phones} onChange={(phones) => patch(r.key, { phones })} /></td>
                    <td style={{ minWidth: 170 }}><input className="m-input" placeholder="e.g. 5:00 PM - 6:00 PM" value={r.classTime} onChange={(e) => patch(r.key, { classTime: e.target.value })} aria-label="Class time" /></td>
                    <td style={{ minWidth: 220 }}><Combobox value={r.teacherId} onChange={(v) => onTeacher(r, v)} options={options} placeholder="Search teacher…" aria-label="Assigned teacher" /></td>
                    <td style={{ minWidth: 150 }}><input type="date" className="m-input" value={r.assignDate || ''} onChange={(e) => patch(r.key, { assignDate: e.target.value })} aria-label="Assignment date (optional)" title={r.assignDate ? assignHint(r.assignDate) : 'Optional: first class date — the first month is counted by days'} /></td>
                    <td><input type="number" min="0" className="m-input in-fee" placeholder="0" value={r.fee} onChange={(e) => patch(r.key, { fee: e.target.value })} aria-label="Monthly fee" /></td>
                    {isSuper && <><td>
                      <div className="flex flex-col gap-1">
                        <input type="number" min="0" className="m-input in-cut" placeholder="0" disabled={r.isPkg} value={r.cut} onChange={(e) => patch(r.key, { cut: e.target.value })} aria-label="Teacher cut" />
                        <button type="button" className={`btn-pkg-toggle ${r.isPkg ? 'active' : ''}`} onClick={() => togglePkg(r)}>
                          {r.isPkg ? `Fixed Salary (${Number(r.pkgVal).toLocaleString()} BDT)` : '+ Fixed Salary Mode'}
                        </button>
                      </div>
                    </td>
                    <td style={{ textAlign: 'center' }}><span className={`pct-tag ${pct.cls}`}>{pct.text}</span></td></>}
                    <td className={`snp-cell ${matches.length ? 'has-match' : ''}`}><SameNumberPick matches={matches} teachers={db.teachers} name={r.name} value={r} onChange={(val) => patch(r.key, val)} missing={tried} /></td>
                    <td>
                      <button type="button" className="btn-del-row" aria-label="Remove row" onClick={() => (rows.length > 1 ? setRows(rows.filter((x) => x.key !== r.key)) : toast('At least one entry row is required.', 'info'))}>×</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
          <button type="button" className="btn-add-row" onClick={() => setRows([...rows, blank()])}>+ Add Another Student</button>
          <button type="submit" className="btn-teal" disabled={busy}>{busy ? 'Saving…' : 'Save All Students'}</button>
        </div>
      </form>
    </div>
  );
}
