import { phoneKey, teacherWithPhone } from './common';
import { useState } from 'react';
import { usePortal } from '../PortalContext';
import { BD_BANKS, CATEGORIES, DEPARTMENTS, PAYMENT_METHODS } from '../lib/constants';
import Combobox from '../components/Combobox';
import { SALARY_TYPES } from './common';
import { useToast } from '../../../components/ui/Toast';

const CATEGORY_OPTIONS = CATEGORIES.map((c) => ({ value: c.value, label: c.short }));
const blank = () => ({ key: Math.random().toString(36).slice(2), name: '', whatsapp: '', category: 'Residential', department: '', salaryType: 'Per-Student', packageAmount: '', method: 'Bank', account: '', bankName: '', branchName: '' });

// Bulk teacher entry. IDs (QIT-R001 / QIT-M001 / QIT-F001 by category) are assigned by the database.
export default function EnrollTeachers() {
  const { addTeachers, db } = usePortal();
  const toast = useToast();
  const [rows, setRows] = useState([blank(), blank()]);
  const [busy, setBusy] = useState(false);
  const [made, setMade] = useState([]);
  const update = (key, field, value) =>
    setRows((rs) =>
      rs.map((r) => {
        if (r.key !== key) return r;
        const next = { ...r, [field]: value };
        if (field === 'salaryType' && value !== 'Package') next.packageAmount = '';
        if (field === 'method' && value !== 'Bank') Object.assign(next, { bankName: '', branchName: '' });
        return next;
      }),
    );

  // WhatsApp numbers must be unique: already used by a teacher, or twice in this form
  const phoneIssue = (r) => {
    const k = phoneKey(r.whatsapp);
    if (k.length < 7) return '';
    const other = teacherWithPhone(db.teachers, r.whatsapp);
    if (other) return `Already used by ${other.name} (${other.id})`;
    if (rows.some((x) => x.key !== r.key && phoneKey(x.whatsapp) === k)) return 'Entered twice in this form';
    return '';
  };
  const blocked = rows.some((r) => phoneIssue(r));

  const submit = async (e) => {
    e.preventDefault();
    if (blocked) return toast('Each teacher needs their own WhatsApp number. Fix the numbers marked in red.', 'error');
    const payload = rows
      .filter((r) => r.name.trim() || r.whatsapp.trim() || r.account.trim() || Number(r.packageAmount) > 0 || r.branchName.trim())
      .map((r, i) => ({
        id: `NEW-T${Date.now()}-${i}`,
        name: r.name.trim() || 'Unnamed Teacher',
        category: r.category,
        department: r.department,
        whatsapp: r.whatsapp.trim() || 'N/A',
        method: r.method,
        account: r.account.trim() || 'N/A',
        salaryType: r.salaryType,
        packageAmount: r.salaryType === 'Package' ? Number(r.packageAmount) || 0 : 0,
        bankName: r.method === 'Bank' ? r.bankName : '',
        branchName: r.method === 'Bank' ? r.branchName.trim() : '',
        status: 'Active',
      }));
    if (!payload.length) return;
    setBusy(true);
    const saved = await addTeachers(payload);
    setBusy(false);
    if (saved) {
      setRows([blank(), blank()]);
      setMade(Array.isArray(saved) ? saved.filter((t) => t.id) : []);
    }
  };

  return (
    <div className="box-card">
      <div className="card-header-bar">
        <h2 className="card-title">Enroll teacher(s)</h2>
        <span className="text-sm font-bold" style={{ color: 'var(--c-teal-mid)' }}>ID from the category: QIT-R… · QIT-M… · QIT-F…</span>
      </div>
      {made.length > 0 && (
        <div className="mb-4 rounded-xl border-2 border-[#034751] bg-[#e8f2f2] p-3" data-testid="enroll-result">
          <div className="mb-2 flex items-center justify-between gap-2">
            <strong className="text-[#034751]">New Teacher IDs and starting passwords</strong>
            <button type="button" className="btn-outline-sm" onClick={() => setMade([])}>Close</button>
          </div>
          <table className="w-full text-sm">
            <tbody>
              {made.map((t) => (
                <tr key={t.id} className="border-t border-[#034751]/15">
                  <td className="py-1 pr-3 font-mono font-extrabold">{t.id}</td>
                  <td className="py-1 pr-3">{t.name}</td>
                  <td className="py-1 font-mono">{t.password || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="mt-2 text-xs text-gray-600">Each teacher signs in at /teacher with Google the first time (their Gmail gets locked to the ID — set it in Security if you know it), then with this ID and password.</p>
        </div>
      )}
      <form onSubmit={submit}>
        <div className="table-wrap">
          <table className="dynamic-table" style={{ minWidth: 1350 }}>
            <thead>
              <tr><th>Teacher Full Name</th><th>WhatsApp</th><th>Panel Category</th><th>Department</th><th>Salary Type</th><th>Fixed Salary</th><th>Method</th><th>Account/Mobile</th><th>Bank Name</th><th>Branch</th><th aria-label="Remove" /></tr>
            </thead>
            <tbody>
              {rows.map((r) => {
                const isBank = r.method === 'Bank';
                return (
                  <tr key={r.key}>
                    <td><input className="m-input" placeholder="Full Name" value={r.name} onChange={(e) => update(r.key, 'name', e.target.value)} aria-label="Teacher name" /></td>
                    <td style={{ minWidth: 170 }}>
                      <input className="m-input" type="tel" placeholder="01XXXXXXXXX" value={r.whatsapp} onChange={(e) => update(r.key, 'whatsapp', e.target.value)} aria-label="WhatsApp" aria-invalid={Boolean(phoneIssue(r))} />
                      {phoneIssue(r) && <div className="mt-1 text-xs font-bold" style={{ color: '#b42318' }} role="alert">{phoneIssue(r)}</div>}
                    </td>
                    <td><Combobox value={r.category} onChange={(v) => update(r.key, 'category', v)} options={CATEGORY_OPTIONS} aria-label="Category" /></td>
                    <td><Combobox value={r.department} onChange={(v) => update(r.key, 'department', v)} options={DEPARTMENTS} placeholder="Select dept." aria-label="Department" /></td>
                    <td><Combobox value={r.salaryType} onChange={(v) => update(r.key, 'salaryType', v)} options={SALARY_TYPES} aria-label="Salary type" /></td>
                    <td><input type="number" min="0" className="m-input in-cut" placeholder="0" disabled={r.salaryType !== 'Package'} value={r.packageAmount} onChange={(e) => update(r.key, 'packageAmount', e.target.value)} aria-label="Fixed salary" /></td>
                    <td><Combobox value={r.method} onChange={(v) => update(r.key, 'method', v)} options={PAYMENT_METHODS} aria-label="Payment method" /></td>
                    <td><input className="m-input" placeholder="Account / Ref" value={r.account} onChange={(e) => update(r.key, 'account', e.target.value)} aria-label="Account" /></td>
                    <td><Combobox disabled={!isBank} value={r.bankName} onChange={(v) => update(r.key, 'bankName', v)} options={BD_BANKS} placeholder="Search bank…" aria-label="Bank name" /></td>
                    <td><input className="m-input" placeholder="Branch" disabled={!isBank} value={r.branchName} onChange={(e) => update(r.key, 'branchName', e.target.value)} aria-label="Branch" /></td>
                    <td>
                      <button type="button" className="btn-del-row" aria-label="Remove row" onClick={() => (rows.length > 1 ? setRows(rows.filter((x) => x.key !== r.key)) : toast('At least one entry row is required.', 'info'))}>×</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
          <button type="button" className="btn-add-row" onClick={() => setRows([...rows, blank()])}>+ Add Another Teacher</button>
          <button type="submit" className="btn-teal" disabled={busy}>{busy ? 'Saving…' : 'Save All Teachers'}</button>
        </div>
      </form>
    </div>
  );
}
