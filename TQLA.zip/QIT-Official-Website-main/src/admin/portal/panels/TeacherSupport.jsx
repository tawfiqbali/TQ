import { useCallback, useEffect, useMemo, useState } from 'react';
import { CheckCircle2, Hourglass, RefreshCw, Send, Trash2, X } from 'lucide-react';
import { profileAttr } from '../components/ProfileOpener';
import { deleteTeacherInquiry, listTeacherInquiries, updateTeacherInquiry } from '../../../lib/teacherData';
import { useConfirm } from '../../../components/ui/Confirm';
import '../../staff/staff.css';
import { useToast } from '../../../components/ui/Toast';

export const INQUIRY_CATEGORIES = { general: 'General question', issue: 'Problem / issue', leave: 'Leave request', salary: 'Salary', other: 'Other' };
const STATUS = { open: 'Open', in_progress: 'In progress', resolved: 'Solved' };
const fmtDate = (d) => (d ? new Date(`${d}T12:00:00`).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '');

function InquiryCard({ item, onSaved, onDeleted, focused }) {
  const toast = useToast();
  const confirm = useConfirm();
  const [reply, setReply] = useState(item.admin_reply || '');
  const [busy, setBusy] = useState(false);
  // v186: "Send to teacher" asks: In progress or Solved?
  const [asking, setAsking] = useState(false);
  const send = async (status) => {
    setAsking(false);
    setBusy(true);
    try {
      const row = await updateTeacherInquiry(item.id, { status, admin_reply: reply.trim() || null });
      onSaved(row);
      toast(status === 'resolved' ? 'Sent to the teacher — marked Solved.' : 'Sent to the teacher — marked In progress.');
    } catch (e) {
      toast(e.message, 'error');
    } finally {
      setBusy(false);
    }
  };
  // v154: a resolved request can be cleared from the list
  const remove = async () => {
    if (!(await confirm({ title: 'Clear this request?', message: `"${item.subject}" from ${item.teacher_name || item.teacher_id} is removed for good (also from the teacher's list).`, confirmText: 'Clear', tone: 'danger' }))) return;
    setBusy(true);
    try {
      await deleteTeacherInquiry(item.id);
      toast('Request cleared.');
      onDeleted(item.id);
    } catch (e) {
      toast(e.message, 'error');
      setBusy(false);
    }
  };
  return (
    <article id={`inq-${item.id}`} className={`rv-card ${item.status === 'resolved' ? 'reviewed' : ''}`} style={focused ? { boxShadow: '0 0 0 3px #DBA66B' } : undefined}>
      <div className="rv-head">
        <div>
          <div className="rv-name">{item.subject}</div>
          <div className="rv-sub"><span className="p-link" {...profileAttr('teacher', item.teacher_id)}>{item.teacher_name || '—'}</span> ({item.teacher_id}) · {new Date(item.created_at).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' })}</div>
        </div>
        <span className={`st-badge ${item.status}`}>{STATUS[item.status]}</span>
      </div>
      <div className="rv-row"><b>Type</b><span>{INQUIRY_CATEGORIES[item.category]}</span></div>
      {item.category === 'leave' && (item.leave_from || item.leave_to) && (
        <div className="rv-row"><b>Leave dates</b><span>{fmtDate(item.leave_from)}{item.leave_to && item.leave_to !== item.leave_from ? ` → ${fmtDate(item.leave_to)}` : ''}</span></div>
      )}
      <div className="rv-row"><b>Message</b><span>{item.message}</span></div>
      <label className="rv-sub" htmlFor={`reply-${item.id}`}>Reply to the teacher (they see it on their dashboard and get a notification)</label>
      <textarea id={`reply-${item.id}`} className="m-input" rows={2} value={reply} onChange={(e) => setReply(e.target.value)} />
      <div className="rv-actions items-center">
        <button type="button" className="btn-teal inline-flex items-center gap-1.5" disabled={busy} onClick={() => setAsking((x) => !x)} aria-expanded={asking} data-testid={`inq-send-${item.id}`}>
          <Send className="h-4 w-4" aria-hidden="true" /> {busy ? 'Sending…' : 'Send to teacher'}
        </button>
        {item.status === 'resolved' && (
          <button type="button" className="btn-danger ml-auto inline-flex items-center gap-1" onClick={remove} disabled={busy} data-testid={`inq-del-${item.id}`}><Trash2 className="h-3.5 w-3.5" aria-hidden="true" /> Clear</button>
        )}
      </div>
      {asking && (
        <div className="inq-pick qit-pop-in" role="dialog" aria-label="Send as" data-testid={`inq-pick-${item.id}`}>
          <div className="inq-pick-head">
            <span>Send to {item.teacher_name || item.teacher_id} as…</span>
            <button type="button" className="inq-pick-x" onClick={() => setAsking(false)} aria-label="Cancel"><X className="h-4 w-4" /></button>
          </div>
          <div className="inq-pick-btns">
            <button type="button" className="inq-pick-btn is-progress" onClick={() => send('in_progress')} data-testid="inq-progress"><Hourglass className="h-4 w-4" aria-hidden="true" /> In progress<small>still being handled</small></button>
            <button type="button" className="inq-pick-btn is-solved" onClick={() => send('resolved')} data-testid="inq-solved"><CheckCircle2 className="h-4 w-4" aria-hidden="true" /> Solved<small>done — the teacher gets a notice</small></button>
          </div>
        </div>
      )}
    </article>
  );
}

// Executives: questions, problems and leave requests sent from the Teacher Dashboard
export default function TeacherSupport({ focusId = '' }) {
  const [items, setItems] = useState(null);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState(focusId ? 'all' : 'open');
  // Opened from a notification: show that request and scroll to it
  useEffect(() => {
    if (!focusId || !items) return;
    setFilter('all');
    requestAnimationFrame(() => document.getElementById(`inq-${focusId}`)?.scrollIntoView({ behavior: 'smooth', block: 'center' }));
  }, [focusId, items]);

  const load = useCallback(async () => {
    setError('');
    try {
      setItems(await listTeacherInquiries());
    } catch (e) {
      setError(e.message);
      setItems([]);
    }
  }, []);
  useEffect(() => {
    load();
  }, [load]);

  const counts = useMemo(() => {
    const c = { all: 0, open: 0, in_progress: 0, resolved: 0 };
    (items || []).forEach((i) => {
      c.all += 1;
      c[i.status] += 1;
    });
    return c;
  }, [items]);
  const shown = (items || []).filter((i) => filter === 'all' || i.status === filter);

  return (
    <div className="box-card">
      <div className="card-header-bar">
        <h2 className="card-title">Teacher support &amp; leave requests</h2>
        <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={load}><RefreshCw className="h-3.5 w-3.5" /> Refresh</button>
      </div>
      <div className="rv-counts" role="group" aria-label="Filter by status">
        {[['open', 'Open'], ['in_progress', 'In progress'], ['resolved', 'Solved'], ['all', 'All']].map(([k, label]) => (
          <button key={k} type="button" className="rv-count" aria-pressed={filter === k} onClick={() => setFilter(k)}>{label} · {counts[k]}</button>
        ))}
      </div>
      {error && <p className="setup-box mb-4 text-sm font-bold" role="alert">{error}</p>}
      {items === null ? <p className="rv-empty">Loading…</p> : !shown.length ? <p className="rv-empty">Nothing here.</p> : (
        <div className="rv-grid">
          {shown.map((i) => (
            <InquiryCard key={`${i.id}-${i.updated_at}`} item={i} focused={i.id === focusId} onSaved={(row) => setItems((list) => list.map((x) => (x.id === row.id ? row : x)))} onDeleted={(id) => setItems((list) => list.filter((x) => x.id !== id))} />
          ))}
        </div>
      )}
    </div>
  );
}
