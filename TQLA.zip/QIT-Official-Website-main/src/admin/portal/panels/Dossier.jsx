import { profileAttr } from '../components/ProfileOpener';
import { forwardRef, useCallback, useLayoutEffect, useRef, useState } from 'react';
import { useSiteData } from '../../../context/SiteDataContext';
import { CEO_SIGNATURE_DATA_URL } from '../lib/ceoSignature';
import { GRADES, detectCountryFromPhone, ratingScore, splitPhones, toBengaliNumerals, translateText } from '../lib/constants';
import { DEFAULT_PORTAL_CONTENT, fillText } from '../lib/portalContent';

/**
 * The printed progress report: two A4 pages.
 *   Page 1 — letterhead, report details, student & class details, letter to
 *            the guardian / student, attendance summary, and the skills
 *            evaluation when it fits (a long letter moves it to page 2).
 *   Page 2 — (evaluation), achievements, next goals, teacher remarks, tips
 *            for the coming month (when there is room), grading key, signatures.
 * The same markup is shown in the preview and sent to the print window, so
 * all styles live in dossier.css.js. Every word comes from `portal`
 * (Portal Contents tab → saved text, falling back to lib/portalContent.js).
 */
const Dossier = forwardRef(function Dossier({ r, student, teacher, portal = DEFAULT_PORTAL_CONTENT }, ref) {
  const { content } = useSiteData();
  const contact = content?.site?.contact || {};
  const isBn = r.lang === 'BN';
  const x = portal.report[isBn ? 'BN' : 'EN'];
  const show = portal.layout;
  const n = (v) => (isBn ? toBengaliNumerals(v) : v);
  // Rating / grade / category label as written in Portal Contents
  const T = (v) => x.ratings?.[v] || translateText(v, isBn);

  const total = Number(r.total) || 0;
  const attended = Math.min(total || Infinity, Number(r.attended) || 0);
  const missed = Math.max(0, total - attended);
  const pct = total ? Math.round((attended / total) * 1000) / 10 : 0;
  const phones = splitPhones(student.phone);
  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  const monthIndex = String(new Date(`${r.month} 1, 2000`).getMonth() + 1).padStart(2, '0');
  const reference = `QIT-PR-${String(student.id).replace(/[^A-Z0-9]/gi, '')}-${r.year}${monthIndex}`;
  const issued = new Date().toLocaleDateString(isBn ? 'bn-BD' : 'en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
  const attendanceNote = pct >= 90 ? x.noteExcellent : pct >= 75 ? x.noteGood : x.noteLow;

  // Filling page 1 (so it never ends with a big empty space). Tried in order:
  //   eval      – skills evaluation under the attendance summary
  //   evalTight – the same with slightly tighter spacing on page 1
  //   tips      – evaluation stays on page 2; the tips box goes on page 1
  //   none      – nothing extra (a very long letter)
  // Any space still left is shared evenly between the sections of the page.
  const MODES = ['eval', 'evalTight', 'tips', 'none'];
  const [modeIdx, setModeIdx] = useState(0);
  const mode = MODES[modeIdx];
  const evalFirst = mode === 'eval' || mode === 'evalTight';
  const page1 = useRef(null);
  const sig = JSON.stringify([r, student?.name, student?.phone, student?.classTime, teacher?.name, portal?.report, portal?.layout]);
  const measure = useCallback(() => {
    const el = page1.current;
    if (!el) return;
    el.classList.add('d-measure'); // natural height, without the shared spacing
    const body = el.querySelector('.d-body');
    const foot = el.querySelector('.d-foot');
    // 74 px page padding + 14 px safety for the print margins (a little larger)
    const need = body.offsetHeight + foot.offsetHeight + 74 + 14;
    el.classList.remove('d-measure');
    if (need > 1123) setModeIdx((i) => Math.min(i + 1, MODES.length - 1));
  }, []);
  useLayoutEffect(() => setModeIdx(0), [sig]);
  useLayoutEffect(() => {
    if (mode === 'none') return undefined;
    measure();
    let alive = true;
    document.fonts?.ready?.then(() => alive && measure());
    return () => {
      alive = false;
    };
  });
  const hasTips = show.showTips !== false && Boolean(x.tip1 || x.tip2 || x.tip3);

  const skills = [
    [x.skillTajweed, r.tajweed],
    [x.skillHifz, r.hifz],
    [x.skillMurajaah, r.murajaah],
    [x.skillFluency, r.fluency],
  ];

  const evaluation = (
    <>
      <h3 className="d-section">{x.secEvaluation}</h3>
      <div className="d-eval">
        <table>
          <thead>
            <tr><th>{x.colArea}</th><th>{x.colRating}</th>{show.showLevelBars && <th className="w-bar">{x.colLevel}</th>}</tr>
          </thead>
          <tbody>
            {skills.map(([label, value]) => (
              <tr key={label}>
                <td className="strong">{label}</td>
                <td>{T(value)}</td>
                {show.showLevelBars && <td className="w-bar"><div className="d-mini"><i style={{ width: `${ratingScore(value)}%` }} /></div></td>}
              </tr>
            ))}
          </tbody>
        </table>
        <div className="d-grade">
          <span>{x.overallGrade}</span>
          <strong>{T(r.overallScore)}</strong>
        </div>
      </div>
    </>
  );

  const tipsBox = (
    <div className="d-tips">
      <span>{x.secTips}</span>
      <ol>
        {[x.tip1, x.tip2, x.tip3].filter(Boolean).map((tip, i) => (
          <li key={i}><b>{n(i + 1)}</b><p>{tip}</p></li>
        ))}
      </ol>
    </div>
  );

  const Letterhead = () => (
    <header className="d-head">
      <div className="d-brand">
        <img src={`${origin}/brand/logo-mark.png`} alt="" className="d-logo" />
        <div>
          <div className="d-org">{x.orgName}</div>
          <div className="d-org-sub">{x.orgSubtitle}</div>
        </div>
      </div>
      <div className="d-doc">
        <div className="d-doc-title">{x.docTitle}</div>
        <div className="d-doc-period">{T(r.month)} {n(r.year)}</div>
      </div>
    </header>
  );

  const Footer = ({ page }) => (
    <footer className="d-foot">
      <span>{fillText(x.footerText, { email: contact.email || '', phone: contact.phone || '' }).replace(/^\s*•\s*|\s*•\s*$/g, '')}</span>
      <span>{fillText(x.pageLabel, { page: n(page), total: n(2) })}</span>
    </footer>
  );

  return (
    <div ref={ref} className={`qit-dossier ${isBn ? 'bn' : ''}`}>
      {/* ---------------- Page 1 ---------------- */}
      <section className="d-page d-p1" ref={page1} data-eval={evalFirst ? 'page1' : 'page2'} data-mode={mode}>
        <div className="d-body">
          <Letterhead />

          <div className={`d-meta ${show.showReference ? '' : 'no-ref'}`}>
            {show.showReference && <div><span>{x.metaReference}</span><strong>{reference}</strong></div>}
            <div><span>{x.metaPeriod}</span><strong>{T(r.month)} {n(r.year)}</strong></div>
            <div><span>{x.metaIssued}</span><strong>{issued}</strong></div>
            <div><span>{x.metaPreparedFor}</span><strong>{r.reportType === 'Student' ? x.audienceStudent : x.audienceGuardian}</strong></div>
          </div>

          <i className="d-gap" aria-hidden="true" />
          <h3 className="d-section">{x.secDetails}</h3>
          <div className="d-info">
            <table>
              <tbody>
                <tr><th>{x.fStudentName}</th><td className="strong"><span {...profileAttr('student', student.id)}>{student.name}</span></td></tr>
                <tr><th>{x.fStudentId}</th><td>{student.id}</td></tr>
                <tr><th>{x.fWhatsapp}</th><td>{phones.length ? phones.map((p) => <div key={p}>{n(p)}</div>) : '—'}</td></tr>
                <tr><th>{x.fCountry}</th><td>{detectCountryFromPhone(phones[0], isBn)}</td></tr>
              </tbody>
            </table>
            <table>
              <tbody>
                <tr><th>{x.fTeacher}</th><td className="strong">{teacher ? <span {...profileAttr('teacher', teacher.id)}>{teacher.name}</span> : student.teacherId || x.notAssigned}</td></tr>
                <tr><th>{x.fDepartment}</th><td>{teacher?.department ? T(teacher.department) : '—'}</td></tr>
                <tr><th>{x.fPanel}</th><td>{teacher ? T(teacher.category) : '—'}</td></tr>
                <tr><th>{x.fClassTime}</th><td>{student.classTime ? n(student.classTime) : '—'}</td></tr>
              </tbody>
            </table>
          </div>

          <i className="d-gap" aria-hidden="true" />
          {show.showLetter && <div className="d-letter">{r.greeting}</div>}

          <i className="d-gap" aria-hidden="true" />
          <h3 className="d-section">{x.secAttendance}</h3>
          <div className="d-att">
            <div className="d-kpi"><span>{x.kScheduled}</span><strong>{n(total)}</strong></div>
            <div className="d-kpi ok"><span>{x.kAttended}</span><strong>{n(attended)}</strong></div>
            <div className="d-kpi bad"><span>{x.kMissed}</span><strong>{n(missed)}</strong></div>
            <div className="d-kpi rate"><span>{x.kRate}</span><strong>{n(pct)}%</strong></div>
          </div>
          {show.showAttendanceBar && (
            <>
              <div className="d-bar" aria-hidden="true"><i style={{ width: `${Math.min(100, pct)}%` }} /></div>
              <p className="d-bar-note">{attendanceNote}</p>
            </>
          )}

          <i className="d-gap" aria-hidden="true" />
          {evalFirst && evaluation}
          {mode === 'tips' && hasTips && tipsBox}
        </div>
        <Footer page={1} />
      </section>

      <hr className="page-break" />

      {/* ---------------- Page 2 ---------------- */}
      <section className="d-page d-p2">
        <div className="d-body">
          <Letterhead />

          {!evalFirst && evaluation}

          <i className="d-gap" aria-hidden="true" />
          <div className="d-two">
            <div className="d-note good"><span>{x.achievements}</span><p>{r.achievements || '—'}</p></div>
            <div className="d-note next"><span>{x.goals}</span><p>{r.goals || '—'}</p></div>
          </div>

          <i className="d-gap" aria-hidden="true" />
          <div className="d-remarks">
            <span>{x.remarks}</span>
            <p>{r.remarks || '—'}</p>
          </div>

          <i className="d-gap" aria-hidden="true" />
          {evalFirst && hasTips && tipsBox}

          <i className="d-gap" aria-hidden="true" />
          {show.showGradingKey && <h3 className="d-section">{x.secGrading}</h3>}
          {show.showGradingKey && <div className="d-key">
            {GRADES.map((g) => {
              const [label, code] = T(g).split(/\s*[(（]/);
              return (
                <div key={g} className={g === r.overallScore ? 'on' : ''}>
                  <strong>{(code || '').replace(/[)）]/g, '')}</strong>
                  <span>{label}</span>
                </div>
              );
            })}
          </div>}
        </div>

        <div>
          <div className="d-sign">
            {show.showTeacherSignature ? (
              <div className="d-sig">
                <div className="d-sig-space" />
                <div className="d-sig-line" />
                <strong>{teacher ? teacher.name : x.teacherRole}</strong>
                <span>{x.teacherRole}</span>
              </div>
            ) : <div />}
            {show.showSeal ? (
              <div className="d-seal" aria-hidden="true">
                <div>QIT</div>
                <span>{x.sealText}</span>
              </div>
            ) : <div />}
            <div className="d-sig">
              <img src={CEO_SIGNATURE_DATA_URL} alt="Signature of the CEO" className="d-sig-img" />
              <div className="d-sig-line" />
              <strong>{x.ceoTitle}</strong>
              <span>{x.ceoOrg}</span>
            </div>
          </div>
          <Footer page={2} />
        </div>
      </section>
    </div>
  );
});

export default Dossier;
