import PanelNotes from '../components/PanelNotes';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { byTeacherOrder } from '../lib/constants';
import { AlertTriangle, Check, KeyRound, LockKeyhole, LogOut, Mail, Pencil, RefreshCw, Search, ShieldCheck, Smartphone, Trash2, UserPlus, X } from 'lucide-react';
import { usePortal } from '../PortalContext';
import { isGmail, signOut } from '../../../lib/auth';
import {
  addExecutive, addJunior, changeExecutive, changeJunior, removeExecutive, removeJunior, juniorPasswordInfo, setJuniorPassword,
  executivePinLength, securityOverview, setExecutivePassword, setTeacherGmail, signOutTeacher,
} from '../../../lib/teacherData';
import { useConfirm } from '../../../components/ui/Confirm';
import { useToast } from '../../../components/ui/Toast';
import '../../staff/staff.css';

// What each security log entry means
const EVENTS = {
  signed_in: ['Signed in', 'ok'],
  signed_in_took_over: ['Signed in on a new device (old one signed out)', 'info'],
  bad_password: ['Wrong Teacher ID or password', 'warn'],
  admin_signed_in: ['Executive signed in', 'ok'],
  bad_admin_password: ['Wrong Executive password', 'bad'],
  admin_blocked: ['Blocked: not an Executive Gmail', 'bad'],
  admin_password_changed: ['Executive password changed', 'warn'],
  wrong_gmail: ['Blocked: wrong Gmail for this Teacher ID', 'bad'],
  gmail_linked: ['Gmail locked to Teacher ID', 'info'],
  old_login_used: ['Signed in with an earlier ID / password (shown the new one)', 'info'],
  gmail_changed: ['Gmail changed by the office', 'info'],
  gmail_removed: ['Gmail removed by the office', 'info'],
  new_teacher: ['New Teacher ID', 'info'],
  link_requested: ['Asked to link (waiting for approval)', 'info'],
  link_approved: ['Link approved by the office', 'info'],
  signed_out_by_office: ['Signed out by the office', 'info'],
  executive_added: ['Executive added', 'info'],
  executive_removed: ['Executive removed', 'warn'],
  executive_changed: ['Executive Gmail changed', 'info'],
  junior_added: ['Junior Admin added', 'info'],
  junior_removed: ['Junior Admin removed', 'warn'],
  junior_changed: ['Junior Admin Gmail changed', 'info'],
};
const TONE = {
  ok: { bg: '#e8f5ee', fg: '#166534' },
  info: { bg: '#e8f2f2', fg: '#034751' },
  warn: { bg: '#fef6e4', fg: '#92400e' },
  bad: { bg: '#fdecec', fg: '#b91c1c' },
};

const when = (v) => (v ? new Date(v).toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }) : '—');
const ago = (v) => {
  if (!v) return '';
  const m = Math.round((Date.now() - new Date(v).getTime()) / 60000);
  if (m < 2) return 'just now';
  if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60);
  return h < 48 ? `${h} h ago` : `${Math.round(h / 24)} days ago`;
};

function Pill({ tone = 'info', children, title }) {
  const c = TONE[tone];
  return <span title={title} className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-extrabold" style={{ background: c.bg, color: c.fg }}>{children}</span>;
}

// One Gmail row with Edit / Remove, used for Executives and Junior Admins
// Executives set the one password every Junior Admin enters after Google
function JuniorPassword({ act }) {
  const [info, setInfo] = useState(null);
  const [pw, setPw] = useState('');
  const [show, setShow] = useState(false);
  const load = () => juniorPasswordInfo().then(setInfo).catch(() => setInfo(null));
  useEffect(() => { load(); }, []);
  const ok = pw.length >= 6 && pw.length <= 64;
  return (
    <form className="mt-4 rounded-xl border p-3" style={{ borderColor: 'var(--c-box-border)', background: 'var(--c-box-bg)' }} data-testid="junior-password"
      onSubmit={async (e) => { e.preventDefault(); if (!ok) return; await act(() => setJuniorPassword(pw), 'Junior Admin password saved. Every Junior Admin enters it at the next sign-in.'); setPw(''); load(); }}>
      <label htmlFor="jr-pw" className="block text-sm font-extrabold">Junior Admin password</label>
      <p className="mb-2 text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>
        {info?.set ? `Set${info.changedBy ? ` by ${info.changedBy}` : ''} on ${new Date(info.changedAt).toLocaleDateString('en-GB')}. ` : 'Not set yet: each Junior Admin is using a PIN of their own. '}
        One password for all Junior Admins, asked after Google and after every sign-out. 6 to 64 characters; 6 to 8 digits make it a PIN. It is stored scrambled, so it cannot be shown again.
      </p>
      <div className="flex flex-wrap gap-2">
        <input id="jr-pw" className="m-input" style={{ maxWidth: 260 }} type={show ? 'text' : 'password'} autoComplete="new-password" value={pw} onChange={(e) => setPw(e.target.value)} placeholder={info?.set ? 'New password' : 'Choose a password'} data-testid="jr-pw" />
        <button type="button" className="btn-outline-sm" onClick={() => setShow((v) => !v)}>{show ? 'Hide' : 'Show'}</button>
        <button type="submit" className="btn-teal" disabled={!ok} data-testid="jr-pw-save">{info?.set ? 'Change password' : 'Set password'}</button>
      </div>
    </form>
  );
}

function GmailRow({ item, you, onSave, onRemove, removeLabel, meta }) {
  const [edit, setEdit] = useState(false);
  const [val, setVal] = useState(item.email);
  const [busy, setBusy] = useState(false);
  const save = async (e) => {
    e.preventDefault();
    setBusy(true);
    if (await onSave(item.email, val)) setEdit(false);
    setBusy(false);
  };
  return (
    <div className="team-row" data-testid={`gmail-row-${item.email}`}>
      {edit ? (
        <form onSubmit={save} className="flex min-w-0 flex-1 flex-wrap items-center gap-2">
          <input className="m-input" style={{ maxWidth: 320 }} type="email" value={val} onChange={(e) => setVal(e.target.value)} aria-label="New Gmail" autoFocus />
          <button type="submit" className="btn-teal inline-flex items-center gap-1" disabled={busy || !isGmail(val)}><Check className="h-4 w-4" /> Save</button>
          <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={() => { setEdit(false); setVal(item.email); }}><X className="h-3.5 w-3.5" /> Cancel</button>
        </form>
      ) : (
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2 font-extrabold"><Mail className="h-4 w-4 opacity-60" /> <span className="break-all">{item.email}</span> {you && <Pill tone="ok">You</Pill>}</div>
          <div className="rv-sub">{meta}</div>
        </div>
      )}
      {!edit && (
        <div className="flex flex-wrap gap-2">
          <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={() => setEdit(true)}><Pencil className="h-3.5 w-3.5" /> Edit Gmail</button>
          <button type="button" className="btn-outline-sm inline-flex items-center gap-1" style={{ color: '#b91c1c', borderColor: '#f3c4c4' }} onClick={() => onRemove(item)}>
            <Trash2 className="h-3.5 w-3.5" /> {removeLabel}
          </button>
        </div>
      )}
    </div>
  );
}

function AddGmail({ label, onAdd, testid }) {
  const [val, setVal] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    if (await onAdd(val.trim().toLowerCase())) setVal('');
    setBusy(false);
  };
  return (
    <form onSubmit={submit} className="mb-4 flex flex-wrap gap-2">
      <input type="email" className="m-input" style={{ maxWidth: 340 }} placeholder="name@gmail.com" value={val} onChange={(e) => setVal(e.target.value)} aria-label={label} data-testid={testid} />
      <button type="submit" className="btn-teal inline-flex items-center gap-1" disabled={busy || !isGmail(val.trim())}><UserPlus className="h-4 w-4" /> {label}</button>
    </form>
  );
}

function ExecPassword({ changedAt, changedBy, onSave }) {
  const [cur, setCur] = useState('');
  const [pw, setPw] = useState('');
  const [pw2, setPw2] = useState('');
  const [busy, setBusy] = useState(false);
  // 'pin' = digits only (6 to 8): the sign-in screen shows PIN boxes and opens by itself
  const [kind, setKind] = useState('password');
  const [pinNow, setPinNow] = useState(null);
  const refresh = () => executivePinLength().then(setPinNow).catch(() => {});
  useEffect(() => { refresh(); }, []);
  const isPin = kind === 'pin';
  const digits = (x) => x.replace(/\D/g, '').slice(0, 8);
  const valid = isPin ? /^\d{6,8}$/.test(pw) : pw.length >= 6;
  const mismatch = pw2 && pw !== pw2;
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    if (await onSave(cur, pw)) { setCur(''); setPw(''); setPw2(''); refresh(); }
    setBusy(false);
  };
  const word = isPin ? 'PIN' : 'password';
  return (
    <div className="box-card" data-testid="exec-password-card">
      <div className="card-header-bar"><h2 className="card-title inline-flex items-center gap-2"><KeyRound className="h-5 w-5" /> Executive password / PIN</h2><PanelNotes><p>The second step after Google for every Executive. Changing it does not sign anyone out; they use the new one next time.
        {' '}<strong data-testid="exec-kind-now">Now: {pinNow ? `a ${pinNow}-digit PIN` : 'a text password'}.</strong>
        {changedAt && changedBy !== 'setup' ? ` Last changed ${when(changedAt)}${changedBy ? ` by ${changedBy}` : ''}.` : ''}</p></PanelNotes></div>
      <div className="mb-3 flex flex-wrap gap-2" role="radiogroup" aria-label="Change to">
        {[['password', 'Password (letters and numbers)'], ['pin', 'PIN (digits only)']].map(([k, label]) => (
          <button key={k} type="button" role="radio" aria-checked={kind === k} className={`dir-tab ${kind === k ? 'active' : ''}`} data-testid={`exec-kind-${k}`}
            onClick={() => { setKind(k); setPw(''); setPw2(''); }}>{label}</button>
        ))}
      </div>
      {isPin && <p className="mb-3 text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>A PIN is 6 to 8 digits. The sign-in screen then shows one box per digit and opens the admin panel as soon as the last digit is typed. Avoid easy ones such as 123456 or a birthday.</p>}
      <form onSubmit={submit} className="flex flex-wrap items-end gap-2">
        <label className="text-xs font-bold">Current password or PIN<input type="password" autoComplete="current-password" className="m-input mt-1" style={{ maxWidth: 200 }} value={cur} onChange={(e) => setCur(e.target.value)} data-testid="exec-cur" /></label>
        <label className="text-xs font-bold">{isPin ? 'New PIN (6 to 8 digits)' : 'New password (6+)'}<input type="password" inputMode={isPin ? 'numeric' : undefined} autoComplete="new-password" className="m-input mt-1" style={{ maxWidth: 200 }} value={pw} onChange={(e) => setPw(isPin ? digits(e.target.value) : e.target.value)} data-testid="exec-new" /></label>
        <label className="text-xs font-bold">Repeat new {word}<input type="password" inputMode={isPin ? 'numeric' : undefined} autoComplete="new-password" className="m-input mt-1" style={{ maxWidth: 200 }} value={pw2} onChange={(e) => setPw2(isPin ? digits(e.target.value) : e.target.value)} aria-invalid={mismatch || undefined} data-testid="exec-new2" /></label>
        <button type="submit" className="btn-teal inline-flex items-center gap-1" disabled={busy || !cur || !valid || pw !== pw2} data-testid="exec-save"><Check className="h-4 w-4" /> Change to this {word}</button>
        {mismatch && <span className="text-xs font-bold text-red-700">The two entries don’t match.</span>}
      </form>
    </div>
  );
}

function TeacherRow({ t, onGmail, onSignOut }) {
  const [edit, setEdit] = useState(false);
  const [val, setVal] = useState(t.gmail || '');
  const [busy, setBusy] = useState(false);
  const save = async (e) => {
    e.preventDefault();
    setBusy(true);
    if (await onGmail(t, val)) setEdit(false);
    setBusy(false);
  };
  return (
    <tr data-testid={`sec-teacher-${t.teacherId}`}>
      <td className="whitespace-nowrap font-extrabold">{t.teacherId}</td>
      <td>{t.name || '—'}</td>
      <td style={{ minWidth: 220 }}>
        {edit ? (
          <form onSubmit={save} className="flex flex-wrap items-center gap-1.5">
            <input className="m-input" style={{ maxWidth: 240, padding: '6px 10px' }} type="email" value={val} onChange={(e) => setVal(e.target.value)} aria-label={`Gmail for ${t.teacherId}`} autoFocus />
            <button type="submit" className="btn-teal inline-flex items-center gap-1" style={{ padding: '6px 10px' }} disabled={busy || !isGmail(val.trim())}><Check className="h-3.5 w-3.5" /> Save</button>
            <button type="button" className="btn-outline-sm" onClick={() => { setEdit(false); setVal(t.gmail || ''); }} aria-label="Cancel"><X className="h-3.5 w-3.5" /></button>
          </form>
        ) : t.gmail ? (
          <div>
            <div className="flex items-center gap-1.5 break-all font-bold"><LockKeyhole className="h-3.5 w-3.5 shrink-0 text-[#034751]" /> {t.gmail}</div>
            <div className="rv-sub">{t.linked ? (t.firstSignInDone ? 'Locked · ID + password needed' : 'Locked · first sign-in not done yet') : 'On record · not signed in yet'}</div>
          </div>
        ) : (
          <div>
            <Pill tone="warn">No Gmail yet</Pill>
            <div className="rv-sub">The next Gmail with the right ID + password gets locked to it</div>
          </div>
        )}
      </td>
      <td style={{ minWidth: 170 }}>
        {t.off ? <Pill tone="bad">Sign-in switched off</Pill> : t.online ? (
          <div>
            <Pill tone="ok"><Smartphone className="h-3 w-3" /> {t.device || 'Signed in'}</Pill>
            <div className="rv-sub">since {when(t.since)}{t.lastSeen ? ` · seen ${ago(t.lastSeen)}` : ''}</div>
          </div>
        ) : <span className="rv-sub">{t.lastSeen ? `Signed out · last seen ${ago(t.lastSeen)}` : 'Not signed in'}</span>}
        {t.failed24h > 0 && <div className="mt-1"><Pill tone={t.failed24h >= 5 ? 'bad' : 'warn'}><AlertTriangle className="h-3 w-3" /> {t.failed24h} failed in 24 h</Pill></div>}
        {t.pending > 0 && <div className="mt-1"><Pill tone="warn">{t.pending} waiting for approval (Teacher Dashboards)</Pill></div>}
      </td>
      <td>
        {!edit && (
          <div className="flex flex-wrap gap-1.5">
            <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={() => setEdit(true)}><Pencil className="h-3.5 w-3.5" /> {t.gmail ? 'Edit' : 'Set'} Gmail</button>
            {t.gmail && <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={() => onGmail(t, '')}><Trash2 className="h-3.5 w-3.5" /> Remove</button>}
            {t.online && <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={() => onSignOut(t)}><LogOut className="h-3.5 w-3.5" /> Sign out</button>}
          </div>
        )}
      </td>
    </tr>
  );
}

/**
 * Executives: who can sign in, and how.
 *  - Executives and Junior Admins: only the Gmails listed here, through Google
 *  - Teachers: their Gmail is locked to their Teacher ID; one device at a time
 *  - Security log: sign-ins, blocked attempts, changes
 */
export default function Security() {
  const { liveTick, load: reloadPortal } = usePortal();
  const confirm = useConfirm();
  const toast = useToast();
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [q, setQ] = useState('');
  const [logFilter, setLogFilter] = useState('all');

  const load = useCallback(async () => {
    setError('');
    try {
      setData(await securityOverview());
    } catch (e) {
      setError(e.message);
    }
  }, []);
  useEffect(() => {
    load();
  }, [load, liveTick]);
  // Keep "signed in" status current while the page is open
  useEffect(() => {
    const t = setInterval(() => document.visibilityState === 'visible' && load(), 60_000);
    return () => clearInterval(t);
  }, [load]);

  const act = async (fn, okMsg) => {
    try {
      await fn();
      if (okMsg) toast(okMsg);
      await load();
      return true;
    } catch (e) {
      toast(e.message, 'error');
      return false;
    }
  };

  const teachers = useMemo(() => {
    const s = q.trim().toLowerCase();
    const list = [...(data?.teachers || [])].sort(byTeacherOrder);
    return s ? list.filter((t) => `${t.teacherId} ${t.name} ${t.gmail}`.toLowerCase().includes(s)) : list;
  }, [data, q]);
  const events = useMemo(() => {
    const list = data?.events || [];
    if (logFilter === 'warn') return list.filter((e) => ['warn', 'bad'].includes(EVENTS[e.kind]?.[1]));
    if (logFilter === 'admin') return list.filter((e) => /executive|junior|admin_|gmail_changed|gmail_removed|signed_out_by_office|link_approved/.test(e.kind));
    return list;
  }, [data, logFilter]);

  if (error && !data) {
    return (
      <div className="box-card" role="alert">
        <p className="font-bold">{error}</p>
        <button type="button" className="btn-teal mt-3" onClick={load}>Try again</button>
      </div>
    );
  }
  if (!data) return <div className="box-card text-center">Loading security…</div>;

  const execCount = data.executives.length;
  const online = data.teachers.filter((t) => t.online).length;
  const locked = data.teachers.filter((t) => t.gmail).length;
  const warn24 = data.teachers.reduce((n, t) => n + (t.failed24h || 0), 0);

  const removeExec = async (x) => {
    const self = x.you;
    if (execCount <= 1) return toast('This is the last Executive. Add another Executive first.', 'error');
    const ok = await confirm({
      title: self ? 'Remove yourself as Executive?' : 'Remove this Executive?',
      message: self
        ? `${x.email} will lose Executive access at once and be signed out on every device. Only another Executive can add you back.`
        : `${x.email} loses Executive access at once and is signed out on every device.`,
      confirmText: self ? 'Remove me' : 'Remove Executive',
      tone: 'danger',
    });
    if (!ok) return;
    if (await act(() => removeExecutive(x.email), `${x.email} is no longer an Executive.`) && self) {
      await signOut({ full: true });
      window.location.assign('/admin/login');
    }
  };
  const removeJr = async (j) => {
    if (!(await confirm({ title: 'Remove Junior Admin?', message: `${j.email} loses access at once and is signed out.`, confirmText: 'Remove access', tone: 'danger' }))) return;
    await act(() => removeJunior(j.email), `${j.email} removed.`);
  };
  const teacherGmail = async (t, email) => {
    const e = email.trim().toLowerCase();
    const msg = e
      ? `${t.teacherId} will work ONLY with ${e}. ${t.gmail ? `${t.gmail} is unlinked and signed out. ` : ''}The first Google sign-in with ${e} opens the dashboard; after that Teacher ID + password too. The password stays the same.`
      : `${t.teacherId} will have no Gmail. ${t.gmail} is unlinked and signed out. The next Gmail that signs in with the right Teacher ID + password is locked to it.`;
    if (!(await confirm({ title: e ? `Lock ${t.teacherId} to this Gmail?` : `Remove ${t.teacherId}'s Gmail?`, message: msg, confirmText: e ? 'Save Gmail' : 'Remove Gmail', tone: e ? undefined : 'danger' }))) return false;
    const ok = await act(() => setTeacherGmail(t.teacherId, e), e ? `${t.teacherId} is locked to ${e}.` : `${t.teacherId} has no Gmail now.`);
    if (ok) reloadPortal?.();
    return ok;
  };
  const teacherOut = async (t) => {
    if (!(await confirm({ title: `Sign ${t.teacherId} out?`, message: `${t.name || t.teacherId} is signed out of ${t.device || 'their device'} now. They can sign in again with their Gmail + Teacher ID + password.`, confirmText: 'Sign out' }))) return;
    await act(() => signOutTeacher(t.teacherId), `${t.teacherId} signed out.`);
  };

  return (
    <div data-testid="security-panel">
      <div className="box-card">
        <div className="card-header-bar">
          <div>
            <h2 className="card-title inline-flex items-center gap-2"><ShieldCheck className="h-5 w-5" /> Security</h2>
          </div>
          <PanelNotes><p>Who can sign in, on which Gmail, on which device.</p></PanelNotes>
          <button type="button" className="btn-muted inline-flex items-center gap-1" onClick={load}><RefreshCw className="h-4 w-4" /> Refresh</button>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {[
            ['Executives', execCount, 'Google + Executive password'],
            ['Junior Admins', data.juniors.length, 'Google sign-in only'],
            ['Teachers locked to a Gmail', `${locked} / ${data.teachers.length}`, `${online} signed in now`],
            ['Failed teacher sign-ins (24 h)', warn24, warn24 ? 'See the log below' : 'All clear'],
          ].map(([k, v, s]) => (
            <div key={k} className="rounded-xl border p-3" style={{ borderColor: 'var(--c-box-border)' }}>
              <div className="text-xs font-bold" style={{ color: 'var(--text-muted)' }}>{k}</div>
              <div className="text-2xl font-extrabold" style={{ color: '#034751' }}>{v}</div>
              <div className="rv-sub">{s}</div>
            </div>
          ))}
        </div>
        <ul className="mt-4 grid gap-2 text-sm font-semibold sm:grid-cols-3" style={{ color: '#034751' }}>
          <li className="flex gap-2 rounded-xl bg-[#e8f2f2] p-3"><ShieldCheck className="h-4 w-4 shrink-0" /> Executives: only the Gmails below, through Google, then the Executive password. Junior Admins: only their Gmails, through Google. Any other Gmail is blocked.</li>
          <li className="flex gap-2 rounded-xl bg-[#e8f2f2] p-3"><KeyRound className="h-4 w-4 shrink-0" /> Teachers: first time Gmail only; after that the same Gmail + Teacher ID + password. Another Gmail is blocked.</li>
          <li className="flex gap-2 rounded-xl bg-[#e8f2f2] p-3"><Smartphone className="h-4 w-4 shrink-0" /> Teachers can use several devices at a time, always with the Gmail locked to their ID. 5 wrong passwords pause sign-in for 15 minutes.</li>
        </ul>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="box-card" style={{ margin: 0 }}>
          <div className="card-header-bar"><h2 className="card-title">Executives</h2><PanelNotes><p>Full access. Any Executive can add or remove Executives, including themselves. The last Executive can’t be removed.</p></PanelNotes></div>
          <AddGmail label="Add Executive" testid="add-exec" onAdd={(e) => act(() => addExecutive(e), `${e} is now an Executive. They sign in with Google.`)} />
          {data.executives.map((x) => (
            <GmailRow key={x.email} item={x} you={x.you}
              meta={`Added ${x.addedBy && x.addedBy !== 'setup' ? `by ${x.addedBy} ` : ''}${when(x.createdAt)} · last sign-in ${x.lastSignIn ? ago(x.lastSignIn) : 'never'}`}
              onSave={(o, n) => act(() => changeExecutive(o, n), `Executive changed to ${n}.`)}
              onRemove={removeExec} removeLabel={x.you ? 'Remove me' : 'Remove'} />
          ))}
        </div>
        <div className="box-card" style={{ margin: 0 }}>
          <div className="card-header-bar"><h2 className="card-title">Junior Admins</h2><PanelNotes><p>Teacher list, students and monthly reports only. No salaries, fees or settings.</p></PanelNotes></div>
          <AddGmail label="Add Junior Admin" testid="add-junior" onAdd={(e) => act(() => addJunior(e), `${e} can now sign in as a Junior Admin with Google.`)} />
          {!data.juniors.length ? <p className="rv-empty">No Junior Admins yet.</p> : data.juniors.map((j) => (
            <GmailRow key={j.email} item={j}
              meta={`Added ${j.addedBy ? `by ${j.addedBy} ` : ''}${when(j.createdAt)} · last sign-in ${j.lastSignIn ? ago(j.lastSignIn) : 'never'}`}
              onSave={(o, n) => act(() => changeJunior(o, n), `Junior Admin changed to ${n}.`)}
              onRemove={removeJr} removeLabel="Remove" />
          ))}
          <JuniorPassword act={act} />
        </div>
      </div>

      <ExecPassword changedAt={data.passwordChangedAt} changedBy={data.passwordChangedBy}
        onSave={(c, n) => act(() => setExecutivePassword(c, n), 'Executive password / PIN changed.')} />

      <div className="box-card">
        <div className="card-header-bar">
          <h2 className="card-title">Teacher Gmail locks & devices</h2>
          <label className="relative block" style={{ minWidth: 220 }}>
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 opacity-50" />
            <input className="m-input" style={{ paddingLeft: 34 }} placeholder="Search ID, name or Gmail" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search teachers" />
          </label>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm" style={{ borderCollapse: 'separate', borderSpacing: '0 6px' }}>
            <thead>
              <tr className="text-left text-xs uppercase" style={{ color: 'var(--text-muted)' }}>
                <th className="px-2">ID</th><th className="px-2">Teacher</th><th className="px-2">Locked Gmail</th><th className="px-2">Device</th><th className="px-2">Actions</th>
              </tr>
            </thead>
            <tbody className="[&_td]:border-y [&_td]:border-[var(--c-box-border)] [&_td]:bg-white [&_td]:px-2 [&_td]:py-2 [&_td]:align-top">
              {teachers.map((t) => <TeacherRow key={t.teacherId} t={t} onGmail={teacherGmail} onSignOut={teacherOut} />)}
            </tbody>
          </table>
          {!teachers.length && <p className="rv-empty">No teachers match.</p>}
        </div>
      </div>

      <div className="box-card">
        <div className="card-header-bar">
          <h2 className="card-title">Security log</h2>
          <select className="m-input" style={{ maxWidth: 220 }} value={logFilter} onChange={(e) => setLogFilter(e.target.value)} aria-label="Show">
            <option value="all">Everything</option>
            <option value="warn">Warnings only</option>
            <option value="admin">Admin changes</option>
          </select>
        </div>
        {!events.length ? <p className="rv-empty">Nothing here yet.</p> : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs uppercase" style={{ color: 'var(--text-muted)' }}>
                  <th className="px-2 py-1">When</th><th className="px-2 py-1">What</th><th className="px-2 py-1">Gmail</th><th className="px-2 py-1">Teacher</th><th className="px-2 py-1">Details</th>
                </tr>
              </thead>
              <tbody>
                {events.map((e) => {
                  const [label, tone] = EVENTS[e.kind] || [e.kind, 'info'];
                  return (
                    <tr key={e.id} className="border-t" style={{ borderColor: 'var(--c-box-border)' }} data-testid="sec-event">
                      <td className="whitespace-nowrap px-2 py-1.5">{when(e.at)}</td>
                      <td className="px-2 py-1.5"><Pill tone={tone}>{label}</Pill></td>
                      <td className="break-all px-2 py-1.5">{e.email || '—'}</td>
                      <td className="whitespace-nowrap px-2 py-1.5 font-bold">{e.teacher_id || '—'}</td>
                      <td className="px-2 py-1.5" style={{ color: 'var(--text-muted)' }}>{[e.detail, e.device].filter(Boolean).join(' · ') || '—'}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
