import { useState } from 'react';
import { Banknote, DatabaseZap, FileSpreadsheet, FileText, GraduationCap, HardDrive, ListChecks, RefreshCw, Users } from 'lucide-react';
import { usePortal } from '../PortalContext';
import { SHEETS_URL, fetchSheetsData, importIntoSupabase, portalApi, readBrowserData } from '../lib/api';
import '../../staff/staff.css';
import { useConfirm } from '../../../components/ui/Confirm';
import { useToast } from '../../../components/ui/Toast';

const summary = (d) =>
  `${d.teachers?.length || 0} teachers · ${d.students?.length || 0} students · ${d.payments?.length || 0} salary payments · ${d.reports?.length || 0} saved reports`;

/**
 * Executives: copy the existing portal records into Supabase (once).
 * Records keep their IDs, so running it again updates instead of duplicating.
 */
export default function ImportData() {
  const { db, adminEmail, load } = usePortal();
  const confirm = useConfirm();
  const toast = useToast();
  const [url, setUrl] = useState(SHEETS_URL);
  const [password, setPassword] = useState('');
  const [preview, setPreview] = useState(null); // { source, data }
  const [busy, setBusy] = useState('');
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');
  const browser = readBrowserData();

  const fetchSheet = async (e) => {
    e.preventDefault();
    setBusy('fetch');
    setError('');
    setMsg('');
    try {
      const data = await fetchSheetsData(url.trim(), adminEmail, password);
      setPreview({ source: 'your Google Sheet', data });
    } catch (err) {
      setError(`Could not read the Google Sheet: ${err.message}`);
    } finally {
      setBusy('');
    }
  };

  const doImport = async (source, data) => {
    const current = db.teachers.length || db.students.length;
    if (current && !(await confirm({ title: 'Import into the cloud database?', message: `Supabase already has ${summary(db)}.\n\nImport ${summary(data)} from ${source}? Records with the same ID are replaced; others are kept.`, confirmText: 'Import' }))) return;
    setBusy('import');
    setError('');
    try {
      const counts = await importIntoSupabase(data, (key, n) => setMsg(`Copying ${n} ${key}…`));
      toast('Import finished.');
      setMsg(`Done — imported ${counts.teachers} teachers, ${counts.students} students, ${counts.payments} payments and ${counts.reports} reports from ${source}.`);
      setPreview(null);
      setPassword('');
      await load();
    } catch (err) {
      setError(`Import stopped: ${err.message}`);
    } finally {
      setBusy('');
    }
  };

  const seed = async () => {
    if (!(await confirm({ title: 'Add the standard teacher list?', message: 'Names only, with new IDs. Teachers already present by name are skipped.', confirmText: 'Add teachers' }))) return;
    setBusy('seed');
    setError('');
    try {
      const rows = await portalApi.seedTeachers();
      setMsg(`Added ${rows.length} teachers from the standard list.`);
      await load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy('');
    }
  };

  return (
    <div className="box-card">
      <div className="card-header-bar">
        <h2 className="card-title inline-flex items-center gap-2"><DatabaseZap className="h-5 w-5" /> Import data into the cloud database</h2>
        <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={() => load()} disabled={busy !== ''}><RefreshCw className="h-3.5 w-3.5" aria-hidden="true" /> Refresh</button>
      </div>
      <p className="mb-3 text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>
        Teachers, students and salaries live in Supabase, shared with the Teacher Dashboard. This is what the cloud database holds right now:
      </p>
      <div className="imp-counts mb-6" role="list" aria-label="Now in Supabase">
        {[[Users, 'Teachers', db.teachers.length, 'teal'], [GraduationCap, 'Students', db.students.length, 'teal'], [Banknote, 'Salary payments', db.payments.length, 'gold'], [FileText, 'Saved reports', db.reports.length, 'slate']].map(([Icon, label, n, tone]) => (
          <div key={label} role="listitem" className={`imp-count tone-${tone}`}>
            <span className="tone-chip"><Icon className="h-4 w-4" aria-hidden="true" /></span>
            <span><b>{n}</b><small>{label}</small></span>
          </div>
        ))}
      </div>

      <p className="imp-heading">Ways to bring data in</p>

      <div className="imp-src imp-teal">
        <div className="imp-src-head">
          <span className="imp-step">1</span>
          <div>
            <div className="imp-src-title"><FileSpreadsheet className="h-4 w-4" aria-hidden="true" /> From the Google Sheet (old portal)</div>
            <p className="imp-src-when">Use once, to move everything from the old Google-Sheet portal.</p>
          </div>
        </div>
        <form onSubmit={fetchSheet} className="grid gap-3 md:grid-cols-[2fr_1fr_auto] md:items-end">
          <div className="form-group" style={{ margin: 0 }}>
            <label htmlFor="imp-url">Apps Script web-app URL</label>
            <input id="imp-url" className="m-input" placeholder="https://script.google.com/macros/s/…/exec" value={url} onChange={(e) => setUrl(e.target.value)} required />
          </div>
          <div className="form-group" style={{ margin: 0 }}>
            <label htmlFor="imp-pw">Sheet admin password</label>
            <input id="imp-pw" type="password" className="m-input" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </div>
          <button type="submit" className="btn-teal" disabled={busy !== '' || !url.trim() || !password}>{busy === 'fetch' ? 'Reading…' : 'Read the Sheet'}</button>
        </form>
        <p className="mt-2 text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>Signs in as {adminEmail} with the password the old portal used (admin5050 unless it was changed).</p>
      </div>

      {browser && (
        <div className="imp-src imp-gold">
          <div className="imp-src-head">
            <span className="imp-step">2</span>
            <div>
              <div className="imp-src-title"><HardDrive className="h-4 w-4" aria-hidden="true" /> From this browser (demo-mode records)</div>
              <p className="imp-src-when">Records typed into the portal on this computer before the cloud database was set up: {summary(browser)}.</p>
            </div>
          </div>
          <button type="button" className="btn-teal" disabled={busy !== ''} onClick={() => setPreview({ source: 'this browser', data: browser })}>Review &amp; import</button>
        </div>
      )}

      <div className="imp-src imp-slate">
        <div className="imp-src-head">
          <span className="imp-step">{browser ? 3 : 2}</span>
          <div>
            <div className="imp-src-title"><ListChecks className="h-4 w-4" aria-hidden="true" /> Standard teacher list</div>
            <p className="imp-src-when">Only if you are starting fresh: adds the QIT teacher names without students or salaries. Teachers already in the list are skipped.</p>
          </div>
        </div>
        <button type="button" className="btn-add-row" disabled={busy !== ''} onClick={seed}>{busy === 'seed' ? 'Adding…' : 'Add standard teacher list'}</button>
      </div>

      {preview && (
        <div className="setup-box mb-4" role="region" aria-label="Import preview">
          <p className="font-extrabold">Ready to import from {preview.source}:</p>
          <p className="mb-3 text-sm font-semibold">{summary(preview.data)}</p>
          <div className="flex gap-2">
            <button type="button" className="btn-teal" disabled={busy !== ''} onClick={() => doImport(preview.source, preview.data)}>{busy === 'import' ? 'Importing…' : 'Import now'}</button>
            <button type="button" className="btn-muted" onClick={() => setPreview(null)}>Cancel</button>
          </div>
        </div>
      )}
      {msg && <p className="text-sm font-bold" role="status" style={{ color: 'var(--c-teal-mid)' }}>{msg}</p>}
      {error && <p className="mt-2 rounded-lg bg-red-50 px-3 py-2 text-sm font-bold text-red-800" role="alert">{error}</p>}
    </div>
  );
}
