import { useCallback, useEffect, useMemo, useState } from 'react';
import { KeyRound, Search, Trash2, UserPlus, X } from 'lucide-react';
import PanelNotes from '../components/PanelNotes';
import { PortalModal } from './common';
import { usePortal } from '../PortalContext';
import { isGmail } from '../../../lib/auth';
import { matchSearch } from '../../../lib/search';
import {
  STATUSES, kindLabel, listCounselors, listRecords, onRecordsChange, removeCounselor, saveCounselor, statusLabel, updateRecord,
} from '../../../lib/counselorData';
import { useConfirm } from '../../../components/ui/Confirm';
import { useToast } from '../../../components/ui/Toast';
import '../../staff/staff.css';
import '../../../counselor/counselor.css';

const when = (v) => (v ? new Date(v).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '');

/**
 * v188 (Executives): Academic Counselors and their work.
 *  - add a counselor's Gmail with a name, side (male / female teachers) and a
 *    first password; they choose their own password at the first sign-in
 *  - every counselor record; cases sent to the office can be answered here
 */
export default function Counseling() {
  const { db } = usePortal();
  const toast = useToast();
  const confirm = useConfirm();
  const [people, setPeople] = useState(null);
  const [records, setRecords] = useState(null);
  const [error, setError] = useState('');
  const [edit, setEdit] = useState(null); // {} = new, or a counselor
  const [filter, setFilter] = useState('office');
  const [who, setWho] = useState('');
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(null);

  const load = useCallback(async () => {
    try {
      const [p, r] = await Promise.all([listCounselors(), listRecords({ limit: 1000 })]);
      setPeople(p);
      setRecords(r);
      setError('');
    } catch (e) {
      setError(e.message);
      setPeople((x) => x || []);
      setRecords((x) => x || []);
    }
  }, []);
  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    let stop = () => {};
    let t;
    onRecordsChange(() => { clearTimeout(t); t = setTimeout(load, 300); }).then((s) => { stop = s; }).catch(() => {});
    return () => { clearTimeout(t); stop(); };
  }, [load]);

  const studentName = useMemo(() => Object.fromEntries(db.students.map((s) => [s.id, s.name])), [db.students]);
  const teacherName = useMemo(() => Object.fromEntries(db.teachers.map((t) => [t.id, t.name])), [db.teachers]);
  const shown = (records || []).filter((r) => (filter === 'all' || (filter === 'active' ? r.status !== 'solved' : r.status === filter))
    && (!who || r.counselor_email === who)
    && matchSearch(`${r.title} ${studentName[r.student_id] || ''} ${r.student_id || ''} ${r.counselor_name || ''}`, q));
  const officeCount = (records || []).filter((r) => r.status === 'office').length;

  const remove = async (c) => {
    if (!(await confirm({ title: 'Remove this Academic Counselor?', message: `${c.email} loses access at once. Their notes stay.`, confirmText: 'Remove', tone: 'danger' }))) return;
    try {
      await removeCounselor(c.email);
      toast(`${c.email} removed.`);
      load();
    } catch (e) {
      toast(e.message, 'error');
    }
  };

  return (
    <>
      <div className="box-card">
        <div className="card-header-bar">
          <h2 className="card-title">Academic Counselors</h2>
          <div className="flex items-center gap-2">
            <PanelNotes>
              <p>Counselors sign in at <strong>/admin/login</strong> → “Academic Counselor” → Continue with Google → their password. The first password is the one you set here; they must choose their own at the first sign-in.</p>
              <p>They see students and teachers (a female counselor: the female teachers’ students), the teachers’ monthly reports and the shared counseling notes. They never see fees, teacher shares, salaries or bank details.</p>
            </PanelNotes>
            <button type="button" className="btn-teal" onClick={() => setEdit({})} data-testid="cs-add"><UserPlus className="h-4 w-4" /> Add counselor</button>
          </div>
        </div>
        {error && <p className="setup-box mb-3 text-sm font-bold" role="alert">{error}</p>}
        {people === null ? <p className="rv-empty">Loading…</p> : !people.length ? <p className="rv-empty">No Academic Counselor yet.</p> : people.map((c) => (
          <div key={c.email} className="team-row" data-testid={`cs-row-${c.email}`}>
            <div className="min-w-0">
              <div className="font-extrabold">{c.name || c.email} <span className="cn-kind">{c.gender === 'female' ? 'Female side' : 'Male side'}</span>{c.mustChange ? <span className="cn-pill cn-in_progress ml-1">First password not changed yet</span> : null}</div>
              <div className="rv-sub">{c.email} · {c.records} record{c.records === 1 ? '' : 's'}{c.lastSignIn ? ` · last sign-in ${when(c.lastSignIn)}` : ''}</div>
            </div>
            <div className="flex flex-wrap gap-2">
              <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={() => setEdit(c)}><KeyRound className="h-3.5 w-3.5" /> Edit / reset password</button>
              <button type="button" className="btn-danger inline-flex items-center gap-1" onClick={() => remove(c)}><Trash2 className="h-3.5 w-3.5" /> Remove</button>
            </div>
          </div>
        ))}
      </div>

      <div className="box-card">
        <div className="card-header-bar">
          <h2 className="card-title">Counseling records</h2>
          <span className="rv-sub">{officeCount} waiting for the office</span>
        </div>
        <div className="mb-3 flex flex-wrap gap-2">
          {[['office', 'Sent to the office'], ['active', 'Not solved'], ['solved', 'Solved'], ['all', 'All']].map(([k, l]) => (
            <button key={k} type="button" className={`dir-tab ${filter === k ? 'active' : ''}`} onClick={() => setFilter(k)} data-testid={`cs-f-${k}`}>{l}</button>
          ))}
          <select className="premium-select" value={who} onChange={(e) => setWho(e.target.value)} aria-label="Counselor">
            <option value="">All counselors</option>
            {(people || []).map((c) => <option key={c.email} value={c.email}>{c.name || c.email}</option>)}
          </select>
        </div>
        <label className="cn-search">
          <Search className="h-4 w-4" aria-hidden="true" />
          <input className="m-input" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search title, student or counselor" />
        </label>
        {records === null ? <p className="rv-empty">Loading…</p> : !shown.length ? <p className="rv-empty">Nothing here.</p> : shown.map((r) => (
          <div key={r.id} className="cn-rec" data-testid={`cs-rec-${r.id}`}>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="cn-kind">{kindLabel(r.kind)}</span><strong>{r.title}</strong><span className={`cn-pill cn-${r.status}`}>{statusLabel(r.status)}</span>
              </div>
              <div className="rv-sub">{studentName[r.student_id] ? `${studentName[r.student_id]} (${r.student_id})` : 'General'}{r.teacher_id ? ` · ${teacherName[r.teacher_id] || r.teacher_id}` : ''} · {r.counselor_name || r.counselor_email} · {when(r.created_at)}</div>
              {r.office_reply && <div className="cn-reply"><strong>Office:</strong> {r.office_reply}</div>}
            </div>
            <button type="button" className="btn-outline-sm" onClick={() => setOpen(r)} data-testid={`cs-open-${r.id}`}>Open</button>
          </div>
        ))}
      </div>

      {edit && <CounselorForm c={edit} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); load(); }} />}
      {open && <Reply r={open} studentName={studentName[open.student_id]} onClose={() => setOpen(null)} onSaved={(x) => { setRecords((list) => list.map((y) => (y.id === x.id ? x : y))); setOpen(null); }} />}
    </>
  );
}

function CounselorForm({ c, onClose, onSaved }) {
  const toast = useToast();
  const isNew = !c.email;
  const [v, setV] = useState({ email: c.email || '', name: c.name || '', gender: c.gender || 'male', password: '' });
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setV((x) => ({ ...x, [k]: e.target.value }));
  const save = async (e) => {
    e?.preventDefault();
    const email = v.email.trim().toLowerCase();
    if (!isGmail(email)) { toast('Enter a Gmail address (…@gmail.com).', 'error'); return; }
    if (!v.name.trim()) { toast('Write the counselor’s name.', 'error'); return; }
    if ((isNew || v.password) && (v.password.length < 6 || v.password.length > 64)) { toast('The password must be 6 to 64 characters.', 'error'); return; }
    setBusy(true);
    try {
      await saveCounselor({ email, name: v.name.trim(), gender: v.gender, password: v.password });
      toast(isNew ? `${email} can now sign in as an Academic Counselor.` : v.password ? 'Saved. The new password must be changed at the next sign-in.' : 'Saved.');
      onSaved();
    } catch (err) {
      toast(err.message, 'error');
      setBusy(false);
    }
  };
  return (
    <PortalModal onClose={onClose} labelledBy="cs-form-title">
      <form onSubmit={save} noValidate>
        <div className="mb-3 flex items-start justify-between gap-3">
          <h2 id="cs-form-title" className="card-title">{isNew ? 'Add Academic Counselor' : 'Edit Academic Counselor'}</h2>
          <button type="button" className="btn-icon-edit" onClick={onClose} aria-label="Close"><X className="h-4 w-4" /></button>
        </div>
        <div className="form-group"><label htmlFor="cs-email">Gmail</label><input id="cs-email" type="email" className="m-input" value={v.email} onChange={set('email')} disabled={!isNew} placeholder="name@gmail.com" data-testid="cs-email" /></div>
        <div className="form-group"><label htmlFor="cs-name">Name</label><input id="cs-name" className="m-input" value={v.name} onChange={set('name')} data-testid="cs-name" /></div>
        <div className="form-group">
          <label htmlFor="cs-gender">Works with</label>
          <select id="cs-gender" className="m-select" value={v.gender} onChange={set('gender')} data-testid="cs-gender">
            <option value="male">Male counselor: male & residential teachers’ students</option>
            <option value="female">Female counselor: female teachers’ students</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="cs-pw">{isNew ? 'First password' : 'New password (leave empty to keep)'}</label>
          <input id="cs-pw" type="text" autoComplete="off" className="m-input" value={v.password} onChange={set('password')} placeholder="6 or more characters" data-testid="cs-password" />
          <p className="rv-sub mt-1">Give this to the counselor. At their first sign-in they choose their own password.</p>
        </div>
        <div className="mt-4 flex justify-end"><button type="submit" className="btn-teal" disabled={busy} data-testid="cs-save">{busy ? 'Saving…' : 'Save'}</button></div>
      </form>
    </PortalModal>
  );
}

function Reply({ r, studentName, onClose, onSaved }) {
  const toast = useToast();
  const [reply, setReply] = useState(r.office_reply || '');
  const [status, setStatus] = useState(r.status);
  const [busy, setBusy] = useState(false);
  const save = async () => {
    setBusy(true);
    try {
      onSaved(await updateRecord(r.id, { office_reply: reply.trim() || null, status }));
      toast('Saved. The counselor sees it at once.');
    } catch (e) {
      toast(e.message, 'error');
      setBusy(false);
    }
  };
  return (
    <PortalModal onClose={onClose} labelledBy="cs-reply-title">
      <div className="mb-3 flex items-start justify-between gap-3">
        <h2 id="cs-reply-title" className="card-title">{r.title}</h2>
        <button type="button" className="btn-icon-edit" onClick={onClose} aria-label="Close"><X className="h-4 w-4" /></button>
      </div>
      <p className="rv-sub">{kindLabel(r.kind)} · {studentName || 'General'} · {r.counselor_name || r.counselor_email} · {when(r.created_at)}</p>
      {r.kind === 'exam' && r.data?.exam ? <p className="mt-2 text-sm font-bold">{r.data.exam}: {r.data.marks ?? '—'}{r.data.total ? ` / ${r.data.total}` : ''}{r.data.grade ? ` · ${r.data.grade}` : ''}</p> : null}
      {r.details && <p className="cn-details mt-2">{r.details}</p>}
      <div className="form-group mt-3">
        <label htmlFor="cs-reply">Office reply</label>
        <textarea id="cs-reply" className="m-input" rows={4} value={reply} onChange={(e) => setReply(e.target.value)} placeholder="What the office decided or did" data-testid="cs-reply" />
      </div>
      <div className="form-group">
        <label htmlFor="cs-status">Status</label>
        <select id="cs-status" className="m-select" value={status} onChange={(e) => setStatus(e.target.value)} data-testid="cs-status">
          {STATUSES.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}
        </select>
      </div>
      <div className="mt-4 flex justify-end"><button type="button" className="btn-teal" onClick={save} disabled={busy} data-testid="cs-reply-save">{busy ? 'Saving…' : 'Save'}</button></div>
    </PortalModal>
  );
}
