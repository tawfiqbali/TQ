import PanelNotes from '../components/PanelNotes';
import { lazy, Suspense, useEffect, useMemo, useRef, useState } from 'react';
import TimePicker from '../../../components/ui/TimePicker';
import { BellRing, Copy, FileText, Megaphone, Printer, RotateCcw, Sparkles, Trash2 } from 'lucide-react';
import { AUDIENCES, SIGNERS, TYPES, buildNotice, detect, noticeNumber } from '../lib/noticeTemplates';
import { aikyaFontFace } from '../dossier.css.js';
import { useToast } from '../../../components/ui/Toast';
import { QIT_CONTEXT, askAI } from '../../../lib/ai';

const TeacherPush = lazy(() => import('../components/TeacherPush'));
const HISTORY = 'qit:notices';
const today = () => new Date().toISOString().slice(0, 10);
const readHistory = () => {
  try {
    return JSON.parse(localStorage.getItem(HISTORY) || '[]');
  } catch {
    return [];
  }
};
const writeHistory = (list) => {
  try {
    localStorage.setItem(HISTORY, JSON.stringify(list.slice(0, 12)));
  } catch {
    /* history is only a convenience */
  }
};
const EMPTY = { topic: '', subjBn: '', subjEn: '', type: 'general', audience: 'teachers', date: '', time: '', place: '', points: '', signer: 'ceo', issued: today(), number: '' };

// Letterhead print (Save as PDF from the print window)
function printNotice(text, lang) {
  const w = window.open('', '_blank');
  if (!w) return false;
  const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;');
  const lines = text.split('\n');
  const body = lines.slice(2).map((l) => {
    const bold = /^\*.*\*$/.test(l.trim());
    const t = esc(l.replace(/^\*|\*$/g, ''));
    return t.trim() ? `<p${bold ? ' class="b"' : ''}>${t}</p>` : '<p class="gap"></p>';
  }).join('');
  const o = window.location.origin;
  w.document.write(`<!doctype html><html lang="${lang}"><head><meta charset="utf-8"><title>Notice</title><style>${aikyaFontFace()}
@page{size:A4;margin:16mm 18mm}
body{font-family:${lang === 'bn' ? "'QIT Bangla Digits','Aikya','Hind Siliguri'," : ''}'Barlow',Arial,sans-serif;color:#0B2E31;font-size:15px;line-height:1.75;margin:0}
.head{display:flex;align-items:center;gap:14px;border-bottom:2px solid #0B2E31;padding-bottom:12px;position:relative}
.head:after{content:'';position:absolute;left:0;right:0;bottom:-6px;height:1px;background:#C89A3C}
.head img{width:56px;height:56px}
.org{font-size:22px;font-weight:800;line-height:1.2}.sub{font-size:12px;color:#5B7477;letter-spacing:.05em}
.title{margin:22px 0 10px;text-align:center}.title span{display:inline-block;border:2px solid #0B2E31;border-radius:6px;padding:4px 26px;font-weight:800;letter-spacing:.2em}
p{margin:0}.gap{height:10px}.b{font-weight:800}
</style></head><body><div class="head"><img src="${o}/brand/logo-mark.png" alt=""><div><div class="org">${lang === 'bn' ? 'কুরআন ইন্টারন্যাশনাল ইনস্টিটিউট' : 'Quran International Institute'}</div><div class="sub">quraninternational.academy</div></div></div>
<div class="title"><span>${lang === 'bn' ? 'নোটিশ' : 'NOTICE'}</span></div>${body}
<script>document.fonts.ready.then(()=>setTimeout(()=>window.print(),300))</script></body></html>`);
  w.document.close();
  return true;
}

/**
 * Executives: write a formal notice from a short topic. Bangla first, English
 * alongside; both editable, copy / WhatsApp / print (PDF).
 */
export default function NoticeMaker() {
  const toast = useToast();
  const [v, setV] = useState(EMPTY);
  const [auto, setAuto] = useState(true); // follow what the topic suggests until changed by hand
  const [edited, setEdited] = useState({ bn: null, en: null });
  const [history, setHistory] = useState(readHistory);
  const set = (k) => (e) => {
    setV((x) => ({ ...x, [k]: e.target.value }));
    setEdited({ bn: null, en: null });
    if (k === 'type' || k === 'audience') setAuto(false);
  };

  // Guess the kind of notice, audience, time and day from the topic
  useEffect(() => {
    if (!auto || !v.topic.trim()) return;
    const d = detect(v.topic);
    setV((x) => ({ ...x, type: d.type, audience: d.audience, time: x.time || d.time || '', date: x.date || d.date || '' }));
  }, [v.topic, auto]);

  const monthCount = history.filter((h) => (h.issued || '').slice(0, 7) === v.issued.slice(0, 7)).length + 1;
  const number = v.number.trim() || noticeNumber(v.issued, monthCount);
  const out = useMemo(() => {
    if (!v.topic.trim()) return { bn: '', en: '' };
    return buildNotice({ ...v, number });
  }, [v, number]);

  // Gemini writes the notice by itself a moment after the last change: a
  // precise subject and a fuller body for this topic, in the usual layout.
  // The built-in notice shows at once and stays whenever AI is not available.
  const [ai, setAi] = useState({ key: '', bn: '', en: '', state: 'idle', note: '' });
  const aiOff = useRef(false);
  const aiKey = JSON.stringify([v.topic, v.subjBn, v.subjEn, v.type, v.audience, v.date, v.time, v.place, v.points, v.signer, v.issued, number]);
  useEffect(() => {
    if (!v.topic.trim() || v.topic.trim().length < 6 || aiOff.current || (edited.bn !== null && edited.en !== null)) return undefined; // a saved or hand-edited notice is not rewritten
    let alive = true;
    const timer = setTimeout(async () => {
      setAi((x) => ({ ...x, state: 'writing', note: '' }));
      try {
        const facts = { instruction: v.topic, extraPoints: v.points, kind: TYPES.find((t) => t.key === v.type)?.en, audience: AUDIENCES.find((a) => a.key === v.audience)?.en, eventDate: v.date, eventTime: v.time, place: v.place, issuedOn: v.issued, noticeNumber: number, ownSubjectBangla: v.subjBn, ownSubjectEnglish: v.subjEn };
        const r = await askAI({
          json: true,
          system: `${QIT_CONTEXT}\n\nYou write formal office notices. The user's text under "instruction" is a PROMPT: it tells you what the notice is about and may also say what the body must contain, the tone, the length, points to include or leave out, and who it is for. Follow it exactly and write the notice it asks for. Return ONLY JSON: {"bn": "...", "en": "..."} — the full notice in Bangla and in English.\nRules:\n- The instruction decides the content. Include every point it asks for, in the order and detail it asks for; do not add topics it did not mention. If it asks for a length or style, obey it. Otherwise write 2 to 4 well-developed paragraphs: what it is, why it matters, exactly what the reader must do, and by when; use numbered points when the instruction lists several things.\n- Never copy the instruction into the notice and never mention that you were given instructions: write the finished notice itself.\n- Keep the layout of the sample notices: the same first two lines (reference number and date), a subject line wrapped in *asterisks* that states the real topic precisely, the greeting, the closing and the signature block, line breaks included.\n- Use the other facts given (date, time, place, extra points) unless the instruction says otherwise.\n- Understand the instruction even when it is informal, misspelled or mixes Bangla and English.\n- Do not invent facts (names, amounts, dates) that were not given. No markdown other than the *subject* line.\n- Bangla: natural formal Bangla with Bangla digits; English: formal British English. Both versions say the same thing.`,
          messages: [{ role: 'user', text: `Facts:\n${JSON.stringify(facts, null, 1)}\n\nSample notice (Bangla) to keep the layout of:\n${out.bn}\n\nSample notice (English) to keep the layout of:\n${out.en}` }],
        });
        if (!alive) return;
        if (!r?.bn || !r?.en) throw new Error('The AI answer was incomplete.');
        setAi({ key: aiKey, bn: String(r.bn), en: String(r.en), state: 'done', note: '' });
      } catch (e) {
        if (!alive) return;
        // not installed / no key: stop asking for this visit and keep the built-in writer
        if (/not installed|not switched on|Sign in/i.test(e.message)) aiOff.current = true;
        setAi((x) => ({ ...x, state: 'failed', note: e.message }));
      }
    }, 2200);
    return () => { alive = false; clearTimeout(timer); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [aiKey, edited.bn !== null && edited.en !== null]);
  const aiFresh = ai.key === aiKey && ai.bn;
  const text = { bn: edited.bn ?? (aiFresh ? ai.bn : out.bn), en: edited.en ?? (aiFresh ? ai.en : out.en) };
  // v179: the notice as a notification (title = the *subject* line)
  const [pushFor, setPushFor] = useState(null);
  const pushText = (lang) => {
    const all = String(text[lang] || '');
    const subj = (all.match(/\*([^*\n]+)\*/) || [])[1] || (lang === 'bn' ? v.subjBn : v.subjEn) || (lang === 'bn' ? 'নতুন নোটিশ' : 'New notice');
    return { title: subj.replace(/^\s*(বিষয়|Subject)\s*[:：]\s*/i, '').trim().slice(0, 140), body: all.replace(/\*/g, '').trim() };
  };

  const copy = async (lang) => {
    try {
      await navigator.clipboard.writeText(text[lang]);
      toast(lang === 'bn' ? 'বাংলা নোটিশ কপি হয়েছে।' : 'English notice copied.');
    } catch {
      toast('Copy did not work — select the text and copy it by hand.', 'error');
    }
  };
  const save = () => {
    if (!v.topic.trim()) return;
    const item = { id: Date.now(), ...v, number, bn: text.bn, en: text.en };
    const list = [item, ...history.filter((h) => h.number !== number)];
    setHistory(list);
    writeHistory(list);
    toast('Saved in Recent notices (this browser).');
  };
  const load = (h) => {
    setV({ ...EMPTY, ...h });
    setAuto(false);
    setEdited({ bn: h.bn, en: h.en });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  const remove = (id) => {
    const list = history.filter((h) => h.id !== id);
    setHistory(list);
    writeHistory(list);
  };
  const reset = () => {
    setV({ ...EMPTY, issued: today() });
    setAuto(true);
    setEdited({ bn: null, en: null });
  };

  // A plain function (not a component) so the text boxes keep focus while typing
  const output = (lang, title, primary) => (
    <section className="box-card" style={{ margin: 0, borderTop: `4px solid ${primary ? '#034751' : '#C89A3C'}` }} aria-labelledby={`nm-${lang}`}>
      <div className="card-header-bar">
        <h3 id={`nm-${lang}`} className="card-title" lang={lang}>{title}</h3>
        <div className="flex flex-wrap gap-2">
          <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={() => copy(lang)} disabled={!text[lang]}><Copy className="h-3.5 w-3.5" /> Copy</button>
          <a className="btn-outline-sm inline-flex items-center gap-1" href={`https://wa.me/?text=${encodeURIComponent(text[lang])}`} target="_blank" rel="noreferrer" aria-disabled={!text[lang]} style={!text[lang] ? { pointerEvents: 'none', opacity: 0.5 } : undefined}>WhatsApp</a>
          <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={() => printNotice(text[lang], lang) || toast('Allow pop-ups to print.', 'error')} disabled={!text[lang]}><Printer className="h-3.5 w-3.5" /> Print / PDF</button>
          {v.audience !== 'guardians' && <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={() => setPushFor(lang)} disabled={!text[lang]} data-testid={`notice-push-${lang}`}><BellRing className="h-3.5 w-3.5" /> Send to teachers’ phones</button>}
        </div>
      </div>
      <textarea
        className={`m-input ${lang === 'bn' ? 'bn' : ''}`}
        lang={lang}
        rows={primary ? 22 : 20}
        style={{ fontSize: lang === 'bn' ? 15 : 14, lineHeight: 1.7, fontFamily: lang === 'bn' ? "'QIT Bangla Digits','Aikya','Hind Siliguri',sans-serif" : undefined }}
        value={text[lang]}
        placeholder={lang === 'bn' ? 'উপরে বিষয় লিখলে এখানে নোটিশ তৈরি হবে…' : 'The English notice appears here…'}
        onChange={(e) => setEdited((x) => ({ ...x, [lang]: e.target.value }))}
        data-testid={`notice-${lang}`}
      />
      {edited[lang] !== null && <button type="button" className="btn-outline-sm mt-2 inline-flex items-center gap-1" onClick={() => setEdited((x) => ({ ...x, [lang]: null }))}><RotateCcw className="h-3.5 w-3.5" /> Undo my edits</button>}
    </section>
  );

  return (
    <>
      <div className="box-card" data-testid="notice-maker">
        <div className="card-header-bar">
          <div>
            <h2 className="card-title inline-flex items-center gap-2"><Megaphone className="h-5 w-5" /> Notice Maker</h2>
          </div>
          <PanelNotes><p>Write the topic in a few words (বাংলা or English). A formal notice is written in বাংলা and English — edit, copy, send on WhatsApp or print.</p></PanelNotes>
          <button type="button" className="btn-muted inline-flex items-center gap-1" onClick={reset}><RotateCcw className="h-4 w-4" /> New notice</button>
        </div>

        <div className="form-group">
          <label htmlFor="nm-topic">What is the notice about? · নোটিশের বিষয় <span className="text-red-700">*</span> <span className="ml-1 text-[11px] font-semibold normal-case" style={{ color: 'var(--text-muted)', letterSpacing: 0 }}>Write it like a prompt: the topic, what the body must say, tone, points to include. The notice is written from this.</span></label>
          <textarea id="nm-topic" className="m-input" rows={5} value={v.topic} onChange={set('topic')} placeholder="যেমন: আজ রাত ৯টায় অনলাইন শিক্ষকদের টিচার ড্যাশবোর্ড নিয়ে মিটিং   ·   e.g. Teacher Dashboard training for residential teachers tomorrow 11 am" data-testid="nm-topic" />
        </div>
        <p className="mb-3 flex flex-wrap items-center gap-2 text-xs font-bold" data-testid="nm-ai-status" data-state={!v.topic.trim() ? 'idle' : ai.state === 'writing' ? 'writing' : aiFresh ? 'ai' : 'builtin'}>
          {ai.state === 'writing' && <span className="ai-chip is-busy"><Sparkles className="h-3.5 w-3.5" /> Gemini is writing…</span>}
          {ai.state !== 'writing' && aiFresh && <span className="ai-chip"><Sparkles className="h-3.5 w-3.5" /> Written by Gemini — read it before sending</span>}
          {ai.state === 'failed' && !aiFresh && v.topic.trim() && <span className="ai-chip is-off" title={ai.note}>Built-in writer in use · {ai.note}</span>}
        </p>
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="form-group" style={{ margin: 0 }}>
            <label htmlFor="nm-subj-bn">বিষয় (বাংলা) — নিজে লিখতে চাইলে</label>
            <input id="nm-subj-bn" className="m-input bn" value={v.subjBn} onChange={set('subjBn')} placeholder={out.subjects?.bn || 'স্বয়ংক্রিয়ভাবে লেখা হবে'} data-testid="nm-subj-bn" />
          </div>
          <div className="form-group" style={{ margin: 0 }}>
            <label htmlFor="nm-subj-en">Subject (English) — only to write your own</label>
            <input id="nm-subj-en" className="m-input" value={v.subjEn} onChange={set('subjEn')} placeholder={out.subjects?.en || 'Written automatically'} data-testid="nm-subj-en" />
          </div>
        </div>

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          <div className="form-group" style={{ margin: 0 }}>
            <label htmlFor="nm-type">Kind of notice {auto && v.topic && <span className="ml-1 inline-flex items-center gap-0.5 text-[11px] font-bold text-amber-700"><Sparkles className="h-3 w-3" /> guessed</span>}</label>
            <select id="nm-type" className="m-select" value={v.type} onChange={set('type')} data-testid="nm-type">
              {TYPES.map((t) => <option key={t.key} value={t.key}>{t.en} · {t.bn}</option>)}
            </select>
          </div>
          <div className="form-group" style={{ margin: 0 }}>
            <label htmlFor="nm-aud">For</label>
            <select id="nm-aud" className="m-select" value={v.audience} onChange={set('audience')} data-testid="nm-aud">
              {AUDIENCES.map((a) => <option key={a.key} value={a.key}>{a.en} · {a.bn}</option>)}
            </select>
          </div>
          <div className="form-group" style={{ margin: 0 }}>
            <label htmlFor="nm-sign">Signed by</label>
            <select id="nm-sign" className="m-select" value={v.signer} onChange={set('signer')}>
              {SIGNERS.map((s) => <option key={s.key} value={s.key}>{s.en} · {s.bn}</option>)}
            </select>
          </div>
          <div className="form-group" style={{ margin: 0 }}>
            <label htmlFor="nm-date">Day (optional)</label>
            <input id="nm-date" type="date" className="m-input" value={v.date} onChange={set('date')} data-testid="nm-date" />
          </div>
          <div className="form-group" style={{ margin: 0 }}>
            <label htmlFor="nm-time">Time (optional, Bangladesh time)</label>
            <TimePicker id="nm-time" className="m-input" value={v.time} onChange={(x) => set('time')({ target: { value: x } })} clearable testId="nm-time" />
          </div>
          <div className="form-group" style={{ margin: 0 }}>
            <label htmlFor="nm-place">Place or link (optional)</label>
            <input id="nm-place" className="m-input" value={v.place} onChange={set('place')} placeholder="e.g. Zoom / Google Meet, QIT office, Savar" />
          </div>
        </div>
        <div className="mt-3 grid gap-3 lg:grid-cols-[1fr_16rem_16rem]">
          <div className="form-group" style={{ margin: 0 }}>
            <label htmlFor="nm-points">Extra points (optional, one per line — same in both notices)</label>
            <textarea id="nm-points" className="m-input" rows={3} value={v.points} onChange={set('points')} placeholder={'ফোনে টিচার ড্যাশবোর্ড খুলে আনবেন\nBring your Teacher ID'} />
          </div>
          <div className="form-group" style={{ margin: 0 }}>
            <label htmlFor="nm-issued">Date on the notice</label>
            <input id="nm-issued" type="date" className="m-input" value={v.issued} onChange={set('issued')} />
          </div>
          <div className="form-group" style={{ margin: 0 }}>
            <label htmlFor="nm-no">Notice number</label>
            <input id="nm-no" className="m-input" value={v.number} onChange={set('number')} placeholder={number} />
          </div>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          <button type="button" className="btn-teal inline-flex items-center gap-1" onClick={save} disabled={!v.topic.trim()} data-testid="nm-save"><FileText className="h-4 w-4" /> Save to Recent notices</button>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {output('bn', 'বাংলা নোটিশ', true)}
        {output('en', 'English notice', false)}
      </div>

      {history.length > 0 && (
        <div className="box-card">
          <h3 className="card-title mb-3">Recent notices <span className="text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>(saved in this browser)</span></h3>
          <ul className="divide-y" style={{ borderColor: '#eef2f3' }}>
            {history.map((h) => (
              <li key={h.id} className="flex flex-wrap items-center justify-between gap-2 py-2">
                <button type="button" className="text-left" onClick={() => load(h)}>
                  <strong className="block">{h.topic}</strong>
                  <span className="text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>{h.number} · {h.issued}</span>
                </button>
                <button type="button" className="btn-del-row" onClick={() => remove(h.id)} aria-label={`Remove ${h.topic}`}><Trash2 className="h-4 w-4" /></button>
              </li>
            ))}
          </ul>
        </div>
      )}
      {pushFor && <Suspense fallback={null}><TeacherPush onClose={() => setPushFor(null)} audience={v.audience} {...pushText(pushFor)} /></Suspense>}
    </>
  );
}
