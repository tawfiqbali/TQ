import { profileAttr } from '../components/ProfileOpener';
import { matchSearch } from '../../../lib/search';
import PanelNotes from '../components/PanelNotes';
import PhoneLinks from '../../../components/ui/PhoneLinks';
import { useCallback, useEffect, useMemo, useState, useDeferredValue } from 'react';
import { byTeacherOrder, catTone } from '../lib/constants';
import { Link } from 'react-router-dom';
import { ArrowRightLeft, BellRing, Check, GitMerge, IdCard, KeyRound, LayoutDashboard, Search, Trash2, UserPlus, Users } from 'lucide-react';
import { usePortal } from '../PortalContext';
import { fillTeacherIdGaps, teacherIdGaps } from '../../../lib/teacherData';
import { adminDisableTeacherLogin, adminRemoveTeacherAccount, adminSetTeacherPassword, adminTeacherLogins, changeTeacherId, linkTeacherAccount, listTeacherAccounts, mergeTeacher, resolveClaim, transferStudents } from '../../../lib/teacherData';
import { CategoryPicker, catOf, ID_CATEGORIES, IdCardResult, isNewStyleId, Modal, StudentPicker } from '../components/TeacherIdTools';
import PasswordDialog from '../components/PasswordDialog';
import Combobox from '../components/Combobox';
import { CATEGORIES } from '../lib/constants';
import { useConfirm } from '../../../components/ui/Confirm';
import { useToast } from '../../../components/ui/Toast';
import '../../staff/staff.css';
import { lazy, Suspense } from 'react';

const TeacherPush = lazy(() => import('../components/TeacherPush'));

// Next free ID per letter, from the Teachers List (the database decides the real one)
function useNextIds(teachers) {
  return useMemo(() => {
    const out = {};
    ID_CATEGORIES.forEach(({ letter }) => {
      const max = teachers.reduce((m, t) => {
        const x = String(t.id).match(new RegExp(`^QIT-${letter}(\\d+)$`));
        return x ? Math.max(m, Number(x[1])) : m;
      }, 0);
      out[letter] = `QIT-${letter}${String(max + 1).padStart(3, '0')}`;
    });
    return out;
  }, [teachers]);
}

/** Approve a new sign-up: choose the category (→ ID + password) and, if wanted, students to copy or cut in. */
function ApproveDialog({ account, db, logins, onClose, onDone }) {
  const nextIds = useNextIds(db.teachers);
  // 'new' = a new teacher (category → new ID); 'existing' = already in the
  // Teachers List under another spelling of their name → their own ID
  const [kind, setKind] = useState('new');
  const [existing, setExisting] = useState('');
  const free = useMemo(() => db.teachers.filter((t) => !logins?.[t.id]?.googleEmail)
    .map((t) => ({ value: t.id, label: `${t.name} (${t.id})${t.whatsapp && t.whatsapp !== 'N/A' ? ` · ${t.whatsapp}` : ''}` })), [db.teachers, logins]);
  const [cat, setCat] = useState('');
  const [picked, setPicked] = useState(new Set());
  const [mode, setMode] = useState('cut');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState(null);
  const submit = async () => {
    setBusy(true);
    setError('');
    try {
      let r;
      if (kind === 'existing') {
        await linkTeacherAccount(account.user_id, existing);
        const lg = logins?.[existing];
        r = { teacherId: existing, password: lg?.currentPassword || (lg?.defaultPassword ? lg.autoPassword : null), existing: true };
      } else {
        r = await resolveClaim(account.user_id, false, cat);
      }
      let moved = null;
      if (picked.size) moved = await transferStudents([...picked], r.teacherId, mode);
      setResult({ ...r, moved });
      onDone?.();
    } catch (e) {
      setError(e.message);
    }
    setBusy(false);
  };
  return (
    <Modal title={result ? (result.existing ? 'Teacher linked to their ID' : 'Teacher ID created') : `Approve ${account.full_name}`} onClose={onClose} busy={busy} wide testid="approve-dialog">
      {result ? (
        <>
          <IdCardResult teacherId={result.teacherId} password={result.password} name={account.full_name} email={account.email} whatsapp={account.whatsapp} />
          {result.moved && <p className="mt-3 text-sm font-semibold text-gray-700">{result.moved.moved ? `${result.moved.moved} student(s) moved. ` : ''}{result.moved.copied?.length ? `${result.moved.copied.length} student(s) copied.` : ''}</p>}
          <button type="button" className="btn-teal mt-4 flex w-full justify-center" onClick={onClose}>Done</button>
        </>
      ) : (
        <>
          <p className="mb-4 text-sm text-gray-700"><strong>{account.full_name}</strong> · {account.email} · WhatsApp <PhoneLinks value={account.whatsapp} /></p>
          <div className="mb-4 grid gap-2 sm:grid-cols-2" role="radiogroup" aria-label="Who is this?">
            {[['new', 'A new teacher', 'Gets the next ID of the category you choose, and a password.'],
              ['existing', 'Already in the Teachers List', 'Typed their name differently? Give them their own existing ID and its password.']].map(([k, tt, d]) => (
              <button key={k} type="button" role="radio" aria-checked={kind === k} onClick={() => setKind(k)} data-testid={`kind-${k}`}
                className={`rounded-xl border-2 p-3 text-left ${kind === k ? 'border-[#034751] bg-[#e8f2f2]' : 'border-gray-200 hover:border-[#005359]'}`}>
                <div className="text-sm font-extrabold text-[#034751]">{tt}</div>
                <div className="mt-1 text-xs text-gray-600">{d}</div>
              </button>
            ))}
          </div>
          {kind === 'existing' ? (
            <>
              <h3 className="mb-2 text-sm font-extrabold text-gray-800">1. Which teacher is it?</h3>
              <Combobox value={existing} onChange={setExisting} options={free} placeholder="Search name, ID or number" aria-label="Existing teacher" />
              <p className="mt-1 text-xs font-semibold text-gray-600">Only teachers without a Gmail lock are listed. {account.email} gets locked to the ID you pick; no new ID is made.</p>
            </>
          ) : (
            <>
              <h3 className="mb-2 text-sm font-extrabold text-gray-800">1. Category (decides the Teacher ID)</h3>
              <CategoryPicker value={cat} onChange={setCat} nextIds={nextIds} />
            </>
          )}
          <h3 className="mb-2 mt-5 text-sm font-extrabold text-gray-800">2. Students (optional)</h3>
          <StudentPicker students={db.students} teachers={db.teachers} selected={picked} onSelected={setPicked} mode={mode} onMode={setMode} />
          {error && <p role="alert" className="mt-3 rounded-xl bg-red-50 px-3 py-2 text-sm text-red-800">{error}</p>}
          <button type="button" className="btn-teal mt-4 inline-flex w-full items-center justify-center gap-1" disabled={(kind === 'existing' ? !existing : !cat) || busy} onClick={submit} data-testid="approve-submit">
            <Check className="h-4 w-4" /> {busy ? 'Saving…' : kind === 'existing' ? (existing ? `Approve as ${existing}` : 'Choose the teacher') : cat ? `Approve and give ${nextIds[ID_CATEGORIES.find((c) => c.value === cat).letter]}` : 'Choose a category'}
          </button>
        </>
      )}
    </Modal>
  );
}

/** Copy or cut students from other teachers into this teacher. */
function StudentsDialog({ teacher, db, onClose, onDone }) {
  const [picked, setPicked] = useState(new Set());
  const [mode, setMode] = useState('cut');
  const [replace, setReplace] = useState({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const submit = async () => {
    setBusy(true);
    setError('');
    try {
      const r = await transferStudents([...picked], teacher.id, mode, replace);
      await onDone?.(r);
      onClose();
    } catch (e) {
      setError(e.message);
      setBusy(false);
    }
  };
  return (
    <Modal title={`Add students to ${teacher.name} (${teacher.id})`} icon={Users} onClose={onClose} busy={busy} wide testid="students-dialog">
      <StudentPicker students={db.students} teachers={db.teachers} excludeTeacherId={teacher.id} selected={picked} onSelected={setPicked} mode={mode} onMode={setMode} onReplace={setReplace} />
      {error && <p role="alert" className="mt-3 rounded-xl bg-red-50 px-3 py-2 text-sm text-red-800">{error}</p>}
      <button type="button" className="btn-teal mt-4 inline-flex w-full items-center justify-center gap-1" disabled={!picked.size || busy} onClick={submit} data-testid="students-submit">
        <ArrowRightLeft className="h-4 w-4" /> {busy ? 'Saving…' : `${mode === 'cut' ? 'Move' : 'Copy'} ${picked.size || ''} student${picked.size === 1 ? '' : 's'} to ${teacher.id}`}
      </button>
    </Modal>
  );
}

/** A duplicate ID is merged into the teacher's real record (they keep the real ID and its password). */
function MergeDialog({ teacher, db, logins, onClose, onDone }) {
  const [into, setInto] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState(null);
  const options = useMemo(() => db.teachers.filter((t) => t.id !== teacher.id)
    .map((t) => ({ value: t.id, label: `${t.name} (${t.id})${logins?.[t.id]?.googleEmail ? ` · ${logins[t.id].googleEmail}` : ''}` })), [db.teachers, logins, teacher.id]);
  const target = db.teachers.find((t) => t.id === into);
  const submit = async () => {
    setBusy(true);
    setError('');
    try {
      setResult(await mergeTeacher(teacher.id, into));
      onDone?.();
    } catch (e) {
      setError(e.message);
    }
    setBusy(false);
  };
  return (
    <Modal title={result ? 'Merged' : `Merge ${teacher.name} (${teacher.id}) into…`} icon={GitMerge} onClose={onClose} busy={busy} testid="merge-dialog">
      {result ? (
        <>
          <IdCardResult teacherId={result.teacherId} password={result.password} name={target?.name || teacher.name} oldId={result.removedId} />
          <button type="button" className="btn-teal mt-4 flex w-full justify-center" onClick={onClose}>Done</button>
        </>
      ) : (
        <>
          <p className="mb-3 text-sm text-gray-700">
            Use this when one teacher has two IDs (for example they signed in with a different spelling of their name and got a new one).
            <strong> {teacher.id}</strong> is removed. Its Gmail lock, students, payments, attendance, reports and requests move to the ID you choose, and the teacher uses that ID and its password. They stay signed in.
          </p>
          <Combobox value={into} onChange={setInto} options={options} placeholder="The teacher’s real record" aria-label="Merge into" />
          {error && <p role="alert" className="mt-3 rounded-xl bg-red-50 px-3 py-2 text-sm text-red-800">{error}</p>}
          <button type="button" className="btn-teal mt-4 inline-flex w-full items-center justify-center gap-1" disabled={!into || busy} onClick={submit} data-testid="merge-submit">
            <GitMerge className="h-4 w-4" /> {busy ? 'Merging…' : into ? `Merge ${teacher.id} into ${into}` : 'Choose the real record'}
          </button>
        </>
      )}
    </Modal>
  );
}

/** Give a teacher the new-style ID of a category (everything moves with them). */
function ChangeIdDialog({ teacher, db, onClose, onDone }) {
  const nextIds = useNextIds(db.teachers);
  const [cat, setCat] = useState(catOf(teacher.category));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState(null);
  const letter = ID_CATEGORIES.find((c) => c.value === cat)?.letter;
  const same = isNewStyleId(teacher.id) && teacher.id.charAt(4) === letter;
  const submit = async () => {
    setBusy(true);
    setError('');
    try {
      const r = await changeTeacherId(teacher.id, cat);
      setResult(r);
      onDone?.();
    } catch (e) {
      setError(e.message);
    }
    setBusy(false);
  };
  return (
    <Modal title={result ? 'Teacher ID changed' : `New Teacher ID for ${teacher.name}`} onClose={onClose} busy={busy} testid="changeid-dialog">
      {result ? (
        <>
          <IdCardResult teacherId={result.teacherId} password={result.password} name={teacher.name} oldId={result.oldId} />
          <button type="button" className="btn-teal mt-4 flex w-full justify-center" onClick={onClose}>Done</button>
        </>
      ) : (
        <>
          <p className="mb-3 text-sm text-gray-700">
            <span className="id-tag">{teacher.id}</span> gets the next ID of the category you choose. Students, salary and payments, reports, attendance, schedules, requests, points and the Gmail lock all move to the new ID. The password stays the same. The teacher signs in again with the new ID.
          </p>
          <CategoryPicker value={cat} onChange={setCat} nextIds={nextIds} />
          {same && <p className="mt-2 text-xs font-bold text-amber-700">This teacher already has a {cat} ID.</p>}
          {error && <p role="alert" className="mt-3 rounded-xl bg-red-50 px-3 py-2 text-sm text-red-800">{error}</p>}
          <button type="button" className="btn-teal mt-4 inline-flex w-full items-center justify-center gap-1" disabled={!cat || same || busy} onClick={submit} data-testid="changeid-submit">
            <IdCard className="h-4 w-4" /> {busy ? 'Changing…' : cat ? `Change ${teacher.id} → ${nextIds[letter]}` : 'Choose a category'}
          </button>
        </>
      )}
    </Modal>
  );
}

/**
 * Executives: open any teacher's own dashboard (everything editable there),
 * and confirm sign-ups whose name matched an existing teacher.
 */
// v156: Teacher IDs without gaps (R023, R024, R025 … not R023 → R025)
function IdGaps({ onDone, tick }) {
  const confirm = useConfirm();
  const toast = useToast();
  const [gaps, setGaps] = useState([]);
  const [busy, setBusy] = useState(false);
  useEffect(() => { teacherIdGaps().then((g) => setGaps(g || [])).catch(() => setGaps([])); }, [tick]);
  if (!gaps.length) return null;
  const run = async () => {
    if (!(await confirm({ title: 'Close the gaps in Teacher IDs?', message: `${gaps.map((g) => `${g.oldId} → ${g.teacherId}`).join(', ')}. Everything moves with each teacher. Their password changes to the new ID's automatic one; the old ID + password open the dashboard one last time, then they see the new ones.`, confirmText: 'Close the gaps' }))) return;
    setBusy(true);
    try {
      const done = await fillTeacherIdGaps();
      toast(`${(done || []).length} Teacher ID(s) moved down.`);
      setGaps([]);
      onDone();
    } catch (e) {
      toast(e.message, 'error');
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border px-3.5 py-2.5" style={{ background: 'var(--qit-gold-tint)', borderColor: 'var(--qit-gold-line)' }} data-testid="id-gaps">
      <p className="text-sm font-semibold">Gaps in Teacher IDs: {gaps.slice(0, 4).map((g) => `${g.oldId} → ${g.teacherId}`).join(', ')}{gaps.length > 4 ? ` and ${gaps.length - 4} more` : ''}</p>
      <button type="button" className="btn-teal" onClick={run} disabled={busy} data-testid="id-gaps-fix">{busy ? 'Moving…' : 'Close the gaps'}</button>
    </div>
  );
}

export default function TeacherDashboards() {
  const [notify, setNotify] = useState(false); // v179: notification to teachers' phones
  const { db, load: reloadPortal, deleteTeacher, liveTick } = usePortal();
  const confirm = useConfirm();
  const toast = useToast();
  const [accounts, setAccounts] = useState(null);
  const [q, setQ] = useState('');
  const deferredQ = useDeferredValue(q);
  const [busy, setBusy] = useState('');
  const [logins, setLogins] = useState(null);
  const [pwFor, setPwFor] = useState(null);
  // v165: after a password change: the new ID + password, ready to send to the teacher on WhatsApp
  const [pwResult, setPwResult] = useState(null);
  const [approveFor, setApproveFor] = useState(null);
  const [studentsFor, setStudentsFor] = useState(null);
  const [idFor, setIdFor] = useState(null);
  const [mergeFor, setMergeFor] = useState(null);
  const [bulk, setBulk] = useState(null); // { done, total, errors }
  const [category, setCategory] = useState('Residential');

  const load = useCallback(async () => {
    try {
      const [a, l] = await Promise.all([listTeacherAccounts(), adminTeacherLogins()]);
      setAccounts(a);
      setLogins(Object.fromEntries((l || []).map((x) => [x.teacherId, x])));
    } catch (e) {
      toast(e.message, 'error');
      setAccounts([]);
      setLogins({});
    }
  }, [toast]);

  const savePassword = async (password) => {
    const pw = await adminSetTeacherPassword(pwFor.id, password);
    toast(password ? `New password saved for ${pwFor.id}.` : `${pwFor.id}’s password is back to ${pw}.`);
    setPwResult({ teacher: pwFor, password: pw || password });
    setPwFor(null);
    load();
  };
  const disableLogin = async () => {
    const ok = await confirm({ title: `Switch off ${pwFor.id}’s sign-in?`, message: 'They are signed out on every device and cannot sign in with Teacher ID and password until you set a password again or they sign in with Google.', confirmText: 'Switch off', tone: 'danger' });
    if (!ok) return;
    await adminDisableTeacherLogin(pwFor.id);
    toast(`${pwFor.id}’s sign-in is switched off.`);
    setPwFor(null);
    load();
  };
  useEffect(() => {
    load();
  }, [load, liveTick]);

  const pending = (accounts || []).filter((a) => a.link_status === 'pending');
  const teacherName = (id) => db.teachers.find((t) => t.id === id)?.name || id;
  const studentCount = useMemo(() => db.students.reduce((m, s) => ({ ...m, [s.teacherId]: (m[s.teacherId] || 0) + 1 }), {}), [db.students]);

  const decide = async (a) => {
    const ok = await confirm({ title: 'Confirm this teacher?', message: `${a.full_name} (${a.email}) becomes ${teacherName(a.claim_teacher_id)} (${a.claim_teacher_id}) and will see that teacher’s students and salary. Their first Google sign-in opens the dashboard.`, confirmText: 'Yes, it’s them' });
    if (!ok) return;
    setBusy(a.user_id);
    try {
      const r = await resolveClaim(a.user_id, true);
      toast(`${a.full_name} linked to ${r.teacherId}.`);
      await Promise.all([load(), reloadPortal()]);
    } catch (e) {
      toast(e.message, 'error');
    } finally {
      setBusy('');
    }
  };

  const removeClaim = async (a) => {
    const ok = await confirm({ title: `Remove ${a.email}?`, message: `${a.full_name}’s sign-up is deleted. No teacher record is changed. If they sign in with Google again, they start from the beginning.`, confirmText: 'Remove account', tone: 'danger' });
    if (!ok) return;
    try {
      await adminRemoveTeacherAccount(a.user_id);
      toast(`${a.email} removed.`);
      await load();
    } catch (e) {
      toast(e.message, 'error');
    }
  };

  // Same rule as the Salary Directory: students must be moved to another teacher first
  const removeTeacher = async (t) => {
    const count = studentCount[t.id] || 0;
    if (count) {
      toast(`${t.name} still has ${count} student${count > 1 ? 's' : ''}. Reassign or remove them first (Students tab).`, 'error');
      return;
    }
    const lg = logins?.[t.id];
    const ok = await confirm({
      title: `Delete ${t.name} (${t.id})?`,
      message: `${t.name} is removed from the Teachers List and the Salary Directory.${lg?.googleEmail ? ` Their Google account (${lg.googleEmail}) is unlinked.` : ''} Their Teacher ID sign-in is switched off at once.\n\nPast monthly reports and support requests are kept. This cannot be undone.`,
      confirmText: 'Delete teacher',
      tone: 'danger',
    });
    if (!ok) return;
    setBusy(t.id);
    try {
      await deleteTeacher(t.id);
      await load();
    } finally {
      setBusy('');
    }
  };

  // Give every teacher who still has an old ID (QIT-007) the ID of their category
  const legacy = db.teachers.filter((t) => !isNewStyleId(t.id));
  const legacyNoCat = legacy.filter((t) => !catOf(t.category));
  const convertAll = async () => {
    const todo = legacy.filter((t) => catOf(t.category));
    const ok = await confirm({
      title: `Give ${todo.length} teacher(s) new IDs?`,
      message: `Each teacher gets the next ID of their category (Residential → QIT-R…, Non-Residential Male → QIT-M…, Female → QIT-F…). Students, salary, reports and everything else move with them; passwords stay the same.${legacyNoCat.length ? `\n\n${legacyNoCat.length} teacher(s) have no category and are skipped: ${legacyNoCat.map((t) => t.id).join(', ')}. Set their category in the Salary Directory first.` : ''}\n\nTell every teacher their new ID: they sign in with it next time.`,
      confirmText: 'Give new IDs',
    });
    if (!ok) return;
    const errors = [];
    const changed = [];
    setBulk({ done: 0, total: todo.length, errors, changed });
    for (let i = 0; i < todo.length; i += 1) {
      try {
        const r = await changeTeacherId(todo[i].id, catOf(todo[i].category));
        changed.push(`${r.oldId} → ${r.teacherId} (${todo[i].name})`);
      } catch (e) {
        errors.push(`${todo[i].id}: ${e.message}`);
      }
      setBulk({ done: i + 1, total: todo.length, errors: [...errors], changed: [...changed] });
    }
    await Promise.all([load(), reloadPortal()]);
  };

  // Category tabs, like the Salary Directory (plus "No category" when needed)
  const NO_CAT = '__none';
  const tabOf = (t) => catOf(t.category) || NO_CAT;
  const tabs = useMemo(() => {
    const base = CATEGORIES.map((c) => ({ value: c.value, label: c.label }));
    return db.teachers.some((t) => tabOf(t) === NO_CAT) ? [...base, { value: NO_CAT, label: 'No category' }] : base;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [db.teachers]);
  const counts = useMemo(() => db.teachers.reduce((m, t) => ({ ...m, [tabOf(t)]: (m[tabOf(t)] || 0) + 1 }), {}),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [db.teachers]);
  const term = deferredQ.trim().toLowerCase();
  const list = db.teachers.filter((t) => tabOf(t) === category
    && (!term || matchSearch(`${t.name} ${t.id} ${t.department || ''} ${t.email || ''} ${t.whatsapp || ''}`, term)))
    .sort(byTeacherOrder);

  return (
    <>
      {pending.length > 0 && (
        <div className="box-card" style={{ borderColor: '#f2d48a' }}>
          <div className="card-header-bar"><h2 className="card-title">Waiting for confirmation ({pending.length})</h2><PanelNotes><p>New Gmail sign-ups wait here. <strong>Approve</strong> a new teacher by choosing the category: they get the next ID (QIT-R… / QIT-M… / QIT-F…) and a password, and you can copy or cut students to them. If their name or WhatsApp matched a teacher already in the list, confirm it is them instead.</p></PanelNotes></div>
          {pending.map((a) => (
            <div key={a.user_id} className="team-row" data-testid={`pending-${a.email}`}>
              <div className="min-w-0">
                <div className="font-extrabold">{a.full_name} {a.claim_teacher_id ? <span className="rv-sub">→ matches {teacherName(a.claim_teacher_id)} ({a.claim_teacher_id})</span> : <span className="rv-sub">→ new teacher</span>}</div>
                <div className="rv-sub">{a.email} · WhatsApp <PhoneLinks value={a.whatsapp} /> · signed up {new Date(a.created_at).toLocaleDateString('en-GB')}</div>
              </div>
              <div className="flex flex-wrap gap-2">
                {a.claim_teacher_id && <button type="button" className="btn-teal inline-flex items-center gap-1" disabled={busy === a.user_id} onClick={() => decide(a)}><Check className="h-4 w-4" /> It’s them</button>}
                <button type="button" className={`${a.claim_teacher_id ? 'btn-add-row' : 'btn-teal'} inline-flex items-center gap-1`} disabled={busy === a.user_id} onClick={() => setApproveFor(a)} data-testid="approve-open"><UserPlus className="h-4 w-4" /> {a.claim_teacher_id ? 'New teacher + ID' : 'Approve + give ID'}</button>
                <button type="button" className="btn-danger inline-flex items-center gap-1" disabled={busy === a.user_id} onClick={() => removeClaim(a)}><Trash2 className="h-3.5 w-3.5" /> Remove</button>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="box-card">
        <div className="card-header-bar"><h2 className="card-title">Teacher dashboards</h2><button type="button" className="btn-teal ml-auto" onClick={() => setNotify(true)} data-testid="notify-teachers"><BellRing className="h-4 w-4" /> Notify teachers</button><PanelNotes><p>Open a teacher’s dashboard exactly as they see it. As an Executive you can change everything there: class times, monthly reports, requests, profile and points. Submitted attendance is corrected in the Attendance log.</p><p>Teachers sign in at <strong>/teacher</strong> with <strong>Google</strong> (their Gmail is locked to their ID), and after the first time also with their <strong>Teacher ID + password</strong>. New IDs follow the category: <strong>QIT-R…</strong> Residential, <strong>QIT-M…</strong> Non-Residential Male, <strong>QIT-F…</strong> Non-Residential Female, each with its automatic password: Residential <strong>1010…1999</strong>, Male <strong>2020…2999</strong>, Female <strong>3030…3999</strong> (by the ID number: QIT-R001 = 1010, QIT-M001 = 2020, QIT-F001 = 3030). After a password or ID change the old ones open the dashboard once more; then the teacher sees the new ones. IDs never have gaps: after a merge, later IDs move down by one. Use <strong>Students</strong> to copy or cut students to a teacher, <strong>New ID</strong> to move a teacher with an old ID to their category’s ID, and <strong>Password</strong> to reset it, set your own or switch it off. Gmail locks and devices are in <strong>Security</strong>.</p></PanelNotes></div>
        <IdGaps onDone={() => { load(); reloadPortal(); }} tick={logins} />
        {legacy.length > 0 && (
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-amber-200 bg-amber-50 px-3.5 py-2.5" data-testid="legacy-banner">
            <p className="text-sm font-semibold text-amber-900">{legacy.length} teacher(s) still have old IDs (like {legacy[0].id}).{legacyNoCat.length ? ` ${legacyNoCat.length} have no category yet.` : ''}</p>
            <button type="button" className="btn-teal inline-flex items-center gap-1" onClick={convertAll} disabled={Boolean(bulk && bulk.done < bulk.total)}><IdCard className="h-4 w-4" /> Give all new IDs</button>
          </div>
        )}
        {bulk && (
          <div className="mb-4 rounded-xl border border-gray-200 bg-white px-3.5 py-2.5 text-sm" role="status">
            <strong>{bulk.done < bulk.total ? `Changing IDs… ${bulk.done} / ${bulk.total}` : `Done: ${bulk.changed.length} teacher(s) have new IDs.`}</strong>
            {bulk.done >= bulk.total && bulk.changed.length > 0 && <div className="mt-1 max-h-40 overflow-y-auto font-mono text-xs text-gray-700">{bulk.changed.map((x) => <div key={x}>{x}</div>)}</div>}
            {bulk.errors.length > 0 && <div className="mt-1 text-xs text-red-700">{bulk.errors.map((x) => <div key={x}>{x}</div>)}</div>}
            {bulk.done >= bulk.total && <button type="button" className="btn-outline-sm mt-2" onClick={() => setBulk(null)}>Close</button>}
          </div>
        )}
        <div className="mb-4 flex flex-wrap gap-2 border-b-2 pb-3" style={{ borderColor: 'var(--c-box-border)' }} role="tablist" data-testid="td-tabs">
          {tabs.map((c) => (
            <button key={c.value} type="button" role="tab" aria-selected={category === c.value} className={`dir-tab ${category === c.value ? 'active' : ''} ${c.value === NO_CAT ? 'dir-tab-new' : ''}`} data-tone={catTone(c.value)} onClick={() => setCategory(c.value)}>
              {c.label} <span className="count">{counts[c.value] || 0}</span>
            </button>
          ))}
        </div>
        <div className="dir-search mb-4">
          <Search className="dir-search-icon" aria-hidden="true" />
          <input type="search" className="m-input" placeholder={`Search in ${tabs.find((c) => c.value === category)?.label || ''} — name, ID, department or Gmail`} value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search teachers" />
        </div>
        <div className="table-wrap">
          <table className="tl-table row-cards">
            <thead><tr><th>ID</th><th>Teacher</th><th>Students</th><th>Sign-in</th><th /></tr></thead>
            <tbody>
              {list.map((t) => {
                const lg = logins?.[t.id];
                return (
                  <tr key={t.id} className={`row-card tl-${{ Residential: 'res', 'Non-Residential Male': 'male', 'Non-Residential Female': 'female' }[catOf(t.category)] || 'res'}`}>
                    <td><span className="id-tag">{t.id}</span></td>
                    <td><strong className="p-link" {...profileAttr('teacher', t.id)}>{t.name}</strong><div className="rv-sub">{[t.department, t.category].filter(Boolean).join(' · ')}</div></td>
                    <td>{studentCount[t.id] || 0}</td>
                    <td>
                      {!logins ? '…' : !lg?.active ? (
                        <>
                          <span className="st-badge no">{lg?.switchedOff ? 'Switched off' : 'Not set up — run the SQL'}</span>
                          <div className="rv-sub">{lg?.googleEmail || 'No Google account linked'}</div>
                        </>
                      ) : (
                        <>
                          <span className={`st-badge ${lg.defaultPassword ? 'part' : 'yes'}`} data-testid={`pw-${t.id}`}>Password {lg.currentPassword || (lg.defaultPassword ? lg.autoPassword : '—')}</span>
                          {lg.graceLeft > 0 && <div className="rv-sub" style={{ color: 'var(--qit-gold)' }}>Old {lg.oldId ? `ID ${lg.oldId} / ` : ''}password still opens once</div>}
                          <div className="rv-sub">{lg.googleEmail || 'No Google account linked'}</div>
                          <div className="rv-sub">{lg.googleLastSignIn ? `Signed in ${new Date(lg.googleLastSignIn).toLocaleDateString('en-GB')}` : 'Not signed in yet'}</div>
                        </>
                      )}
                    </td>
                    <td className="whitespace-nowrap text-right">
                      <button type="button" className="btn-outline-sm mr-2 inline-flex items-center gap-1" onClick={() => setStudentsFor(t)} aria-label={`Add students to ${t.name} (${t.id})`} data-testid={`students-${t.id}`}>
                        <Users className="h-3.5 w-3.5" /> Students
                      </button>
                      {!isNewStyleId(t.id) && (
                        <button type="button" className="btn-outline-sm mr-2 inline-flex items-center gap-1" onClick={() => setIdFor(t)} aria-label={`New ID for ${t.name} (${t.id})`} data-testid={`newid-${t.id}`}>
                          <IdCard className="h-3.5 w-3.5" /> New ID
                        </button>
                      )}
                      <button type="button" className="btn-outline-sm mr-2 inline-flex items-center gap-1" onClick={() => setMergeFor(t)} aria-label={`Merge ${t.name} (${t.id}) into another teacher`} title="This teacher has two IDs? Merge this one into their real record" data-testid={`merge-${t.id}`}>
                        <GitMerge className="h-3.5 w-3.5" /> <span className="hidden 2xl:inline">Merge</span>
                      </button>
                      <button type="button" className="btn-outline-sm mr-2 inline-flex items-center gap-1" onClick={() => setPwFor(t)} disabled={!logins} aria-label={`Password for ${t.name} (${t.id})`}>
                        <KeyRound className="h-3.5 w-3.5" /> Password
                      </button>
                      <Link to={`/admin/teachers/${encodeURIComponent(t.id)}`} className="btn-teal inline-flex items-center gap-1" style={{ padding: '6px 12px', fontSize: '0.8rem' }}>
                        <LayoutDashboard className="h-3.5 w-3.5" /> Open dashboard
                      </Link>
                      <button type="button" className="btn-danger ml-2 inline-flex items-center gap-1" style={{ padding: '6px 10px', fontSize: '0.8rem' }} disabled={busy === t.id}
                        onClick={() => removeTeacher(t)} aria-label={`Delete ${t.name} (${t.id})`} title="Delete teacher">
                        <Trash2 className="h-3.5 w-3.5" /> <span className="hidden xl:inline">Delete</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
              {!list.length && <tr><td colSpan={5} className="rv-empty">No teachers match.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
      {mergeFor && <MergeDialog teacher={mergeFor} db={db} logins={logins} onClose={() => setMergeFor(null)} onDone={() => Promise.all([load(), reloadPortal()])} />}
      {approveFor && <ApproveDialog account={approveFor} db={db} logins={logins} onClose={() => setApproveFor(null)} onDone={() => Promise.all([load(), reloadPortal()])} />}
      {studentsFor && <StudentsDialog teacher={studentsFor} db={db} onClose={() => setStudentsFor(null)}
        onDone={async (r) => { toast(`${r.moved ? `${r.moved} student(s) moved` : `${r.copied?.length || 0} student(s) copied`} to ${studentsFor.id}.${r.replaced?.length ? ` ${r.replaced.length} replaced: ${r.replaced.map((x) => x.old).join(', ')}.` : ''}`); await reloadPortal(); }} />}
      {idFor && <ChangeIdDialog teacher={idFor} db={db} onClose={() => setIdFor(null)} onDone={() => Promise.all([load(), reloadPortal()])} />}
      {pwResult && (
        <Modal title="New password saved" onClose={() => setPwResult(null)} wide testid="pw-result">
          <IdCardResult teacherId={pwResult.teacher.id} password={pwResult.password} name={pwResult.teacher.name} whatsapp={pwResult.teacher.whatsapp} passwordChanged />
          <button type="button" className="btn-teal mt-4 w-full" onClick={() => setPwResult(null)}>Done</button>
        </Modal>
      )}
      {pwFor && <PasswordDialog teacher={pwFor} login={logins?.[pwFor.id]} onSave={savePassword} onDisable={disableLogin} onClose={() => setPwFor(null)} />}
      {notify && <Suspense fallback={null}><TeacherPush onClose={() => setNotify(false)} /></Suspense>}
    </>
  );
}
