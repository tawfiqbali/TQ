import PanelNotes from '../components/PanelNotes';
import PhoneLinks from '../../../components/ui/PhoneLinks';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Copy, Link2, Trash2, UserPlus } from 'lucide-react';
import { usePortal } from '../PortalContext';
import Combobox from '../components/Combobox';
import { isGmail } from '../../../lib/auth';
import { copyText } from '../../../lib/whatsappGroup';
import { addJunior, adminRemoveTeacherAccount, linkTeacherAccount, listJuniors, listTeacherAccounts, removeJunior } from '../../../lib/teacherData';
import '../../staff/staff.css';
import { useConfirm } from '../../../components/ui/Confirm';
import { useToast } from '../../../components/ui/Toast';

const digits = (s) => String(s || '').replace(/[০-৯]/g, (c) => '০১২৩৪৫৬৭৮৯'.indexOf(c)).replace(/\D/g, '').slice(-10);

function ShareLink({ label, path, hint }) {
  const url = `${window.location.origin}${path}`;
  const [done, setDone] = useState(false);
  return (
    <div className="team-row">
      <div className="min-w-0">
        <div className="font-extrabold">{label}</div>
        <div className="rv-sub break-all">{url}</div>
        {hint && <div className="rv-sub">{hint}</div>}
      </div>
      <button type="button" className="btn-add-row inline-flex items-center gap-1" onClick={async () => { await copyText(url); setDone(true); setTimeout(() => setDone(false), 1800); }}>
        <Copy className="h-3.5 w-3.5" /> {done ? 'Copied!' : 'Copy link'}
      </button>
    </div>
  );
}

/**
 * Executives: who may sign in to what.
 *  - Junior Admins: add or remove a Gmail. They sign in with Google and see
 *    only the teacher list and the monthly reports.
 *  - Teacher accounts: teachers who signed in with Google. A teacher whose
 *    Gmail wasn't on their record gets a new ID at sign-up; link them to their
 *    real record here so they see their students and salary.
 */
export default function TeamRoles() {
  const { db, adminEmail, load: reloadPortal, liveTick } = usePortal();
  const confirm = useConfirm();
  const toast = useToast();
  const [juniors, setJuniors] = useState(null);
  const [accounts, setAccounts] = useState(null);
  const [error, setError] = useState('');
  const [email, setEmail] = useState('');
  const [msg, setMsg] = useState('');
  const [linkPick, setLinkPick] = useState({});

  const load = useCallback(async () => {
    setError('');
    try {
      const [j, a] = await Promise.all([listJuniors(), listTeacherAccounts()]);
      setJuniors(j);
      setAccounts(a);
    } catch (e) {
      setError(e.message);
      setJuniors([]);
      setAccounts([]);
    }
  }, []);
  useEffect(() => {
    load();
  }, [load, liveTick]);

  const gmail = email.trim().toLowerCase();
  const add = async (e) => {
    e.preventDefault();
    if (!isGmail(gmail)) return setMsg('Enter a Gmail address (…@gmail.com).');
    try {
      await addJunior(gmail, adminEmail);
      setEmail('');
      setMsg(`${gmail} can now sign in as a Junior Admin with Google.`);
      load();
    } catch (err) {
      setMsg(err.message);
    }
  };
  const remove = async (j) => {
    if (!(await confirm({ title: 'Remove Junior Admin?', message: `${j.email} loses access to the admin pages at once.`, confirmText: 'Remove access', tone: 'danger' }))) return;
    try {
      await removeJunior(j.email);
      toast(`${j.email} removed.`);
      load();
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  const linked = useMemo(() => new Set((accounts || []).map((a) => a.teacher_id)), [accounts]);
  const teacherById = useMemo(() => Object.fromEntries(db.teachers.map((t) => [t.id, t])), [db.teachers]);
  const freeTeachers = useMemo(
    () => db.teachers.filter((t) => !linked.has(t.id)).map((t) => ({ value: t.id, label: `${t.name} (${t.id})` })),
    [db.teachers, linked],
  );
  // Likely real record for a new sign-up: same WhatsApp number or same name
  const suggest = (a) => {
    const w = digits(a.whatsapp);
    const name = a.full_name.trim().toLowerCase();
    return db.teachers.find((t) => !linked.has(t.id) && t.id !== a.teacher_id && ((w.length >= 7 && digits(t.whatsapp) === w) || String(t.name).trim().toLowerCase() === name));
  };

  const link = async (a, teacherId) => {
    const t = teacherById[teacherId];
    if (!t || !(await confirm({ title: 'Link this account?', message: `${a.full_name} (${a.email}) will become ${t.name} (${t.id}) and see ${t.name}’s students and salary.`, confirmText: 'Link account' }))) return;
    try {
      await linkTeacherAccount(a.user_id, teacherId);
      toast(`${a.full_name} linked to ${t.id}.`);
      await Promise.all([load(), reloadPortal()]);
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  // Delete a Google sign-up (a test, a wrong Gmail, someone who is not a teacher)
  const removeAccount = async (a) => {
    const t = a.teacher_id ? teacherById[a.teacher_id] : null;
    const onlyNew = t?.selfRegistered && !db.students.some((s) => s.teacherId === t.id);
    const ok = await confirm({
      title: `Remove ${a.email}?`,
      message: `${a.full_name}’s Google sign-in is deleted and they are signed out.${
        t ? (onlyNew ? `\n\n${t.id} was created by this sign-up and has no students, so it is removed from the Teachers List too (unless it already has payments or reports).` : `\n\n${t.name} (${t.id}) stays in the Teachers List with all its data; only this Gmail is unlinked.`) : ''
      }\n\nIf they sign in with Google again, they start from the beginning.`,
      confirmText: 'Remove account',
      tone: 'danger',
    });
    if (!ok) return;
    try {
      const r = await adminRemoveTeacherAccount(a.user_id);
      toast(r?.removedTeacherId ? `${a.email} removed, and ${r.removedTeacherId} deleted from the Teachers List.` : `${a.email} removed.`);
      await Promise.all([load(), reloadPortal()]);
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  return (
    <>
      <div className="box-card">
        <div className="card-header-bar"><h2 className="card-title">Links to share</h2></div>
        <ShareLink label="Teacher Dashboard" path="/teacher" hint="First time: Google (Gmail) → name + WhatsApp → Teacher ID. After that: Teacher ID + password (Residential QIT-R001 = 1010, Male QIT-M001 = 2020, Female QIT-F001 = 3030, and so on by the ID number)." />
        <ShareLink label="Monthly report form (direct)" path="/teacher/report" hint="Send on the 1st of every month. Opens the report form after sign-in." />
        <ShareLink label="Junior Admin sign-in" path="/admin/login" hint="Junior Admins pick “Junior Admin” → Continue with Google." />
        <ShareLink label="Academic Counselor sign-in" path="/admin/login" hint="Counselors pick “Academic Counselor” → Continue with Google → their password. Add them in the portal: Overview → Academic Counseling." />
      </div>

      <div className="box-card">
        <div className="card-header-bar"><h2 className="card-title">Junior Admins</h2><PanelNotes><p>Junior Admins sign in with Google and can only see the teacher list and review teachers’ monthly reports — no salaries, fees, bank details or website settings.</p></PanelNotes></div>
        <form onSubmit={add} className="mb-4 flex flex-wrap gap-2">
          <input type="email" className="m-input" style={{ maxWidth: 340 }} placeholder="name@gmail.com" value={email} onChange={(e) => { setEmail(e.target.value); setMsg(''); }} aria-label="Junior Admin Gmail" />
          <button type="submit" className="btn-teal inline-flex items-center gap-1" disabled={!gmail}><UserPlus className="h-4 w-4" /> Add Junior Admin</button>
        </form>
        {msg && <p className="mb-3 text-sm font-bold" role="status" style={{ color: 'var(--c-teal-mid)' }}>{msg}</p>}
        {error && <p className="setup-box mb-3 text-sm font-bold" role="alert">{error}</p>}
        {juniors === null ? <p className="rv-empty">Loading…</p> : !juniors.length ? <p className="rv-empty">No Junior Admins yet.</p> : juniors.map((j) => (
          <div key={j.email} className="team-row">
            <div>
              <div className="font-extrabold">{j.email}</div>
              <div className="rv-sub">Added {new Date(j.created_at).toLocaleDateString('en-GB')}{j.added_by ? ` by ${j.added_by}` : ''}</div>
            </div>
            <button type="button" className="btn-danger inline-flex items-center gap-1" onClick={() => remove(j)}><Trash2 className="h-3.5 w-3.5" /> Remove</button>
          </div>
        ))}
      </div>

      <div className="box-card">
        <div className="card-header-bar"><h2 className="card-title">Teacher Dashboard accounts</h2><PanelNotes><p>Tip: put each teacher’s Gmail on their record (Salary Directory → Edit Teacher) before sharing the link — they then land on their own Teacher ID automatically.</p></PanelNotes></div>
        {accounts === null ? <p className="rv-empty">Loading…</p> : !accounts.length ? <p className="rv-empty">No teacher has signed in yet.</p> : accounts.map((a) => {
          const t = teacherById[a.teacher_id];
          const fresh = t?.selfRegistered && !db.students.some((s) => s.teacherId === a.teacher_id);
          const hint = fresh ? suggest(a) : null;
          const pick = linkPick[a.user_id] ?? hint?.id ?? '';
          return (
            <div key={a.user_id} className="team-row" style={fresh ? { borderColor: '#f2d48a', background: '#fffdf5' } : undefined}>
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-extrabold">{a.full_name}</span>
                  {a.teacher_id ? <span className="id-tag">{a.teacher_id}</span> : <span className="st-badge part">Waiting for confirmation (see Teacher Dashboards)</span>}
                  {fresh && <span className="st-badge part">New sign-up · no students</span>}
                  {(a.linked_by === 'name' || a.linked_by === 'whatsapp') && a.teacher_id && (
                    <span className="st-badge part" title="Linked automatically on first sign-in. If it is the wrong person, press Remove.">
                      Matched by {a.linked_by === 'name' ? 'name' : 'WhatsApp number'} · check it’s them
                    </span>
                  )}
                </div>
                <div className="rv-sub">{a.email} · WhatsApp <PhoneLinks value={a.whatsapp} /> · joined {new Date(a.created_at).toLocaleDateString('en-GB')}</div>
                {hint && <div className="rv-sub" style={{ color: '#92400e' }}>Possible match: {hint.name} ({hint.id})</div>}
              </div>
              {fresh && (
                <div className="flex flex-wrap items-center gap-2">
                  <div style={{ minWidth: 240 }}>
                    <Combobox value={pick} onChange={(v) => setLinkPick((m) => ({ ...m, [a.user_id]: v }))} options={freeTeachers} placeholder="Find their teacher record…" aria-label={`Link ${a.full_name} to a teacher`} />
                  </div>
                  <button type="button" className="btn-teal inline-flex items-center gap-1" disabled={!pick} onClick={() => link(a, pick)}><Link2 className="h-4 w-4" /> Link</button>
                </div>
              )}
              <button type="button" className="btn-danger inline-flex items-center gap-1" onClick={() => removeAccount(a)} aria-label={`Remove account ${a.email}`}>
                <Trash2 className="h-3.5 w-3.5" /> Remove
              </button>
            </div>
          );
        })}
      </div>
    </>
  );
}
