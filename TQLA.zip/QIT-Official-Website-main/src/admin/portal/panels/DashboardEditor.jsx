import PanelNotes from '../components/PanelNotes';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { AlertTriangle, Asterisk, Lock, RotateCcw, Save, Search, Type } from 'lucide-react';
import { usePortal } from '../PortalContext';
import { getDashConfig, saveDashConfig } from '../../../lib/teacherData';
import { FIELD_GROUPS, applyDashConfig, requiredIn } from '../../../teacher/dashConfig';
import { BN, EN } from '../../../teacher/i18n';
import { useToast } from '../../../components/ui/Toast';
import { useConfirm } from '../../../components/ui/Confirm';

// Friendly names for each part of the Teacher Dashboard
const SECTIONS = {
  home: 'My Students page', stu: 'Add / edit student', att: 'Attendance', rp: 'Monthly Report', sch: 'Schedule', pg: 'My Progress',
  sal: 'Salary', sup: 'Support', login: 'Sign-in page', ob: 'First sign-in (profile)', card: 'Teacher ID card', notice: 'Notices',
  nav: 'Menu items', menu: 'Menu groups', brand: 'Header', emg: 'Emergency button', badge: 'Status badges', pdf: 'PDF summary',
  loading: 'Loading messages', common: 'Common words', admin: 'Admin-mode banner', cb: 'Google sign-in return', lock: 'Secure sign-in (Teacher ID + password)', first: 'First sign-in after approval', hist: 'Student history',
};
const ORDER = Object.keys(SECTIONS);

function flatten(obj, prefix = '', out = {}) {
  Object.entries(obj || {}).forEach(([k, v]) => {
    const key = prefix ? `${prefix}.${k}` : k;
    if (typeof v === 'string') out[key] = v;
    else if (v && typeof v === 'object') flatten(v, key, out);
  });
  return out;
}
const EN_FLAT = flatten(EN);
const BN_FLAT = flatten(BN);
const ALL_KEYS = Object.keys(EN_FLAT).sort((a, b) => ORDER.indexOf(a.split('.')[0]) - ORDER.indexOf(b.split('.')[0]));
const vars = (s) => [...String(s || '').matchAll(/\{(\w+)\}/g)].map((m) => m[1]);
const blank = () => ({ text: { en: {}, bn: {} }, required: {} });
const normalize = (c) => ({ text: { en: { ...(c?.text?.en || {}) }, bn: { ...(c?.text?.bn || {}) } }, required: { ...(c?.required || {}) } });
// Save only real changes: no empty texts, no required flags equal to the default
function clean(cfg) {
  const text = { en: {}, bn: {} };
  ['en', 'bn'].forEach((l) => Object.entries(cfg.text[l]).forEach(([k, v]) => { if (String(v).trim()) text[l][k] = v; }));
  const required = {};
  FIELD_GROUPS.forEach((g) => g.fields.forEach((f) => { if (!f.locked && typeof cfg.required[f.key] === 'boolean' && cfg.required[f.key] !== Boolean(f.def)) required[f.key] = cfg.required[f.key]; }));
  return { text, required };
}

function Switch({ on, onChange, label, disabled }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      aria-label={label}
      disabled={disabled}
      onClick={() => onChange(!on)}
      className={`relative inline-flex h-7 w-12 shrink-0 items-center rounded-full transition ${on ? 'bg-[#b91c1c]' : 'bg-slate-300'} ${disabled ? 'opacity-60' : ''}`}
    >
      <span className={`inline-block h-5 w-5 rounded-full bg-white shadow transition ${on ? 'translate-x-6' : 'translate-x-1'}`} />
    </button>
  );
}

/**
 * Executives: edit the Teacher Dashboard. Every text teachers see (English and
 * Bangla) and which entry fields are required (red *). Saved to the cloud;
 * teachers get the changes the next time their dashboard refreshes (about a minute,
 * or when they reopen it). Required fields are enforced by the database too.
 */
export default function DashboardEditor() {
  const { adminEmail } = usePortal();
  const toast = useToast();
  const confirm = useConfirm();
  const [cfg, setCfg] = useState(null);
  const [meta, setMeta] = useState(null);
  const [loadError, setLoadError] = useState('');
  const [dirty, setDirty] = useState(false);
  const [busy, setBusy] = useState(false);
  const [view, setView] = useState('required');
  const [section, setSection] = useState('home');
  const [q, setQ] = useState('');
  const [onlyEdited, setOnlyEdited] = useState(false);

  const load = useCallback(async () => {
    setLoadError('');
    try {
      const r = await getDashConfig();
      setCfg(normalize(r?.config || blank()));
      setMeta(r);
      setDirty(false);
    } catch (e) {
      setLoadError(e.message);
    }
  }, []);
  useEffect(() => {
    load();
  }, [load]);

  const edit = (fn) => {
    setCfg((c) => fn(structuredClone(c)));
    setDirty(true);
  };
  const setReq = (key, on) => edit((c) => { c.required[key] = on; return c; });
  const setText = (lang, key, v) => edit((c) => { if (v === '') delete c.text[lang][key]; else c.text[lang][key] = v; return c; });

  const save = async () => {
    const bad = ALL_KEYS.find((k) => ['en', 'bn'].some((l) => cfg.text[l][k]?.trim() && vars(EN_FLAT[k]).some((x) => !cfg.text[l][k].includes(`{${x}}`))));
    if (bad && !(await confirm({ title: 'Some texts are missing a {placeholder}', message: `“${bad}” no longer contains ${vars(EN_FLAT[bad]).map((x) => `{${x}}`).join(', ')}, so that detail (for example the teacher’s name or a number) won’t be shown. Save anyway?`, confirmText: 'Save anyway' }))) return;
    setBusy(true);
    try {
      const config = clean(cfg);
      await saveDashConfig(config, adminEmail);
      applyDashConfig(config);
      toast('Teacher Dashboard updated. Teachers see the changes within a minute.');
      await load();
    } catch (e) {
      toast(e.message, 'error');
    } finally {
      setBusy(false);
    }
  };
  const discard = async () => {
    if (!(await confirm({ title: 'Discard your changes?', message: 'Everything goes back to the last saved version.', confirmText: 'Discard', tone: 'danger' }))) return;
    load();
  };

  const counts = useMemo(() => {
    const m = {};
    if (cfg) ALL_KEYS.forEach((k) => { if (cfg.text.en[k] || cfg.text.bn[k]) { const s = k.split('.')[0]; m[s] = (m[s] || 0) + 1; } });
    return m;
  }, [cfg]);
  const keys = useMemo(() => {
    if (!cfg) return [];
    const term = q.trim().toLowerCase();
    let list = term
      ? ALL_KEYS.filter((k) => [k, EN_FLAT[k], BN_FLAT[k], cfg.text.en[k], cfg.text.bn[k]].some((x) => String(x || '').toLowerCase().includes(term)))
      : ALL_KEYS.filter((k) => k.split('.')[0] === section);
    if (onlyEdited) list = list.filter((k) => cfg.text.en[k] || cfg.text.bn[k]);
    return list.slice(0, 80);
  }, [cfg, q, section, onlyEdited]);

  if (!cfg) {
    return (
      <div className="box-card text-center">
        {loadError ? (
          <>
            <p className="font-bold text-red-700" role="alert">{loadError}</p>
            <button type="button" className="btn-teal mt-3" onClick={load}>Try again</button>
          </>
        ) : 'Loading…'}
      </div>
    );
  }
  const editedTotal = Object.values(counts).reduce((a, b) => a + b, 0);
  const reqChanged = Object.keys(clean(cfg).required).length;

  return (
    <div className="box-card" data-testid="dash-editor">
      <div className="card-header-bar">
        <div>
          <h2 className="card-title">Teacher Dashboard editor</h2>
        </div>
          <PanelNotes><p>Change any text teachers see and choose which entries are required. Applies to every teacher’s dashboard.</p></PanelNotes>
        <div className="flex gap-2">
          {dirty && <button type="button" className="btn-muted" onClick={discard}>Discard</button>}
          <button type="button" className="btn-teal inline-flex items-center gap-1" onClick={save} disabled={!dirty || busy} data-testid="de-save">
            <Save className="h-4 w-4" /> {busy ? 'Saving…' : 'Save changes'}
          </button>
        </div>
      </div>
      {meta?.updated_at && (
        <p className="mb-3 text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>
          Last saved {new Date(meta.updated_at).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' })}{meta.updated_by ? ` by ${meta.updated_by}` : ''}.
        </p>
      )}

      <div className="rv-counts mb-4" role="tablist" aria-label="Editor section">
        <button type="button" role="tab" className="rv-count inline-flex items-center gap-1.5" aria-selected={view === 'required'} aria-pressed={view === 'required'} onClick={() => setView('required')} data-testid="de-tab-required">
          <Asterisk className="h-4 w-4" /> Required fields {reqChanged ? `· ${reqChanged} changed` : ''}
        </button>
        <button type="button" role="tab" className="rv-count inline-flex items-center gap-1.5" aria-selected={view === 'text'} aria-pressed={view === 'text'} onClick={() => setView('text')} data-testid="de-tab-text">
          <Type className="h-4 w-4" /> Texts &amp; labels {editedTotal ? `· ${editedTotal} edited` : ''}
        </button>
      </div>

      {view === 'required' ? (
        <>
          <p className="mb-3 rounded-lg px-3 py-2 text-sm font-semibold" style={{ background: '#fdf6ec', color: '#7c4a03' }}>
            Required entries show a red <span className="text-red-700">*</span> and can’t be sent empty — on the teacher’s screen and in the database. Fields with a lock are always required.
          </p>
          <div className="grid gap-4 lg:grid-cols-2">
            {FIELD_GROUPS.map((g) => (
              <section key={g.key} className="rounded-xl border p-4" style={{ borderColor: '#dbe4e6' }} aria-labelledby={`fg-${g.key}`}>
                <h3 id={`fg-${g.key}`} className="font-extrabold" style={{ color: 'var(--c-teal-dark)' }}>{g.label}</h3>
                <p className="mb-2 text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>{g.where}</p>
                <ul className="divide-y" style={{ borderColor: '#eef2f3' }}>
                  {g.fields.map((f) => {
                    const on = requiredIn(cfg, f.key);
                    return (
                      <li key={f.key} className="flex items-center justify-between gap-3 py-2" data-field={f.key}>
                        <span className="text-sm font-semibold">
                          {f.label}
                          {on && <span className="text-red-700"> *</span>}
                          {!f.locked && on !== Boolean(f.def) && <span className="ml-2 rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-extrabold uppercase text-amber-800">changed</span>}
                        </span>
                        {f.locked ? (
                          <span className="inline-flex items-center gap-1 text-xs font-bold" style={{ color: 'var(--text-muted)' }}><Lock className="h-3.5 w-3.5" /> Always required</span>
                        ) : (
                          <span className="inline-flex items-center gap-2">
                            <span className={`w-16 text-right text-xs font-extrabold ${on ? 'text-red-700' : ''}`} style={on ? undefined : { color: 'var(--text-muted)' }}>{on ? 'Required' : 'Optional'}</span>
                            <Switch on={on} onChange={(v) => setReq(f.key, v)} label={`${g.label}: ${f.label} required`} />
                          </span>
                        )}
                      </li>
                    );
                  })}
                </ul>
              </section>
            ))}
          </div>
          {reqChanged > 0 && (
            <button type="button" className="btn-outline-sm mt-4 inline-flex items-center gap-1" onClick={() => edit((c) => ({ ...c, required: {} }))}>
              <RotateCcw className="h-3.5 w-3.5" /> Back to the built-in required fields
            </button>
          )}
        </>
      ) : (
        <>
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <label className="relative min-w-[16rem] flex-1">
              <span className="sr-only">Search all texts</span>
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2" style={{ color: 'var(--text-muted)' }} />
              <input className="m-input" style={{ paddingLeft: 34 }} placeholder="Search any text, English or বাংলা…" value={q} onChange={(e) => setQ(e.target.value)} data-testid="de-search" />
            </label>
            <label className="inline-flex items-center gap-2 text-sm font-bold">
              <input type="checkbox" checked={onlyEdited} onChange={(e) => setOnlyEdited(e.target.checked)} /> Only edited
            </label>
          </div>
          {!q.trim() && (
            <div className="mb-4 flex flex-wrap gap-1.5" role="group" aria-label="Part of the dashboard">
              {ORDER.filter((s) => ALL_KEYS.some((k) => k.startsWith(`${s}.`))).map((s) => (
                <button key={s} type="button" className="rv-count" aria-pressed={section === s} onClick={() => setSection(s)}>
                  {SECTIONS[s]}{counts[s] ? ` · ${counts[s]}` : ''}
                </button>
              ))}
            </div>
          )}
          <p className="mb-2 text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>
            Leave a box empty to use the original text (shown in grey). Words in {'{curly brackets}'} are filled in automatically — keep them.
          </p>
          {!keys.length ? (
            <p className="rv-empty">No texts match.</p>
          ) : (
            <ul className="space-y-2">
              {keys.map((k) => {
                const edited = Boolean(cfg.text.en[k] || cfg.text.bn[k]);
                const need = vars(EN_FLAT[k]);
                const lost = (l) => cfg.text[l][k]?.trim() && need.filter((x) => !cfg.text[l][k].includes(`{${x}}`));
                const warn = [...(lost('en') || []), ...(lost('bn') || [])];
                const long = (EN_FLAT[k] || '').length > 60 || (BN_FLAT[k] || '').length > 60;
                const Box = long ? 'textarea' : 'input';
                return (
                  <li key={k} className="rounded-xl border p-3" style={{ borderColor: edited ? '#e0b45a' : '#dbe4e6', background: edited ? '#fffaf0' : undefined }} data-key={k}>
                    <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                      <span className="text-xs font-bold" style={{ color: 'var(--text-muted)' }}>
                        {SECTIONS[k.split('.')[0]] || k.split('.')[0]} · <code>{k}</code>
                        {need.length > 0 && <> · keeps {need.map((x) => `{${x}}`).join(' ')}</>}
                      </span>
                      {edited && (
                        <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={() => edit((c) => { delete c.text.en[k]; delete c.text.bn[k]; return c; })}>
                          <RotateCcw className="h-3.5 w-3.5" /> Original
                        </button>
                      )}
                    </div>
                    <div className="grid gap-2 md:grid-cols-2">
                      {[['en', 'English', EN_FLAT[k]], ['bn', 'বাংলা', BN_FLAT[k] ?? EN_FLAT[k]]].map(([l, name, def]) => (
                        <label key={l} className="block">
                          <span className="mb-0.5 block text-[11px] font-extrabold uppercase tracking-wider" style={{ color: 'var(--text-muted)' }}>{name}</span>
                          <Box
                            className={`m-input ${l === 'bn' ? 'bn' : ''}`}
                            rows={long ? 2 : undefined}
                            placeholder={def}
                            value={cfg.text[l][k] ?? ''}
                            onChange={(e) => setText(l, k, e.target.value)}
                            data-testid={`de-${l}-${k}`}
                          />
                          {cfg.text[l][k] && <span className="mt-0.5 block text-[11px]" style={{ color: 'var(--text-muted)' }}>Original: {def}</span>}
                        </label>
                      ))}
                    </div>
                    {warn.length > 0 && (
                      <p className="mt-2 inline-flex items-center gap-1 text-xs font-bold text-amber-800" role="alert">
                        <AlertTriangle className="h-3.5 w-3.5" /> Add {[...new Set(warn)].map((x) => `{${x}}`).join(', ')} back, or that detail won’t show.
                      </p>
                    )}
                  </li>
                );
              })}
            </ul>
          )}
          {keys.length === 80 && <p className="mt-2 text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>Showing the first 80 — search to narrow down.</p>}
        </>
      )}
    </div>
  );
}
