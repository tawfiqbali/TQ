import { lockScroll } from '../../../lib/scrollLock';
import { Suspense, lazy, useEffect, useRef, useState } from 'react';
// v179: a teacher's reports open in a pop-up here
const TeacherReportsModal = lazy(() => import('../../staff/ReportsReview').then((m) => ({ default: m.TeacherReportsModal })));
import { Pencil, Plus, X } from 'lucide-react';
import WeeklyClassTimes from '../../../components/ui/WeeklyClassTimes';
import { listStudentSchedules, resolveStudentDelete, setStudentSchedule } from '../../../lib/teacherData';
import { usePortal } from '../PortalContext';
import { BD_BANKS, CATEGORIES, DEPARTMENTS, MONTHS, PAYMENT_METHODS, currentMonthName, feeFor, fmt, hasMonthFee, joinPhones, monthKey, previousMonthOf, splitPhones, yearsWith } from '../lib/constants';
import { studentMonth } from '../lib/salaryCalc';
import Combobox from '../components/Combobox';
import { isGmail } from '../../../lib/auth';
import { useConfirm } from '../../../components/ui/Confirm';
import { useToast } from '../../../components/ui/Toast';

// Open pop-ups, newest last: Esc closes only the one on top
const openModals = [];

export function PortalModal({ children, onClose, className = '', labelledBy }) {
  useEffect(() => {
    const token = {};
    openModals.push(token);
    const onKey = (e) => e.key === 'Escape' && openModals[openModals.length - 1] === token && onClose();
    document.addEventListener('keydown', onKey);
    const prev = lockScroll();
    return () => {
      openModals.splice(openModals.indexOf(token), 1);
      document.removeEventListener('keydown', onKey);
      prev();
    };
  }, [onClose]);
  return (
    <div className="qit-portal qit-portal-modal" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`modal-card ${className}`} role="dialog" aria-modal="true" aria-labelledby={labelledBy}>
        {children}
      </div>
    </div>
  );
}

export function EditIconButton({ onClick, label }) {
  return (
    <button type="button" className="btn-icon-edit" title={label} aria-label={label} onClick={onClick}>
      <Pencil className="h-4 w-4" />
    </button>
  );
}

// Options for a "pick a teacher" dropdown, grouped by panel
export function teacherOptions(teachers, { none = '-- Unassigned --' } = {}) {
  const out = none ? [{ value: '', label: none }] : [];
  CATEGORIES.forEach((c) =>
    teachers
      .filter((t) => t.category === c.value)
      .forEach((t) => out.push({ value: t.id, group: c.label, label: `${t.name} (${t.id})${t.salaryType === 'Package' ? ' [Fixed Salary]' : ''}` })),
  );
  return out;
}

// One input per WhatsApp number, with + / × buttons
export function PhoneListInput({ value, onChange, compact = false }) {
  const list = value.length ? value : [''];
  const setAt = (i, v) => onChange(list.map((x, j) => (j === i ? v : x)));
  return (
    <div className={`phone-list ${compact ? 'compact' : ''}`}>
      {list.map((p, i) => (
        <div key={i} className="phone-row">
          <input
            className="m-input"
            inputMode="tel"
            placeholder={i === 0 ? 'WhatsApp number' : `WhatsApp number ${i + 1}`}
            value={p}
            onChange={(e) => setAt(i, e.target.value)}
            aria-label={`WhatsApp number ${i + 1}`}
          />
          {list.length > 1 && (
            <button type="button" className="phone-remove" onClick={() => onChange(list.filter((_, j) => j !== i))} aria-label={`Remove number ${i + 1}`}>
              <X className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
      ))}
      <button type="button" className="phone-add" onClick={() => onChange([...list, ''])}>
        <Plus className="h-3.5 w-3.5" /> Add number
      </button>
    </div>
  );
}

// Teacher WhatsApp numbers must be unique (last 10 digits; names may repeat).
// Returns the other teacher using this number, or null.
export const phoneKey = (p) => String(p || '').replace(/[০-৯]/g, (d) => '০১২৩৪৫৬৭৮৯'.indexOf(d)).replace(/\D/g, '').slice(-10);
export function teacherWithPhone(teachers, phone, exceptId) {
  const k = phoneKey(phone);
  if (k.length < 7) return null;
  return teachers.find((t) => t.id !== exceptId && phoneKey(t.whatsapp) === k) || null;
}

// v151: same WhatsApp number + same name = the same child. Brothers and sisters
// on one number need different names; the same child in a second class (another
// teacher) is saved with sameStudentOf = the other record's ID.
const nameKey = (n) => String(n || '').trim().replace(/\s+/g, ' ').toLowerCase();
const studentPhoneKeys = (p) => String(p || '').split(/\s*(?:,|\/|;|\||\s+or\s+)\s*/).map(phoneKey).filter((k) => k.length >= 7);
export function findSameStudent(students, name, phone, exceptId) {
  const n = nameKey(name);
  const keys = studentPhoneKeys(phone);
  if (!n || !keys.length) return null;
  return students.find((s) => s.id !== exceptId && nameKey(s.name) === n && studentPhoneKeys(s.phone).some((k) => keys.includes(k))) || null;
}
// v172: class time from the teacher's weekly schedule ("Sun, Mon 7:00 AM; Tue 8:00 PM")
// → just the time(s) and how many days a week: { time: '7:00 AM / 8:00 PM', days: 3 }
const DAY_RE = /\b(Sun|Mon|Tue|Wed|Thu|Fri|Sat)\b/g;
export function classTimeParts(classTime) {
  const text = String(classTime || '').trim();
  if (!text) return null;
  const groups = text.split(/\s*;\s*/);
  const times = [];
  const days = new Set();
  for (const g of groups) {
    const m = g.match(/(\d{1,2}:\d{2}\s*(?:AM|PM)?)\s*$/i);
    const ds = g.match(DAY_RE);
    if (!m || !ds) return null; // typed by hand: shown as written
    if (!times.includes(m[1])) times.push(m[1]);
    ds.forEach((d) => days.add(d));
  }
  return { time: times.join(' / '), days: days.size };
}

// v169: every student already on this WhatsApp number
export function findByPhone(students, phone, exceptId) {
  const keys = studentPhoneKeys(phone);
  if (!keys.length) return [];
  return students.filter((s) => s.id !== exceptId && studentPhoneKeys(s.phone).some((k) => keys.includes(k)));
}
export const sameName = (a, b) => nameKey(a) === nameKey(b) && nameKey(a) !== '';
/**
 * v169: "Same number?" choice shown right in the entry, as soon as the number
 * matches another student: Relative (brother / sister — needs a different name)
 * or Same student, different class. value = { link: '' | 'relative' | 'same', linkTo }
 */
export function sameNumberProblem(matches, name, value) {
  if (!matches.length) return '';
  if (!value?.link) return 'choose';
  if (value.link === 'relative' && matches.some((m) => sameName(m.name, name))) return 'relative-name';
  if (value.link === 'same' && !matches.some((m) => m.id === value.linkTo)) return 'choose';
  return '';
}
export function SameNumberPick({ matches, teachers = [], name, value, onChange, missing }) {
  // v170: small tick boxes that fit the empty space of the entry (the box never grows)
  if (!matches.length) return <div className="snp is-empty" data-testid="snp"><span className="snp-none">Same number? — no</span></div>;
  const tName = (id) => teachers.find((t) => t.id === id)?.name;
  const problem = sameNumberProblem(matches, name, value);
  const pickLink = (link) => {
    if (value?.link === link) return onChange({ link: '', linkTo: '' });
    const sameOne = matches.find((m) => sameName(m.name, name)) || matches[0];
    onChange({ link, linkTo: link === 'same' ? sameOne.id : '' });
  };
  const who = matches.map((m) => `${m.name} (${m.id}${tName(m.teacherId) ? `, ${tName(m.teacherId)}` : ''})`).join(', ');
  return (
    <div className={`snp ${missing && problem ? 'is-missing' : ''}`} data-testid="snp">
      <span className="snp-label" title={who}>Number used by {matches[0].name}{matches.length > 1 ? ` +${matches.length - 1}` : ''}</span>
      <label className="snp-tick"><input type="checkbox" checked={value?.link === 'relative'} onChange={() => pickLink('relative')} data-testid="snp-relative" /> Relative</label>
      <label className="snp-tick"><input type="checkbox" checked={value?.link === 'same'} onChange={() => pickLink('same')} data-testid="snp-same" /> Same student, different class</label>
      {value?.link === 'same' && matches.length > 1 && (
        <select className="snp-which" value={value.linkTo} onChange={(e) => onChange({ ...value, linkTo: e.target.value })} aria-label="Which student">
          {matches.map((m) => <option key={m.id} value={m.id}>{m.name} ({m.id})</option>)}
        </select>
      )}
      {problem === 'relative-name' && <span className="snp-warn">Relative needs a different name</span>}
      {missing && problem === 'choose' && <span className="snp-warn">Tick one to save</span>}
    </div>
  );
}

/** The warning + "Same student, 2 different classes" tick under a student entry */
export function SameStudentNote({ match, teachers = [], checked, onChange, missing }) {
  if (!match) return null;
  const t = teachers.find((x) => x.id === match.teacherId);
  return (
    <div className={`same-note ${missing && !checked ? 'is-missing' : ''}`} role="alert" data-testid="same-note">
      <p><strong>{match.name}</strong> ({match.id}{t ? `, with ${t.name}` : ''}) already has this WhatsApp number and this name. Brothers and sisters need different names.</p>
      {String(match.id).startsWith('row ') ? <p>Enroll the second class after saving this one.</p> : (
        <label><input type="checkbox" checked={Boolean(checked)} onChange={(e) => onChange(e.target.checked)} data-testid="same-ok" /> Same student, 2 different classes</label>
      )}
    </div>
  );
}

export const STUDENT_STATUSES = [
  { value: 'Active', label: 'Active', hint: 'Taking classes — shown in the teacher’s My Students' },
  { value: 'Hold', label: 'Hold', hint: 'Paused for now — moves to the teacher’s Student history' },
  { value: 'Inactive', label: 'Inactive', hint: 'Stopped — kept in Student history with all records' },
];
export const statusOf = (s) => (['Active', 'Hold', 'Inactive'].includes(s?.status) ? s.status : 'Active');

/**
 * A student's real weekly class times (the ones the teacher sees on the
 * student card, the Schedule page and Attendance): "Add class time" until the
 * student has one, then "Edit class time" with the saved days selected.
 */
export function WeeklyTimes({ student, teacherId, onChanged, onCount, pendingRef }) {
  const toast = useToast();
  const [rows, setRows] = useState(null);
  const [error, setError] = useState('');
  useEffect(() => {
    let alive = true;
    listStudentSchedules(student.id)
      .then((list) => { if (alive) { setRows(list); onCount?.(list.length); } })
      .catch((e) => { if (alive) { setRows([]); setError(e.message); } });
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [student.id]);
  const onSave = async (slots) => {
    const saved = (await setStudentSchedule(student.id, slots, teacherId)) || [];
    setRows(saved);
    onCount?.(saved.length);
    onChanged?.(); // v183: refresh the list in the background (no waiting)
    toast(slots.length ? 'Class times saved.' : 'Schedule deleted.');
  };
  return (
    <div className="form-group">
      <label>Weekly class times</label>
      <div style={{ border: '1px solid var(--border, #d9e2e1)', borderRadius: 12, padding: 12 }}>
        {rows === null ? <p className="text-sm" style={{ color: 'var(--text-muted)' }}>Loading…</p>
          : <WeeklyClassTimes rows={rows} onSave={onSave} pendingRef={pendingRef} inputClass="m-input" showNote={false} labels={{ applyHint: 'Press Save to apply.' }} />}
        {error && <p role="alert" className="mt-2 text-sm font-semibold" style={{ color: '#b42318' }}>{error}</p>}
      </div>
    </div>
  );
}

// What an Assignment Date means for pay (shown under the date)
export function assignHint(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || '');
  if (!m) return '';
  const d = Number(m[3]);
  const mon = MONTHS[Number(m[2]) - 1];
  const next = MONTHS[Number(m[2]) % 12];
  if (d <= 3) return `Starts in the first 3 days: ${mon} counts as a full month.`;
  const days = Math.max(0, 30 - d);
  return d <= 15 ? `${mon}: ${days} days counted (fee and teacher share), paid with ${mon}'s salary.` : `${mon}: ${days} days — the teacher gets them with ${next}'s salary (together with the full ${next}).`;
}

export const MEDIUMS = ['Bangla Medium', 'English Medium'];

/**
 * v161: a student's details, shown when the name is pressed anywhere.
 * Every staff member sees the monthly payment; the other payment terms
 * (teacher share, fixed salary, months with their own amount, last month's
 * counted amounts) are for Executives only.
 */
export function StudentDetails({ student: s }) {
  const { db, isSuper } = usePortal();
  const t = db.teachers.find((x) => x.id === s.teacherId);
  const last = previousMonthOf();
  const lm = studentMonth(s, last.month, last.year);
  const st = statusOf(s);
  const own = Object.entries(s.feeByMonth || {}).filter(([, a]) => Number(a) !== (Number(s.fee) || 0)).sort();
  const isPkg = t?.salaryType === 'Package';
  const fee = Number(s.fee) || 0;
  const cut = Number(s.cut) || 0;
  const Row = ({ k, children, testid }) => <div className="sd-row" data-testid={testid}><span>{k}</span><b>{children}</b></div>;
  return (
    <section className="sd-card" data-testid="student-details" aria-label="Student details">
      <div className="sd-head">
        <div className="min-w-0">
          <div className="sd-name">{s.name} <span className={`st-chip ${st.toLowerCase()}`}>{st}</span></div>
          <div className="sd-sub"><span className="id-tag">{s.id}</span>{s.medium ? <span className={`t-medium ${s.medium === 'English Medium' ? 'en' : 'bn'}`}>{s.medium}</span> : <span className="t-medium miss">Medium not set</span>}</div>
        </div>
      </div>
      <div className="sd-grid">
        <div className="sd-box">
          <h4>Class</h4>
          <Row k="Teacher">{t ? <span className="p-link" {...{ 'data-profile': `teacher:${t.id}`, role: 'link', tabIndex: 0 }}>{t.name}</span> : 'Not assigned'}{t ? ` (${t.id})` : ''}</Row>
          <Row k="Class time">{s.scheduleType === 'flexible' ? 'Flexible' : s.classTime || '—'}</Row>
          <Row k="WhatsApp">{s.phone && s.phone !== 'N/A' ? s.phone : '—'}</Row>
          <Row k="Course">{s.course || '—'}</Row>
          {s.assignDate && <Row k="First class">{new Date(`${s.assignDate}T00:00:00`).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}</Row>}
        </div>
        <div className="sd-box sd-pay">
          <h4>Payment terms</h4>
          <Row k="Monthly payment" testid="sd-fee">{fmt(fee)} BDT</Row>
          <Row k={`${last.month.slice(0, 3)} ${last.year} payment`}>{fmt(lm.fee)} BDT{lm.partial && lm.note ? <small className="sd-note">{lm.note}</small> : null}</Row>
          {isSuper && (
            <div className="sd-exec" data-testid="sd-exec">
              <Row k="Teacher share">{isPkg ? `Part of fixed salary (${fmt(Number(t.packageAmount) || 0)} BDT)` : `${fmt(cut)} BDT${fee ? ` · ${((cut / fee) * 100).toFixed(1)}%` : ''}`}</Row>
              {!isPkg && <Row k={`${last.month.slice(0, 3)} ${last.year} share`}>{fmt(lm.cut)} BDT</Row>}
              <Row k="Office keeps">{isPkg ? '—' : `${fmt(Math.max(0, fee - cut))} BDT`}</Row>
              <Row k="Months with own amount">{own.length ? own.map(([k, a]) => `${MONTHS[Number(k.slice(5)) - 1]?.slice(0, 3)} ${k.slice(0, 4)}: ${fmt(a)}`).join(' · ') : 'None'}</Row>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

export function EditStudentModal({ student, onClose, month: startMonth, year: startYear, details = false }) {
  const { db, updateStudent, deleteStudent, isSuper, load, mode } = usePortal();
  const confirm = useConfirm();
  const toast = useToast();
  // Weekly class times write the Class Time summary themselves
  const [auto, setAuto] = useState(false);
  const pending = useRef(null);
  const [saving, setSaving] = useState(false);
  const live = db.students.find((x) => x.id === student.id) || student;
  const [v, setV] = useState({
    name: student.name,
    phones: splitPhones(student.phone),
    classTime: student.classTime || '',
    scheduleType: student.scheduleType === 'flexible' ? 'flexible' : 'fixed',
    teacherId: student.teacherId || '',
    fee: student.fee,
    feeByMonth: { ...(student.feeByMonth || {}) },
    cut: student.cut,
    status: statusOf(student),
    assignDate: student.assignDate || '',
    medium: student.medium || '',
    statusDate: new Date().toISOString().slice(0, 10),
    // v185: the dated Active / Hold / Inactive changes (they decide which months count)
    statusLog: Array.isArray(student.statusLog) ? student.statusLog.map((e, i) => ({ ...e, _k: i })) : [],
    stopDate: '', // v188: a Hold / Inactive student without a date: when the classes stopped
  });
  const statusChanged = v.status !== statusOf(student);
  const [mediumMiss, setMediumMiss] = useState(false);
  // v151: a name / number change that makes this the same as another student
  const [sameOk, setSameOk] = useState(false);
  const [sameMiss, setSameMiss] = useState(false);
  const idChanged = v.name.trim() !== String(student.name || '').trim() || joinPhones(v.phones) !== (student.phone || 'N/A');
  const sameMatch = idChanged ? findSameStudent(db.students, v.name, joinPhones(v.phones), student.id) : null;
  const set = (k) => (e) => setV((x) => ({ ...x, [k]: e.target.value }));
  // Payment of one month: the default tuition unless this month has its own amount
  const [pm, setPm] = useState({ month: startMonth || currentMonthName(), year: String(startYear || new Date().getFullYear()) });
  const key = monthKey(pm.month, pm.year);
  const draft = { fee: v.fee, feeByMonth: v.feeByMonth };
  const monthChanged = hasMonthFee(draft, pm.month, pm.year);
  const setMonthFee = (val) => setV((x) => {
    const next = { ...x.feeByMonth };
    // typing the default amount again (or emptying the box) goes back to the default
    if (val === '' || Number(val) === (Number(x.fee) || 0)) delete next[key];
    else next[key] = Math.max(0, Number(val) || 0);
    return { ...x, feeByMonth: next };
  });
  // v185: status history as saved (without the editing keys); edited = dates changed or removed
  const cleanLog0 = v.statusLog.filter((e) => /^\d{4}-\d{2}-\d{2}$/.test(e.date || '')).map(({ _k, ...e }) => e);
  // v188: Hold / Inactive with no dated change yet → "Hold from" date box; the days before it count
  const needStop = !statusChanged && v.status !== 'Active' && !cleanLog0.some((e) => e.status !== 'Active');
  const cleanLog = needStop && /^\d{4}-\d{2}-\d{2}$/.test(v.stopDate) ? [...cleanLog0, { status: v.status, date: v.stopDate, from: 'Active' }] : cleanLog0;
  const logEdited = JSON.stringify(cleanLog) !== JSON.stringify(Array.isArray(student.statusLog) ? student.statusLog : []);
  const setLog = (k, patch) => setV((x) => ({ ...x, statusLog: patch ? x.statusLog.map((e) => (e._k === k ? { ...e, ...patch } : e)) : x.statusLog.filter((e) => e._k !== k) }));
  // what the chosen month counts with the changes in this box (before saving)
  const previewOf = () => {
    const draftS = {
      ...student, status: v.status, assignDate: v.assignDate || '', fee: Number(v.fee) || 0, feeByMonth: v.feeByMonth, cut: Number(v.cut) || 0,
      statusLog: [...cleanLog, ...(statusChanged && /^\d{4}-\d{2}-\d{2}$/.test(v.statusDate) ? [{ status: v.status, date: v.statusDate }] : [])],
    };
    return { m: studentMonth(draftS, pm.month, pm.year), full: feeFor(draftS, pm.month, pm.year) };
  };
  const save = async () => {
    if (saving) return;
    const toView = (sel) => document.querySelector(sel)?.scrollIntoView({ block: 'center', behavior: 'smooth' });
    // v183: anything that stops the save says why, in a floating message
    if (sameMatch && !sameOk) { setSameMiss(true); toView('[data-testid="same-note"]'); toast(`${sameMatch.name} (${sameMatch.id}) already has this name and number — tick "Same student, 2 different classes" or change the name.`, 'error'); return; }
    // v161: Bangla / English Medium is required
    if (!MEDIUMS.includes(v.medium)) { setMediumMiss(true); toView('[data-testid="admin-medium"]'); toast('Choose Bangla Medium or English Medium.', 'error'); return; }
    if (statusChanged && !/^\d{4}-\d{2}-\d{2}$/.test(v.statusDate)) { toast('Choose the date of the status change.', 'error'); return; }
    setSaving(true);
    // days and time chosen under Weekly class times without pressing Add are saved too
    const timesFn = pending.current;
    const saveTimes = async () => (v.scheduleType === 'fixed' && timesFn ? timesFn() : true);
    const wasFlex = student.scheduleType === 'flexible';
    let res = wasFlex ? true : await saveTimes();
    if (!res) {
      setSaving(false);
      toView('[data-testid="wt-error"]');
      toast('The class times could not be saved — see the red message under Weekly class times.', 'error');
      return;
    }
    const hasTimes = auto || res === 'saved';
    // v177: moved to another teacher — the old teacher keeps the days up to the
    // move (paid with that month's salary); the new teacher counts from the date
    const today = new Date().toISOString().slice(0, 10);
    const moved = Boolean(student.teacherId) && v.teacherId !== student.teacherId;
    const moveDate = moved ? (v.assignDate && v.assignDate !== student.assignDate ? v.assignDate : today) : '';
    const oldLog = Array.isArray(student.teacherLog) ? student.teacherLog : [];
    let teacherLog = null;
    if (moved) teacherLog = [...oldLog, { teacherId: student.teacherId, from: student.assignDate || '', to: moveDate, cut: Number(student.cut) || 0, toTeacher: v.teacherId, at: today }];
    else if (oldLog.length && v.assignDate && v.assignDate !== student.assignDate && oldLog[oldLog.length - 1].to === student.assignDate) {
      // the move date was corrected: the old teacher's last day follows it
      teacherLog = oldLog.map((e, i) => (i === oldLog.length - 1 ? { ...e, to: v.assignDate } : e));
    }
    // v183: the change shows at once (the list updates right away) and the box
    // closes; the cloud save finishes in the background with a floating message
    onClose();
    const ok = await updateStudent({
      id: student.id,
      status: v.status,
      assignDate: moved ? moveDate : v.assignDate || '',
      ...(teacherLog ? { teacherLog } : {}),
      medium: v.medium || '',
      ...(sameMatch && sameOk ? { sameStudentOf: sameMatch.id } : {}),
      // v155: a dated status change, used to prorate the salary and the revenue
      ...(statusChanged || logEdited ? { statusLog: [...cleanLog, ...(statusChanged ? [{ status: v.status, date: v.statusDate, from: statusOf(student) }] : [])] } : {}),
      name: v.name.trim() || 'Unnamed Student',
      phone: joinPhones(v.phones),
      // with weekly class times, Class Time is their summary (written by the database)
      ...(hasTimes && v.scheduleType !== 'flexible' ? {} : { classTime: v.scheduleType === 'flexible' ? '' : v.classTime.trim() }),
      scheduleType: v.scheduleType,
      teacherId: v.teacherId,
      fee: Number(v.fee) || 0,
      feeByMonth: Object.fromEntries(Object.entries(v.feeByMonth).filter(([, a]) => Number(a) !== (Number(v.fee) || 0))),
      // Junior Admins never see or change the teacher's share
      ...(isSuper ? { cut: Number(v.cut) || 0 } : {}),
    });
    if (wasFlex && ok !== null) res = await saveTimes();
    if (res === 'saved') load(['students']);
  };
  const remove = async () => {
    if (!(await confirm({ title: 'Delete student?', message: `${student.name} (${student.id}) will be removed. This cannot be undone.`, confirmText: 'Delete student', tone: 'danger' }))) return;
    deleteStudent(student.id);
    onClose();
  };
  return (
    <PortalModal onClose={onClose} labelledBy="edit-student-title">
      <div className="mb-4 flex items-center justify-between">
        <h3 id="edit-student-title" className="text-lg font-extrabold">{details ? 'Student details' : 'Edit Student'}</h3>
        <span className="id-tag">{student.id}</span>
      </div>
      {details && <><StudentDetails student={live} /><h4 className="sd-edit-title">Edit</h4></>}
      {live.deleteRequest && (
        <div className="del-req mb-4" data-testid="del-req">
          <p><strong>Delete requested</strong> by {live.deleteRequest.by === 'office' ? 'the office' : `the teacher (${live.deleteRequest.teacherId || student.teacherId})`}{live.deleteRequest.at ? ` on ${new Date(live.deleteRequest.at).toLocaleDateString('en-GB')}` : ''}.{live.deleteRequest.reason ? ` Reason: ${live.deleteRequest.reason}` : ''}</p>
          {isSuper ? (
            <div className="mt-2 flex flex-wrap gap-2">
              <button type="button" className="btn-danger" data-testid="del-approve" onClick={async () => {
                if (!(await confirm({ title: 'Delete this student?', message: `${student.name} (${student.id}) is removed for good, with the class times.`, confirmText: 'Delete student', tone: 'danger' }))) return;
                try { await resolveStudentDelete(student.id, true); await load(['students']); onClose(); } catch (e) { alert(e.message); }
              }}>Confirm delete</button>
              <button type="button" className="btn-muted" data-testid="del-refuse" onClick={async () => { try { await resolveStudentDelete(student.id, false); await load(['students']); onClose(); } catch (e) { alert(e.message); } }}>Keep the student</button>
            </div>
          ) : <p className="mt-1 text-xs">An Executive confirms or refuses it.</p>}
        </div>
      )}
      <div className="form-group"><label>Student Full Name</label><input className="m-input" value={v.name} onChange={set('name')} /></div>
      <div className="form-group"><label>WhatsApp Number(s)</label><PhoneListInput value={v.phones} onChange={(phones) => setV((x) => ({ ...x, phones }))} /></div>
      <SameStudentNote match={sameMatch} teachers={db.teachers} checked={sameOk} onChange={setSameOk} missing={sameMiss} />
      <div className="grid grid-cols-2 gap-3">
        <div className="form-group">
          <label>Schedule</label>
          <Combobox value={v.scheduleType} onChange={(scheduleType) => setV((x) => ({ ...x, scheduleType }))} options={[{ value: 'fixed', label: 'Fixed days & times' }, { value: 'flexible', label: 'Flexible (সুবিধাজনক)' }]} aria-label="Schedule type" />
        </div>
        <div className="form-group"><label>{mode === 'supabase' ? 'Class time note' : 'Class Time'}</label><input className="m-input" data-testid="es-classtime" value={v.scheduleType === 'flexible' ? 'Flexible' : auto ? live.classTime || '' : v.classTime} disabled={v.scheduleType === 'flexible' || auto} title={auto ? 'Filled in from the weekly class times below' : undefined} onChange={set('classTime')} /></div>
      </div>
      {mode === 'supabase' && v.scheduleType === 'fixed' && (
        <WeeklyTimes student={student} teacherId={v.teacherId || student.teacherId} onChanged={() => load(['students'])} onCount={(n) => setAuto(n > 0)} pendingRef={pending} />
      )}
      <div className="form-group">
        <label>Status</label>
        <div className="grid grid-cols-3 gap-2" role="radiogroup" aria-label="Student status" data-testid="student-status">
          {STUDENT_STATUSES.map((o) => (
            <button key={o.value} type="button" role="radio" aria-checked={v.status === o.value} title={o.hint}
              onClick={() => setV((x) => ({ ...x, status: o.value }))}
              className={`st-pick st-pick-${o.value.toLowerCase()} ${v.status === o.value ? 'on' : ''}`}>{o.label}</button>
          ))}
        </div>
        <p className="mt-1 text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>{STUDENT_STATUSES.find((o) => o.value === v.status)?.hint}</p>
        {statusChanged && (
          <div className="status-date mt-2" data-testid="status-date-box">
            <label htmlFor="es-status-date">{v.status === 'Active' ? 'Active again from' : `${v.status} from`} <span style={{ color: '#b42318' }}>*</span></label>
            <input id="es-status-date" type="date" className="m-input" required value={v.statusDate} onChange={set('statusDate')} data-testid="status-date" />
            <span>{v.status === 'Active' ? '1st–3rd = full month; from the 4th the days left are counted (from the 16th, paid with next month).' : '1st–3rd = not counted this month; from the 4th that many days are counted (4th = 4 days).'}</span>
          </div>
        )}
        {needStop && (
          <div className="status-date mt-2" data-testid="stop-date-box">
            <label htmlFor="es-stop-date">{v.status} from <span style={{ fontWeight: 500 }}>(the day the classes stopped)</span></label>
            <input id="es-stop-date" type="date" className="m-input" value={v.stopDate} onChange={set('stopDate')} data-testid="stop-date" />
            <span>The teacher is paid for the days before it, with that month&apos;s salary (1st–3rd = nothing; from the 4th that many days, e.g. 11 Aug = 11 days). Unpaid, it stays in the teacher&apos;s Total due.</span>
          </div>
        )}
        {v.statusLog.length > 0 && (
          <div className="status-log mt-2" data-testid="status-log">
            <p className="status-log-title">Status history <span>— these dates decide which months count. Correct a wrong date or remove a change made by mistake.</span></p>
            {[...v.statusLog].sort((a, b) => String(a.date).localeCompare(String(b.date))).map((e) => (
              <div key={e._k} className="status-log-row" data-testid="status-log-row">
                <span className={`st-chip ${String(e.status).toLowerCase()}`}>{e.status}</span>
                <span className="text-xs font-semibold">from</span>
                <input type="date" className="m-input" value={e.date || ''} onChange={(ev) => setLog(e._k, { date: ev.target.value })} aria-label={`${e.status} from`} />
                {e.from && <span className="text-xs" style={{ color: 'var(--text-muted)' }}>(was {e.from})</span>}
                <button type="button" className="status-log-del" onClick={() => setLog(e._k, null)} aria-label={`Remove the ${e.status} change`} title="Remove this change" data-testid="status-log-del"><X className="h-3.5 w-3.5" /></button>
              </div>
            ))}
          </div>
        )}
      </div>
      <div className="form-group">
        <label>Bangla or English Medium <span style={{ color: '#b42318' }}>*</span></label>
        <div className={`grid grid-cols-2 gap-2 ${mediumMiss && !v.medium ? 'medium-miss' : ''}`} role="radiogroup" aria-label="Bangla or English Medium" aria-required="true" data-testid="admin-medium">
          {MEDIUMS.map((m) => (
            <button key={m} type="button" role="radio" aria-checked={v.medium === m} onClick={() => setV((x) => ({ ...x, medium: m }))} className={`st-pick ${v.medium === m ? 'on st-pick-active' : ''}`}>{m}</button>
          ))}
        </div>
        {mediumMiss && !v.medium && <p className="mt-1 text-xs font-bold" style={{ color: '#b42318' }} role="alert" data-testid="medium-required">Choose Bangla Medium or English Medium to save.</p>}
      </div>
      <div className="form-group">
        <label htmlFor="es-assign">Assignment date <span style={{ fontWeight: 500, color: 'var(--text-muted)' }}>(optional — the first class with this teacher)</span></label>
        <input id="es-assign" type="date" className="m-input" value={v.assignDate} onChange={set('assignDate')} data-testid="assign-date" />
        {v.assignDate && <p className="mt-1 text-xs font-semibold" style={{ color: 'var(--qit-gold)' }} data-testid="assign-hint">{assignHint(v.assignDate)}</p>}
      </div>
      <div className="form-group">
        <label>Assigned Teacher</label>
        <Combobox value={v.teacherId} onChange={(teacherId) => setV((x) => ({ ...x, teacherId }))} options={teacherOptions(db.teachers)} aria-label="Assigned teacher" />
        {student.teacherId && v.teacherId && v.teacherId !== student.teacherId && (() => {
          // v177: what the old teacher keeps for the month of the move
          const d = v.assignDate && v.assignDate !== student.assignDate ? v.assignDate : new Date().toISOString().slice(0, 10);
          const day = Number(d.slice(8, 10));
          const mon = MONTHS[Number(d.slice(5, 7)) - 1];
          const oldName = db.teachers.find((x) => x.id === student.teacherId)?.name || student.teacherId;
          return <p className="mt-1 text-xs font-semibold" style={{ color: 'var(--qit-gold)' }} data-testid="move-hint">
            Moving from {oldName} on {day} {mon?.slice(0, 3)}: {day <= 3 ? `${oldName} gets nothing for ${mon}` : `${oldName} keeps ${Math.min(day, 30)} days of ${mon}, paid with ${mon}'s salary`} — added automatically.{!(v.assignDate && v.assignDate !== student.assignDate) && ' Set the Assignment date above to the day of the move.'}
          </p>;
        })()}
      </div>
      {/* v188: two clearly named amounts — what the STUDENT pays, what the TEACHER gets */}
      <div className={isSuper ? 'grid grid-cols-2 gap-3' : ''}>
        <div className="form-group money-box is-student">
          <label htmlFor="es-fee"><span className="money-tag">Student</span> Student pays QIT monthly (BDT)</label>
          <input id="es-fee" type="number" min="0" className="m-input in-fee" value={v.fee} onChange={set('fee')} data-testid="fee-default" />
          <p className="money-hint">The guardian’s monthly fee.</p>
        </div>
        {isSuper && (
          <div className="form-group money-box is-teacher">
            <label htmlFor="es-cut"><span className="money-tag">Teacher</span> Teacher gets monthly (BDT)</label>
            <input id="es-cut" type="number" min="0" className="m-input in-cut" value={v.cut} onChange={set('cut')} data-testid="cut-default" />
            <p className="money-hint">Goes into the teacher’s salary for this student.</p>
          </div>
        )}
      </div>
      {isSuper && (Number(v.fee) || 0) > 0 && (
        <p className="money-keep" data-testid="money-keep">
          QIT keeps <strong>{fmt((Number(v.fee) || 0) - (Number(v.cut) || 0))} BDT</strong> a month · the teacher gets {Math.round(((Number(v.cut) || 0) / (Number(v.fee) || 1)) * 1000) / 10}% of the fee
        </p>
      )}
      <div className="form-group" data-testid="month-payment">
        <label><span className="money-tag is-student">Student</span> Student pays a different amount in one month? <span style={{ fontWeight: 500, color: 'var(--text-muted)' }}>(e.g. a discount month. Leave it as it is otherwise. The teacher’s amount does not change.)</span></label>
        <div className="grid grid-cols-[1.2fr_0.9fr_1fr] gap-2">
          <select className="m-input" value={pm.month} onChange={(e) => setPm((x) => ({ ...x, month: e.target.value }))} aria-label="Payment month" data-testid="pay-month">
            {MONTHS.map((m) => <option key={m} value={m}>{m}</option>)}
          </select>
          <select className="m-input" value={pm.year} onChange={(e) => setPm((x) => ({ ...x, year: e.target.value }))} aria-label="Payment year" data-testid="pay-year">
            {yearsWith(pm.year).map((y) => <option key={y} value={y}>{y}</option>)}
          </select>
          <input type="number" min="0" className="m-input in-fee" value={feeFor(draft, pm.month, pm.year)} onChange={(e) => setMonthFee(e.target.value)} aria-label={`Payment for ${pm.month} ${pm.year} (BDT)`} data-testid="pay-amount" />
        </div>
        <p className="mt-1 text-xs font-semibold" style={{ color: monthChanged ? 'var(--qit-gold)' : 'var(--text-muted)' }} data-testid="pay-note">
          {monthChanged ? (
            <>
              In {pm.month} {pm.year} the student pays this amount instead of the usual {fmt(Number(v.fee) || 0)} BDT.{' '}
              <button type="button" className="underline" onClick={() => setMonthFee('')} data-testid="pay-reset">Back to the usual amount</button>
            </>
          ) : `${pm.month} ${pm.year}: the student pays the usual ${fmt(Number(v.fee) || 0)} BDT.`}
          {Object.keys(v.feeByMonth).length > 0 && ` Months with a different amount: ${Object.keys(v.feeByMonth).sort().map((k) => `${MONTHS[Number(k.slice(5)) - 1]?.slice(0, 3)} ${k.slice(0, 4)}`).join(', ')}.`}
        </p>
        {(() => {
          // v185: what this month really counts, with the reason
          const { m, full } = previewOf();
          const zero = m.fee === 0 && m.cut === 0;
          return (
            <p className={`month-calc ${zero ? 'is-zero' : ''}`} data-testid="month-calc">
              {pm.month} {pm.year}: student pays <strong>{fmt(m.fee)} BDT</strong>{m.fee !== full ? ` of ${fmt(full)}` : ''}{isSuper ? <> · teacher gets <strong>{fmt(m.cut)} BDT</strong></> : null}
              {m.note ? ` — ${m.note}` : ''}
              {zero && (v.status !== 'Active' ? ` — the student is ${v.status}.` : `. If the classes ran in ${pm.month}, correct or remove the wrong change in the Status history above, or check the Assignment date.`)}
            </p>
          );
        })()}
      </div>
      <div className="mt-5 flex items-center justify-between">
        {isSuper ? <button type="button" className="btn-danger" onClick={remove}>Delete</button> : <span />}
        <div className="flex gap-2">
          <button type="button" className="btn-teal" onClick={save} disabled={saving}>Save</button>
          <button type="button" className="btn-muted" onClick={onClose}>Cancel</button>
        </div>
      </div>
    </PortalModal>
  );
}

export const SALARY_TYPES = [
  { value: 'Per-Student', label: 'Per-Student' },
  { value: 'Package', label: 'Fixed Salary' },
];

export function EditTeacherModal({ teacher, onClose, onDeleted }) {
  // Junior Admins get the same form without the salary model and amount
  const { db, updateTeacher, deleteTeacher, isSuper } = usePortal();
  const [assigning, setAssigning] = useState(false);
  const [reportsOpen, setReportsOpen] = useState(false);
  const confirm = useConfirm();
  const toast = useToast();
  const [v, setV] = useState({
    name: teacher.name,
    category: teacher.category,
    department: teacher.department || '',
    salaryType: teacher.salaryType || 'Per-Student',
    packageAmount: teacher.packageAmount || 0,
    payWith: teacher.payWith || '',
    whatsapp: teacher.whatsapp === 'N/A' ? '' : teacher.whatsapp || '',
    email: teacher.email || '',
    method: teacher.method || 'Bank',
    bankName: teacher.bankName || '',
    branchName: teacher.branchName || '',
    account: teacher.account === 'N/A' ? '' : teacher.account || '',
  });
  const set = (k) => (e) => setV((x) => ({ ...x, [k]: e.target.value }));
  const pick = (k) => (value) => setV((x) => ({ ...x, [k]: value }));
  const isBank = v.method === 'Bank';
  const gmail = v.email.trim().toLowerCase();
  const gmailBad = gmail && !isGmail(gmail);
  const gmailTaken = gmail && db.teachers.some((t) => t.id !== teacher.id && String(t.email || '').toLowerCase() === gmail);
  const oldGmail = String(teacher.email || '').trim().toLowerCase();
  const handover = Boolean(oldGmail) && gmail !== oldGmail;
  const phoneTakenBy = teacherWithPhone(db.teachers, v.whatsapp, teacher.id);
  const save = async () => {
    if (!v.name.trim() || gmailBad || gmailTaken || phoneTakenBy) return;
    // A new Gmail on a record that had one hands this Teacher ID to someone else
    if (handover && !(await confirm({
      title: `Give ${teacher.id} to ${gmail || 'nobody'}?`,
      message: `${oldGmail} is unlinked from ${teacher.id} and signed out everywhere. The Teacher ID password goes back to the automatic starting password, so give it to the new teacher.${gmail ? ` ${gmail} can also sign in with Google.` : ''}\n\nThe students, reports and salary history stay with ${teacher.id}. Update the name and WhatsApp for the new teacher too.`,
      confirmText: 'Hand over Teacher ID',
      tone: 'danger',
    }))) return;
    updateTeacher({
      id: teacher.id,
      name: v.name.trim(),
      category: v.category,
      department: v.department,
      ...(isSuper ? { salaryType: v.salaryType, packageAmount: v.salaryType === 'Package' ? Number(v.packageAmount) || 0 : 0, payWith: v.payWith || '' } : {}),
      whatsapp: v.whatsapp.trim() || 'N/A',
      email: gmail,
      method: v.method,
      bankName: isBank ? v.bankName : '',
      branchName: isBank ? v.branchName.trim() : '',
      account: v.account.trim() || 'N/A',
    });
    onClose();
  };
  const remove = async () => {
    if (db.students.some((s) => s.teacherId === teacher.id)) {
      toast("Reassign or remove this teacher's students first.", 'error');
      return;
    }
    if (!(await confirm({ title: 'Delete teacher?', message: `${teacher.name} (${teacher.id}) will be removed from the directory. This cannot be undone.`, confirmText: 'Delete teacher', tone: 'danger' }))) return;
    deleteTeacher(teacher.id);
    onClose();
    onDeleted?.();
  };
  return (
    <PortalModal onClose={onClose} labelledBy="edit-teacher-title">
      <div className="mb-4 flex items-center justify-between gap-2">
        <h3 id="edit-teacher-title" className="text-lg font-extrabold">Edit Teacher</h3>
        <span className="flex items-center gap-2">
          <button type="button" className="btn-outline-sm" onClick={() => setAssigning(true)} data-testid="assign-students">+ Assign Students</button>
          <button type="button" className="btn-outline-sm" onClick={() => setReportsOpen(true)} data-testid="teacher-reports">Reports</button>
          <span className="id-tag">{teacher.id}</span>
        </span>
      </div>
      {assigning && <AssignStudentModal teacher={teacher} onClose={() => setAssigning(false)} />}
      {reportsOpen && <Suspense fallback={null}><TeacherReportsModal teacher={teacher} onClose={() => setReportsOpen(false)} /></Suspense>}
      <div className="form-group"><label>Teacher Full Name</label><input className="m-input" value={v.name} onChange={set('name')} required /></div>
      <div className="form-group">
        <label>Panel Category</label>
        <Combobox value={v.category} onChange={pick('category')} options={CATEGORIES.map((c) => ({ value: c.value, label: c.label }))} aria-label="Panel category" />
      </div>
      <div className="form-group">
        <label>Department</label>
        <Combobox value={v.department} onChange={pick('department')} options={[{ value: '', label: '-- Not set --' }, ...DEPARTMENTS]} aria-label="Department" />
      </div>
      {isSuper && (
        <div className="form-group">
          <label>Salary Model</label>
          <Combobox value={v.salaryType} onChange={pick('salaryType')} options={SALARY_TYPES} aria-label="Salary model" />
        </div>
      )}
      {isSuper && v.salaryType === 'Package' && (
        <div className="form-group"><label>Fixed Salary Amount (BDT)</label><input type="number" min="0" className="m-input in-cut" value={v.packageAmount} onChange={set('packageAmount')} /></div>
      )}
      {/* v168: husband and wife — her salary and due are paid together with his */}
      {isSuper && (() => {
        const partners = db.teachers.filter((x) => x.payWith === teacher.id);
        if (partners.length) return <p className="form-group text-sm font-bold" style={{ color: 'var(--qit-teal)' }} data-testid="pay-with-partners">Salary paid together with: {partners.map((x) => `${x.name} (${x.id})`).join(', ')} — their salary and due are added to this teacher.</p>;
        return (
          <div className="form-group" data-testid="pay-with">
            <label>Salary paid together with <span style={{ fontWeight: 500, color: 'var(--text-muted)' }}>(husband — her salary and due are paid to him)</span></label>
            <Combobox value={v.payWith} onChange={pick('payWith')} aria-label="Salary paid together with"
              options={[{ value: '', label: '-- Paid separately --' }, ...db.teachers.filter((x) => x.id !== teacher.id && !x.payWith).map((x) => ({ value: x.id, label: `${x.name} (${x.id})` }))]} />
          </div>
        );
      })()}
      <div className="form-group">
        <label>WhatsApp Contact</label>
        <input className="m-input" value={v.whatsapp} onChange={set('whatsapp')} aria-invalid={Boolean(phoneTakenBy)} data-testid="teacher-phone" />
        {phoneTakenBy && <p className="mt-1 text-xs font-bold" style={{ color: '#b42318' }} role="alert" data-testid="phone-taken">This number is already used by {phoneTakenBy.name} ({phoneTakenBy.id}). Each teacher needs their own number.</p>}
      </div>
      <div className="form-group">
        <label htmlFor="edit-teacher-gmail">Gmail (Teacher Dashboard sign-in)</label>
        <input id="edit-teacher-gmail" type="email" className="m-input" placeholder="teacher@gmail.com" value={v.email} onChange={set('email')} aria-invalid={Boolean(gmailBad || gmailTaken)} />
        <p className="mt-1 text-xs font-semibold" style={{ color: gmailBad || gmailTaken ? '#b42318' : 'var(--text-muted)' }}>
          {gmailBad ? 'Enter a Gmail address (…@gmail.com).' : gmailTaken ? 'Another teacher already uses this Gmail.' : handover ? `Changing the Gmail hands ${teacher.id} to a new person. ${oldGmail} will be signed out.` : 'When this teacher signs in with Google using this Gmail, they get this Teacher ID and their students automatically.'}
        </p>
      </div>
      <div className="form-group">
        <label>Payment Method</label>
        <Combobox value={v.method} onChange={pick('method')} options={PAYMENT_METHODS} aria-label="Payment method" />
      </div>
      {isBank && (
        <>
          <div className="form-group">
            <label>Bank Name</label>
            <Combobox value={v.bankName} onChange={pick('bankName')} options={BD_BANKS} placeholder="Type to search banks…" aria-label="Bank name" />
          </div>
          <div className="form-group"><label>Branch Name</label><input className="m-input" placeholder="e.g. Mirpur Branch" value={v.branchName} onChange={set('branchName')} /></div>
        </>
      )}
      <div className="form-group"><label>Account Number / Ref</label><input className="m-input" value={v.account} onChange={set('account')} /></div>
      <div className="mt-5 flex items-center justify-between">
        {isSuper ? <button type="button" className="btn-danger" onClick={remove}>Delete</button> : <span />}
        <div className="flex gap-2">
          <button type="button" className="btn-teal" onClick={save} disabled={Boolean(phoneTakenBy || gmailBad || gmailTaken)} data-testid="teacher-save">Save</button>
          <button type="button" className="btn-muted" onClick={onClose}>Cancel</button>
        </div>
      </div>
    </PortalModal>
  );
}


/**
 * v156: "Assign Students" from a teacher's profile — add one or more students
 * straight to this teacher, with everything (fee, Executive: teacher share,
 * Assignment date, class division).
 */
export function AssignStudentModal({ teacher, onClose }) {
  const { addStudents, isSuper, db } = usePortal();
  const blank = () => ({ name: '', phone: '', fee: '', cut: '', assignDate: '', medium: '', link: '', linkTo: '' });
  // v169: other students on this number, and the Relative / Same student choice
  const [rows, setRows] = useState([blank()]);
  const [busy, setBusy] = useState(false);
  // v183: while saving, the new students are already in the list — don't match them with themselves
  const [before, setBefore] = useState(null);
  const matchesOf = (r) => (r.phone.trim() ? findByPhone(busy && before ? before : db.students, r.phone) : []);
  const setAt = (i, k, val) => setRows((list) => list.map((r, j) => (j === i ? { ...r, [k]: val } : r)));
  const [tried, setTried] = useState(false);
  const save = async () => {
    // v161: every student needs Bangla / English Medium
    if (rows.some((r) => r.name.trim() && !MEDIUMS.includes(r.medium))) { setTried(true); return; }
    if (rows.some((r) => r.name.trim() && sameNumberProblem(matchesOf(r), r.name, r))) { setTried(true); return; }
    const list = rows.filter((r) => r.name.trim()).map((r, i) => ({
      id: `NEW-S${Date.now()}-${i}`, name: r.name.trim(), phone: r.phone.trim() || 'N/A', teacherId: teacher.id,
      fee: Number(r.fee) || 0, cut: isSuper && teacher.salaryType !== 'Package' ? Number(r.cut) || 0 : 0,
      course: 'Quran & Tajweed', status: 'Active', classTime: '',
      ...(r.assignDate ? { assignDate: r.assignDate } : {}), ...(r.medium ? { medium: r.medium } : {}),
      ...(r.link === 'same' && r.linkTo ? { sameStudentOf: r.linkTo } : {}), ...(r.link === 'relative' ? { relative: true } : {}),
    }));
    if (!list.length) return;
    setBusy(true);
    setBefore(db.students);
    await addStudents(list, []);
    setBusy(false);
    onClose();
  };
  return (
    <PortalModal onClose={onClose} className="wide" labelledBy="assign-title">
      <div className="mb-3 flex items-center justify-between">
        <h3 id="assign-title" className="text-lg font-extrabold">Assign students to {teacher.name}</h3>
        <span className="id-tag">{teacher.id}</span>
      </div>
      <div className="space-y-3" data-testid="assign-rows">
        {rows.map((r, i) => (
          <div key={i} className="assign-row">
            <input className="m-input" placeholder="Student name" value={r.name} onChange={(e) => setAt(i, 'name', e.target.value)} aria-label="Student name" />
            <input className="m-input" inputMode="tel" placeholder="WhatsApp number" value={r.phone} onChange={(e) => setAt(i, 'phone', e.target.value)} aria-label="WhatsApp number" />
            <input className="m-input in-fee" type="number" min="0" placeholder="Monthly fee" value={r.fee} onChange={(e) => setAt(i, 'fee', e.target.value)} aria-label="Monthly fee (BDT)" />
            {isSuper && teacher.salaryType !== 'Package' && <input className="m-input in-cut" type="number" min="0" placeholder="Teacher share" value={r.cut} onChange={(e) => setAt(i, 'cut', e.target.value)} aria-label="Teacher share (BDT)" />}
            <input className="m-input" type="date" value={r.assignDate} onChange={(e) => setAt(i, 'assignDate', e.target.value)} aria-label="Assignment date (optional)" title={r.assignDate ? assignHint(r.assignDate) : 'Assignment date (optional)'} />
            <select className={`m-input ${tried && r.name.trim() && !r.medium ? 'is-missing' : ''}`} required value={r.medium} onChange={(e) => setAt(i, 'medium', e.target.value)} aria-label="Bangla or English Medium (required)" data-testid="assign-medium">
              <option value="">Medium (required)…</option><option>Bangla Medium</option><option>English Medium</option>
            </select>
            <div className="assign-same"><SameNumberPick matches={matchesOf(r)} teachers={db.teachers} name={r.name} value={r} onChange={(val) => setRows((list) => list.map((x, j) => (j === i ? { ...x, ...val } : x)))} missing={tried} /></div>
          </div>
        ))}
      </div>
      {tried && rows.some((r) => r.name.trim() && !r.medium) && <p className="mt-2 text-sm font-bold" style={{ color: '#b42318' }} role="alert">Choose Bangla Medium or English Medium for every student.</p>}
      <div className="mt-4 flex flex-wrap items-center justify-between gap-2">
        <button type="button" className="btn-outline-sm" onClick={() => setRows((l) => [...l, blank()])}>+ Another student</button>
        <div className="flex gap-2">
          <button type="button" className="btn-teal" onClick={save} disabled={busy || !rows.some((r) => r.name.trim())} data-testid="assign-save">{busy ? 'Saving…' : 'Assign'}</button>
          <button type="button" className="btn-muted" onClick={onClose}>Cancel</button>
        </div>
      </div>
    </PortalModal>
  );
}
