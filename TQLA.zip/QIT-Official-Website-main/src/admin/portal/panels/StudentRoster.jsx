import { matchSearch } from '../../../lib/search';
import PhoneLinks from '../../../components/ui/PhoneLinks';
import { useEffect, useMemo, useState, useDeferredValue } from 'react';
import { Search } from 'lucide-react';
import { usePortal } from '../PortalContext';
import { MONTHS, feeFor, fmt, hasMonthFee, splitPhones, yearsWith } from '../lib/constants';
import { MonthModeToggle, defaultPick, figuresMonth, useMonthMode } from '../lib/monthMode';
import { studentMonth } from '../lib/salaryCalc';
import { renumberStudents, studentRenumberPlan } from '../../../lib/teacherData';
import { useConfirm } from '../../../components/ui/Confirm';
import { useToast } from '../../../components/ui/Toast';
import { EditIconButton, EditStudentModal, classTimeParts, statusOf } from './common';
import { profileAttr } from '../components/ProfileOpener';

export default function StudentRoster({ onEnroll }) {
  const { db, isSuper, load } = usePortal();
  const confirm = useConfirm();
  const toast = useToast();
  const [editing, setEditing] = useState(null);
  // v167: a long list shows in pages (phones 30, computers 100) — drawing every
  // student at once used too much memory on phones (the page reloaded on iPhone)
  const PAGE = typeof window !== 'undefined' && window.innerWidth < 900 ? 30 : 100;
  const [limit, setLimit] = useState(PAGE);
  const [q, setQ] = useState('');
  const deferredQ = useDeferredValue(q);
  const [status, setStatus] = useState('All');
  useEffect(() => { setLimit(PAGE); }, [deferredQ, status, PAGE]);
  // Which month's payment the list shows
  // v164: the month picked is the PAYMENT month; amounts are for the month before (October → September)
  const mode = useMonthMode();
  const [pick, setPay] = useState(() => defaultPick(mode));
  const pay = figuresMonth(mode, pick.month, pick.year);
  const counts = useMemo(() => db.students.reduce((m, s) => ({ ...m, [statusOf(s)]: (m[statusOf(s)] || 0) + 1 }), {}), [db.students]);
  // v151: the other record of a student taking 2 classes
  const otherClass = useMemo(() => Object.fromEntries(db.students.filter((x) => x.sameStudentOf).map((x) => [x.sameStudentOf, x.id])), [db.students]);
  const teacherName = (id) => db.teachers.find((t) => t.id === id)?.name || id || 'Unassigned';
  // v153: the teacher's share of each student as % and amount — for Fixed-Salary teachers
  // the fixed amount is spread over their active students by fee.
  const shareOf = useMemo(() => {
    const tById = Object.fromEntries(db.teachers.map((t) => [t.id, t]));
    const feeSum = {};
    db.students.forEach((s) => { if (statusOf(s) === 'Active' && s.teacherId) feeSum[s.teacherId] = (feeSum[s.teacherId] || 0) + (feeFor(s, pay.month, pay.year) || 0); });
    return (s) => {
      const fee = feeFor(s, pay.month, pay.year) || 0;
      const t = tById[s.teacherId];
      const sm = studentMonth(s, pay.month, pay.year);
      let amt = sm.payFrac !== 1 ? sm.cut : Number(s.cut) || 0;
      let fixed = false;
      if (t?.salaryType === 'Package' && !amt) {
        fixed = true;
        amt = statusOf(s) === 'Active' && feeSum[s.teacherId] ? Math.round((Number(t.packageAmount) || 0) * fee / feeSum[s.teacherId]) : 0;
      }
      return { amt, pct: fee ? Math.round(((fixed ? amt : Number(s.cut) || 0) / fee) * 1000) / 10 : 0, fixed, note: sm.note };
    };
  }, [db.students, db.teachers, pay.month, pay.year]);

  // v156: students who share a WhatsApp number with another student
  const dupGroups = useMemo(() => {
    const keysOf = (p) => String(p || '').split(/\s*(?:,|\/|;|\||\s+or\s+)\s*/).map((x) => x.replace(/\D/g, '').slice(-10)).filter((k) => k.length >= 7);
    const byKey = {};
    db.students.forEach((s) => keysOf(s.phone).forEach((k) => { (byKey[k] = byKey[k] || new Set()).add(s.id); }));
    const group = {};
    Object.values(byKey).filter((set) => set.size > 1).forEach((set) => { const g = [...set].sort()[0]; set.forEach((id) => { group[id] = group[id] && group[id] < g ? group[id] : g; }); });
    return group;
  }, [db.students]);
  const dupCount = Object.keys(dupGroups).length;
  const reorder = async () => {
    let plan = [];
    try { plan = (await studentRenumberPlan()) || []; } catch (e) { return toast(e.message, 'error'); }
    if (!plan.length) return toast('Same-number students already have IDs one after another.');
    if (!(await confirm({ title: 'Put same-number students one after another?', message: `${plan.length} Student ID(s) change, e.g. ${plan.slice(0, 3).map((p) => `${p.name}: ${p.oldId} → ${p.newId}`).join('; ')}. Class times, attendance and reports move with each student. The same ID numbers are used; only their order changes.`, confirmText: 'Re-order IDs' }))) return;
    try { const moved = await renumberStudents(); toast(`${(moved || []).length} Student ID(s) changed.`); await load(['students']); } catch (e) { toast(e.message, 'error'); }
  };
  const rows = useMemo(() => {
    const term = deferredQ.trim().toLowerCase();
    // v188: typing searches every student, whichever tab is open
    if (term) return db.students.filter((s) => matchSearch(`${s.name} ${s.id} ${s.phone} ${teacherName(s.teacherId)}`, term));
    if (status === 'Same number') {
      const num = (id) => Number(String(id).replace(/\D/g, '')) || 0;
      return db.students.filter((s) => dupGroups[s.id] && (!term || matchSearch(`${s.name} ${s.id} ${s.phone}`, term)))
        .sort((a, b) => num(dupGroups[a.id]) - num(dupGroups[b.id]) || num(a.id) - num(b.id));
    }
    const inTab = status === 'All' ? db.students : status === 'Delete requests' ? db.students.filter((s) => s.deleteRequest) : db.students.filter((s) => statusOf(s) === status);
    if (!term) return inTab;
    return inTab.filter((s) => matchSearch(`${s.name} ${s.id} ${s.phone} ${teacherName(s.teacherId)}`, term));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [db.students, db.teachers, deferredQ, status, dupGroups]);

  return (
    <div className="box-card">
      {/* v174: month picker up in the title row; a full-width search bar under it (like Teacher List) */}
      <div className="card-header-bar ro-head">
        <h2 className="card-title">Student roster</h2>
        <div className="flex flex-wrap items-center gap-2">
          <label className="flex items-center gap-1.5 text-xs font-bold uppercase" style={{ color: 'var(--text-muted)' }}>
            {mode === 'class' ? 'Class month' : 'Payment month'}
            <select className="m-input" style={{ width: 'auto' }} value={pick.month} onChange={(e) => setPay((x) => ({ ...x, month: e.target.value }))} aria-label="Payment month" data-testid="roster-month">
              {MONTHS.map((m) => <option key={m} value={m}>{m}</option>)}
            </select>
            <select className="m-input" style={{ width: 'auto' }} value={pick.year} onChange={(e) => setPay((x) => ({ ...x, year: e.target.value }))} aria-label="Payment year" data-testid="roster-year">
              {yearsWith(pick.year).map((y) => <option key={y} value={y}>{y}</option>)}
            </select>
            <span className="pay-period-for normal-case" data-testid="roster-for">for <strong>{pay.month.slice(0, 3)} {pay.year}</strong></span>
          </label>
          <MonthModeToggle />
          <button type="button" className="btn-teal" onClick={onEnroll}>+ Enroll New</button>
        </div>
      </div>
      <label className="roster-search ro-search-wide">
        <span className="sr-only">Search students</span>
        <Search aria-hidden="true" />
        <input type="search" className="m-input" placeholder="Search every student — name, ID, phone, teacher" value={q} onChange={(e) => setQ(e.target.value)} />
      </label>
      <div className="mb-4 flex flex-wrap gap-2" role="tablist" aria-label="Student status" data-testid="roster-tabs">
        {['All', 'Active', 'Hold', 'Inactive', 'Same number'].map((k) => (
          <button key={k} type="button" role="tab" aria-selected={status === k} className={`dir-tab ${status === k ? 'active' : ''}`} data-tone={{ All: 'teal', Active: 'green', Hold: 'gold', Inactive: 'slate', 'Same number': 'rose' }[k]} onClick={() => setStatus(k)} data-testid={`roster-tab-${k.replace(' ', '-')}`}>
            {k === 'Same number' ? 'Find duplicate numbers' : k} <span className="count">{k === 'All' ? db.students.length : k === 'Same number' ? dupCount : counts[k] || 0}</span>
          </button>
        ))}
        {db.students.some((s) => s.deleteRequest) && (
          <button type="button" role="tab" aria-selected={status === 'Delete requests'} className={`dir-tab ${status === 'Delete requests' ? 'active' : ''}`} data-tone="rose" onClick={() => setStatus('Delete requests')}>
            Delete requests <span className="count">{db.students.filter((s) => s.deleteRequest).length}</span>
          </button>
        )}
        {status === 'Same number' && isSuper && dupCount > 0 && (
          <button type="button" className="btn-outline-sm" onClick={reorder} data-testid="renumber">Put them one after another (IDs)</button>
        )}
      </div>
      <div className="table-wrap">
        <table className="salary-table row-cards" style={{ minWidth: isSuper ? 760 : 640 }}>
          <thead>
            <tr>
              <th>Student Profile</th><th>Class Time</th><th>Assigned Faculty</th><th>Payment · {pay.month.slice(0, 3)} {pay.year} {mode === 'pay' && <span className="block text-[10px] opacity-80">paid {pick.month.slice(0, 3)}</span>}</th>
              {/* Teacher Share is salary information: Super Admins only */}
              {isSuper && <th>Teacher Share</th>}
              <th style={{ textAlign: 'right' }}>Action</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && <tr><td colSpan={isSuper ? 6 : 5} style={{ textAlign: 'center', padding: 18 }}>{db.students.length ? 'No students match your search.' : 'No students enrolled yet.'}</td></tr>}
            {rows.slice(0, limit).map((s) => (
              <tr key={s.id} className={`row-card st-${statusOf(s).toLowerCase()}`} onClick={(e) => { if (!e.target.closest('a, button, input, select')) setEditing(s); }} title={`Open ${s.name}`} data-testid={`roster-row-${s.id}`}>
                <td>
                  {/* v161: name with a small status label beside it; ID and number below; Bangla / English Medium under them */}
                  <div className="ro-name"><strong className="p-link" {...profileAttr('student', s.id)}>{s.name}</strong><span className={`st-chip ${statusOf(s).toLowerCase()}`} data-testid={`status-${s.id}`}>{statusOf(s)}</span>{s.addedByTeacher && !Number(s.fee) ? <span className="st-badge submitted" title="Added by the teacher from the Teacher Dashboard — set the fee">New · set fee</span> : null}{s.deleteRequest ? <span className="st-badge no" title={s.deleteRequest.reason || ''}>Delete requested</span> : null}</div>
                  {(s.sameStudentOf || otherClass[s.id]) && <div className="ro-same" data-testid={`same-${s.id}`}>Same student, 2 classes · <span className="p-link" {...profileAttr('student', s.sameStudentOf || otherClass[s.id])}>{s.sameStudentOf || otherClass[s.id]}</span></div>}
                  <div className="ro-sub"><span className="ro-id">{s.id}</span><span className="text-xs"><PhoneLinks value={s.phone} empty="" /></span></div>
                  {s.medium ? <span className={`ro-medium ${s.medium === 'English Medium' ? 'en' : 'bn'}`} data-testid={`medium-${s.id}`}>{s.medium}</span> : <span className="ro-medium miss" data-testid={`medium-${s.id}`} title="Open the student and choose Bangla or English Medium">Medium not set</span>}
                </td>
                <td>{s.scheduleType === 'flexible' ? <span className="st-badge part">Flexible</span> : (() => {
                  const ct = classTimeParts(s.classTime);
                  return ct ? <><strong>{ct.time}</strong><span className="ct-days" title={s.classTime}>{ct.days} day{ct.days === 1 ? '' : 's'} a week</span></> : <strong>{s.classTime || '—'}</strong>;
                })()}</td>
                <td><span className="p-link" {...profileAttr('teacher', s.teacherId)}>{teacherName(s.teacherId)}</span></td>
                <td>{(() => { const sm = studentMonth(s, pay.month, pay.year); return sm.partial && sm.fee !== feeFor(s, pay.month, pay.year) ? <><strong>{fmt(sm.fee)} BDT</strong> <span className="text-xs" style={{ color: 'var(--text-muted)' }}>of {fmt(feeFor(s, pay.month, pay.year))}</span><div className="calc-note">{sm.note}</div></> : <strong>{fmt(feeFor(s, pay.month, pay.year))} BDT</strong>; })()}{hasMonthFee(s, pay.month, pay.year) && <span className="st-badge part" style={{ marginLeft: 6 }} title={`Default ${fmt(s.fee)} BDT`}>this month</span>}</td>
                {isSuper && (() => { const sh = shareOf(s); return <td data-testid={`share-${s.id}`}><strong>{fmt(sh.amt)} BDT</strong> <span className="share-pct">{sh.pct}%</span>{sh.fixed && <span className="block text-[11px]" style={{ color: 'var(--text-muted)' }}>part of fixed salary</span>}</td>; })()}
                <td style={{ textAlign: 'right' }}><EditIconButton label={`Edit ${s.name}`} onClick={() => setEditing(s)} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {rows.length > limit && (
        <div className="ro-more" data-testid="roster-more">
          <span>Showing {limit} of {rows.length}</span>
          <button type="button" className="btn-outline-sm" onClick={() => setLimit((n) => n + PAGE)} data-testid="roster-more-btn">Show {Math.min(PAGE, rows.length - limit)} more</button>
          {PAGE >= 100 && <button type="button" className="btn-muted" onClick={() => setLimit(Infinity)}>Show all</button>}
        </div>
      )}
      {editing && <EditStudentModal student={editing} month={pay.month} year={pay.year} onClose={() => setEditing(null)} />}
    </div>
  );
}
