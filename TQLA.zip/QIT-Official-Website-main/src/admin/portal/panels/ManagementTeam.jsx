import { matchSearch } from '../../../lib/search';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { CheckCircle2, Crown, Pencil, Plus, Trash2, UserRound } from 'lucide-react';
import { teamApi } from '../lib/api';
import { BD_BANKS, PAYMENT_METHODS, fmt } from '../lib/constants';
import { idxMonth, studentMonth } from '../lib/salaryCalc';
import { PortalModal } from './common';
import Combobox from '../components/Combobox';
import PhoneLinks from '../../../components/ui/PhoneLinks';
import { useConfirm } from '../../../components/ui/Confirm';
import { useToast } from '../../../components/ui/Toast';

/**
 * v178: Management Team Salary — the office team (not teachers): each member's
 * profile, monthly salary, disbursements and dues. Executives only (stored in
 * portal_team). Same month rules as teachers: a member who joins on the 1st–3rd
 * gets the whole month, from the 4th the days left (from the 16th they are paid
 * with the next month); leaving works like Hold / Inactive.
 */
export function useTeam() {
  const [team, setTeam] = useState(null);
  const [error, setError] = useState('');
  const reload = useCallback(async () => {
    try { setTeam(await teamApi.list()); setError(''); } catch (e) { setError(e.message); setTeam([]); }
  }, []);
  useEffect(() => { reload(); }, [reload]);
  return { team, error, reload, setTeam };
}

// The member as a "student" of the salary engine: cut = monthly salary
const asSalaryRecord = (m) => ({
  id: m.id, cut: Number(m.salary) || 0, fee: 0, assignDate: m.joinDate || '',
  status: m.status === 'Inactive' ? 'Inactive' : 'Active',
  statusLog: m.status === 'Inactive' && m.leftDate ? [{ status: 'Inactive', date: m.leftDate }] : [],
});
export function memberMonth(m, month, year) {
  const r = studentMonth(asSalaryRecord(m), month, year);
  const payments = (m.payments || []).filter((p) => p.month === month && String(p.year) === String(year));
  const paid = payments.reduce((a, p) => a + (Number(p.amount) || 0), 0);
  // v179: part payments keep the month open until the rest is paid
  const settled = payments.some((p) => !p.partial);
  const partPaid = payments.filter((p) => p.partial).reduce((a, p) => a + (Number(p.amount) || 0), 0);
  return { salary: r.cut, note: r.note, payments, paid, partPaid, settled, due: settled ? 0 : Math.max(0, r.cut - partPaid) };
}
export function memberDues(m, today = new Date()) {
  const lastK = today.getFullYear() * 12 + today.getMonth() - 1;
  const join = /^\d{4}-\d{2}/.test(m.joinDate || '') ? Number(m.joinDate.slice(0, 4)) * 12 + Number(m.joinDate.slice(5, 7)) - 1 : lastK;
  const months = [];
  for (let k = Math.max(join, lastK - 11); k <= lastK; k += 1) {
    const { month, year } = idxMonth(k);
    const f = memberMonth(m, month, year);
    if (f.due > 0) months.push({ month, year, salary: f.due, note: f.note });
  }
  return { months, total: months.reduce((a, x) => a + x.salary, 0) };
}

const BLANK = { name: '', role: '', whatsapp: '', email: '', joinDate: '', salary: '', method: 'Bank', bankName: '', branchName: '', account: '', address: '', nid: '', notes: '', status: 'Active', leftDate: '' };

function MemberForm({ member, onClose, onSaved }) {
  const toast = useToast();
  const [v, setV] = useState(() => ({ ...BLANK, ...(member || {}), salary: member?.salary ?? '' }));
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setV((x) => ({ ...x, [k]: e.target.value }));
  const save = async (e) => {
    e?.preventDefault();
    if (v.name.trim().length < 2) return toast('Write the member’s name.', 'error');
    if (!(Number(v.salary) >= 0) || v.salary === '') return toast('Write the monthly salary (BDT).', 'error');
    setBusy(true);
    try {
      const row = await teamApi.save({ ...v, name: v.name.trim(), role: v.role.trim(), salary: Number(v.salary) || 0, payments: member?.payments || [], ...(member?.id ? { id: member.id } : {}) });
      toast(member ? 'Member saved.' : `${row.name} added (${row.id}).`);
      onSaved(row);
    } catch (e2) { toast(e2.message, 'error'); setBusy(false); }
  };
  return (
    <PortalModal onClose={onClose} className="wide" labelledBy="mt-form-title">
      <form onSubmit={save} data-testid="team-form">
        <div className="mb-4 flex items-center justify-between">
          <h3 id="mt-form-title" className="text-lg font-extrabold">{member ? 'Edit team member' : 'Add a team member'}</h3>
          {member && <span className="id-tag">{member.id}</span>}
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="form-group"><label>Full name *</label><input className="m-input" value={v.name} onChange={set('name')} data-testid="mt-name" /></div>
          <div className="form-group"><label>Designation / role</label><input className="m-input" placeholder="e.g. Office Manager, Accountant" value={v.role} onChange={set('role')} data-testid="mt-role" /></div>
          <div className="form-group"><label>WhatsApp</label><input className="m-input" inputMode="tel" placeholder="01XXXXXXXXX" value={v.whatsapp} onChange={set('whatsapp')} /></div>
          <div className="form-group"><label>Email</label><input className="m-input" type="email" value={v.email} onChange={set('email')} /></div>
          <div className="form-group"><label>Monthly salary (BDT) *</label><input className="m-input in-cut" type="number" min="0" value={v.salary} onChange={set('salary')} data-testid="mt-salary" /></div>
          <div className="form-group"><label>Joining date <span style={{ fontWeight: 500, color: 'var(--text-muted)' }}>(first month counted by days)</span></label><input className="m-input" type="date" value={v.joinDate} onChange={set('joinDate')} data-testid="mt-join" /></div>
          <div className="form-group"><label>Paid by</label><select className="m-input" value={v.method} onChange={set('method')}>{PAYMENT_METHODS.map((m) => <option key={m}>{m}</option>)}</select></div>
          <div className="form-group"><label>{v.method === 'Bank' ? 'Account number' : 'Account / number'}</label><input className="m-input" value={v.account} onChange={set('account')} /></div>
          {v.method === 'Bank' && <>
            <div className="form-group"><label>Bank</label><Combobox value={v.bankName} onChange={(x) => setV((y) => ({ ...y, bankName: x }))} options={BD_BANKS} placeholder="Search bank…" aria-label="Bank" /></div>
            <div className="form-group"><label>Branch</label><input className="m-input" value={v.branchName} onChange={set('branchName')} /></div>
          </>}
          <div className="form-group"><label>Address</label><input className="m-input" value={v.address} onChange={set('address')} /></div>
          <div className="form-group"><label>NID / ID number</label><input className="m-input" value={v.nid} onChange={set('nid')} /></div>
          <div className="form-group"><label>Status</label>
            <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label="Status">
              {['Active', 'Inactive'].map((s) => <button key={s} type="button" role="radio" aria-checked={v.status === s} className={`st-pick st-pick-${s.toLowerCase()} ${v.status === s ? 'on' : ''}`} onClick={() => setV((x) => ({ ...x, status: s }))}>{s}</button>)}
            </div>
          </div>
          {v.status === 'Inactive' && <div className="form-group"><label>Left on</label><input className="m-input" type="date" value={v.leftDate} onChange={set('leftDate')} /></div>}
          <div className="form-group sm:col-span-2"><label>Notes</label><textarea className="m-input" rows={2} value={v.notes} onChange={set('notes')} /></div>
        </div>
        <div className="mt-4 flex justify-end gap-2">
          <button type="submit" className="btn-teal" disabled={busy} data-testid="mt-save">{busy ? 'Saving…' : 'Save'}</button>
          <button type="button" className="btn-muted" onClick={onClose}>Cancel</button>
        </div>
      </form>
    </PortalModal>
  );
}

function MemberWorkspace({ member, month, year, onClose, onChanged, onEdit }) {
  const toast = useToast();
  const confirm = useConfirm();
  const f = memberMonth(member, month, year);
  const dues = memberDues(member);
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [method, setMethod] = useState(member.method || 'Bank');
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [partial, setPartial] = useState(false);
  const amountValue = amount === '' ? (f.due > 0 && !partial ? String(f.due) : '') : amount;
  // compared with what is left of the month (salary minus part payments)
  const diff = partial ? 0 : (Number(amountValue) || 0) - f.due;
  const history = [...(member.payments || [])].sort((a, b) => String(b.date).localeCompare(String(a.date)));
  const persist = async (payments, msg) => {
    try { const row = await teamApi.save({ ...member, payments }); toast(msg); onChanged(row); } catch (e) { toast(e.message, 'error'); }
  };
  const disburse = async () => {
    const amt = Number(amountValue) || 0;
    if (f.settled) return toast(`${month} ${year} is already disbursed. Cancel it in the history to pay again.`, 'error');
    if (amt <= 0) return toast('Enter the amount.', 'error');
    if (partial && amt >= f.due) return toast(`A part payment must be less than ${fmt(f.due)} BDT. To pay all of it, untick "Part payment".`, 'error');
    if (diff !== 0 && !note.trim()) return toast(`The amount is ${fmt(Math.abs(diff))} BDT ${diff > 0 ? 'more' : 'less'} than the salary — write a short note.`, 'error');
    const msg = partial
      ? `${fmt(amt)} BDT to ${member.name} as part of the salary for ${month} ${year}. ${fmt(f.due - amt)} BDT stays due.`
      : `${fmt(amt)} BDT to ${member.name} as salary for ${month} ${year}${f.partPaid ? ` (with ${fmt(f.partPaid)} BDT paid before)` : ''}.`;
    if (!(await confirm({ title: partial ? 'Disburse part of the salary?' : 'Disburse salary?', message: msg, confirmText: 'Disburse' }))) return;
    const row = { id: `MPAY-${Date.now()}`, month, year: String(year), amount: amt, calculated: partial ? amt : f.due, date, method, ...(partial ? { partial: true, note: note.trim() || `Part payment · ${fmt(f.due - amt)} BDT left` } : diff ? { note: note.trim() } : {}) };
    await persist([...(member.payments || []), row], partial ? 'Part payment saved.' : 'Salary disbursed.');
    setAmount(''); setNote(''); setPartial(false);
  };
  return (
    <PortalModal onClose={onClose} className="wide" labelledBy="mt-ws-title">
      <div className="tile mb-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h2 id="mt-ws-title" className="text-xl font-extrabold">{member.name}</h2>
            <span className="id-tag">{member.id}</span>
            {member.role && <span className="mt-post" data-testid="mt-post"><Crown className="h-3.5 w-3.5" aria-hidden="true" />{member.role}</span>}
            <span className={`st-chip ${member.status === 'Inactive' ? 'inactive' : 'active'}`}>{member.status || 'Active'}</span>
          </div>
          <p className="mt-1 text-sm" style={{ color: 'var(--text-muted)' }}>
            Monthly salary: <strong>{fmt(member.salary)} BDT</strong>{member.joinDate ? <> • Joined {member.joinDate}</> : null}{member.whatsapp ? <> • WhatsApp: <PhoneLinks value={member.whatsapp} /></> : null}{member.email ? <> • {member.email}</> : null}
          </p>
          <p className="text-sm" style={{ color: 'var(--text-muted)' }}>
            {member.method === 'Bank' && member.bankName ? `Bank: ${member.bankName}${member.branchName ? ` (${member.branchName})` : ''}` : `Paid by ${member.method || 'not set'}`} • Acc: {member.account || 'not set'}{member.address ? ` • ${member.address}` : ''}{member.nid ? ` • NID ${member.nid}` : ''}
          </p>
          {member.notes && <p className="mt-1 text-sm font-semibold">{member.notes}</p>}
        </div>
        <button type="button" className="btn-teal inline-flex items-center gap-1.5" onClick={onEdit}><Pencil className="h-4 w-4" /> Edit profile</button>
      </div>

      <div className="payout-bar" data-testid="mt-payout">
        <div className="text-sm font-bold">
          <div>Salary for: <strong>{month} {year}</strong> • {f.settled ? <span style={{ color: 'var(--qit-teal)' }}>Disbursed: <strong>{fmt(f.paid)} BDT</strong></span> : <>Due: <strong style={{ color: 'var(--qit-gold)' }}>{fmt(f.due)} BDT</strong>{f.partPaid > 0 && <> • Part paid: <strong style={{ color: 'var(--qit-teal)' }}>{fmt(f.partPaid)} BDT</strong></>}</>}</div>
          {f.note && <div className="text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>{f.note}</div>}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {f.settled ? <span className="disbursed-box"><CheckCircle2 className="h-4 w-4" aria-hidden="true" /> Disbursed</span> : (
            <>
              <label className="payout-field"><span>Payment date</span><input type="date" value={date} onChange={(e) => setDate(e.target.value)} aria-label="Disbursement date" /></label>
              <label className="payout-field"><span>Sent by</span><select value={method} onChange={(e) => setMethod(e.target.value)} aria-label="Transfer method">{PAYMENT_METHODS.map((m) => <option key={m}>{m}</option>)}</select></label>
              <label className="payout-field"><span>Amount (BDT)</span><input type="number" className="w-28" value={amountValue} onChange={(e) => setAmount(e.target.value)} aria-label="Amount" data-testid="mt-amount" /></label>
              <label className="payout-field mt-part" title="Pay only part now; the rest stays due"><span>Part payment</span><span className="inline-flex h-[38px] items-center gap-1.5 text-sm font-bold"><input type="checkbox" checked={partial} onChange={(e) => { setPartial(e.target.checked); setAmount(''); }} data-testid="mt-partial" /> Pay part now</span></label>
              {partial && <label className="payout-field"><span>Note (optional)</span><input className="w-48" placeholder="e.g. advance" value={note} onChange={(e) => setNote(e.target.value)} aria-label="Note" /></label>}
              {!partial && amountValue !== '' && diff !== 0 && <label className="payout-field"><span>Note ({diff > 0 ? '+' : '−'}{fmt(Math.abs(diff))} BDT)</span><input className="w-48" placeholder={diff > 0 ? 'e.g. Eid bonus' : 'e.g. leave deducted'} value={note} onChange={(e) => setNote(e.target.value)} aria-label="Note" /></label>}
              <button type="button" className="btn-teal self-end" onClick={disburse} data-testid="mt-disburse">Disburse</button>
            </>
          )}
        </div>
      </div>

      <h3 className="mb-2 mt-6 text-sm font-extrabold uppercase">Salary due (not yet disbursed)</h3>
      <div className="dues-box mb-2">
        {!dues.months.length ? <p className="text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Nothing due — every month up to last month is disbursed.</p> : (
          <ul>{dues.months.map((d) => <li key={`${d.month}${d.year}`}><span className="dues-m">{d.month} {d.year}</span> <strong>{fmt(d.salary)} BDT</strong>{d.note && <span className="dues-notes">{d.note}</span>}</li>)}</ul>
        )}
        {dues.total > 0 && <p className="mt-1 text-sm font-extrabold">Total due: {fmt(dues.total)} BDT</p>}
      </div>

      <h3 className="mb-2 mt-6 text-sm font-extrabold uppercase">Disbursed payment history</h3>
      <div className="table-wrap">
        <table className="salary-table">
          <thead><tr><th>Salary month</th><th>Amount paid</th><th>Disbursement date</th><th style={{ textAlign: 'right' }}>Actions</th></tr></thead>
          <tbody data-testid="mt-history">
            {!history.length && <tr><td colSpan={4} style={{ textAlign: 'center', color: 'var(--text-muted)' }}>No disbursements yet.</td></tr>}
            {history.map((p) => (
              <tr key={p.id}>
                <td><strong>{p.month} {p.year}</strong></td>
                <td><strong style={{ color: 'var(--qit-teal)' }}>{fmt(p.amount)} BDT</strong>{p.calculated != null && Number(p.amount) !== Number(p.calculated) && <div className="diff-note">{String(p.month).slice(0, 3)}. Salary {fmt(p.calculated)} {Number(p.amount) > Number(p.calculated) ? '+' : '−'} {fmt(Math.abs(Number(p.amount) - Number(p.calculated)))}{p.note ? ` (${p.note})` : ''}</div>}{p.partial && <div className="diff-note">Part payment{p.note ? ` · ${p.note}` : ''}</div>}</td>
                <td>{p.date}{p.method && <div className="text-xs" style={{ color: 'var(--text-muted)' }}>by {p.method}</div>}</td>
                <td style={{ textAlign: 'right' }}><button type="button" className="btn-danger" style={{ padding: '5px 12px' }} onClick={async () => (await confirm({ title: 'Cancel this payment?', message: `${fmt(p.amount)} BDT for ${p.month} ${p.year} will be removed.`, confirmText: 'Cancel payment', cancelText: 'Keep', tone: 'danger' })) && persist((member.payments || []).filter((x) => x.id !== p.id), 'Payment cancelled.')}>Cancel</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="mt-5 flex justify-end"><button type="button" className="btn-muted" onClick={onClose}>Close</button></div>
    </PortalModal>
  );
}

export default function ManagementTeam({ team, reload, setTeam, month, year, namesOnly, term = '' }) {
  const confirm = useConfirm();
  const toast = useToast();
  const [form, setForm] = useState(null); // null | 'new' | member
  const [openId, setOpenId] = useState(null);
  const list = useMemo(() => (team || []).filter((m) => !term || matchSearch(`${m.name} ${m.id} ${m.role} ${m.whatsapp} ${m.email}`, term)), [team, term]);
  const figs = useMemo(() => Object.fromEntries((team || []).map((m) => [m.id, { f: memberMonth(m, month, year), owed: memberDues(m) }])), [team, month, year]);
  const totals = Object.values(figs).reduce((a, x) => ({ salary: a.salary + x.f.salary, paid: a.paid + x.f.paid, due: a.due + x.owed.total }), { salary: 0, paid: 0, due: 0 });
  const saved = (row) => {
    setTeam((l) => { const has = (l || []).some((m) => m.id === row.id); return has ? l.map((m) => (m.id === row.id ? row : m)) : [...(l || []), row]; });
    setForm(null);
  };
  const remove = async (m) => {
    if (!(await confirm({ title: `Remove ${m.name}?`, message: 'The profile and its payment history are deleted.', confirmText: 'Remove', tone: 'danger' }))) return;
    try { await teamApi.remove(m.id); toast(`${m.name} removed.`); reload(); } catch (e) { toast(e.message, 'error'); }
  };
  const open = (team || []).find((m) => m.id === openId);
  if (team === null) return <p className="py-8 text-center" style={{ color: 'var(--text-muted)' }}>Loading the management team…</p>;
  return (
    <div data-testid="team-panel">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="metrics-bar dir-metrics">
          <div className="metric-col m-tuition"><div className="metric-val">{(team || []).length}</div><div className="metric-lbl">Members</div></div>
          <div className="metric-col m-cut"><div className="metric-val">{fmt(totals.salary)} BDT</div><div className="metric-lbl">Salaries · {month.slice(0, 3)}</div></div>
          <div className="metric-col m-paid"><div className="metric-val">{fmt(totals.paid)} BDT</div><div className="metric-lbl">Disbursed · {month.slice(0, 3)}</div></div>
          <div className={`metric-col m-due ${totals.due ? 'is-due' : ''}`}><div className="metric-val">{fmt(totals.due)} BDT</div><div className="metric-lbl">Total due</div></div>
        </div>
        <button type="button" className="btn-teal inline-flex items-center gap-1.5" onClick={() => setForm('new')} data-testid="team-add"><Plus className="h-4 w-4" /> Add member</button>
      </div>
      {!list.length && <p className="py-8 text-center" style={{ color: 'var(--text-muted)' }}>{term ? 'No team member matches.' : 'No team members yet — press “Add member”.'}</p>}
      {list.map((m) => {
        const { f, owed } = figs[m.id];
        return (
          <div key={m.id} className="teacher-card mt-card" role="button" tabIndex={0} onClick={() => setOpenId(m.id)} onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), setOpenId(m.id))} data-testid={`team-card-${m.id}`}>
            <div className="teacher-card-top">
              <div className="flex flex-wrap items-center gap-3">
                <span className="t-name"><UserRound className="mr-1 inline h-4 w-4" aria-hidden="true" />{m.name}</span>
                <span className="id-tag">{m.id}</span>
                {m.role && <span className="mt-post" data-testid="mt-post"><Crown className="h-3.5 w-3.5" aria-hidden="true" />{m.role}</span>}
                <span className={`st-chip ${m.status === 'Inactive' ? 'inactive' : 'active'}`}>{m.status || 'Active'}</span>
              </div>
              {!namesOnly && (
                <div className="card-right">
                  <div className="metrics-bar dir-metrics">
                    <div className="metric-col m-cut"><div className="metric-val">{fmt(f.salary)} BDT</div><div className="metric-lbl">Salary · {month.slice(0, 3)}</div>{f.note && <div className="metric-note">{f.note}</div>}</div>
                    <div className="metric-col m-paid"><div className="metric-val">{fmt(f.paid)} BDT</div><div className="metric-lbl">{f.settled ? <>Disbursed ✓ {month.slice(0, 3)}</> : f.partPaid ? `Part paid · ${month.slice(0, 3)} · ${fmt(f.due)} left` : `Disbursed · ${month.slice(0, 3)}`}</div>{f.payments.filter((p) => p.note).map((p) => <div key={p.id} className="metric-note">{p.note}</div>)}</div>
                    <div className={`metric-col m-due ${owed.total ? 'is-due' : ''}`}><div className="metric-val">{fmt(owed.total)} BDT</div><div className="metric-lbl">Total due{owed.months.length ? ` · ${owed.months.map((d) => d.month.slice(0, 3)).join(', ')}` : ''}</div></div>
                  </div>
                  <span className="inline-flex items-center gap-1.5" onClick={(e) => e.stopPropagation()} onKeyDown={(e) => e.stopPropagation()}>
                    <button type="button" className="btn-icon-edit" onClick={() => setForm(m)} aria-label={`Edit ${m.name}`}><Pencil className="h-4 w-4" /></button>
                    <button type="button" className="btn-icon-edit" onClick={() => remove(m)} aria-label={`Remove ${m.name}`} style={{ color: '#b42318' }}><Trash2 className="h-4 w-4" /></button>
                  </span>
                </div>
              )}
            </div>
            <div className="teacher-strip">
              <span>{m.whatsapp ? <>WhatsApp: <PhoneLinks value={m.whatsapp} /> • </> : null}{m.email ? <>Email: <strong>{m.email}</strong> • </> : null}{m.method === 'Bank' && m.bankName ? `Bank: ${m.bankName} • Acc: ${m.account || 'not set'}` : `Method: ${m.method || 'not set'} • Acc: ${m.account || 'not set'}`}</span>
              <span>Click to open the profile &amp; disburse →</span>
            </div>
          </div>
        );
      })}
      {form && <MemberForm member={form === 'new' ? null : form} onClose={() => setForm(null)} onSaved={saved} />}
      {open && <MemberWorkspace member={open} month={month} year={year} onClose={() => setOpenId(null)} onEdit={() => { setForm(open); }} onChanged={(row) => setTeam((l) => l.map((m) => (m.id === row.id ? row : m)))} />}
    </div>
  );
}

