import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, RefreshCw, Save, Trash2, Trophy } from 'lucide-react';
import { usePortal } from '../PortalContext';
import Combobox from '../components/Combobox';
import { MONTHS, getPointRules, leaderboard, savePointRules } from '../../../lib/teacherData';
import { useToast } from '../../../components/ui/Toast';
import { useConfirm } from '../../../components/ui/Confirm';
import '../../staff/staff.css';

const POINT_FIELDS = [
  ['presentMark', 'Each student marked present'],
  ['dailyLogDay', 'Each day attendance is marked'],
  ['monthlyReport', 'Each monthly report sent'],
  ['reportOnTimeBonus', 'Bonus when the report is on time'],
  ['reportDeadlineDay', 'On time = sent by this day of the next month', 'day'],
  ['reviewedReport', 'Each report reviewed by the office'],
  ['perfectAttendanceStudent', 'Each student with 100% attendance in a month'],
  ['excellent', 'Student level “Excellent”'],
  ['veryGood', 'Student level “Very Good”'],
  ['good', 'Student level “Good”'],
  ['average', 'Student level “Average”'],
  ['weak', 'Student level “Weak”'],
];

/**
 * Executives: the teacher points system. Point values, levels (the
 * "Hardworking Level" names and the points needed) and rewards. Teachers see
 * the changes on their My Progress page straight away.
 */
export default function PointsSettings() {
  const { adminEmail } = usePortal();
  const toast = useToast();
  const confirm = useConfirm();
  const [cfg, setCfg] = useState(null);
  const [loadError, setLoadError] = useState('');
  const [meta, setMeta] = useState(null);
  const [dirty, setDirty] = useState(false);
  const [busy, setBusy] = useState(false);
  const now = new Date();
  const [month, setMonth] = useState(MONTHS[now.getMonth()]);
  const [year, setYear] = useState(String(now.getFullYear()));
  const [board, setBoard] = useState(null);

  const load = useCallback(async () => {
    setLoadError('');
    try {
      const r = await getPointRules();
      setCfg(r?.config || { points: {}, levels: [], rewards: [] });
      setMeta(r);
      setDirty(false);
    } catch (e) {
      setLoadError(e.message);
    }
  }, [toast]);
  const loadBoard = useCallback(async () => {
    setBoard(null);
    try {
      setBoard(await leaderboard(month, year));
    } catch (e) {
      toast(e.message, 'error');
      setBoard([]);
    }
  }, [month, year, toast]);
  useEffect(() => {
    load();
  }, [load]);
  useEffect(() => {
    loadBoard();
  }, [loadBoard]);

  const edit = (fn) => {
    setCfg((c) => fn(structuredClone(c)));
    setDirty(true);
  };
  const setPoint = (k, v) => edit((c) => ({ ...c, points: { ...c.points, [k]: v === '' ? '' : Number(v) } }));

  const save = async () => {
    const levels = [...(cfg.levels || [])].filter((l) => l.en?.trim()).map((l) => ({ ...l, min: Number(l.min) || 0 })).sort((a, b) => a.min - b.min);
    if (!levels.length || levels[0].min !== 0) return toast('The first level must start at 0 points.', 'error');
    const points = Object.fromEntries(Object.entries(cfg.points || {}).map(([k, v]) => [k, Number(v) || 0]));
    if (points.reportDeadlineDay < 1 || points.reportDeadlineDay > 28) return toast('The report deadline day must be between 1 and 28.', 'error');
    setBusy(true);
    try {
      await savePointRules({ ...cfg, points, levels, rewards: (cfg.rewards || []).filter((r) => r.en?.trim()) }, adminEmail);
      toast('Points and rewards saved. Teachers see the new values now.');
      await Promise.all([load(), loadBoard()]);
    } catch (e) {
      toast(e.message, 'error');
    } finally {
      setBusy(false);
    }
  };

  const discard = async () => {
    if (dirty && !(await confirm({ title: 'Discard your changes?', message: 'The point values go back to the last saved version.', confirmText: 'Discard', tone: 'danger' }))) return;
    load();
  };

  if (!cfg) {
    return (
      <div className="box-card text-center">
        {loadError ? (
          <>
            <p className="font-bold text-red-700" role="alert">{loadError}</p>
            <button type="button" className="btn-teal mt-3" onClick={load}>Try again</button>
          </>
        ) : (
          'Loading…'
        )}
      </div>
    );
  }
  const levelOptions = (cfg.levels || []).filter((l) => l.en).map((l) => ({ value: l.en, label: `${l.en} (${l.bn || '—'})` }));

  return (
    <>
      <div className="box-card">
        <div className="card-header-bar">
          <h2 className="card-title">Teacher points &amp; rewards</h2>
          <div className="flex gap-2">
            {dirty && <button type="button" className="btn-muted" onClick={discard}>Discard</button>}
            <button type="button" className="btn-teal inline-flex items-center gap-1" onClick={save} disabled={!dirty || busy}><Save className="h-4 w-4" /> {busy ? 'Saving…' : 'Save'}</button>
          </div>
        </div>
        {meta?.updated_at && <p className="mb-3 text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>Last saved {new Date(meta.updated_at).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' })}{meta.updated_by ? ` by ${meta.updated_by}` : ''}.</p>}

        <h3 className="pt-head tone-teal mb-2 mt-2 font-extrabold">Points</h3>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {POINT_FIELDS.map(([k, label, unit]) => (
            <div key={k} className="form-group pt-box" style={{ margin: 0 }}>
              <label htmlFor={`pt-${k}`}>{label}</label>
              <div className="flex items-center gap-2">
                <input id={`pt-${k}`} type="number" className="m-input" min={unit === 'day' ? 1 : -1000} max={unit === 'day' ? 28 : 1000} value={cfg.points?.[k] ?? ''} onChange={(e) => setPoint(k, e.target.value)} />
                <span className="text-xs font-bold" style={{ color: 'var(--text-muted)' }}>{unit === 'day' ? 'day' : 'pts'}</span>
              </div>
            </div>
          ))}
        </div>

        <h3 className="pt-head tone-gold mb-2 mt-6 font-extrabold">Levels (“Hardworking Level”)</h3>
        <p className="mb-2 text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>A teacher reaches a level when their total points reach its number. The first level starts at 0.</p>
        <div className="space-y-2">
          {(cfg.levels || []).map((l, i) => (
            <div key={i} className="pt-row pt-level grid items-center gap-2 sm:grid-cols-[7rem_1fr_1fr_auto]">
              <input type="number" className="m-input" min={0} value={l.min} onChange={(e) => edit((c) => { c.levels[i].min = e.target.value; return c; })} aria-label={`Points needed for level ${i + 1}`} />
              <input className="m-input" placeholder="Name (English)" value={l.en || ''} onChange={(e) => edit((c) => { c.levels[i].en = e.target.value; return c; })} aria-label={`Level ${i + 1} name in English`} />
              <input className="m-input bn" placeholder="নাম (বাংলা)" value={l.bn || ''} onChange={(e) => edit((c) => { c.levels[i].bn = e.target.value; return c; })} aria-label={`Level ${i + 1} name in Bangla`} />
              <button type="button" className="btn-del-row" onClick={() => edit((c) => { c.levels.splice(i, 1); return c; })} aria-label={`Remove level ${l.en || i + 1}`}><Trash2 className="h-4 w-4" /></button>
            </div>
          ))}
        </div>
        <button type="button" className="btn-add-row mt-2 inline-flex items-center gap-1" onClick={() => edit((c) => ({ ...c, levels: [...(c.levels || []), { min: '', en: '', bn: '' }] }))}><Plus className="h-4 w-4" /> Add level</button>

        <h3 className="pt-head tone-slate mb-2 mt-6 font-extrabold">Rewards</h3>
        <div className="space-y-2">
          {(cfg.rewards || []).map((r, i) => (
            <div key={i} className="pt-row pt-reward grid items-center gap-2 sm:grid-cols-[14rem_1fr_1fr_auto]">
              <Combobox value={r.level} onChange={(v) => edit((c) => { c.rewards[i].level = v; return c; })} options={levelOptions} aria-label={`Level for reward ${i + 1}`} />
              <input className="m-input" placeholder="Reward (English)" value={r.en || ''} onChange={(e) => edit((c) => { c.rewards[i].en = e.target.value; return c; })} aria-label={`Reward ${i + 1} in English`} />
              <input className="m-input bn" placeholder="পুরস্কার (বাংলা)" value={r.bn || ''} onChange={(e) => edit((c) => { c.rewards[i].bn = e.target.value; return c; })} aria-label={`Reward ${i + 1} in Bangla`} />
              <button type="button" className="btn-del-row" onClick={() => edit((c) => { c.rewards.splice(i, 1); return c; })} aria-label={`Remove reward ${r.en || i + 1}`}><Trash2 className="h-4 w-4" /></button>
            </div>
          ))}
        </div>
        <button type="button" className="btn-add-row mt-2 inline-flex items-center gap-1" onClick={() => edit((c) => ({ ...c, rewards: [...(c.rewards || []), { level: levelOptions[0]?.value || '', en: '', bn: '' }] }))}><Plus className="h-4 w-4" /> Add reward</button>
      </div>

      <div className="box-card pt-board">
        <div className="card-header-bar">
          <h2 className="card-title inline-flex items-center gap-2"><Trophy className="h-5 w-5" /> Leaderboard</h2>
          <div className="flex items-center gap-2">
            <div style={{ minWidth: 150 }}><Combobox value={month} onChange={setMonth} options={MONTHS.map((m) => ({ value: m, label: m }))} aria-label="Leaderboard month" /></div>
            <div style={{ minWidth: 100 }}><Combobox value={year} onChange={setYear} options={[0, 1, 2].map((d) => String(now.getFullYear() - d)).map((v) => ({ value: v, label: v }))} aria-label="Leaderboard year" /></div>
            <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={loadBoard}><RefreshCw className="h-3.5 w-3.5" /> Refresh</button>
          </div>
        </div>
        {board === null ? <p className="rv-empty">Loading…</p> : !board.length ? <p className="rv-empty">No teachers with students or accounts yet.</p> : (
          <div className="table-wrap">
            <table className="tl-table">
              <thead><tr><th>#</th><th>Teacher</th><th>Students</th><th>{month} points</th><th>All-time</th><th /></tr></thead>
              <tbody>
                {board.map((r, i) => (
                  <tr key={r.id}>
                    <td><strong>{i + 1}</strong></td>
                    <td><strong>{r.name}</strong> <span className="id-tag">{r.id}</span></td>
                    <td>{r.students}</td>
                    <td><strong>{r.points}</strong></td>
                    <td>{r.allTime}</td>
                    <td className="text-right"><Link className="tl-link" to={`/admin/teachers/${encodeURIComponent(r.id)}/progress`}>Progress →</Link></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
}
