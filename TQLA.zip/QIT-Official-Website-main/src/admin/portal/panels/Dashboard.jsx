import { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { profileAttr } from '../components/ProfileOpener';
import Combobox from '../components/Combobox';
import { leaderboard } from '../../../lib/teacherData';
import Chart from 'chart.js/auto';
import { usePortal } from '../PortalContext';
import { Banknote, ClipboardCheck, GraduationCap, HandCoins, PiggyBank, Trophy, UserRound, Users, Wallet } from 'lucide-react';
import { MONTHS, currentMonthName, fmt, previousMonthOf, yearsWith } from '../lib/constants';
import { MonthModeToggle, defaultPick, figuresMonth, pickFor, useMonthMode } from '../lib/monthMode';
import { studentMonth, teacherMonth } from '../lib/salaryCalc';
import { memberMonth, useTeam } from './ManagementTeam';
import { catOf } from '../components/TeacherIdTools';

// One stat box: teal, gold or slate (the only three colours in the admin)
function Tile({ tone, Icon, label, value, note, progress }) {
  return (
    <div className={`dash-tile tone-${tone}`}>
      <div className="dash-tile-head">
        <span className="tone-chip"><Icon className="h-4 w-4" aria-hidden="true" /></span>
        <span className="tile-label">{label}</span>
      </div>
      <div className="tile-value tone-value">{value}</div>
      {progress != null && (
        <div className="progress-track" role="progressbar" aria-valuenow={Math.round(Math.min(100, progress))} aria-valuemin={0} aria-valuemax={100} aria-label={label}>
          <div className="progress-fill" style={{ width: `${Math.min(100, progress)}%`, background: 'var(--t)' }} />
        </div>
      )}
      {note && <div className="text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>{note}</div>}
    </div>
  );
}

function useChart(config) {
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current) return undefined;
    const chart = new Chart(ref.current, config);
    return () => chart.destroy();
  }, [config]);
  return ref;
}

const chartFont = { family: "Bahnschrift, 'Barlow', 'QIT Bangla Digits','Aikya', sans-serif", weight: '700' };
// Chart colours come from the theme: main, accent and a neutral grey
function themeColours() {
  const cs = getComputedStyle(document.documentElement);
  const v = (n, fb) => (cs.getPropertyValue(n) || '').trim() || fb;
  const main = v('--pine-900', '3 71 79');
  return { main: `rgb(${main})`, ramp: [1, 0.86, 0.72, 0.6, 0.48, 0.38, 0.28, 0.2].map((a) => `rgb(${main} / ${a})`), mid: `rgb(${v('--pine-500', '31 127 128')})`, accent: v('--th-accent-bright', '#C8943F'), grey: v('--qit-slate', '#64748b') };
}

// Financial overview (Super Admin only)
export default function Dashboard() {
  const { db } = usePortal();
  const { team: teamRaw } = useTeam(); // v179: the Management Team's salaries count too
  const team = useMemo(() => teamRaw || [], [teamRaw]);
  // Salaries are paid after the month ends, so the dashboard opens on last month.
  // "This month" shows the current situation, "Overall" every month together.
  // v164: the month picked is the PAYMENT month — October shows September's
  // tuition, salaries and dues (salary is paid the month after the classes)
  const mmode = useMonthMode();
  const [pick, setSel] = useState(() => ({ mode: 'month', ...defaultPick(mmode) }));
  const overall = pick.mode === 'overall';
  const sel = overall ? pick : { ...pick, ...figuresMonth(mmode, pick.month, pick.year) };
  // redraw the charts when the colour theme changes
  const [themeTick, setThemeTick] = useState(0);
  useEffect(() => {
    const on = () => setThemeTick((n) => n + 1);
    window.addEventListener('qit-admin-theme', on);
    return () => window.removeEventListener('qit-admin-theme', on);
  }, []);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const col = useMemo(themeColours, [themeTick]);
  const [showAllUnpaid, setShowAllUnpaid] = useState(false);
  const last = previousMonthOf();
  const nowP = { month: currentMonthName(), year: String(new Date().getFullYear()) };
  // quick buttons pick the month whose figures show (Last month = September's figures)
  const isP = (x) => !overall && sel.month === x.month && String(sel.year) === String(x.year);
  const periodLabel = overall ? 'all months' : `${sel.month} ${sel.year}`;

  // Teacher leaderboard for the chosen month (Overall: all-time points)
  const [board, setBoard] = useState(null);
  useEffect(() => {
    let alive = true;
    setBoard(null);
    const q = overall ? nowP : sel;
    leaderboard(q.month, q.year)
      .then((rows) => alive && setBoard(Array.isArray(rows) ? rows : []))
      .catch(() => alive && setBoard(false));
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sel.mode, sel.month, sel.year]);
  const ranked = useMemo(() => {
    if (!board) return [];
    const key = overall ? 'allTime' : 'points';
    return [...board].sort((a, b) => (Number(b[key]) || 0) - (Number(a[key]) || 0)).slice(0, 10);
  }, [board, overall]);

  const stats = useMemo(() => {
    // Money fields can arrive as text ("3000"): always add them as numbers
    const num = (v) => Number(v) || 0;
    const isActive = (x) => !['Hold', 'Inactive'].includes(x.status);
    const active = db.students.filter(isActive);
    const onHold = db.students.filter((x) => x.status === 'Hold').length;
    const inactive = db.students.filter((x) => x.status === 'Inactive').length;
    const totalTeachers = db.teachers.length;
    // Only Active students are billed and count towards a per-student salary
    // this month's payments (a month can have its own amount)
    // v155: each teacher's salary and tuition for the month, prorated by Assignment Date / status dates
    const pm = overall ? nowP.month : sel.month;
    const py = String(overall ? nowP.year : sel.year);
    const tm = Object.fromEntries(db.teachers.map((t) => [t.id, teacherMonth(t, db, pm, py)]));
    const totalTuition = db.students.reduce((sum, x) => sum + studentMonth(x, pm, py).fee, 0);
    const cutByTeacher = {};
    const countByTeacher = {};
    active.forEach((x) => {
      cutByTeacher[x.teacherId] = (cutByTeacher[x.teacherId] || 0) + num(x.cut);
      countByTeacher[x.teacherId] = (countByTeacher[x.teacherId] || 0) + 1;
    });
    const salaryOf = (t) => tm[t.id]?.salary || 0;
    const teacherSalary = db.teachers.reduce((sum, t) => sum + salaryOf(t), 0);
    // v179: Management Team — salary of the month, part payments, what is left
    const teamF = team.map((m) => ({ m, f: memberMonth(m, pm, py) }));
    const teamSalary = teamF.reduce((a, x) => a + x.f.salary, 0);
    const teamPays = team.flatMap((m) => (m.payments || []).map((p) => ({ ...p, teacherId: m.id, method: p.method || m.method })));
    const totalSalary = teacherSalary + teamSalary;
    // Salaries are paid after the month ends: this month's payments are for last month
    const due = overall ? { month: 'all months', year: '' } : { month: sel.month, year: String(sel.year) };
    const month = overall ? nowP.month : sel.month;
    const year = String(overall ? nowP.year : sel.year);
    const monthsPaid = new Set([...db.payments, ...teamPays].map((p) => `${p.month} ${p.year}`)).size;
    const activeIds = new Set(active.map((x) => x.id));
    const reported = new Set(db.reports.filter((r) => (overall || (r.month === month && String(r.year) === year)) && activeIds.has(r.studentId)).map((r) => r.studentId));
    const paidFor = (list) => list.filter((p) => overall || (p.month === due.month && String(p.year) === due.year)).reduce((sum, p) => sum + num(p.amount), 0);
    const paidDue = paidFor(db.payments) + paidFor(teamPays);
    // Salary by panel: Residential, and Non-Residential (male + female together)
    const group = (test) => {
      const ts = db.teachers.filter(test);
      const ids = new Set(ts.map((t) => t.id));
      const salary = ts.reduce((sum, t) => sum + salaryOf(t), 0);
      const paid = paidFor(db.payments.filter((p) => ids.has(p.teacherId)));
      const paidSet = new Set(db.payments.filter((p) => ids.has(p.teacherId) && (overall || (p.month === due.month && String(p.year) === due.year))).map((p) => p.teacherId));
      const left = ts.filter((t) => !paidSet.has(t.id)).reduce((sum, t) => sum + salaryOf(t), 0);
      return { teachers: ts.length, students: ts.reduce((n, t) => n + (countByTeacher[t.id] || 0), 0), salary, paid, left: overall ? Math.max(0, salary - paid) : left };
    };
    const isRes = (t) => catOf(t.category) === 'Residential';
    const isNon = (t) => /^Non/.test(catOf(t.category));
    const withStudents = db.teachers.filter((t) => countByTeacher[t.id]).length;
    // Who is still waiting for this month's salary
    const paidBy = {};
    db.payments.filter((p) => overall || (p.month === due.month && String(p.year) === due.year)).forEach((p) => { paidBy[p.teacherId] = (paidBy[p.teacherId] || 0) + num(p.amount); });
    const owed = [
      ...db.teachers.map((t) => ({ id: t.id, name: t.name, category: catOf(t.category), salary: salaryOf(t), paid: paidBy[t.id] || 0, settled: Boolean(paidBy[t.id]), left: salaryOf(t) })),
      ...teamF.map(({ m, f }) => ({ id: m.id, name: m.name, category: 'Management Team', team: true, salary: f.salary, paid: f.paid, settled: f.settled, left: f.due })),
    ].filter((x) => x.salary > 0);
    // a disbursed month is settled, whatever amount was paid (team: part payments leave the rest due)
    const unpaid = owed.filter((x) => !x.settled).sort((a, b) => b.left - a.left);
    const paidCount = owed.length - unpaid.length;
    // v154: where the money went — disbursements of the period by transfer method
    const tMethod = Object.fromEntries(db.teachers.map((t) => [t.id, t.method]));
    const bySource = { Bank: 0, Bkash: 0, Nagad: 0, Other: 0 };
    const countBySource = { Bank: 0, Bkash: 0, Nagad: 0, Other: 0 };
    [...db.payments, ...teamPays].filter((p) => overall || (p.month === due.month && String(p.year) === due.year)).forEach((p) => {
      const m = p.method || tMethod[p.teacherId];
      const k = ['Bank', 'Bkash', 'Nagad'].includes(m) ? m : 'Other';
      bySource[k] += num(p.amount);
      countBySource[k] += 1;
    });
    return {
      totalStudents: active.length,
      allStudents: db.students.length,
      onHold,
      inactive,
      totalTeachers,
      totalTuition,
      totalSalary,
      net: totalTuition - totalSalary,
      reportedCount: reported.size,
      reportPct: active.length ? ((reported.size / active.length) * 100).toFixed(1) : '0',
      avgLoad: withStudents ? (active.length / withStudents).toFixed(1) : '0',
      withStudents,
      paidDue,
      monthsPaid,
      owedCount: owed.length,
      paidCount,
      unpaid,
      bySource,
      countBySource,
      leftDue: overall ? Math.max(0, totalSalary - paidDue) : unpaid.reduce((a, x) => a + x.left, 0),
      due,
      payPct: totalSalary ? ((paidDue / (totalSalary * (overall ? Math.max(1, monthsPaid) : 1))) * 100).toFixed(1) : '0',
      residential: group(isRes),
      nonResidential: group(isNon),
      noCategory: group((t) => !catOf(t.category)),
      management: (() => {
        const paid = paidFor(teamPays);
        return { teachers: team.filter((m) => m.status !== 'Inactive').length, salary: teamSalary, paid, left: overall ? Math.max(0, teamSalary - paid) : teamF.reduce((a, x) => a + x.f.due, 0), team: true };
      })(),
      teacherSalary,
      teamSalary,
      year,
      month,
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [db, team, sel.mode, sel.month, sel.year]);

  const revenueCfg = useMemo(
    () => ({
      type: 'doughnut',
      data: {
        labels: ['Faculty Salary', 'Institute Retention'],
        datasets: [{ data: [stats.totalSalary, Math.max(0, stats.net)], backgroundColor: [col.main, col.accent], borderColor: '#fff', borderWidth: 3, hoverOffset: 8 }],
      },
      options: {
        cutout: '62%',
        plugins: {
          legend: { position: 'bottom', labels: { font: chartFont, padding: 16, usePointStyle: true } },
          tooltip: { callbacks: { label: (c) => `${c.label}: ${c.parsed.toLocaleString()} BDT` } },
        },
      },
    }),
    [stats.totalSalary, stats.net, col],
  );

  const categoryCfg = useMemo(() => {
    const count = (c) => db.teachers.filter((t) => catOf(t.category) === c).length;
    return {
      type: 'bar',
      data: {
        labels: ['Residential', 'Non-Res. Male', 'Non-Res. Female'],
        datasets: [{ label: 'Teachers', data: [count('Residential'), count('Non-Residential Male'), count('Non-Residential Female')], backgroundColor: [col.main, col.grey, col.accent], borderRadius: 8, barThickness: 42 }],
      },
      options: {
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true, ticks: { font: chartFont, stepSize: 1 } }, x: { ticks: { font: chartFont }, grid: { display: false } } },
      },
    };
  }, [db.teachers, col]);

  const perTeacherCfg = useMemo(() => {
    const rows = db.teachers
      .map((t) => {
        const assigned = db.students.filter((s) => s.teacherId === t.id && !['Hold', 'Inactive'].includes(s.status));
        const name = String(t.name || t.id);
        return { name: name.length > 18 ? `${name.slice(0, 16)}…` : name, revenue: assigned.reduce((sum, x) => sum + (Number(x.fee) || 0), 0), count: assigned.length };
      })
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 8);
    return {
      type: 'bar',
      data: { labels: rows.map((r) => r.name), datasets: [{ label: 'Tuition Revenue', data: rows.map((r) => r.revenue), backgroundColor: col.ramp.slice(0, rows.length), borderRadius: 6, barThickness: 20 }] },
      options: {
        indexAxis: 'y',
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: (c) => `${c.parsed.x.toLocaleString()} BDT (${rows[c.dataIndex].count} students)` } } },
        scales: { x: { beginAtZero: true, ticks: { font: chartFont, callback: (v) => `${v / 1000}K` } }, y: { ticks: { font: chartFont }, grid: { display: false } } },
      },
    };
  }, [db.teachers, db.students, col]);

  const monthlyCfg = useMemo(() => {
    const totals = MONTHS.map((m) => db.payments.filter((p) => p.month === m && String(p.year) === stats.year).reduce((sum, p) => sum + (Number(p.amount) || 0), 0));
    const cur = overall ? -1 : MONTHS.indexOf(sel.month);
    return {
      type: 'bar',
      data: { labels: MONTHS.map((m) => m.slice(0, 3)), datasets: [{ label: 'Disbursed', data: totals, backgroundColor: totals.map((_, i) => (i === cur ? col.accent : col.main)), borderRadius: 6, barThickness: 22 }] },
      options: {
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: (c) => `${c.parsed.y.toLocaleString()} BDT` } } },
        scales: { y: { beginAtZero: true, ticks: { font: chartFont, callback: (v) => `${v / 1000}K` } }, x: { ticks: { font: chartFont }, grid: { display: false } } },
      },
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [db.payments, stats.year, sel.mode, sel.month, col]);

  const r1 = useChart(revenueCfg);
  const r2 = useChart(categoryCfg);
  const r3 = useChart(perTeacherCfg);
  const r4 = useChart(monthlyCfg);

  return (
    <div className="box-card dash-shaded">
      <div className="card-header-bar">
        <h2 className="card-title">Management overview</h2>
        <div className="dash-period" data-testid="dash-period">
          <div className="seg" role="group" aria-label="Quick period">
            <button type="button" aria-pressed={isP(last)} onClick={() => setSel({ mode: 'month', ...pickFor(mmode, last.month, last.year) })} data-testid="dash-last">Last month</button>
            <button type="button" aria-pressed={isP(nowP)} onClick={() => setSel({ mode: 'month', ...pickFor(mmode, nowP.month, nowP.year) })} data-testid="dash-now">This month</button>
            <button type="button" aria-pressed={overall} onClick={() => setSel((x) => ({ ...x, mode: 'overall' }))} data-testid="dash-overall">Overall</button>
          </div>
          <div className="filter-cluster">
            <span className="filter-label">{mmode === 'class' ? 'Class month' : 'Payment month'}</span>
            <Combobox variant="pill" value={overall ? '' : pick.month} onChange={(m) => setSel((x) => ({ ...x, mode: 'month', month: m }))} options={MONTHS} placeholder="Month" aria-label="Dashboard month" />
            <Combobox variant="pill" className="qcb-year" value={String(pick.year)} onChange={(y) => setSel((x) => ({ ...x, mode: 'month', year: String(y) }))} options={yearsWith(pick.year)} aria-label="Dashboard year" />
            {!overall && <span className="pay-period-for" data-testid="dash-for">{mmode === 'class' ? 'figures of' : 'pays for'} <strong>{sel.month} {sel.year}</strong></span>}
            <MonthModeToggle />
          </div>
        </div>
      </div>
      <div className="dash-strong grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-4">
        <Tile tone="teal" Icon={GraduationCap} label="Active Students" value={stats.totalStudents}
          note={stats.onHold || stats.inactive ? `${stats.onHold} on hold · ${stats.inactive} inactive · ${stats.allStudents} in all` : `${stats.allStudents} in all`} />
        <Tile tone="teal" Icon={Users} label="Teachers" value={stats.totalTeachers} note={`${stats.withStudents} with active students`} />
        <Tile tone="gold" Icon={Banknote} label="Tuition Volume" value={`${fmt(stats.totalTuition)} BDT`} note={`fees of active students · ${overall ? nowP.month : sel.month}`} />
        <Tile tone="gold" Icon={PiggyBank} label="Net Institute Retention" value={`${fmt(stats.net)} BDT`} note="tuition − all salaries (teachers + management team)" />
      </div>

      <div className="mt-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Tile tone="teal" Icon={ClipboardCheck} label="Report Completion" value={`${stats.reportPct}%`} progress={stats.reportPct}
          note={`${stats.reportedCount} / ${stats.totalStudents} active students reported ${overall ? 'in any month' : `for ${stats.month}`}`} />
        <Tile tone="slate" Icon={UserRound} label="Avg. Teacher Load" value={stats.avgLoad} note="active students per teacher who has students" />
        <Tile tone="slate" Icon={Wallet} label="Total Monthly Salary" value={`${fmt(stats.totalSalary)} BDT`} note={`teachers ${fmt(stats.teacherSalary)} + management team ${fmt(stats.teamSalary)}`} />
        <Tile tone="gold" Icon={HandCoins} label={overall ? 'Disbursed overall' : `Paid for ${stats.due.month}`} value={overall ? `${fmt(stats.paidDue)} BDT` : `${stats.payPct}%`} progress={overall ? null : stats.payPct}
          note={overall ? `salary paid in ${stats.monthsPaid} month${stats.monthsPaid === 1 ? '' : 's'}` : `${fmt(stats.paidDue)} paid · ${fmt(stats.leftDue)} BDT left`} />
      </div>

      {/* Salary of the chosen month: what is paid and, large and clear, what is still left */}
      {!overall && (
        <div className="pay-hero mt-5" data-testid="pay-hero">
          <div className="pay-hero-head">
            <span className="pay-hero-title"><HandCoins className="h-5 w-5" aria-hidden="true" /> Salary for {stats.due.month} {stats.due.year}</span>
            <span className="pay-hero-pill">{stats.paidCount} of {stats.owedCount} paid (teachers + team) · {stats.unpaid.length} waiting</span>
          </div>
          <div className="pay-hero-grid">
            <div className="pay-fig"><span>Total salary</span><strong>{fmt(stats.totalSalary)} <small>BDT</small></strong></div>
            <div className="pay-fig is-paid"><span>Paid</span><strong>{fmt(stats.paidDue)} <small>BDT</small></strong></div>
            <div className="pay-fig is-left" data-testid="pay-left"><span>Left to pay</span><strong>{fmt(stats.leftDue)} <small>BDT</small></strong></div>
          </div>
          <div className="pay-bar" role="progressbar" aria-valuenow={Math.round(Math.min(100, Number(stats.payPct)))} aria-valuemin={0} aria-valuemax={100} aria-label="Salary paid">
            <div style={{ width: `${Math.min(100, Number(stats.payPct))}%` }} />
            <span>{stats.payPct}% paid</span>
          </div>
        </div>
      )}

      <div className="mt-5" data-testid="pay-sources">
        <div className="chart-title" style={{ marginBottom: 10 }}>Money transferred by · {overall ? 'all months' : `salary for ${stats.due.month} ${stats.due.year}`}</div>
        <div className="src-grid">
          {['Bank', 'Bkash', 'Nagad', 'Other'].map((k) => (
            <div key={k} className={`src-tile src-${k.toLowerCase()}`} data-testid={`src-${k}`}>
              <span className="src-name">{k}</span>
              <strong>{fmt(stats.bySource[k])} <small>BDT</small></strong>
              <span className="src-n">{stats.countBySource[k]} payment{stats.countBySource[k] === 1 ? '' : 's'}{stats.paidDue ? ` · ${Math.round((stats.bySource[k] / stats.paidDue) * 100)}%` : ''}</span>
            </div>
          ))}
        </div>
        <p className="mt-2 text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>From each disbursement's method (or the teacher's "Paid by" when an older payment has none). Upay, Cash and others count as Other.</p>
      </div>

      <div className="mt-5" data-testid="salary-by-panel">
        <div className="chart-title" style={{ marginBottom: 10 }}>Salary by panel · {overall ? 'all months' : `${stats.due.month} ${stats.due.year}`}</div>
        <div className="grid gap-4 md:grid-cols-2">
          {[['Residential', stats.residential, 'teal'], ['Non-Residential (Male + Female)', stats.nonResidential, 'gold'], ['Management Team', stats.management, 'slate']].map(([label, g, tone]) => (
            <div key={label} className={`dash-tile tone-${tone} ${g.team ? 'md:col-span-2' : ''}`} data-testid={`panel-${tone}`}>
              <div className="dash-tile-head">
                <span className="tone-chip"><Wallet className="h-4 w-4" aria-hidden="true" /></span>
                <span className="tile-label">{label}</span>
                <span className="panel-meta">{g.team ? `${g.teachers} member${g.teachers === 1 ? '' : 's'}` : `${g.teachers} teachers · ${g.students} active students`}</span>
              </div>
              <div className="panel-figs">
                <div><span>Monthly salary</span><strong>{fmt(g.salary)} BDT</strong></div>
                <div className="is-paid"><span>Paid{overall ? ' (all months)' : ''}</span><strong>{fmt(g.paid)} BDT</strong></div>
                {!overall && <div className="is-left"><span>Left</span><strong>{fmt(g.left)} BDT</strong></div>}
              </div>
              {!overall && (
                <div className="progress-track" role="progressbar" aria-valuenow={g.salary ? Math.round(Math.min(100, (g.paid / g.salary) * 100)) : 0} aria-valuemin={0} aria-valuemax={100} aria-label={`${label} paid`}>
                  <div className="progress-fill" style={{ width: `${g.salary ? Math.min(100, (g.paid / g.salary) * 100) : 0}%`, background: 'var(--t)' }} />
                </div>
              )}
            </div>
          ))}
        </div>
        <p className="mt-2 text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>
          Total: {fmt(stats.residential.salary)} + {fmt(stats.nonResidential.salary)}{stats.noCategory.salary ? ` + ${fmt(stats.noCategory.salary)} (no category)` : ''} + {fmt(stats.management.salary)} (Management Team) = {fmt(stats.totalSalary)} BDT.
          Package teachers count their fixed salary; per-student teachers count the share of each Active student.
        </p>
      </div>

      {!overall && stats.unpaid.length > 0 && (
        <div className="chart-box tint-gold mt-5" data-testid="unpaid-list">
          <div className="chart-title">Waiting for {stats.due.month} salary · {stats.unpaid.length} people · {fmt(stats.leftDue)} BDT</div>
          <div className="table-wrap">
            <table className="salary-table">
              <thead><tr><th>Name</th><th>Panel</th><th>Salary</th><th>Paid</th><th>Left to pay</th></tr></thead>
              <tbody>
                {(showAllUnpaid ? stats.unpaid : stats.unpaid.slice(0, 8)).map((x) => (
                  <tr key={x.id}>
                    <td style={{ whiteSpace: 'nowrap' }}>{x.team ? <strong>{x.name}</strong> : <strong className="p-link" {...profileAttr('teacher', x.id)}>{x.name}</strong>} <span className="id-tag">{x.id}</span></td>
                    <td>{x.category || '—'}</td>
                    <td className="nowrap-num">{fmt(x.salary)} BDT</td>
                    <td className="nowrap-num">{fmt(x.paid)} BDT</td>
                    <td className="nowrap-num"><strong className="left-chip">{fmt(x.left)} BDT</strong></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {stats.unpaid.length > 8 && <button type="button" className="btn-outline-sm mt-3" onClick={() => setShowAllUnpaid((v) => !v)}>{showAllUnpaid ? 'Show fewer' : `Show all ${stats.unpaid.length}`}</button>}
          <p className="mt-2 text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>Pay them in Salary Directory; a paid teacher leaves this list.</p>
        </div>
      )}

      {board !== false && (
        <div className="chart-box tint-teal mt-6" data-testid="dash-leaderboard">
          <div className="chart-title inline-flex items-center gap-2"><Trophy className="h-4 w-4" aria-hidden="true" /> Teacher Leaderboard · {overall ? 'all-time' : periodLabel}</div>
          {board === null ? <p className="py-4 text-sm" style={{ color: 'var(--text-muted)' }}>Loading…</p> : !ranked.length ? <p className="py-4 text-sm" style={{ color: 'var(--text-muted)' }}>No teachers with students or accounts yet.</p> : (
            <div className="table-wrap">
              <table className="salary-table">
                <thead><tr><th>#</th><th>Teacher</th><th>Students</th><th>{overall ? 'All-time points' : `${sel.month} points`}</th><th>{overall ? `${nowP.month} points` : 'All-time'}</th><th /></tr></thead>
                <tbody>
                  {ranked.map((r, i) => (
                    <tr key={r.id}>
                      <td><strong>{i < 3 && Number(overall ? r.allTime : r.points) > 0 ? ['🥇', '🥈', '🥉'][i] : i + 1}</strong></td>
                      <td><strong className="p-link" {...profileAttr('teacher', r.id)}>{r.name}</strong> <span className="id-tag">{r.id}</span></td>
                      <td>{r.students}</td>
                      <td><strong>{overall ? r.allTime : r.points}</strong></td>
                      <td>{overall ? r.points : r.allTime}</td>
                      <td style={{ textAlign: 'right' }}><Link className="btn-outline-sm" to={`/admin/teachers/${encodeURIComponent(r.id)}/progress`}>Progress →</Link></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          <p className="mt-2 text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>Top 10. The full list and the point rules are in Points &amp; Rewards.</p>
        </div>
      )}

      <div className="mt-6 grid gap-5 lg:grid-cols-2">
        <div className="chart-box"><div className="chart-title">Revenue Distribution</div><div className="mx-auto max-w-xs"><canvas ref={r1} /></div></div>
        <div className="chart-box"><div className="chart-title">Faculty Category Distribution</div><canvas ref={r2} /></div>
        <div className="chart-box"><div className="chart-title">Student Revenue Per Teacher (Top 8)</div><canvas ref={r3} /></div>
        <div className="chart-box"><div className="chart-title">Monthly Payment Trends</div><canvas ref={r4} /></div>
      </div>
    </div>
  );
}
