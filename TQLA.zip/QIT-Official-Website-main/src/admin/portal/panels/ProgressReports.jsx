import { useEffect, useMemo, useRef, useState } from 'react';
import { usePortal } from '../PortalContext';
import { GRADES, SKILL_OPTIONS, MONTHS, currentMonthName, translateText, yearsWith } from '../lib/constants';
import { usePortalContent } from '../lib/portalContent';
import Combobox from '../components/Combobox';
import { findMatchingStudent, parseTeacherMessages } from '../lib/whatsappParser';
import { DOSSIER_CSS, DOSSIER_PRINT_CSS, aikyaFontFace } from '../dossier.css.js';
import Dossier from './Dossier';
import ReportFormatCard from './ReportFormatCard';
import { PortalModal } from './common';
import { useToast } from '../../../components/ui/Toast';
import { latestStudentReport, studentAttendance } from '../../../lib/teacherData';
import { RefreshCw } from 'lucide-react';

const LABELS = {
  EN: {
    student: 'Select Student', audience: 'Report Audience', template: 'Greeting Template', greeting: 'Customized Greeting Message',
    attended: 'Classes Attended', total: 'Total Classes', rate: 'Attendance Rate', grade: 'Overall Grade Score', header: 'QURANIC STUDY EVALUATION',
    tajweed: 'Tajweed & Pronunciation', hifz: 'Memorization / Hifz Progress', murajaah: "Muraja'ah Discipline", fluency: 'Noorani Qaida / Fluency',
    achievements: 'Key Achievements', goals: 'Next Development Goals', remarks: "Teacher's Certified Remarks", period: 'Report Period',
  },
  BN: {
    student: 'শিক্ষার্থী নির্বাচন করুন', audience: 'প্রতিবেদনের প্রাপক', template: 'শুভেচ্ছা বার্তার ধরণ', greeting: 'কাস্টমাইজড শুভেচ্ছা বার্তা',
    attended: 'উপস্থিত ক্লাস', total: 'মোট ক্লাস', rate: 'উপস্থিতির হার', grade: 'সার্বিক মূল্যায়ন', header: 'কুরআনিক শিক্ষা ও দক্ষতার সার্বিক অগ্রগতি',
    tajweed: 'তাজবীদ ও মাখরাজ', hifz: 'হিফজ / মুখস্থের নির্ভুলতা', murajaah: 'মুরাওয়াহা (রিভিশন) ধারাবাহিকতা', fluency: 'তিলাওয়াত ও কায়দা পাঠের গতি',
    achievements: 'বিশেষ অর্জন ও অগ্রগতি', goals: 'পরবর্তী উন্নয়ন লক্ষ্যমাত্রা', remarks: 'শিক্ষকের বিশেষ মন্তব্য ও দিকনির্দেশনা', period: 'প্রতিবেদনের মাস',
  },
};

// What a teacher's "study status" (from WhatsApp) sets on the form
const LEVEL_PRESETS = {
  excellent: { overallScore: GRADES[0], tajweed: SKILL_OPTIONS.tajweed[0], hifz: SKILL_OPTIONS.hifz[0], murajaah: SKILL_OPTIONS.murajaah[0], fluency: SKILL_OPTIONS.fluency[0] },
  veryGood: { overallScore: GRADES[1], tajweed: SKILL_OPTIONS.tajweed[1], hifz: SKILL_OPTIONS.hifz[0], murajaah: SKILL_OPTIONS.murajaah[0], fluency: SKILL_OPTIONS.fluency[0] },
  good: { overallScore: GRADES[2], tajweed: SKILL_OPTIONS.tajweed[1], hifz: SKILL_OPTIONS.hifz[1], murajaah: SKILL_OPTIONS.murajaah[1], fluency: SKILL_OPTIONS.fluency[1] },
  average: { overallScore: GRADES[3], tajweed: SKILL_OPTIONS.tajweed[2], hifz: SKILL_OPTIONS.hifz[1], murajaah: SKILL_OPTIONS.murajaah[1], fluency: SKILL_OPTIONS.fluency[1] },
  weak: { overallScore: GRADES[4], tajweed: SKILL_OPTIONS.tajweed[3], hifz: SKILL_OPTIONS.hifz[2], murajaah: SKILL_OPTIONS.murajaah[2], fluency: SKILL_OPTIONS.fluency[2] },
};
const LEVEL_NAMES = { excellent: 'Excellent', veryGood: 'Very good', good: 'Good', average: 'Average', weak: 'Needs improvement' };

const initial = (portal, lang = 'BN') => ({
  lang,
  studentId: '',
  reportType: 'Guardian',
  template: '1',
  greeting: portal.report[lang].greetings.Guardian[1],
  attended: 22,
  total: 24,
  overallScore: 'Outstanding (Grade A+)',
  tajweed: 'Excellent (90-100%)',
  hifz: 'Consistent & Accurate',
  murajaah: 'Daily & Thorough',
  fluency: 'High Fluency',
  month: currentMonthName(),
  year: String(new Date().getFullYear()),
  ...portal.report[lang].defaults,
});

export default function ProgressReports({ incoming = null, onIncomingDone = () => {} } = {}) {
  const toast = useToast();
  const { db, saveReport, mode } = usePortal();
  const cloud = mode === 'supabase';
  const { value: portal } = usePortalContent();
  const [r, setR] = useState(() => initial(portal));
  const [raw, setRaw] = useState('');
  const [parsed, setParsed] = useState([]);
  const [manual, setManual] = useState({});
  const [notice, setNotice] = useState('');
  const [preview, setPreview] = useState(false);
  const [saved, setSaved] = useState(false);
  const formTop = useRef(null);
  // Teacher's report pulled from the database for the selected student
  const [synced, setSynced] = useState({ state: 'idle' });
  const skipSync = useRef(false);
  const syncRun = useRef(0);
  const currentStudent = useRef('');
  currentStudent.current = r.studentId;
  const dossierRef = useRef(null);
  const t = LABELS[r.lang];
  const set = (k) => (e) => setR((x) => ({ ...x, [k]: e.target.value }));

  // Default to the first student once the roster loads
  useEffect(() => {
    if (!r.studentId && db.students.length) setR((x) => ({ ...x, studentId: db.students[0].id }));
  }, [db.students, r.studentId]);

  // Greeting follows language, audience and template (and resets per student)
  useEffect(() => {
    setR((x) => ({ ...x, greeting: portal.report[x.lang].greetings[x.reportType][x.template] }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [r.lang, r.reportType, r.template, r.studentId]);

  const changeLang = (lang) => setR((x) => ({ ...x, lang, ...portal.report[lang].defaults }));

  const attPct = useMemo(() => {
    const tot = Number(r.total) || 1;
    return `${(((Number(r.attended) || 0) / tot) * 100).toFixed(1)}%`;
  }, [r.attended, r.total]);

  const student = db.students.find((s) => s.id === r.studentId);
  const teacher = student ? db.teachers.find((x) => x.id === student.teacherId) : null;
  const report = { ...r, attPct };

  /* ---- WhatsApp importer ---- */
  const detect = () => {
    if (!raw.trim()) return setNotice('Paste a WhatsApp report message first.');
    const list = parseTeacherMessages(raw);
    if (!list.length) return setNotice('Could not detect any report in that text — check the format.');
    setParsed(list);
    setManual({});
    setNotice(`Detected ${list.length} report(s) — review & apply below.`);
  };

  const apply = (p, matchedId, { quiet = false } = {}) => {
    const studentId = matchedId || manual[p.rawText];
    if (!studentId) return setNotice('Pick a matching student for this report first.');
    // The form is being filled from a message: don't overwrite it with the database copy
    if (!quiet && studentId !== currentStudent.current) skipSync.current = true;
    setR((x) => {
      const bn = x.lang === 'BN';
      const taught = [p.subject, p.syllabus || p.lesson].filter(Boolean);
      const next = p.homework || (p.lesson && p.syllabus ? `${bn ? 'পরবর্তী সবক' : 'Continue from'}: ${p.lesson}` : '');
      const notes = [
        p.status && `${bn ? 'পড়ার অবস্থা' : 'Study status'}: ${p.status}`,
        p.remarks,
        p.missedReason && `${bn ? 'অনুপস্থিতির কারণ' : 'Reason for missed classes'}: ${p.missedReason}`,
      ].filter(Boolean);
      return {
        ...x,
        studentId,
        ...(p.month && MONTHS.includes(p.month) ? { month: p.month } : {}),
        ...(p.year ? { year: String(p.year) } : {}),
        ...(p.finalTotal != null ? { total: p.finalTotal } : {}),
        ...(p.finalAttended != null ? { attended: p.finalAttended } : {}),
        ...(p.statusLevel ? LEVEL_PRESETS[p.statusLevel] : {}),
        ...(taught.length ? { achievements: taught.join(' — ') } : {}),
        ...(next ? { goals: next } : {}),
        ...(notes.length ? { remarks: notes.join('\n') } : {}),
      };
    });
    if (quiet) return;
    setNotice('Report data applied to the form below.');
    formTop.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  // A teacher's dashboard report, in the shape apply() understands
  const fromTeacherReport = (rep) => ({
    name: rep.student_name,
    finalTotal: rep.total_classes,
    finalAttended: rep.present,
    statusLevel: rep.status_level,
    status: rep.status_note,
    syllabus: rep.taught,
    lesson: rep.current_lesson,
    homework: rep.next_target,
    remarks: rep.remarks,
    missedReason: rep.absence_reason,
    month: rep.month,
    year: rep.year,
  });

  // Selecting a student fills the form with the newest report their teacher
  // sent from the Teacher Dashboard (Supabase mode)
  const syncFromTeacher = async (studentId) => {
    const s = db.students.find((x) => x.id === studentId);
    if (!cloud || !s) return setSynced({ state: 'idle' });
    const run = ++syncRun.current;
    setSynced({ state: 'loading' });
    try {
      const found = await latestStudentReport(s.id, s.teacherId);
      if (run !== syncRun.current) return; // another student was picked meanwhile
      if (!found) return setSynced({ state: 'none', teacherId: s.teacherId });
      apply(fromTeacherReport(found.report), s.id, { quiet: true });
      setSynced({ state: 'filled', ...found });
    } catch (e) {
      if (run === syncRun.current) setSynced({ state: 'error', message: e.message });
    }
  };
  useEffect(() => {
    if (!r.studentId) return;
    if (skipSync.current) {
      skipSync.current = false;
      return;
    }
    syncFromTeacher(r.studentId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [r.studentId, cloud]);

  // A report a teacher submitted from their dashboard (Teacher Reports →
  // "Use in progress report") fills the form like a detected WhatsApp message
  useEffect(() => {
    if (!incoming) return;
    apply(fromTeacherReport(incoming), incoming.student_id);
    setSynced({ state: 'filled', report: incoming, fromAssigned: true });
    setNotice(`${incoming.teacher_name || 'Teacher'}’s report for ${incoming.student_name} (${incoming.month} ${incoming.year}) is filled in below.`);
    onIncomingDone();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [incoming]);

  // Daily attendance fills Attended / Total for the chosen student and month,
  // unless the teacher's own report for that month is already in the form.
  // The two boxes stay editable.
  const [attNote, setAttNote] = useState(null);
  useEffect(() => {
    setAttNote(null);
    if (!cloud || !r.studentId || synced.state === 'loading') return undefined;
    const rep = synced.state === 'filled' ? synced.report : null;
    if (rep && rep.month === r.month && String(rep.year) === String(r.year) && rep.total_classes != null) return undefined;
    let alive = true;
    studentAttendance(r.studentId, r.month, r.year).then((a) => {
      if (!alive || !a || !Number(a.total)) return;
      setR((x) => (x.studentId === r.studentId && x.month === r.month && String(x.year) === String(r.year) ? { ...x, total: a.total, attended: a.attended } : x));
      setAttNote(a);
    }).catch(() => {});
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cloud, r.studentId, r.month, r.year, synced.state, synced.report?.id]);

  /* ---- save & print ---- */
  const persist = async () => {
    if (saved || !student) return;
    const ok = await saveReport({ ...report, studentId: student.id, studentName: student.name, teacherId: student.teacherId, overallScore: r.overallScore });
    if (ok) setSaved(true);
  };

  const print = () => {
    const html = dossierRef.current?.outerHTML;
    if (!html) return;
    const w = window.open('', '_blank', 'width=950,height=900');
    if (!w) return toast('Allow pop-ups for this site to print the report.', 'error');
    w.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>${student.name} – ${r.month} ${r.year}</title>
<link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;600;700;800&display=swap" rel="stylesheet">
<style>${aikyaFontFace()}${DOSSIER_CSS}${DOSSIER_PRINT_CSS}</style></head><body>${html}</body></html>`);
    w.document.close();
    w.focus();
    // Give fonts and the signature image a moment to load
    setTimeout(() => {
      w.print();
      w.close();
    }, 900);
    persist();
  };

  const openPreview = () => {
    if (!student) return setNotice('Select a valid student first.');
    setSaved(false);
    setPreview(true);
  };

  // Searchable dropdown; option labels follow the report language
  const sel = (k, options) => (
    <Combobox value={r[k]} onChange={(v) => setR((x) => ({ ...x, [k]: v }))} options={options.map((o) => {
      const shown = portal.report[r.lang].ratings?.[o] || (r.lang === 'BN' ? translateText(o, true) : o);
      return { value: o, label: shown !== o ? `${shown} — ${o}` : o };
    })} aria-label={k} />
  );
  // v172: Bangla / English Medium shown with every student (admins)
  const studentOptions = db.students.map((s) => ({ value: s.id, label: `${s.name} (${s.id})${s.medium ? ` · ${s.medium}` : ''}` }));

  return (
    <div className={`box-card ${r.lang === 'BN' ? 'bn' : ''}`}>
      <div className="card-header-bar">
        <h2 className="card-title">Student progress report engine</h2>
        <label className="flex items-center gap-2 text-sm font-extrabold">
          Language / ভাষা:
          <Combobox variant="pill" value={r.lang} onChange={changeLang} options={[{ value: 'EN', label: 'English' }, { value: 'BN', label: 'বাংলা (Bangla)' }]} aria-label="Report language" />
        </label>
      </div>

      {/* Monthly format to send to teachers */}
      <ReportFormatCard />

      {/* WhatsApp raw message importer */}
      <div className="import-box">
        <div className="mb-3">
          <div className="text-[0.92rem] font-extrabold">📥 Paste Teacher's WhatsApp Report(s)</div>
          <div className="text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>
            Paste one or more raw class-report messages (Bangla or English, any format) — the system detects the student, attendance and syllabus automatically.
          </div>
        </div>
        <textarea className="m-input bn" rows={7} style={{ fontWeight: 500, lineHeight: 1.5 }} placeholder="Paste the raw WhatsApp message(s) from teachers here..." value={raw} onChange={(e) => setRaw(e.target.value)} aria-label="WhatsApp report text" />
        <div className="mt-3 flex justify-end gap-2">
          <button type="button" className="btn-add-row" onClick={() => { setRaw(''); setParsed([]); setNotice(''); }}>Clear</button>
          <button type="button" className="btn-teal" onClick={detect}>🔍 Detect &amp; Parse</button>
        </div>
        {notice && <p className="mt-3 text-sm font-bold" role="status" style={{ color: 'var(--c-teal-mid)' }}>{notice}</p>}
        {parsed.length > 0 && (
          <div className="parsed-grid">
            {parsed.map((p, idx) => {
              const matched = findMatchingStudent(p.name, db.students, p.whatsapp);
              return (
                <div key={idx} className={`parsed-card ${matched ? 'matched' : 'unmatched'}`}>
                  <div className="mb-2 flex items-start justify-between gap-2 border-b pb-2" style={{ borderColor: '#EBF2F3' }}>
                    <strong>{p.name || '(Name not detected)'}</strong>
                    <span className={`match-badge ${matched ? 'yes' : 'no'}`}>{matched ? `✓ Matched: ${matched.name}` : '⚠ No roster match'}</span>
                  </div>
                  {p.teacherName && <div className="parsed-row"><b>Teacher:</b><span>{p.teacherName}</span></div>}
                  {p.month && <div className="parsed-row"><b>Month:</b><span>{p.month} {p.year || ''}</span></div>}
                  {p.whatsapp && <div className="parsed-row"><b>WhatsApp:</b><span>{p.whatsapp}</span></div>}
                  {(p.classTime || p.classGroup) && <div className="parsed-row"><b>Class:</b><span>{p.classTime || ''} {p.classGroup ? `(${p.classGroup})` : ''}</span></div>}
                  {p.subject && <div className="parsed-row"><b>Subject:</b><span>{p.subject}</span></div>}
                  {p.syllabus && <div className="parsed-row"><b>Taught:</b><span>{p.syllabus}</span></div>}
                  {p.lesson && <div className="parsed-row"><b>Lesson:</b><span>{p.lesson}</span></div>}
                  {(p.status || p.statusLevel) && (
                    <div className="parsed-row"><b>Status:</b><span>{p.status || '—'}{p.statusLevel && <span className={`level-chip ${p.statusLevel}`}>{LEVEL_NAMES[p.statusLevel]}</span>}</span></div>
                  )}
                  <div className="parsed-row">
                    <b>Attendance:</b>
                    <span>
                      {p.finalAttended ?? '—'} present / {p.finalTotal ?? '—'} total{p.finalMissed != null ? ` • ${p.finalMissed} absent` : ''}
                      {p.attendancePct != null ? ` • ${p.attendancePct}%` : ''}
                    </span>
                  </div>
                  {p.homework && <div className="parsed-row"><b>Next:</b><span>{p.homework}</span></div>}
                  {p.missedReason && <div className="parsed-row"><b>Reason:</b><span>{p.missedReason}</span></div>}
                  {!matched && (
                    <div className="mt-2">
                      <Combobox value={manual[p.rawText] || ''} onChange={(v) => setManual((m) => ({ ...m, [p.rawText]: v }))} options={studentOptions} placeholder="Type to find the student…" aria-label="Pick student" />
                    </div>
                  )}
                  <button type="button" className="btn-teal mt-3" style={{ padding: '6px 12px', fontSize: '0.78rem' }} onClick={() => apply(p, matched?.id)}>
                    Apply to Report Form →
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Report form */}
      <div ref={formTop} className="grid gap-4 md:grid-cols-3">
        <div className="form-group">
          <label>{t.student}</label>
          <Combobox value={r.studentId} onChange={(v) => setR((x) => ({ ...x, studentId: v }))} options={studentOptions} placeholder={db.students.length ? 'Type a name or ID…' : 'No students yet'} aria-label="Student" />
          {student && (() => {
            const med = synced.report?.medium || student.medium;
            return med
              ? <span className={`t-medium ${med === 'English Medium' ? 'en' : 'bn'} mt-1.5`} style={{ marginLeft: 0 }} data-testid="pr-medium">{med}</span>
              : <span className="t-medium miss mt-1.5" style={{ marginLeft: 0 }} data-testid="pr-medium">Medium not set</span>;
          })()}
        </div>
        <div className="form-group">
          <label>{t.audience}</label>
          <Combobox value={r.reportType} onChange={(v) => setR((x) => ({ ...x, reportType: v }))} options={[{ value: 'Guardian', label: 'Guardian Report (অভিভাবক)' }, { value: 'Student', label: 'Student Report (শিক্ষার্থী)' }]} aria-label="Report audience" />
        </div>
        <div className="form-group">
          <label>{t.template}</label>
          <Combobox value={r.template} onChange={(v) => setR((x) => ({ ...x, template: v }))} options={['1', '2', '3'].map((v) => ({ value: v, label: `Template ${v}` }))} aria-label="Greeting template" />
        </div>
      </div>

      {cloud && student && <SyncStatus synced={synced} teacherName={(id) => db.teachers.find((x) => x.id === id)?.name || id} onReload={() => syncFromTeacher(student.id)} />}

      <div className="form-group">
        <label>{t.greeting}</label>
        <textarea className="m-input" rows={6} style={{ fontSize: '0.96rem', lineHeight: 1.65, fontWeight: 500 }} value={r.greeting} onChange={set('greeting')} />
      </div>

      <div className="my-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
        <div className="form-group"><label>{t.attended}</label><input type="number" min="0" className="m-input" value={r.attended} onChange={set('attended')} /></div>
        <div className="form-group"><label>{t.total}</label><input type="number" min="1" className="m-input" value={r.total} onChange={set('total')} /></div>
        {attNote && (
          <p className="text-xs font-semibold" style={{ gridColumn: '1 / -1', color: 'var(--c-teal-dark, #034751)', marginTop: -6 }} data-testid="att-from-daily">
            Filled in from the teacher’s daily attendance for {r.month} {r.year}: {attNote.attended} of {attNote.total} classes
            {Number(attNote.absent) ? `, ${attNote.absent} absent${attNote.reasons ? ` (${attNote.reasons})` : ''}` : ''}{Number(attNote.recovery) ? `, ${attNote.recovery} recovery` : ''}. You can still change the numbers.
          </p>
        )}
        <div className="form-group"><label>{t.rate}</label><input className="m-input" readOnly value={attPct} style={{ background: '#F1F5F9', color: 'var(--qit-teal)' }} /></div>
        <div className="form-group"><label>{t.grade}</label>{sel('overallScore', GRADES)}</div>
        <div className="form-group"><label>{t.period}</label>{sel('month', MONTHS)}</div>
        <div className="form-group"><label>&nbsp;</label>{sel('year', yearsWith(r.year))}</div>
      </div>

      <div className="card-header-bar"><h3 className="card-title" style={{ fontSize: '0.95rem' }}>{t.header}</h3></div>
      <div className="grid gap-3 md:grid-cols-2">
        <div className="form-group"><label>{t.tajweed}</label>{sel('tajweed', SKILL_OPTIONS.tajweed)}</div>
        <div className="form-group"><label>{t.hifz}</label>{sel('hifz', SKILL_OPTIONS.hifz)}</div>
        <div className="form-group"><label>{t.murajaah}</label>{sel('murajaah', SKILL_OPTIONS.murajaah)}</div>
        <div className="form-group"><label>{t.fluency}</label>{sel('fluency', SKILL_OPTIONS.fluency)}</div>
        <div className="form-group"><label>{t.achievements}</label><input className="m-input" value={r.achievements} onChange={set('achievements')} /></div>
        <div className="form-group"><label>{t.goals}</label><input className="m-input" value={r.goals} onChange={set('goals')} /></div>
      </div>
      <div className="form-group">
        <label>{t.remarks}</label>
        <textarea className="m-input" rows={3} style={{ border: '2px solid var(--c-teal-dark)', fontWeight: 500 }} value={r.remarks} onChange={set('remarks')} />
      </div>
      <div className="mt-4 flex justify-end">
        <button type="button" className="btn-teal" onClick={openPreview} disabled={!student}>Preview Progress Report</button>
      </div>

      {preview && student && (
        <PortalModal onClose={() => setPreview(false)} className="report" labelledBy="dossier-title">
          <style>{DOSSIER_CSS}</style>
          <div className="mb-4 flex flex-wrap items-center justify-between gap-2 border-b pb-3" style={{ borderColor: 'var(--c-box-border)' }}>
            <h3 id="dossier-title" className="text-lg font-extrabold">Academic Dossier Preview</h3>
            <div className="flex flex-wrap gap-2">
              <button type="button" className="btn-outline-sm" onClick={persist} disabled={saved}>{saved ? '✓ Saved to records' : 'Save to records'}</button>
              <button type="button" className="btn-teal" onClick={print}>Print / Save PDF</button>
              <button type="button" className="btn-muted" onClick={() => setPreview(false)}>Close</button>
            </div>
          </div>
          {/* Grey desk behind the A4 pages; scrolls sideways on small screens */}
          <div style={{ background: '#E6EEEE', padding: 20, borderRadius: 12, overflowX: 'auto' }}>
            <Dossier ref={dossierRef} r={report} student={student} teacher={teacher} portal={portal} />
          </div>
        </PortalModal>
      )}
    </div>
  );
}

// Where the form's data came from: the teacher's dashboard report, or nothing yet
function SyncStatus({ synced, teacherName, onReload }) {
  const rep = synced.report;
  const reload = (
    <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={onReload} disabled={synced.state === 'loading'}>
      <RefreshCw className={`h-3.5 w-3.5 ${synced.state === 'loading' ? 'animate-spin' : ''}`} /> Reload teacher’s report
    </button>
  );
  let body;
  if (synced.state === 'loading') body = <span>Looking for the teacher’s latest report…</span>;
  else if (synced.state === 'filled' && rep) {
    const status = { reviewed: 'Reviewed', needs_changes: 'Sent back for changes', submitted: 'Not reviewed yet' }[rep.review_status] || '';
    body = (
      <span>
        <strong>Filled in from {rep.teacher_name || teacherName(rep.teacher_id)}’s report</strong> for {rep.month} {rep.year}
        {rep.submitted_at ? ` (sent ${new Date(rep.submitted_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })})` : ''}
        {status && <span className={`st-badge ${rep.review_status === 'reviewed' ? 'yes' : 'part'} ml-2`}>{status}</span>}
        {!synced.fromAssigned && <span className="block text-xs" style={{ color: '#92400e' }}>This report is from {teacherName(rep.teacher_id)}, not the student’s current teacher.</span>}
        <span className="block text-xs" style={{ color: 'var(--text-muted)' }}>Check it and change anything before you preview or print.</span>
      </span>
    );
  } else if (synced.state === 'none') body = <span>No report from {teacherName(synced.teacherId) || 'the teacher'} yet for this student. Fill in the form by hand, or paste a WhatsApp report above.</span>;
  else if (synced.state === 'error') body = <span className="text-red-700">Could not load the teacher’s report: {synced.message}</span>;
  else return null;
  return (
    <div role="status" className={`sync-status ${synced.state}`}>
      <div className="min-w-0 text-sm">{body}</div>
      {synced.state !== 'loading' && reload}
    </div>
  );
}
