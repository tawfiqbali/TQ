import { useState } from 'react';
import { REPORT_FORMAT } from '../lib/reportFormat';
import { GROUP_WEB_LINK, copyText, openGroupInApp } from '../../../lib/whatsappGroup';

/**
 * The monthly report format teachers fill in and send back. Copy it (and open
 * the WhatsApp group) on the 1st of every month; the replies paste straight
 * into the importer below and are detected automatically.
 */
export default function ReportFormatCard() {
  const [lang, setLang] = useState('BN');
  const [open, setOpen] = useState(false);
  const [state, setState] = useState(''); // '' | 'copied' | 'sent' | 'missing' | 'error'
  const text = REPORT_FORMAT[lang];

  const copyOnly = async () => {
    setState((await copyText(text)) ? 'copied' : 'error');
  };
  const copyAndOpen = async () => {
    if (!(await copyText(text))) return setState('error');
    setState('sent');
    openGroupInApp(() => setState('missing'));
  };

  const msg = {
    copied: '✓ Copied! Paste it anywhere with Ctrl+V.',
    sent: '✓ Copied! WhatsApp is opening — paste the notice in the group with Ctrl+V.',
    error: 'Could not copy automatically — select the text above and copy it manually.',
  }[state];

  return (
    <div className="import-box" style={{ marginBottom: 16 }}>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <div className="text-[0.92rem] font-extrabold">📢 Monthly Notice &amp; Report Format for Teachers</div>
          <div className="text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>
            Full notice (salam, purpose, salary note, format, signature) — send it to the teachers on the 1st of every month. Their filled-in replies are detected perfectly below — even the student is matched by WhatsApp number.
          </div>
        </div>
        <div className="flex gap-2">
          <button type="button" className="btn-add-row" onClick={() => setOpen((o) => !o)} aria-expanded={open}>
            {open ? 'Hide notice' : 'Show notice'}
          </button>
          <button type="button" className="btn-add-row" onClick={copyOnly}>📄 Copy</button>
          <button type="button" className="btn-teal" onClick={copyAndOpen}>💬 Copy &amp; Open WhatsApp</button>
        </div>
      </div>

      <div className="mt-3 flex gap-2" role="tablist" aria-label="Format language">
        {[['BN', 'বাংলা'], ['EN', 'English']].map(([k, label]) => (
          <button key={k} type="button" role="tab" aria-selected={lang === k} className={lang === k ? 'btn-teal' : 'btn-add-row'} style={{ padding: '4px 14px', fontSize: '0.78rem' }} onClick={() => { setLang(k); setState(''); }}>
            {label}
          </button>
        ))}
      </div>

      {open && (
        <pre className={`mt-3 whitespace-pre-wrap rounded-xl border p-4 text-[0.85rem] leading-relaxed ${lang === 'BN' ? 'bn' : ''}`} style={{ background: '#fff', borderColor: '#DCE8EA', fontFamily: 'inherit', fontWeight: 500 }} aria-label="Report format text">
          {text}
        </pre>
      )}

      {msg && <p className="mt-3 text-sm font-bold" role="status" style={{ color: state === 'error' ? '#b42318' : 'var(--c-teal-mid)' }}>{msg}</p>}
      {state === 'missing' && (
        <div className="mt-3 rounded-xl border p-3 text-sm font-semibold" role="status" style={{ background: '#FFF8E6', borderColor: '#F2D48A' }}>
          The notice is copied, but WhatsApp Desktop didn't open. Open the group in{' '}
          <a href={GROUP_WEB_LINK} target="_blank" rel="noreferrer" style={{ color: 'var(--c-teal-mid)', textDecoration: 'underline' }}>WhatsApp Web</a>{' '}
          and paste it with Ctrl+V.
        </div>
      )}
    </div>
  );
}
