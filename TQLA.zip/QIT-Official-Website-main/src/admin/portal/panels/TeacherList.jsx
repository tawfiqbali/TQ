import { profileAttr } from '../components/ProfileOpener';
import { matchSearch } from '../../../lib/search';
import { useMemo, useState, useDeferredValue } from 'react';
import { BookOpen, Layers, Mail, Phone, Search, UserRound, Users, Wallet } from 'lucide-react';
import PhoneLinks from '../../../components/ui/PhoneLinks';
import { usePortal } from '../PortalContext';
import { CATEGORIES, teacherCategory, catTone } from '../lib/constants';
import { EditIconButton, EditTeacherModal, statusOf } from './common';

/**
 * Teacher list for the office (Junior Admins and Executives), by category.
 * Edit opens the same form as the Salary Directory. Executives get all of it;
 * Junior Admins get everything except the salary model and the salary amount
 * (the database ignores those two from a Junior Admin as well). A change is
 * saved to the one teacher record, so it shows everywhere.
 */
const catOf = teacherCategory;

export default function TeacherList() {
  const { db } = usePortal();
  const [category, setCategory] = useState('Residential');
  const [q, setQ] = useState('');
  const deferredQ = useDeferredValue(q);
  const [editing, setEditing] = useState(null);
  const counts = useMemo(() => db.teachers.reduce((m, t) => ({ ...m, [catOf(t)]: (m[catOf(t)] || 0) + 1 }), {}), [db.teachers]);
  const students = useMemo(() => db.students.reduce((m, s) => (s.teacherId && statusOf(s) === 'Active' ? { ...m, [s.teacherId]: (m[s.teacherId] || 0) + 1 } : m), {}), [db.students]);
  const term = deferredQ.trim().toLowerCase();
  // searching looks in every category
  const rows = db.teachers.filter((t) => (term ? matchSearch(`${t.name} ${t.id} ${t.whatsapp || ''} ${t.department || ''} ${t.email || ''}`, term) : catOf(t) === category));
  return (
    <div className="box-card" data-testid="teacher-list">
      <div className="card-header-bar">
        <h2 className="card-title">Teacher list</h2>
        <label className="roster-search">
          <span className="sr-only">Search teachers</span>
          <Search aria-hidden="true" />
          <input type="search" className="m-input" placeholder="Search name, ID, number" value={q} onChange={(e) => setQ(e.target.value)} />
        </label>
      </div>
      <div className="mb-4 flex flex-wrap gap-2" role="tablist" aria-label="Teacher category">
        {CATEGORIES.map((c) => (
          <button key={c.value} type="button" role="tab" aria-selected={!term && category === c.value} className={`dir-tab ${!term && category === c.value ? 'active' : ''}`} data-tone={catTone(c.value)} onClick={() => { setCategory(c.value); setQ(''); }} data-testid={`tl-tab-${c.value}`}>
            {c.label} <span className="count">{counts[c.value] || 0}</span>
          </button>
        ))}
      </div>
      <div className="table-wrap">
        <table className="salary-table tl-fit row-cards">
          <thead><tr>
            <th><UserRound className="th-ico h-4 w-4" aria-hidden="true" />Teacher · ID · Gmail</th><th><Layers className="th-ico h-4 w-4" aria-hidden="true" />Category</th><th><BookOpen className="th-ico h-4 w-4" aria-hidden="true" />Department</th>
            <th><Phone className="th-ico h-4 w-4" aria-hidden="true" />WhatsApp</th><th><Wallet className="th-ico h-4 w-4" aria-hidden="true" />Paid by</th>
            <th><Users className="th-ico h-4 w-4" aria-hidden="true" />Students</th><th style={{ textAlign: 'right' }}>Action</th>
          </tr></thead>
          <tbody>
            {rows.length === 0 && <tr><td colSpan={7} style={{ textAlign: 'center', padding: 18 }}>{term ? 'No teachers match your search.' : 'No teachers in this category yet.'}</td></tr>}
            {rows.map((t) => (
              <tr key={t.id} className={`row-card tl-${{ Residential: 'res', 'Non-Residential Male': 'male', 'Non-Residential Female': 'female' }[catOf(t)] || 'res'}`} data-profile={`teacher:${t.id}`} title={`Open ${t.name}'s profile`} data-testid={`tl-row-${t.id}`}>
                <td className="tl-name">
                  <strong className="tl-n" {...profileAttr('teacher', t.id)}>{t.name}</strong>
                  <span className="id-tag">{t.id}</span>
                  <span className="tl-gmail" title={t.email || ''}><Mail className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />{t.email || <em>not signed in yet</em>}</span>
                </td>
                <td><span className={`cell-chip ${{ Residential: 'res', 'Non-Residential Male': 'male', 'Non-Residential Female': 'female' }[catOf(t)] || ''}`}>{CATEGORIES.find((c) => c.value === catOf(t))?.short || '—'}</span></td>
                <td>{t.department ? <span className="cell-chip">{t.department}</span> : '—'}</td>
                <td><PhoneLinks value={t.whatsapp} /></td>
                <td>{t.method ? <span className="cell-chip pay">{t.method}</span> : '—'}</td>
                <td><span className={`cell-count ${students[t.id] ? '' : 'zero'}`}>{students[t.id] || 0}</span></td>
                <td style={{ textAlign: 'right' }}><EditIconButton label={`Edit ${t.name}`} onClick={() => setEditing(t)} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {editing && <EditTeacherModal teacher={editing} onClose={() => setEditing(null)} onDeleted={() => setEditing(null)} />}
    </div>
  );
}
