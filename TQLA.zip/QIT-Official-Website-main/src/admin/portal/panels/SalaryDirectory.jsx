import { matchSearch } from '../../../lib/search';
import { Suspense, lazy, useEffect, useMemo, useState, useDeferredValue } from 'react';
import { ArrowLeft, Award, CheckCircle2, Download, Eye, EyeOff, FileBadge, LayoutDashboard, Monitor, Plus, Search, Trash2, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import { printSalaryDirectory } from '../lib/directoryPdf';
import { usePortal } from '../PortalContext';
import { CATEGORIES, MONTHS, PAYMENT_METHODS, feeFor, fmt, yearsWith, catTone } from '../lib/constants';
import { MonthModeToggle, defaultPick, figuresMonth, pickFor, useMonthMode } from '../lib/monthMode';
import { monthIdx, teacherDues, teacherMonth } from '../lib/salaryCalc';
import Combobox from '../components/Combobox';
import PhoneLinks from '../../../components/ui/PhoneLinks';
import { EditIconButton, EditStudentModal, EditTeacherModal, PortalModal } from './common';
import SalaryCertificate from './SalaryCertificate';
import ManagementTeam, { useTeam } from './ManagementTeam';
// v179: a teacher's reports open in a pop-up here
const TeacherReportsModal = lazy(() => import('../../staff/ReportsReview').then((m) => ({ default: m.TeacherReportsModal })));
import { useConfirm } from '../../../components/ui/Confirm';
import { useToast } from '../../../components/ui/Toast';

// The Salary Directory is only reachable by a Super Admin (checked by the
// portal and by the Apps Script), so it no longer asks for a separate PIN.

function MonthYear({ month, year, onMonth, onYear, label = 'Period' }) {
  return (
    <div className="filter-cluster">
      <span className="filter-label">{label}</span>
      <Combobox variant="pill" value={month} onChange={onMonth} options={MONTHS} aria-label={`${label} month`} />
      <Combobox variant="pill" className="qcb-year" value={year} onChange={onYear} options={yearsWith(year)} aria-label={`${label} year`} />
    </div>
  );
}
/**
 * v164: the month picked is the PAYMENT month. Salary is paid the month after
 * the classes (January's salary in February), so picking October shows
 * September's tuition, teacher share and due.
 */
function PeriodPicker({ month, year, onMonth, onYear }) {
  const mode = useMonthMode();
  const work = figuresMonth(mode, month, year);
  return (
    <div className="pay-period" data-testid="pay-period">
      <MonthYear month={month} year={year} onMonth={onMonth} onYear={onYear} label={mode === 'class' ? 'Class month' : 'Payment month'} />
      <span className="pay-period-for">{mode === 'class' ? 'figures of' : 'pays for'} <strong data-testid="pay-period-for">{work.month} {work.year}</strong>{mode === 'class' ? '' : ' classes'}</span>
      <MonthModeToggle />
    </div>
  );
}

// Teacher department tag (Bangla Dept. / English Dept.)
function DeptTag({ department }) {
  if (!department) return <span className="dept-tag empty">No Department</span>;
  return <span className={`dept-tag ${/bangla/i.test(department) ? 'bn' : 'en'}`}>{department}</span>;
}

// Salary figures for one teacher in one month (v155: prorated by Assignment Date
// and dated status changes — see lib/salaryCalc.js)
function teacherFigures(t, db, month, year) {
  const m = teacherMonth(t, db, month, year);
  const assigned = m.rows.map((x) => ({ ...x.s, fee: x.m.fee, cut: x.m.cut, fullFee: feeFor(x.s, month, year), fullCut: Number(x.s.cut) || 0, partial: x.m.partial, calcNote: x.m.note }));
  // v160: every current student of the teacher is listed, also one who starts
  // later (e.g. assigned on 11 Oct while September is open): 0 for this month
  const shown = new Set(assigned.map((x) => x.id));
  db.students.filter((s) => s.teacherId === t.id && !shown.has(s.id) && !['Hold', 'Inactive'].includes(s.status)).forEach((s) => {
    const d = /^\d{4}-\d{2}-\d{2}$/.test(s.assignDate || '') ? new Date(`${s.assignDate}T12:00:00`).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '';
    assigned.push({ ...s, fee: 0, cut: 0, fullFee: feeFor(s, month, year), fullCut: Number(s.cut) || 0, partial: true, calcNote: d ? `starts ${d} — nothing for ${month}` : `nothing for ${month}` });
  });
  // v188: Hold / Inactive students who count nothing for this month (stopped
  // before it, or on the 1st–3rd): their own list under the roster
  const counted = new Set(assigned.map((x) => x.id));
  const held = db.students
    .filter((s) => s.teacherId === t.id && !counted.has(s.id) && ['Hold', 'Inactive'].includes(s.status))
    .map((s) => ({ ...s, since: statusSince(s) }));
  return { ...m, assigned, held };
}

// v188: the date the student's current status began (from the Status history)
function statusSince(s) {
  const log = (Array.isArray(s.statusLog) ? s.statusLog : []).filter((e) => /^\d{4}-\d{2}-\d{2}/.test(e?.date || ''));
  const cur = s.status || 'Active';
  const same = log.filter((e) => (e.status || 'Active') === cur).sort((x, y) => String(y.date).localeCompare(String(x.date)));
  return same[0]?.date?.slice(0, 10) || '';
}
const dayLabel = (iso) => (iso ? new Date(`${iso}T12:00:00`).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '');
function StatusTag({ s }) {
  const st = s.movedAway ? 'Moved' : s.status === 'Hold' || s.status === 'Inactive' ? s.status : 'Active';
  const since = st === 'Hold' || st === 'Inactive' ? statusSince(s) : '';
  return <span className={`st-mini st-mini-${st.toLowerCase()}`} data-testid={`st-tag-${s.id}`} title={since ? `${st} since ${dayLabel(since)}` : st}>{st}{since ? ` · ${dayLabel(since).replace(/ \d{4}$/, '')}` : ''}</span>;
}

// v188: the students on Hold / Inactive who count nothing in this month
function HeldList({ list, month, onEdit }) {
  const [open, setOpen] = useState(false);
  const [sort, setSort] = useState('since');
  if (!list.length) return null;
  const rows = [...list].sort((a, b) => (sort === 'name' ? String(a.name).localeCompare(String(b.name))
    : sort === 'status' ? String(a.status).localeCompare(String(b.status)) || String(b.since).localeCompare(String(a.since))
      : String(b.since).localeCompare(String(a.since)) || String(a.name).localeCompare(String(b.name))));
  return (
    <div className="held-box mb-5" data-testid="held-list">
      <button type="button" className="held-head" onClick={() => setOpen((o) => !o)} aria-expanded={open} data-testid="held-toggle">
        <span>Hold - Inactive Students <span className="held-count">{list.length}</span></span>
        <span className="text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>nothing counts for {month} · {open ? 'hide' : 'show'}</span>
      </button>
      {open && (
        <>
          <div className="held-sort" role="radiogroup" aria-label="Sort">
            <span>Sort:</span>
            {[['since', 'Latest first'], ['name', 'Name'], ['status', 'Hold / Inactive']].map(([k, l]) => (
              <button key={k} type="button" role="radio" aria-checked={sort === k} className={sort === k ? 'on' : ''} onClick={() => setSort(k)} data-testid={`held-sort-${k}`}>{l}</button>
            ))}
          </div>
          <ul className="held-rows">
            {rows.map((s) => (
              <li key={s.id} data-testid={`held-${s.id}`}>
                <div className="min-w-0">
                  <strong>{s.name}</strong> <StatusTag s={s} />
                  <div className="text-xs" style={{ color: 'var(--text-muted)' }}>{s.id} • <PhoneLinks value={s.phone} empty="N/A" />{s.since ? ` • since ${dayLabel(s.since)}` : ' • no date in the Status history'}</div>
                </div>
                <EditIconButton label={`Edit ${s.name}`} onClick={() => onEdit(s)} />
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
}

function bankLine(t) {
  if (t.method === 'Bank' && t.bankName) return `Bank: ${t.bankName}${t.branchName ? ` (${t.branchName})` : ''} • Acc: ${t.account || 'not set'}`;
  // v165: no "undefined" when the method or account is not filled in yet
  return `Method: ${t.method || 'not set'} • Acc: ${t.account && t.account !== 'N/A' ? t.account : 'not set'}`;
}

// v187: extra responsibilities — a fixed amount added to the salary every month
// from a month (and until a month, or ongoing)
const ymOf = (month, year) => `${year}-${String(MONTHS.indexOf(month) + 1).padStart(2, '0')}`;
const ymLabel = (v) => { const m = /^(\d{4})-(\d{2})/.exec(v || ''); return m ? `${MONTHS[Number(m[2]) - 1].slice(0, 3)} ${m[1]}` : ''; };
function ExtrasBox({ teacher, month, year, extras }) {
  const { updateTeacher } = usePortal();
  const confirm = useConfirm();
  const [adding, setAdding] = useState(false);
  const [v, setV] = useState({ title: '', amount: '', from: ymOf(month, year), until: '' });
  const list = Array.isArray(teacher.extras) ? teacher.extras : [];
  const active = new Set((extras || []).map((e) => e.id));
  const save = (next) => updateTeacher({ ...teacher, extras: next });
  const add = async () => {
    const amount = Math.round(Number(v.amount) || 0);
    if (!v.title.trim() || amount <= 0) return;
    await save([...list, { id: `EX-${Date.now()}`, title: v.title.trim(), amount, from: v.from, until: v.until || '' }]);
    setAdding(false);
    setV({ title: '', amount: '', from: ymOf(month, year), until: '' });
  };
  const end = async (e) => {
    if (!(await confirm({ title: 'End this responsibility?', message: `"${e.title}" (${fmt(e.amount)} BDT a month) is paid up to and including ${month} ${year}, not after.`, confirmText: 'End it' }))) return;
    save(list.map((x) => (x.id === e.id ? { ...x, until: ymOf(month, year) } : x)));
  };
  const remove = async (e) => {
    if (!(await confirm({ title: 'Remove this responsibility?', message: `"${e.title}" is removed from every month (also months already counted but not yet paid).`, confirmText: 'Remove', tone: 'danger' }))) return;
    save(list.filter((x) => x.id !== e.id));
  };
  const monthOpts = (() => {
    const out = [];
    const k0 = Number(year) * 12 + MONTHS.indexOf(month);
    for (let k = k0 - 6; k <= k0 + 12; k += 1) out.push(`${Math.floor(k / 12)}-${String((k % 12) + 1).padStart(2, '0')}`);
    return out;
  })();
  return (
    <div className="extras-box mb-6" data-testid="extras-box">
      <div className="extras-head">
        <h3 className="inline-flex items-center gap-2 text-sm font-extrabold uppercase"><Award className="h-4 w-4" aria-hidden="true" /> Extra responsibilities</h3>
        {!adding && <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={() => setAdding(true)} data-testid="extra-add"><Plus className="h-3.5 w-3.5" /> Add responsibility</button>}
      </div>
      {!list.length && !adding && <p className="text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>None. Add a responsibility (class monitor, admission work…) and its monthly payment — it is added to the main salary.</p>}
      {list.length > 0 && (
        <ul className="extras-list">
          {list.map((e) => (
            <li key={e.id} className={active.has(e.id) ? 'is-on' : ''} data-testid={`extra-${e.id}`}>
              <span className="extras-title">{e.title}</span>
              <strong>+{fmt(e.amount)} BDT / month</strong>
              <span className="extras-when">{ymLabel(e.from) || 'always'} → {e.until ? ymLabel(e.until) : 'ongoing'}{active.has(e.id) ? ` · counted in ${month.slice(0, 3)}` : ''}</span>
              <span className="ml-auto inline-flex gap-1.5">
                {!e.until && <button type="button" className="btn-outline-sm" onClick={() => end(e)} title={`Last month: ${month} ${year}`}>End after {month.slice(0, 3)}</button>}
                <button type="button" className="btn-icon-edit" style={{ color: '#b42318' }} onClick={() => remove(e)} aria-label={`Remove ${e.title}`}><Trash2 className="h-4 w-4" /></button>
              </span>
            </li>
          ))}
        </ul>
      )}
      {adding && (
        <div className="extras-form" data-testid="extra-form">
          <label className="payout-field"><span>Responsibility</span><input className="w-56" value={v.title} onChange={(e) => setV((x) => ({ ...x, title: e.target.value }))} placeholder="e.g. Class monitor" data-testid="extra-title" autoFocus /></label>
          <label className="payout-field"><span>Payment / month (BDT)</span><input type="number" min="0" className="w-32" value={v.amount} onChange={(e) => setV((x) => ({ ...x, amount: e.target.value }))} data-testid="extra-amount" /></label>
          <label className="payout-field"><span>From (salary month)</span><select value={v.from} onChange={(e) => setV((x) => ({ ...x, from: e.target.value }))} data-testid="extra-from">{monthOpts.map((m) => <option key={m} value={m}>{ymLabel(m)}</option>)}</select></label>
          <label className="payout-field"><span>Until</span><select value={v.until} onChange={(e) => setV((x) => ({ ...x, until: e.target.value }))} data-testid="extra-until"><option value="">Ongoing</option>{monthOpts.filter((m) => m >= v.from).map((m) => <option key={m} value={m}>{ymLabel(m)}</option>)}</select></label>
          <button type="button" className="btn-teal self-end" onClick={add} disabled={!v.title.trim() || !(Number(v.amount) > 0)} data-testid="extra-save">Add to salary</button>
          <button type="button" className="btn-muted self-end" onClick={() => setAdding(false)}>Cancel</button>
        </div>
      )}
    </div>
  );
}

export function TeacherWorkspace({ teacherId, initialMonth, initialYear, onClose }) {
  const { db, recordPayment, cancelPayment } = usePortal();
  const confirm = useConfirm();
  const toast = useToast();
  // initialMonth / initialYear = the salary month (classes); the picker shows its payment month
  const mode = useMonthMode();
  const [pay, setPay] = useState(() => pickFor(mode, initialMonth, initialYear));
  const { month, year } = figuresMonth(mode, pay.month, pay.year);
  const setMonth = (m) => setPay((x) => ({ ...x, month: m }));
  const setYear = (y) => setPay((x) => ({ ...x, year: String(y) }));
  const openSalaryMonth = (m, y) => setPay(pickFor(mode, m, y));
  const [editTeacher, setEditTeacher] = useState(false);
  const [editStudent, setEditStudent] = useState(null);
  const [certificate, setCertificate] = useState(null);
  const [reportsOpen, setReportsOpen] = useState(false);
  const t = db.teachers.find((x) => x.id === teacherId);
  const f = t ? teacherFigures(t, db, month, year) : null;
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  // The salary is paid FOR the month chosen in Period (it opens on last month:
  // September's salary is paid in October). One month, one disbursement.
  const [amount, setAmount] = useState('');
  const [amountTouched, setAmountTouched] = useState(false);
  const [payMethod, setPayMethod] = useState('');
  const [payNote, setPayNote] = useState('');
  const dues = t ? teacherDues(t, db) : { months: [], total: 0 };
  useEffect(() => { setAmountTouched(false); }, [month, year]);
  if (!t) return null;
  // v168: husband and wife — her salary and due are paid together with his
  const payTo = t.payWith ? db.teachers.find((x) => x.id === t.payWith) : null;
  const pf = db.teachers.filter((x) => x.payWith === t.id).map((p) => ({ t: p, f: teacherFigures(p, db, month, year), dues: teacherDues(p, db) }));
  const openPf = pf.filter((x) => !x.f.settled);
  const partSalary = openPf.reduce((a, x) => a + x.f.salary, 0);
  // v188: unpaid earlier months are paid together with this month (each month is recorded and settled)
  const kNow = monthIdx(month, year);
  const earlier = dues.months.filter((d) => monthIdx(d.month, d.year) < kNow && d.salary > 0);
  const earlierTotal = earlier.reduce((a, d) => a + d.salary, 0);
  const done = f.settled && !openPf.length && !earlier.length;
  const calcTotal = (f.settled ? 0 : f.salary) + partSalary + earlierTotal;
  const dueTotal = (f.settled ? 0 : f.due) + openPf.reduce((a, x) => a + x.f.due, 0) + earlierTotal;
  const amountValue = amountTouched ? amount : dueTotal > 0 ? dueTotal : '';
  const diff = (Number(amountValue) || 0) - calcTotal;
  // Every disbursement of this teacher, newest first: nothing hides when the period changes
  const history = db.payments.filter((p) => p.teacherId === t.id).sort((x, y) => String(y.date).localeCompare(String(x.date)) || String(y.id).localeCompare(String(x.id)));

  const disburse = async () => {
    const amt = Number(amountValue) || 0;
    if (done) return toast(`${month} ${year} is already disbursed. Cancel it in the history to pay again.`, 'error');
    if (amt <= 0) return toast('Enter a valid disbursement amount.', 'error');
    const d = amt - calcTotal;
    if (d !== 0 && !payNote.trim()) return toast(`The amount is ${fmt(Math.abs(d))} BDT ${d > 0 ? 'more' : 'less'} than the calculated salary — write a short note (bonus, deduction…).`, 'error');
    if (earlier.length && amt < earlierTotal) return toast(`The amount must cover the earlier dues first: ${earlier.map((e) => `${e.month} ${fmt(e.salary)}`).join(', ')} BDT.`, 'error');
    const withText = openPf.length ? ` (with ${openPf.map((x) => `${x.t.name}: ${fmt(x.f.salary)} BDT`).join(', ')})` : '';
    const dueText = earlier.length ? ` Includes the earlier due: ${earlier.map((e) => `${e.month} ${e.year} ${fmt(e.salary)} BDT`).join(', ')}.` : '';
    if (!(await confirm({ title: 'Disburse salary?', message: `${fmt(amt)} BDT to ${t.name} as salary for ${month} ${year}${withText}.${dueText}${d ? ` Calculated: ${fmt(calcTotal)} BDT (${d > 0 ? '+' : '−'}${fmt(Math.abs(d))}).` : ''}`, confirmText: 'Disburse' }))) return;
    const stamp = Date.now();
    const base = { date, month, year: String(year), method: payMethod || t.method || 'Other' };
    // v188: each earlier unpaid month gets its own record (so it is settled), noted as paid with this month
    for (const [i, e] of earlier.entries()) {
      // eslint-disable-next-line no-await-in-loop
      await recordPayment({ id: `PAY-${stamp}-D${i + 1}`, teacherId: t.id, amount: e.salary, calculated: e.salary, ...base, month: e.month, year: String(e.year), note: `Due of ${e.month.slice(0, 3)}. paid with ${month.slice(0, 3)}. salary`, group: `GRP-${stamp}` });
    }
    if (f.settled && !openPf.length) { setAmountTouched(false); setPayNote(''); return; }
    const group = openPf.length ? `GRP-${stamp}` : undefined;
    // the wife's share is recorded on her own page too (paid to her husband)
    for (const [i, x] of openPf.entries()) {
      const last = f.settled && i === openPf.length - 1;
      // eslint-disable-next-line no-await-in-loop
      await recordPayment({ id: `PAY-${stamp}-${i + 1}`, teacherId: x.t.id, amount: x.f.salary + (last ? d : 0), calculated: x.f.salary, ...base, paidVia: t.id, group, ...(last && d ? { note: payNote.trim() } : {}) });
    }
    if (!f.settled) await recordPayment({ id: `PAY-${stamp}`, teacherId: t.id, amount: amt - partSalary - earlierTotal, calculated: f.salary, ...base, ...(group || earlier.length ? { group: group || `GRP-${stamp}` } : {}), ...(d ? { note: payNote.trim() } : {}) });
    setAmountTouched(false);
    setPayNote('');
  };

  return (
    <PortalModal onClose={onClose} className="wide" labelledBy="ws-title">
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3 border-b pb-3" style={{ borderColor: 'var(--c-box-border)' }}>
        <button type="button" className="btn-teal" onClick={onClose}><ArrowLeft className="h-4 w-4" /> Close Workspace</button>
        <PeriodPicker month={pay.month} year={pay.year} onMonth={setMonth} onYear={setYear} />
      </div>

      <div className="tile mb-5 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex flex-wrap items-center gap-3">
            <h2 id="ws-title" className="text-xl font-extrabold">{t.name}</h2>
            <span className="id-tag">{t.id}</span>
            {f.isPkg ? <span className="fixed-tag">Fixed Salary: {fmt(f.salary)} BDT</span> : <span className="per-student-tag">Per-Student Rate</span>}
            <DeptTag department={t.department} />
          </div>
          <p className="mt-1 text-sm" style={{ color: 'var(--text-muted)' }}>
            Category: <strong>{t.category || 'Not set'}</strong> • WhatsApp: <PhoneLinks value={t.whatsapp} />{t.email ? <> • Gmail: <strong>{t.email}</strong></> : null} • {bankLine(t)}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {/* v176: this teacher's monthly reports (every student, every month) */}
          <button type="button" onClick={() => setReportsOpen(true)} className="btn-outline-sm inline-flex items-center gap-1.5" data-testid="ws-reports"><FileBadge className="h-4 w-4" aria-hidden="true" /> Reports</button>
          <button type="button" className="btn-teal" onClick={() => setEditTeacher(true)}>Edit Teacher Details</button>
        </div>
      </div>

      <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="tile" style={{ background: '#fff' }}><div className="tile-label">Total Revenue · {month.slice(0, 3)} ({f.assigned.length} Students)</div><div className="tile-value text-xl">{fmt(f.tuition)} BDT</div></div>
        <div className="tile"><div className="tile-label">{f.isPkg ? 'Fixed Salary' : 'Faculty Cut'} ({f.sharePct}%){f.extraTotal ? ' + extra' : ''}</div><div className="tile-value text-xl">{fmt(f.salary)} BDT</div>{f.extraTotal > 0 && <div className="text-xs font-semibold" style={{ color: 'var(--text-muted)' }} data-testid="ws-extra-note">{fmt(f.baseSalary)} + {fmt(f.extraTotal)} ({f.extras.map((e) => e.title).join(', ')})</div>}</div>
        <div className="tile" style={{ background: 'var(--qit-teal-tint)', borderColor: 'var(--qit-teal-line)' }}><div className="tile-label" style={{ color: 'var(--qit-teal)' }}>Disbursed ({month})</div><div className="tile-value text-xl" style={{ color: 'var(--qit-teal)' }}>{fmt(f.paid)} BDT</div></div>
        <div className="tile" style={{ background: 'var(--qit-gold-tint)', borderColor: 'var(--qit-gold-line)' }}><div className="tile-label" style={{ color: 'var(--qit-gold)' }}>Due Balance Remaining</div><div className="tile-value text-xl" style={{ color: 'var(--qit-gold)' }} data-testid="ws-due">{fmt((f.settled ? 0 : f.due) + earlierTotal)} BDT</div>{earlier.length > 0 && <div className="text-xs font-semibold" style={{ color: 'var(--qit-gold)' }}>incl. earlier due: {earlier.map((e) => `${e.month.slice(0, 3)} ${fmt(e.salary)}`).join(', ')}</div>}</div>
      </div>

      <ExtrasBox teacher={t} month={month} year={year} extras={f.extras} />

      <h3 className="mb-2 text-sm font-extrabold uppercase">Assigned Students Roster</h3>
      <div className="table-wrap mb-5">
        <table className="salary-table">
          <thead><tr><th>Student Info</th><th>Fee ({month.slice(0, 3)})</th><th>Teacher Share</th><th>Teacher %</th><th>Institute Net</th><th style={{ textAlign: 'right' }}>Action</th></tr></thead>
          <tbody>
            {f.assigned.length === 0 && <tr><td colSpan={6} style={{ textAlign: 'center', color: 'var(--text-muted)' }}>No enrolled students assigned to this teacher yet.</td></tr>}
            {f.assigned.map((s) => {
              const share = f.isPkg ? (f.tuition > 0 ? s.fee * (f.salary / f.tuition) : 0) : s.cut;
              const pct = f.isPkg ? Number(f.sharePct) : s.fullFee > 0 ? (s.fullCut / s.fullFee) * 100 : 0;
              const badge = pct >= 50 ? 'high' : pct >= 30 ? 'med' : 'low';
              return (
                <tr key={s.id}>
                  <td><strong>{s.name}</strong> <StatusTag s={s} /><div className="text-xs" style={{ color: 'var(--text-muted)' }}>WhatsApp: <PhoneLinks value={s.phone} empty="N/A" /> • ({s.id})</div>{s.calcNote && <div className="calc-note" data-testid={`calc-note-${s.id}`}>{s.calcNote}</div>}</td>
                  <td>{fmt(s.fee)} BDT{s.partial && s.fee !== s.fullFee && <div className="text-xs" style={{ color: 'var(--text-muted)' }}>of {fmt(s.fullFee)}</div>}</td>
                  <td><strong>{fmt(share)} BDT</strong> {f.isPkg && <span className="text-xs" style={{ color: 'var(--c-teal-mid)' }}>(Fixed)</span>}</td>
                  <td><span className={`pct-tag ${badge}`}>{pct.toFixed(1)}%</span></td>
                  <td className="font-bold">{fmt(s.fee - share)} BDT</td>
                  <td style={{ textAlign: 'right' }}><EditIconButton label={`Edit ${s.name}`} onClick={() => setEditStudent(s)} /></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <HeldList list={f.held || []} month={month} onEdit={setEditStudent} />

      <div className="payout-bar" data-testid="payout-bar">
        <div className="text-sm font-bold">
          <div>Salary for: <strong>{month} {year}</strong> {mode === 'pay' && <span className="text-xs" style={{ color: 'var(--text-muted)' }}>(paid in {pay.month} {pay.year})</span>} • {done ? <span style={{ color: 'var(--qit-teal)' }}>Disbursed: <strong>{fmt(f.paid)} BDT</strong></span> : <>Due: <strong style={{ color: 'var(--qit-gold)' }} data-testid="payout-due">{fmt(dueTotal)} BDT</strong>{earlier.length > 0 && <span className="text-xs" style={{ color: 'var(--qit-gold)' }}> ({month.slice(0, 3)} {fmt(f.settled ? 0 : f.due)} + earlier due {earlier.map((e) => `${e.month.slice(0, 3)} ${fmt(e.salary)}`).join(', ')})</span>}</>}</div>
          <div className="text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>{done ? 'To change it, cancel this disbursement in the history below.' : mode === 'pay' ? `The Payment month at the top is ${pay.month}, so this pays ${month}'s classes.` : `Class month: ${month}'s classes (paid the month after).`}</div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {payTo && !f.settled ? (
            <span className="pair-box" data-testid="paid-with">Paid together with <strong>{payTo.name}</strong> ({payTo.id}) — disburse from his page:
              <span className="btn-outline-sm p-link" data-profile={`teacher:${payTo.id}`} role="link" tabIndex={0}>Open {payTo.name}</span></span>
          ) : done ? (
            <span className="disbursed-box" data-testid="disbursed-box"><CheckCircle2 className="h-4 w-4" aria-hidden="true" /> Disbursed</span>
          ) : (
            <>
              <label className="payout-field"><span>Payment date</span><input type="date" value={date} onChange={(e) => setDate(e.target.value)} aria-label="Disbursement date" /></label>
              <label className="payout-field"><span>Sent by</span><select value={payMethod || t.method || 'Other'} onChange={(e) => setPayMethod(e.target.value)} aria-label="Transfer method" data-testid="pay-method">{PAYMENT_METHODS.map((m) => <option key={m} value={m}>{m}</option>)}</select></label>
              <label className="payout-field"><span>Amount (BDT)</span><input type="number" placeholder="BDT" className="w-28" value={amountValue} onChange={(e) => { setAmount(e.target.value); setAmountTouched(true); }} aria-label="Amount" data-testid="pay-amount" /></label>
              {amountValue !== '' && diff !== 0 && (
                <label className="payout-field"><span>Note ({diff > 0 ? '+' : '−'}{fmt(Math.abs(diff))} BDT)</span><input className="w-48" placeholder={diff > 0 ? 'e.g. Eid bonus' : 'e.g. 2 days leave deducted'} value={payNote} onChange={(e) => setPayNote(e.target.value)} aria-label="Note for the difference" data-testid="pay-note" /></label>
              )}
              <button type="button" className="btn-teal self-end" onClick={disburse} data-testid="disburse-btn">Disburse</button>
            </>
          )}
          <button
            type="button"
            className="btn-outline-sm self-end inline-flex items-center gap-1.5"
            style={{ padding: '9px 12px' }}
            onClick={() => {
              setCertificate({ month, year, amount: f.paid > 0 ? f.paid : f.salary });
            }}
          >
            <FileBadge className="h-4 w-4" /> Generate Salary Certificate
          </button>
        </div>
      </div>

      {pf.length > 0 && (
        <div className="pair-panel" data-testid="pair-panel">
          <strong>Paid together with:</strong>
          {pf.map((x) => (
            <span key={x.t.id}>{x.t.name} ({x.t.id}) · {month.slice(0, 3)} salary <b>{fmt(x.f.salary)} BDT</b>{x.f.settled ? ' · disbursed ✓' : ''}{x.dues.total ? ` · total due ${fmt(x.dues.total)} BDT` : ''}</span>
          ))}
          {!done && <span>To pay now: <b>{fmt(dueTotal)} BDT</b> ({t.name} {fmt(f.settled ? 0 : f.due)} + {fmt(dueTotal - (f.settled ? 0 : f.due))})</span>}
        </div>
      )}

      <h3 className="mb-2 mt-6 text-sm font-extrabold uppercase">Salary due (not yet disbursed)</h3>
      <div className="dues-box mb-2" data-testid="dues-box">
        {!dues.months.length ? <p className="text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>Nothing due — every month up to last month is disbursed.</p> : (
          <>
            <ul>
              {dues.months.map((d) => (
                <li key={`${d.month}${d.year}`}>
                  <button type="button" className="dues-m" onClick={() => openSalaryMonth(d.month, d.year)} title="Open this month">{d.month} {d.year}</button>
                  <strong>{fmt(d.salary)} BDT</strong>{d.partial && <span className="st-badge part ml-1">part month</span>}
                  {d.notes.length > 0 && <span className="dues-notes">{d.notes.join(' · ')}</span>}
                </li>
              ))}
            </ul>
            <p className="dues-total">Total due: <strong data-testid="dues-total">{fmt(dues.total)} BDT</strong></p>
          </>
        )}
      </div>

      <h3 className="mb-2 mt-6 text-sm font-extrabold uppercase">Disbursed Payment History</h3>
      <div className="table-wrap">
        <table className="salary-table">
          <thead><tr><th>Salary month</th><th>Amount Paid</th><th>Disbursement Date</th><th style={{ textAlign: 'right' }}>Actions</th></tr></thead>
          <tbody data-testid="pay-history">
            {history.length === 0 && <tr><td colSpan={4} style={{ textAlign: 'center', color: 'var(--text-muted)' }}>No disbursements recorded for this teacher yet.</td></tr>}
            {history.map((p) => (
              <tr key={p.id} style={p.month === month && String(p.year) === String(year) ? { background: 'var(--qit-teal-tint)' } : undefined}>
                <td><strong>{p.month} {p.year}</strong><div className="text-xs" style={{ color: 'var(--text-muted)' }}>{p.id}</div></td>
                <td><strong style={{ color: 'var(--qit-teal)' }}>{fmt(p.amount)} BDT</strong>{p.calculated != null && Number(p.amount) !== Number(p.calculated) && (
                  // v167: "Sept. Salary 5,000 + 1,050 (Due of Joining 10 Days)"
                  <div className="diff-note" data-testid={`diff-${p.id}`}>
                    {p.month === 'September' ? 'Sept.' : `${String(p.month).slice(0, 3)}.`} Salary {fmt(p.calculated)} {Number(p.amount) > Number(p.calculated) ? '+' : '−'} {fmt(Math.abs(Number(p.amount) - Number(p.calculated)))}{p.note ? ` (${p.note})` : ''}
                  </div>
                )}</td>
                <td>{p.date}{p.method && <div className="text-xs" style={{ color: 'var(--text-muted)' }}>by {p.method}</div>}
                  {p.paidVia && <div className="pair-note">Paid to {db.teachers.find((y) => y.id === p.paidVia)?.name || p.paidVia} (together)</div>}
                  {p.group && !p.paidVia && db.payments.filter((x) => x.group === p.group && x.id !== p.id).map((x) => <div key={x.id} className="pair-note">+ {fmt(x.amount)} BDT for {db.teachers.find((y) => y.id === x.teacherId)?.name || x.teacherId}</div>)}</td>
                <td style={{ textAlign: 'right' }}>
                  <button type="button" className="btn-danger" style={{ padding: '5px 12px' }} onClick={async () => {
                    const together = p.group ? db.payments.filter((x) => x.group === p.group) : [p];
                    const names = together.map((x) => db.teachers.find((y) => y.id === x.teacherId)?.name || x.teacherId).join(' and ');
                    if (!(await confirm({ title: 'Cancel this payment?', message: `${fmt(together.reduce((a, x) => a + Number(x.amount || 0), 0))} BDT for ${p.month} ${p.year}${together.length > 1 ? ` (${names}, paid together)` : ''}, paid on ${p.date}, will be removed from the records.`, confirmText: 'Cancel payment', cancelText: 'Keep', tone: 'danger' }))) return;
                    for (const x of together) await cancelPayment(x.id); // eslint-disable-line no-await-in-loop
                  }}>Cancel</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {editTeacher && <EditTeacherModal teacher={t} onClose={() => setEditTeacher(false)} onDeleted={onClose} />}
      {certificate && <SalaryCertificate teacher={t} {...certificate} onClose={() => setCertificate(null)} />}
      {editStudent && <EditStudentModal student={editStudent} onClose={() => setEditStudent(null)} />}
      {reportsOpen && <Suspense fallback={null}><TeacherReportsModal teacher={t} onClose={() => setReportsOpen(false)} /></Suspense>}
    </PortalModal>
  );
}

export default function SalaryDirectory() {
  const { db } = usePortal();
  const [q, setQ] = useState('');
  const deferredQ = useDeferredValue(q);
  const [category, setCategory] = useState('Residential');
  // v164: the picker is the payment month (opens on this month); the figures are
  // for the month before it — salaries are paid after the month ends
  const mode = useMonthMode();
  const [payMonth, setMonth] = useState(() => defaultPick(mode).month);
  const [payYear, setYear] = useState(() => defaultPick(mode).year);
  const { month, year } = figuresMonth(mode, payMonth, payYear);
  const [openId, setOpenId] = useState(null);
  const [editTeacher, setEditTeacher] = useState(null);
  const toast = useToast();
  // "Names only" hides every amount and bank detail for quick scanning (remembered)
  const [namesOnly, setNamesOnlyState] = useState(() => {
    try {
      return localStorage.getItem('qit:dir-names-only') === '1';
    } catch {
      return false;
    }
  });
  const setNamesOnly = (v) => {
    setNamesOnlyState(v);
    try {
      localStorage.setItem('qit:dir-names-only', v ? '1' : '0');
    } catch {
      /* not remembered */
    }
  };
  const downloadPdf = () => {
    const ok = printSalaryDirectory({ db, month, year, namesOnly, figures: teacherFigures });
    if (!ok) toast('Allow pop-ups for this site to download the PDF.', 'error');
  };

  // Teachers with no panel yet (e.g. signed up through Google) get their own tab
  const NEW_TAB = '__new';
  // v178: the office team's salaries, in their own tab
  const TEAM_TAB = '__team';
  const teamData = useTeam();
  const isNew = (t) => !CATEGORIES.some((c) => c.value === t.category);
  const tabs = useMemo(() => {
    const fresh = db.teachers.filter(isNew).length;
    return [...CATEGORIES, ...(fresh ? [{ value: NEW_TAB, label: 'New sign-ups (no panel yet)' }] : []), { value: TEAM_TAB, label: 'Management Team Salary' }];
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [db.teachers]);
  const counts = useMemo(
    () => Object.fromEntries(tabs.map((c) => [c.value, c.value === TEAM_TAB ? (teamData.team || []).length : db.teachers.filter((t) => (c.value === NEW_TAB ? isNew(t) : t.category === c.value)).length])),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [db.teachers, tabs, teamData.team],
  );
  // The new sign-ups tab disappears once they all have a panel
  useEffect(() => {
    if (category === NEW_TAB && !tabs.some((c) => c.value === NEW_TAB)) setCategory('Residential');
  }, [category, tabs]);

  // v157: every teacher's figures worked out once per change (not on every key press)
  const figs = useMemo(() => Object.fromEntries(db.teachers.map((t) => [t.id, { f: teacherFigures(t, db, month, year), owed: teacherDues(t, db) }])), [db, month, year]);
  // Search within the open category tab: name, ID, department, WhatsApp, account
  const term = deferredQ.trim().toLowerCase();
  const inTab = db.teachers.filter((t) => (category === NEW_TAB ? isNew(t) : t.category === category));
  // v188: typing searches EVERY teacher, whichever tab is open
  const list = term ? db.teachers.filter((t) => matchSearch(`${t.name} ${t.id} ${t.department || ''} ${t.whatsapp} ${t.account} ${t.method} ${t.email || ''}`, term)) : inTab;
  const showList = category !== TEAM_TAB || Boolean(term);

  return (
    <div className="box-card">
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3 border-b-2 pb-3" style={{ borderColor: 'var(--c-box-border)' }}>
        <div className="flex flex-wrap gap-2" role="tablist">
          {tabs.map((c) => (
            <button key={c.value} type="button" role="tab" aria-selected={category === c.value} className={`dir-tab ${category === c.value ? 'active' : ''} ${c.value === NEW_TAB ? 'dir-tab-new' : ''} ${c.value === TEAM_TAB ? 'dir-tab-team' : ''}`} data-tone={c.value === TEAM_TAB ? 'royal' : catTone(c.value)} data-testid={c.value === TEAM_TAB ? 'tab-team' : undefined} onClick={() => setCategory(c.value)}>
              {c.label} <span className="count">{counts[c.value]}</span>
            </button>
          ))}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button type="button" className={`btn-outline-sm inline-flex items-center gap-1.5 ${namesOnly ? 'is-on' : ''}`} aria-pressed={namesOnly} onClick={() => setNamesOnly(!namesOnly)} title="Show only names — hide salaries and bank details">
            {namesOnly ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />} Names only
          </button>
          <button type="button" className="btn-outline-sm inline-flex items-center gap-1.5" onClick={downloadPdf} title={namesOnly ? 'PDF of all teacher names' : `PDF of the full directory for ${month} ${year}`}>
            <Download className="h-3.5 w-3.5" /> Download PDF
          </button>
          {!namesOnly && <PeriodPicker month={payMonth} year={payYear} onMonth={setMonth} onYear={setYear} />}
        </div>
      </div>

      <div className="dir-search mb-5">
        <Search className="dir-search-icon" aria-hidden="true" />
        <input
          type="search"
          className="m-input"
          placeholder="Search every teacher (and the management team) — name, ID, department, phone…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          aria-label="Search all teachers"
        />
        {q && <button type="button" className="dir-search-clear" onClick={() => setQ('')} aria-label="Clear search"><X className="h-4 w-4" /></button>}
        {term && <span className="dir-search-count" data-testid="dir-search-count">{list.length} found in all categories</span>}
      </div>

      {category === TEAM_TAB && <ManagementTeam {...teamData} month={month} year={year} namesOnly={namesOnly} term={term} />}
      {/* v184: overview of the open category, the same as the Management Team's — teachers, salaries and disbursed for the month, total due */}
      {category !== TEAM_TAB && !namesOnly && inTab.length > 0 && (() => {
        const tot = inTab.reduce((a, t) => {
          const x = figs[t.id];
          if (!x) return a;
          const salary = x.f.salary || 0;
          return { salary: a.salary + salary, paid: a.paid + (x.f.paid || 0), due: a.due + (x.owed.total || 0) };
        }, { salary: 0, paid: 0, due: 0 });
        const m3 = month.slice(0, 3);
        return (
          <div className="mb-4 flex flex-wrap items-center gap-3" data-testid="cat-overview">
            <div className="metrics-bar dir-metrics">
              <div className="metric-col m-tuition"><div className="metric-val">{inTab.length}</div><div className="metric-lbl">Teachers</div></div>
              <div className="metric-col m-cut"><div className="metric-val">{fmt(tot.salary)} BDT</div><div className="metric-lbl">Salaries · {m3}</div></div>
              <div className="metric-col m-paid"><div className="metric-val">{fmt(tot.paid)} BDT</div><div className="metric-lbl">Disbursed · {m3}</div></div>
              <div className={`metric-col m-due ${tot.due ? 'is-due' : ''}`}><div className="metric-val">{fmt(tot.due)} BDT</div><div className="metric-lbl">Total due</div></div>
            </div>
          </div>
        );
      })()}
      {showList && list.length === 0 && (category !== TEAM_TAB || !term) && (
        <p className="py-8 text-center" style={{ color: 'var(--text-muted)' }}>
          {term ? `No teacher matches “${q.trim()}”.` : `No faculty listed here.`}
        </p>
      )}
      {showList && namesOnly && list.length > 0 && (
        <ul className="names-grid" aria-label="Teacher names">
          {list.map((t) => (
            <li key={t.id}>
              <button type="button" className="names-row" onClick={() => setOpenId(t.id)}>
                <span className="t-name">{t.name}</span>
                <span className="id-tag">{t.id}</span>
                <DeptTag department={t.department} />
              </button>
            </li>
          ))}
        </ul>
      )}
      {category === TEAM_TAB && term && list.length > 0 && <h3 className="mb-2 mt-4 text-sm font-extrabold uppercase" data-testid="team-tab-teachers">Teachers matching “{q.trim()}”</h3>}
      {showList && !namesOnly && list.map((t) => {
        const { f, owed: ownOwed } = figs[t.id] || { f: teacherFigures(t, db, month, year), owed: teacherDues(t, db) };
        // v168: a husband's total due includes his wife's (paid together)
        const wives = db.teachers.filter((x) => x.payWith === t.id);
        const husband = t.payWith ? db.teachers.find((x) => x.id === t.payWith) : null;
        const wifeOwed = wives.map((w) => teacherDues(w, db));
        const owed = wives.length ? { total: ownOwed.total + wifeOwed.reduce((a, x) => a + x.total, 0), months: [...ownOwed.months, ...wifeOwed.flatMap((x) => x.months)].filter((m, i, all) => all.findIndex((y) => y.month === m.month && y.year === m.year) === i) } : ownOwed;
        return (
          <div
            key={t.id}
            className="teacher-card"
            role="button"
            tabIndex={0}
            onClick={() => setOpenId(t.id)}
            onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), setOpenId(t.id))}
          >
            <div className="teacher-card-top">
              <div className="flex flex-wrap items-center gap-3">
                <span className="t-name">{t.name}</span>
                <span className="id-tag">{t.id}</span>
                <span className={f.isPkg ? 'fixed-tag' : 'per-student-tag'}>{f.isPkg ? 'Fixed Salary' : 'Per-Student'}</span>
                <DeptTag department={t.department} />
                {wives.length > 0 && <span className="pair-chip" data-testid={`pair-${t.id}`}>+ {wives.map((w) => w.name).join(', ')} (paid together)</span>}
                {husband && <span className="pair-chip" data-testid={`pair-${t.id}`}>Paid with {husband.name}</span>}
              </div>
              <div className="card-right">
              <div className="metrics-bar dir-metrics">
                <div className="metric-col m-tuition"><div className="metric-val">{fmt(f.tuition)} BDT</div><div className="metric-lbl">Tuition · {month.slice(0, 3)} ({f.assigned.length} students)</div></div>
                <div className="metric-col m-cut"><div className="metric-val">{fmt(f.salary)} BDT</div><div className="metric-lbl">{f.isPkg ? 'Fixed salary' : 'Faculty cut'} ({f.sharePct}%)</div></div>
                <div className="metric-col m-paid"><div className="metric-val">{fmt(f.paid)} BDT{f.settled && f.paid !== f.salary && <span className="diff-note">{f.paid > f.salary ? '+' : '−'}{fmt(Math.abs(f.paid - f.salary))}</span>}</div><div className="metric-lbl">{f.settled ? <>Disbursed ✓ {month.slice(0, 3)}</> : `Disbursed · ${month.slice(0, 3)}`}</div>{(() => {
                  // v173: the note written when disbursing (bonus, deduction…)
                  const notes = (f.payments || []).map((p) => String(p.note || '').trim()).filter(Boolean);
                  return notes.length ? <div className="metric-note" data-testid={`pay-note-${t.id}`} title={notes.join(' · ')}>{notes.join(' · ')}</div> : null;
                })()}</div>
                <div className={`metric-col m-due ${owed.total ? 'is-due' : ''}`} data-testid={`total-due-${t.id}`}><div className="metric-val">{fmt(owed.total)} BDT</div><div className="metric-lbl">Total due{owed.months.length ? ` · ${owed.months.map((d) => d.month.slice(0, 3)).join(', ')}` : ''}</div></div>
              </div>
              <span className="inline-flex items-center gap-1.5" onClick={(e) => e.stopPropagation()} onKeyDown={(e) => e.stopPropagation()}>
                <Link to={`/admin/teachers/${encodeURIComponent(t.id)}`} className="btn-outline-sm inline-flex items-center gap-1" title={`Open ${t.name}’s Teacher Dashboard`}>
                  <LayoutDashboard className="h-3.5 w-3.5" /> Dashboard
                </Link>
                <EditIconButton label={`Edit ${t.name}`} onClick={() => setEditTeacher(t)} />
              </span>
              </div>
            </div>
            <div className="teacher-strip">
              <span>WhatsApp: <PhoneLinks value={t.whatsapp} />{t.email ? <> • Gmail: <strong>{t.email}</strong></> : null} • {bankLine(t)}</span>
              <span className="inline-flex items-center gap-1.5"><Monitor className="h-3.5 w-3.5" /> Click to open full student list &amp; disburse →</span>
            </div>
          </div>
        );
      })}

      {openId && <TeacherWorkspace teacherId={openId} initialMonth={month} initialYear={year} onClose={() => setOpenId(null)} />}
      {editTeacher && <EditTeacherModal teacher={editTeacher} onClose={() => setEditTeacher(null)} />}
    </div>
  );
}
