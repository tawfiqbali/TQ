import { matchSearch } from '../../../lib/search';
import { Fragment, useCallback, useEffect, useMemo, useRef, useState, useDeferredValue } from 'react';
import { byTeacherOrder, CATEGORIES, teacherCategory, catTone } from '../lib/constants';
import { CalendarCheck, ChevronDown, ChevronRight, Download, History, Pencil, RefreshCw, Search, Sigma, UserX } from 'lucide-react';
import { usePortal } from '../PortalContext';
import Combobox from '../components/Combobox';
import { PortalModal } from './common';
import { profileAttr } from '../components/ProfileOpener';
import { adminAttendanceLog, adminDeleteAttendance, adminUpdateAttendance, attendanceTotals, isoDay, setRecoveryApproval, watchAttendance } from '../../../lib/teacherData';
import { useToast } from '../../../components/ui/Toast';
import { useConfirm } from '../../../components/ui/Confirm';
import '../../staff/staff.css';

const PAGE = 100;
const catOf = teacherCategory;
const CAT_SHORT = { Residential: 'Residential', 'Non-Residential Male': 'Male', 'Non-Residential Female': 'Female' };
const monthNow = () => isoDay().slice(0, 7);
const monthBounds = (ym) => {
  const [y, m] = ym.split('-').map(Number);
  return [isoDay(new Date(y, m - 1, 1)), isoDay(new Date(y, m, 0))];
};
const fmtDay = (d) => new Date(`${d}T12:00:00`).toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
const fmtStamp = (ts) => (ts ? new Date(ts).toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }) : '');
// Teacher ID sign-ins use a hidden address like qit-077@institute.local
const who = (email) => {
  const m = String(email || '').match(/^(.+)@institute\.local$/i);
  return m ? `${m[1].toUpperCase()} (Teacher ID)` : String(email || '');
};

function Tile({ tone, Icon, label, value, note }) {
  return (
    <div className={`dash-tile tone-${tone}`}>
      <div className="dash-tile-head">
        <span className="tone-chip"><Icon className="h-4 w-4" aria-hidden="true" /></span>
        <span className="tile-label">{label}</span>
      </div>
      <div className="tile-value tone-value">{value}</div>
      {note && <div className="text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>{note}</div>}
    </div>
  );
}

const TypeBadge = ({ recovery }) => (
  <span className={`att-type ${recovery ? 'is-recovery' : 'is-regular'}`}>{recovery ? 'Recovery' : 'Regular'}</span>
);
const StatusBadge = ({ status }) => <span className={`st-badge ${status === 'present' ? 'yes' : 'no'}`}>{status === 'present' ? 'Present' : 'Absent'}</span>;

// Executives: correct or delete one entry
function EditEntryModal({ row, studentName, teacherName, onClose, onSaved, onDeleted }) {
  const toast = useToast();
  const confirm = useConfirm();
  const [v, setV] = useState({ day: row.day, status: row.status, is_recovery: row.is_recovery, lesson: row.lesson || '', note: row.note || '' });
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setV((x) => ({ ...x, [k]: e.target.value }));
  const dirty = v.day !== row.day || v.status !== row.status || v.is_recovery !== row.is_recovery || v.lesson.trim() !== (row.lesson || '') || v.note.trim() !== (row.note || '');

  const save = async () => {
    setBusy(true);
    try {
      const saved = await adminUpdateAttendance(row.id, { day: v.day, status: v.status, is_recovery: v.is_recovery, lesson: v.lesson.trim() || null, note: v.note.trim() || null });
      toast('Attendance entry updated.');
      onSaved(saved);
    } catch (e) {
      toast(e.message, 'error');
      setBusy(false);
    }
  };
  const remove = async () => {
    if (!(await confirm({ title: 'Delete this entry?', message: `${studentName} · ${fmtDay(row.day)} · ${row.is_recovery ? 'Recovery' : 'Regular'} class. It is removed from the totals and the teacher's points. This cannot be undone.`, confirmText: 'Delete entry', tone: 'danger' }))) return;
    setBusy(true);
    try {
      await adminDeleteAttendance(row.id);
      toast('Attendance entry deleted.');
      onDeleted(row.id);
    } catch (e) {
      toast(e.message, 'error');
      setBusy(false);
    }
  };

  return (
    <PortalModal onClose={onClose} labelledBy="att-edit-title">
      <div className="mb-1 flex items-center justify-between gap-3">
        <h3 id="att-edit-title" className="text-lg font-extrabold">Edit attendance entry</h3>
        <TypeBadge recovery={row.is_recovery} />
      </div>
      <p className="mb-4 text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>
        {studentName} ({row.student_id}) · {teacherName} ({row.teacher_id})<br />
        Submitted {fmtStamp(row.created_at)}{row.recorded_by ? ` by ${who(row.recorded_by)}` : ''}
        {row.edited_at ? ` · last edited ${fmtStamp(row.edited_at)} by ${who(row.edited_by)}` : ''}
      </p>
      <div className="grid gap-3 sm:grid-cols-3">
        <div className="form-group"><label htmlFor="ae-day">Date</label><input id="ae-day" type="date" className="m-input" value={v.day} onChange={set('day')} /></div>
        <div className="form-group">
          <label>Class type</label>
          <Combobox value={v.is_recovery ? 'recovery' : 'regular'} onChange={(x) => setV((s) => ({ ...s, is_recovery: x === 'recovery' }))} options={[{ value: 'regular', label: 'Regular class' }, { value: 'recovery', label: 'Recovery class' }]} aria-label="Class type" />
        </div>
        <div className="form-group">
          <label>Attendance</label>
          <Combobox value={v.status} onChange={(status) => setV((s) => ({ ...s, status }))} options={[{ value: 'present', label: 'Present' }, { value: 'absent', label: 'Absent' }]} aria-label="Attendance status" />
        </div>
      </div>
      <div className="form-group"><label htmlFor="ae-lesson">Today’s lesson</label><textarea id="ae-lesson" rows={3} maxLength={1000} className="m-input" value={v.lesson} onChange={set('lesson')} /></div>
      <div className="form-group"><label htmlFor="ae-note">{v.is_recovery ? 'Makes up for' : 'Absence reason / note'}</label><input id="ae-note" maxLength={300} className="m-input" value={v.note} onChange={set('note')} /></div>
      <div className="mt-5 flex items-center justify-between">
        <button type="button" className="btn-danger" onClick={remove} disabled={busy}>Delete</button>
        <div className="flex gap-2">
          <button type="button" className="btn-teal" onClick={save} disabled={!dirty || busy}>{busy ? 'Saving…' : 'Save'}</button>
          <button type="button" className="btn-muted" onClick={onClose} disabled={busy}>Cancel</button>
        </div>
      </div>
    </PortalModal>
  );
}

function downloadCsv(rows, nameOf, month) {
  const esc = (x) => `"${String(x ?? '').replace(/"/g, '""')}"`;
  const head = ['Date', 'Type', 'Student ID', 'Student', 'Teacher ID', 'Teacher', 'Status', "Today's lesson", 'Note', 'Submitted', 'Submitted by', 'Edited'];
  const lines = rows.map((r) => [r.day, r.is_recovery ? 'Recovery' : 'Regular', r.student_id, nameOf.student(r.student_id), r.teacher_id, nameOf.teacher(r.teacher_id),
    r.status, r.lesson, r.note, r.created_at, r.recorded_by, r.edited_at ? `${r.edited_at} by ${r.edited_by}` : ''].map(esc).join(','));
  const blob = new Blob([`﻿${[head.map(esc).join(','), ...lines].join('\r\n')}`], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `qit-attendance-${month}.csv`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

/**
 * Executives: every attendance entry of a month, Regular and Recovery classes
 * side by side with the lesson taught. Filters, totals by teacher (classes
 * conducted = regular present + recovery present), CSV export, and Edit /
 * Delete (teachers themselves can never change a submitted entry).
 */
export default function AttendanceLog({ presetTeacher = '' }) {
  const { db } = usePortal();
  const [month, setMonth] = useState(monthNow);
  const [rows, setRows] = useState(null);
  const [error, setError] = useState('');
  const [teacher, setTeacher] = useState(presetTeacher);
  const [cat, setCat] = useState('');
  const [dayF, setDayF] = useState('');
  const [type, setType] = useState('all');
  const [status, setStatus] = useState('all');
  const [q, setQ] = useState('');
  const deferredQ = useDeferredValue(q);
  const [view, setView] = useState('entries');
  const [limit, setLimit] = useState(PAGE);
  const [editing, setEditing] = useState(null);
  const [open, setOpen] = useState({});

  const tName = useMemo(() => Object.fromEntries(db.teachers.map((x) => [x.id, x.name])), [db.teachers]);
  const sName = useMemo(() => Object.fromEntries(db.students.map((x) => [x.id, x.name])), [db.students]);
  const nameOf = useMemo(() => ({ teacher: (id) => tName[id] || id, student: (id) => sName[id] || id }), [tName, sName]);
  const tCat = useMemo(() => Object.fromEntries(db.teachers.map((x) => [x.id, catOf(x)])), [db.teachers]);
  const catOfId = useCallback((id) => tCat[id] || 'Residential', [tCat]);

  const monthRef = useRef(month);
  monthRef.current = month;
  const load = useCallback(async (ym = monthRef.current) => {
    setError('');
    try {
      const [from, to] = monthBounds(ym);
      const data = await adminAttendanceLog(from, to);
      if (ym === monthRef.current) setRows(data);
    } catch (e) {
      setError(e.message);
      setRows([]);
    }
  }, []);
  useEffect(() => {
    setRows(null);
    setLimit(PAGE);
    setDayF('');
    load(month);
  }, [month, load]);

  // Live: a teacher submits, or another Executive edits
  useEffect(() => {
    let stop = () => {};
    let timer;
    watchAttendance(() => {
      clearTimeout(timer);
      timer = setTimeout(() => load(), 700);
    }).then((fn) => (stop = fn)).catch(() => {});
    return () => {
      clearTimeout(timer);
      stop();
    };
  }, [load]);

  const filtered = useMemo(() => {
    const term = deferredQ.trim().toLowerCase();
    return (rows || []).filter((r) => (!teacher || r.teacher_id === teacher)
      && (!cat || catOfId(r.teacher_id) === cat)
      && (!dayF || r.day === dayF)
      && (type === 'all' || (type === 'pending' ? r.approval === 'pending' : (type === 'recovery') === r.is_recovery))
      && (status === 'all' || r.status === status)
      && (!term || matchSearch(`${r.student_id} ${nameOf.student(r.student_id)} ${r.teacher_id} ${nameOf.teacher(r.teacher_id)} ${r.lesson || ''} ${r.note || ''}`, term)));
  }, [rows, teacher, type, status, deferredQ, nameOf, cat, dayF, catOfId]);

  const totals = useMemo(() => attendanceTotals(filtered), [filtered]);
  const toastA = useToast();
  // v156: a recovery class of an earlier month counts after approval
  const approve = async (r, ok) => {
    try {
      await setRecoveryApproval(r.id, ok);
      setRows((list) => list.map((x) => (x.id === r.id ? { ...x, approval: ok ? 'approved' : 'rejected' } : x)));
      toastA(ok ? 'Recovery class approved — it now counts.' : 'Recovery class refused.');
    } catch (e) {
      toastA(e.message, 'error');
    }
  };

  // Totals by teacher, and by student inside each teacher
  const byTeacher = useMemo(() => {
    const m = new Map();
    filtered.forEach((r) => {
      if (!m.has(r.teacher_id)) m.set(r.teacher_id, { id: r.teacher_id, rows: [], students: new Map() });
      const g = m.get(r.teacher_id);
      g.rows.push(r);
      if (!g.students.has(r.student_id)) g.students.set(r.student_id, []);
      g.students.get(r.student_id).push(r);
    });
    return [...m.values()]
      .map((g) => ({ ...g, t: attendanceTotals(g.rows), list: [...g.students.entries()].map(([id, list]) => ({ id, t: attendanceTotals(list) })).sort((a, b) => nameOf.student(a.id).localeCompare(nameOf.student(b.id))) }))
      .sort((a, b) => byTeacherOrder(a.id, b.id));
  }, [filtered, nameOf]);

  const counts = useMemo(() => {
    const base = (rows || []).filter((r) => (!teacher || r.teacher_id === teacher) && (!cat || catOfId(r.teacher_id) === cat) && (!dayF || r.day === dayF));
    return { all: base.length, regular: base.filter((r) => !r.is_recovery).length, recovery: base.filter((r) => r.is_recovery).length, pending: base.filter((r) => r.approval === 'pending').length };
  }, [rows, teacher, cat, dayF, catOfId]);

  const teacherOpts = useMemo(() => [{ value: '', label: cat ? `All ${CAT_SHORT[cat]} teachers` : 'All teachers' }, ...db.teachers.filter((x) => !cat || catOf(x) === cat).sort((a, b) => byTeacherOrder(a.id, b.id)).map((x) => ({ value: x.id, label: `${x.name} (${x.id})` }))], [db.teachers, cat]);
  const [fromDay, toDay] = monthBounds(month);
  const monthLabel = new Date(`${month}-01T12:00:00`).toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });

  return (
    <div className="box-card att-log">
      <div className="card-header-bar">
        <h2 className="card-title">Attendance log</h2>
        <div className="flex flex-wrap items-center gap-2">
          <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={() => downloadCsv(filtered, nameOf, month)} disabled={!filtered.length}>
            <Download className="h-3.5 w-3.5" aria-hidden="true" /> CSV
          </button>
          <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={() => load()}>
            <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" /> Refresh
          </button>
        </div>
      </div>
      <p className="mb-4 text-sm font-semibold" style={{ color: 'var(--text-muted)' }}>
        Every class teachers submitted, with the lesson taught. Teachers can’t change an entry after submitting — correct or delete it here.
        Classes conducted = regular classes present + recovery classes present.
      </p>

      <div className="att-filters">
        <label className="form-group att-f-month"><span className="p-label">Month</span>
          <input type="month" className="m-input" value={month} max={monthNow()} onChange={(e) => e.target.value && setMonth(e.target.value)} />
        </label>
        <label className="form-group att-f-day"><span className="p-label">Date</span>
          <span className="flex items-center gap-1">
            <input type="date" className="m-input" value={dayF} min={fromDay} max={toDay} onChange={(e) => setDayF(e.target.value)} aria-label="Show one date" data-testid="att-day" />
            {dayF && <button type="button" className="btn-outline-sm" onClick={() => setDayF('')} title="Show every day of the month">All days</button>}
          </span>
        </label>
        {!presetTeacher && <div className="form-group att-f-teacher"><span className="p-label">Teacher</span>
          <Combobox value={teacher} onChange={setTeacher} options={teacherOpts} aria-label="Filter by teacher" />
        </div>}
        <div className="form-group att-f-status"><span className="p-label">Attendance</span>
          <Combobox value={status} onChange={setStatus} options={[{ value: 'all', label: 'Present & absent' }, { value: 'present', label: 'Present' }, { value: 'absent', label: 'Absent' }]} aria-label="Filter by attendance" />
        </div>
        <label className="form-group att-f-search"><span className="p-label">Search</span>
          <span className="roster-search"><Search aria-hidden="true" />
            <input type="search" className="m-input" placeholder="Student, teacher or lesson" value={q} onChange={(e) => setQ(e.target.value)} />
          </span>
        </label>
      </div>

      {!presetTeacher && <div className="att-cats mb-3 flex flex-wrap gap-2" role="tablist" aria-label="Teacher category" data-testid="att-cats">
        {[['', 'All teachers'], ...CATEGORIES.map((c) => [c.value, c.label])].map(([k, label]) => (
          <button key={k || 'all'} type="button" role="tab" aria-selected={cat === k} className={`dir-tab ${cat === k ? 'active' : ''}`} data-tone={catTone(k) || 'teal'} onClick={() => { setCat(k); if (k && teacher && catOfId(teacher) !== k) setTeacher(''); }}>
            {label} <span className="count">{k ? db.teachers.filter((x) => catOf(x) === k).length : db.teachers.length}</span>
          </button>
        ))}
      </div>}
      <div className="rv-counts" role="group" aria-label="Class type">
        {[['all', 'All classes'], ['regular', 'Regular'], ['recovery', 'Recovery'], ...(counts.pending ? [['pending', 'Approval required']] : [])].map(([k, label]) => (
          <button key={k} type="button" className="rv-count" aria-pressed={type === k} onClick={() => setType(k)}>{label} · {counts[k]}</button>
        ))}
      </div>

      {(teacher || dayF) && (
        <p className="att-scope mb-3" data-testid="att-scope">
          Showing {teacher ? <strong>{nameOf.teacher(teacher)} ({teacher})</strong> : 'all teachers'}{dayF ? <> on <strong>{fmtDay(dayF)}</strong></> : <> in <strong>{monthLabel}</strong></>}
        </p>
      )}
      <div className="att-tiles mb-5 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
        <Tile tone="teal att-c1" Icon={Sigma} label="Classes conducted" value={totals.conducted} note={`${totals.present} regular + ${totals.recovery} recovery · ${monthLabel}`} />
        <Tile tone="teal att-c2" Icon={CalendarCheck} label="Regular present" value={totals.present} note={totals.rate == null ? 'No regular classes' : `${totals.rate}% attendance`} />
        <Tile tone="slate att-c3" Icon={UserX} label="Regular absent" value={totals.absent} />
        <Tile tone="gold att-c4" Icon={History} label="Recovery classes" value={totals.recovery + totals.recoveryAbsent} note={totals.recoveryAbsent ? `${totals.recoveryAbsent} marked absent` : undefined} />
      </div>

      <div className="mb-3 flex gap-2" role="tablist" aria-label="View">
        {[['entries', 'Entries'], ['totals', 'Totals by teacher']].map(([k, label]) => (
          <button key={k} type="button" role="tab" aria-selected={view === k} className={`btn-outline-sm ${view === k ? 'is-on' : ''}`} onClick={() => setView(k)}>{label}</button>
        ))}
      </div>

      {error && <p className="setup-box mb-4 text-sm font-bold" role="alert">{error}</p>}
      {rows === null ? <p className="rv-empty">Loading…</p> : view === 'entries' ? (
        <>
          <div className="table-wrap">
            <table className="salary-table att-table" style={{ minWidth: 980 }}>
              <thead>
                <tr><th>Date</th><th>Type</th><th>Student</th><th>Teacher</th><th>Status</th><th style={{ width: '32%' }}>Today’s lesson</th><th>Submitted</th><th style={{ textAlign: 'right' }}>Action</th></tr>
              </thead>
              <tbody>
                {!filtered.length && <tr><td colSpan={8} style={{ textAlign: 'center', padding: 18 }}>{rows.length ? 'No entries match these filters.' : `No attendance submitted in ${monthLabel}.`}</td></tr>}
                {filtered.slice(0, limit).map((r, i, arr) => (
                  <Fragment key={r.id}>
                  {(i === 0 || arr[i - 1].day !== r.day) && !dayF && (
                    <tr className="att-day-row"><td colSpan={8}><CalendarCheck className="h-4 w-4" aria-hidden="true" /> {fmtDay(r.day)} <span className="att-day-n">{arr.filter((x) => x.day === r.day).length} entr{arr.filter((x) => x.day === r.day).length === 1 ? 'y' : 'ies'}</span></td></tr>
                  )}
                  <tr className={r.is_recovery ? 'att-row-recovery' : ''} data-type={r.is_recovery ? 'recovery' : 'regular'}>
                    <td className="whitespace-nowrap"><strong>{fmtDay(r.day)}</strong></td>
                    <td><TypeBadge recovery={r.is_recovery} />{r.approval === 'pending' && <span className="st-badge part mt-1 block" data-testid={`appr-${r.id}`}>Approval required</span>}{r.approval === 'rejected' && <span className="st-badge no mt-1 block">Not approved</span>}</td>
                    <td><strong className="p-link" {...profileAttr('student', r.student_id)}>{nameOf.student(r.student_id)}</strong><br /><span className="text-xs" style={{ color: 'var(--text-muted)' }}>{r.student_id}</span></td>
                    <td><span className="p-link" {...profileAttr('teacher', r.teacher_id)}>{nameOf.teacher(r.teacher_id)}</span><br /><span className="text-xs" style={{ color: 'var(--text-muted)' }}>{r.teacher_id}</span></td>
                    <td><StatusBadge status={r.status} /></td>
                    <td>
                      <span className="att-lesson">{r.lesson || <em style={{ color: 'var(--text-muted)' }}>No lesson (entered before lessons were required)</em>}</span>
                      {r.note && <span className="mt-1 block text-xs" style={{ color: 'var(--text-muted)' }}>{r.is_recovery ? 'Makes up for: ' : 'Note: '}{r.note}</span>}
                    </td>
                    <td className="text-xs">
                      {fmtStamp(r.created_at)}
                      {r.edited_at && <span className="mt-1 block font-bold" style={{ color: '#9a6412' }}>Edited {fmtStamp(r.edited_at)}</span>}
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      {r.approval === 'pending' && (
                        <span className="mb-1.5 inline-flex gap-1">
                          <button type="button" className="btn-teal" style={{ padding: '5px 9px' }} onClick={() => approve(r, true)} data-testid={`approve-${r.id}`}>Approve</button>
                          <button type="button" className="btn-muted" style={{ padding: '5px 9px' }} onClick={() => approve(r, false)}>Refuse</button>
                        </span>
                      )}
                      <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={() => setEditing(r)} aria-label={`Edit entry: ${nameOf.student(r.student_id)}, ${r.day}`}>
                        <Pencil className="h-3.5 w-3.5" aria-hidden="true" /> Edit
                      </button>
                    </td>
                  </tr>
                  </Fragment>
                ))}
              </tbody>
            </table>
          </div>
          {filtered.length > limit && (
            <div className="mt-3 text-center">
              <button type="button" className="btn-outline-sm" onClick={() => setLimit((l) => l + PAGE)}>Show more ({filtered.length - limit} left)</button>
            </div>
          )}
        </>
      ) : (
        <div className="table-wrap">
          <table className="salary-table att-table" style={{ minWidth: 760 }}>
            <thead>
              <tr><th>Teacher / student</th><th className="num">Regular present</th><th className="num">Regular absent</th><th className="num">Recovery</th><th className="num">Classes conducted</th><th className="num">Attendance</th></tr>
            </thead>
            <tbody>
              {!byTeacher.length && <tr><td colSpan={6} style={{ textAlign: 'center', padding: 18 }}>No entries for these filters.</td></tr>}
              {byTeacher.map((g) => (
                <Fragment key={g.id}>
                  <tr className="att-total-row">
                    <td>
                      <button type="button" className="inline-flex items-center gap-1.5 font-extrabold" onClick={() => setOpen((o) => ({ ...o, [g.id]: !o[g.id] }))} aria-expanded={Boolean(open[g.id])}>
                        {open[g.id] ? <ChevronDown className="h-4 w-4" aria-hidden="true" /> : <ChevronRight className="h-4 w-4" aria-hidden="true" />}
                        {nameOf.teacher(g.id)} <span className="text-xs font-semibold" style={{ color: 'var(--text-muted)' }}>({g.id} · {g.list.length} students)</span>
                      </button>
                    </td>
                    <td className="num">{g.t.present}</td><td className="num">{g.t.absent}</td><td className="num">{g.t.recovery}</td>
                    <td className="num"><strong>{g.t.conducted}</strong></td><td className="num">{g.t.rate == null ? '—' : `${g.t.rate}%`}</td>
                  </tr>
                  {open[g.id] && g.list.map((s) => (
                    <tr key={`${g.id}-${s.id}`} className="att-sub-row">
                      <td style={{ paddingLeft: 34 }}><span className="p-link" {...profileAttr('student', s.id)}>{nameOf.student(s.id)}</span> <span className="text-xs" style={{ color: 'var(--text-muted)' }}>({s.id})</span></td>
                      <td className="num">{s.t.present}</td><td className="num">{s.t.absent}</td><td className="num">{s.t.recovery}</td>
                      <td className="num"><strong>{s.t.conducted}</strong></td><td className="num">{s.t.rate == null ? '—' : `${s.t.rate}%`}</td>
                    </tr>
                  ))}
                </Fragment>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {editing && (
        <EditEntryModal
          row={editing}
          studentName={nameOf.student(editing.student_id)}
          teacherName={nameOf.teacher(editing.teacher_id)}
          onClose={() => setEditing(null)}
          onSaved={(saved) => {
            setEditing(null);
            setRows((list) => (saved.day.slice(0, 7) === month ? list.map((x) => (x.id === saved.id ? saved : x)) : list.filter((x) => x.id !== saved.id)));
          }}
          onDeleted={(id) => {
            setEditing(null);
            setRows((list) => list.filter((x) => x.id !== id));
          }}
        />
      )}
    </div>
  );
}
