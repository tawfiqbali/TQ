import { useId, useState } from 'react';
import { ChevronDown, StickyNote } from 'lucide-react';

// The explanation of a panel, folded behind a "Notes" button at the right of
// the panel title. Put it as the last child of a .card-header-bar.
export default function PanelNotes({ children, label = 'Notes' }) {
  const [open, setOpen] = useState(false);
  const id = useId();
  return (
    <>
      <button type="button" className={`notes-btn ${open ? 'is-open' : ''}`} aria-expanded={open} aria-controls={id} onClick={() => setOpen((o) => !o)} data-testid="notes-btn">
        <StickyNote className="h-4 w-4" aria-hidden="true" /> {label} <ChevronDown className="notes-chev h-3.5 w-3.5" aria-hidden="true" />
      </button>
      {open && <div id={id} className="notes-body" role="note" data-testid="notes-body">{children}</div>}
    </>
  );
}
