import { matchSearch } from '../../../lib/search';
import { useEffect, useMemo, useRef, useState } from 'react';
import { byTeacherOrder } from '../lib/constants';
import { createPortal } from 'react-dom';
import { AlertTriangle, ArrowRightLeft, Check, Copy, IdCard, Scissors, Search, Users, X } from 'lucide-react';
import { copyText } from '../../../lib/whatsappGroup';
import { waNumber } from '../../../lib/utils';
import { usePortalMaybe } from '../PortalContext';

// The three categories and the letter each one's IDs carry
export const ID_CATEGORIES = [
  { value: 'Residential', letter: 'R', label: 'Residential', sample: 'QIT-R001' },
  { value: 'Non-Residential Male', letter: 'M', label: 'Non-Residential Male', sample: 'QIT-M001' },
  { value: 'Non-Residential Female', letter: 'F', label: 'Non-Residential Female', sample: 'QIT-F001' },
];
export const catOf = (text) => {
  const c = String(text || '');
  if (/female/i.test(c)) return 'Non-Residential Female';
  if (/non.?resid/i.test(c)) return 'Non-Residential Male';
  if (/^\s*resid/i.test(c)) return 'Residential';
  return '';
};
export const isNewStyleId = (id) => /^QIT-[RMF]\d{3,}$/.test(String(id || ''));

/** A small modal shell (Esc / backdrop closes, focus stays inside). */
export function Modal({ title, icon: Icon = IdCard, onClose, busy, children, wide, testid }) {
  const box = useRef(null);
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'Escape' && !busy) {
        e.preventDefault();
        onClose();
      }
    };
    document.addEventListener('keydown', onKey, true);
    box.current?.querySelector('input, button')?.focus();
    return () => document.removeEventListener('keydown', onKey, true);
  }, [onClose, busy]);
  return createPortal(
    <div className="fixed inset-0 z-[80] flex items-end justify-center p-3 sm:items-center" role="presentation">
      <div className="qit-fade-in absolute inset-0 bg-pine-950/55 backdrop-blur-[2px]" onClick={() => !busy && onClose()} aria-hidden="true" />
      <div ref={box} role="dialog" aria-modal="true" aria-label={title} data-testid={testid}
        className={`qit-portal qit-pop-in relative max-h-[92vh] w-full overflow-y-auto rounded-2xl border border-gray-200 bg-white p-5 text-gray-900 shadow-2xl sm:p-6 ${wide ? 'max-w-3xl' : 'max-w-lg'}`}>
        <div className="mb-4 flex items-start justify-between gap-3">
          <h2 className="flex items-center gap-2 text-lg font-bold text-[#034751]"><Icon className="h-5 w-5" aria-hidden="true" /> {title}</h2>
          <button type="button" onClick={onClose} disabled={busy} className="rounded-lg p-1 text-gray-500 hover:bg-gray-100" aria-label="Close"><X className="h-5 w-5" /></button>
        </div>
        {children}
      </div>
    </div>,
    document.body,
  );
}

/** Residential / Non-Residential Male / Female, each with the ID it will get. */
export function CategoryPicker({ value, onChange, nextIds = {}, disabledValue }) {
  return (
    <div className="grid gap-2 sm:grid-cols-3" role="radiogroup" aria-label="Category">
      {ID_CATEGORIES.map((c) => {
        const on = value === c.value;
        const off = disabledValue === c.value;
        return (
          <button key={c.value} type="button" role="radio" aria-checked={on} disabled={off} onClick={() => onChange(c.value)}
            data-testid={`cat-${c.letter}`}
            className={`rounded-xl border-2 p-3 text-left transition ${on ? 'border-[#034751] bg-[#e8f2f2]' : 'border-gray-200 hover:border-[#005359]'} ${off ? 'opacity-40' : ''}`}>
            <div className="text-sm font-extrabold text-[#034751]">{c.label}</div>
            <div className="mt-1 font-mono text-xs font-bold text-gray-600">{nextIds[c.letter] || c.sample.replace('001', '…')}</div>
          </button>
        );
      })}
    </div>
  );
}

// Same child? Names compared without case, dots or extra spaces; phone
// numbers by their last 10 digits (a record can hold several numbers)
const normName = (n) => String(n || '').toLowerCase().replace(/[.,()_\-]/g, ' ').replace(/\s+/g, ' ').trim();
const phoneKeys = (p) => String(p || '')
  .split(/\s*(?:,|\/|;|\||\s+or\s+)\s*/i)
  .map((x) => x.replace(/[০-৯]/g, (d) => '০১২৩৪৫৬৭৮৯'.indexOf(d)).replace(/\D/g, '').slice(-10))
  .filter((k) => k.length >= 7);
/**
 * Students already with the target teacher that look like the same child:
 *   kind 'name'  - same name (and no different number) → replaced by default
 *   kind 'phone' - same number, different name → often a brother or sister,
 *                  so NOT replaced unless you tick it
 */
export function findSameStudents(incoming, targetStudents) {
  const out = [];
  const inName = normName(incoming.name);
  const inPh = phoneKeys(incoming.phone);
  targetStudents.forEach((t) => {
    const tPh = phoneKeys(t.phone);
    const shared = inPh.some((k) => tPh.includes(k));
    const phonesOk = !inPh.length || !tPh.length || shared;
    if (inName && normName(t.name) === inName && phonesOk) out.push({ student: t, kind: 'name' });
    else if (shared) out.push({ student: t, kind: 'phone' });
  });
  return out;
}

/**
 * Pick students from other teachers and choose Copy or Cut.
 *   Cut  = the student moves to this teacher (weekly class times move too)
 *   Copy = a copy of the student is made for this teacher (new Student ID),
 *          the original stays with their teacher
 */
export function StudentPicker({ students, teachers, excludeTeacherId, selected, onSelected, mode, onMode, onReplace }) {
  const [q, setQ] = useState('');
  // Same child already with the target teacher: replace it with the incoming one?
  const [ticks, setTicks] = useState({});
  const matches = useMemo(() => {
    if (!excludeTeacherId) return [];
    const target = students.filter((s) => s.teacherId === excludeTeacherId && !selected.has(s.id));
    return [...selected].flatMap((id) => {
      const inc = students.find((s) => s.id === id);
      return inc ? findSameStudents(inc, target).map((m) => ({ ...m, incoming: inc, key: `${inc.id}|${m.student.id}` })) : [];
    });
  }, [students, excludeTeacherId, selected]);
  const isOn = (m) => ticks[m.key] ?? m.kind === 'name';
  useEffect(() => {
    const map = {};
    matches.forEach((m) => {
      if (isOn(m)) (map[m.incoming.id] ||= []).push(m.student.id);
    });
    onReplace?.(map);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [matches, ticks]);
  const name = useMemo(() => Object.fromEntries(teachers.map((t) => [t.id, t.name])), [teachers]);
  const groups = useMemo(() => {
    const term = q.trim().toLowerCase();
    const list = students.filter((s) => s.teacherId !== excludeTeacherId && (!term
      || matchSearch(`${s.name} ${s.id} ${s.teacherId} ${name[s.teacherId] || ''}`, term)));
    const by = {};
    list.forEach((s) => { (by[s.teacherId || '—'] ||= []).push(s); });
    return Object.entries(by).sort(([a], [b]) => byTeacherOrder(a, b));
  }, [students, excludeTeacherId, q, name]);
  const toggle = (id) => {
    const next = new Set(selected);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    onSelected(next);
  };
  return (
    <div data-testid="student-picker">
      <div className="mb-3 grid gap-2 sm:grid-cols-2" role="radiogroup" aria-label="Copy or cut">
        {[
          { v: 'cut', Icon: Scissors, t: 'Cut (move)', d: 'The student moves here. Their class times move too; past attendance and reports stay with the old teacher.' },
          { v: 'copy', Icon: Copy, t: 'Copy', d: 'A copy is made for this teacher with a new Student ID. The student also stays with the old teacher.' },
        ].map(({ v, Icon, t, d }) => (
          <button key={v} type="button" role="radio" aria-checked={mode === v} onClick={() => onMode(v)} data-testid={`mode-${v}`}
            className={`rounded-xl border-2 p-3 text-left ${mode === v ? 'border-[#034751] bg-[#e8f2f2]' : 'border-gray-200 hover:border-[#005359]'}`}>
            <div className="flex items-center gap-1.5 text-sm font-extrabold text-[#034751]"><Icon className="h-4 w-4" /> {t}</div>
            <div className="mt-1 text-xs text-gray-600">{d}</div>
          </button>
        ))}
      </div>
      <label className="relative mb-2 block">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 opacity-50" />
        <input className="m-input" style={{ paddingLeft: 34 }} placeholder="Search student, Student ID or teacher" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search students" />
      </label>
      <div className="max-h-64 overflow-y-auto rounded-xl border border-gray-200">
        {!groups.length && <p className="p-4 text-center text-sm text-gray-500">No students match.</p>}
        {groups.map(([tid, list]) => (
          <div key={tid}>
            <div className="sticky top-0 bg-gray-50 px-3 py-1.5 text-xs font-extrabold text-gray-600">{name[tid] || 'No teacher'} <span className="font-mono">{tid}</span></div>
            {list.map((s) => (
              <label key={s.id} className="flex cursor-pointer items-center gap-3 border-t border-gray-100 px-3 py-2 text-sm hover:bg-[#f4f9f9]">
                <input type="checkbox" checked={selected.has(s.id)} onChange={() => toggle(s.id)} data-testid={`pick-${s.id}`} />
                <span className="min-w-0 flex-1"><strong>{s.name}</strong> <span className="font-mono text-xs text-gray-500">{s.id}</span></span>
                {s.course && <span className="hidden text-xs text-gray-500 sm:inline">{s.course}</span>}
              </label>
            ))}
          </div>
        ))}
      </div>
      <p className="mt-2 text-xs font-semibold text-gray-600">{selected.size ? `${selected.size} selected — they will be ${mode === 'cut' ? 'moved' : 'copied'}.` : 'Optional: pick students to add now.'}</p>
      {matches.length > 0 && (
        <div className="mt-3 rounded-xl border border-amber-200 bg-amber-50 p-3" data-testid="same-students">
          <p className="mb-2 flex items-center gap-1.5 text-sm font-extrabold text-amber-900"><AlertTriangle className="h-4 w-4" /> Already with this teacher</p>
          <p className="mb-2 text-xs text-amber-900">Ticked records are replaced by the incoming student (their class times, attendance and reports move to it). Same number but a different name is often a brother or sister — tick only if it is the same child.</p>
          {matches.map((m) => (
            <label key={m.key} className="flex cursor-pointer items-start gap-2 border-t border-amber-200 py-1.5 text-sm" data-testid={`same-${m.incoming.id}-${m.student.id}`}>
              <input type="checkbox" className="mt-1" checked={isOn(m)} onChange={(e) => setTicks((t) => ({ ...t, [m.key]: e.target.checked }))} />
              <span>
                Replace <strong>{m.student.name}</strong> <span className="font-mono text-xs">{m.student.id}</span> with <strong>{m.incoming.name}</strong> <span className="font-mono text-xs">{m.incoming.id}</span>
                <span className={`ml-1.5 inline-flex items-center gap-1 rounded-full px-1.5 text-[11px] font-bold ${m.kind === 'name' ? 'bg-[#e8f2f2] text-[#034751]' : 'bg-white text-amber-800'}`}>
                  {m.kind === 'name' ? 'same name' : <><Users className="h-3 w-3" /> same number — sibling?</>}
                </span>
              </span>
            </label>
          ))}
        </div>
      )}
    </div>
  );
}

/** The new Teacher ID + password, with a ready message to send the teacher. */
export function IdCardResult({ teacherId, password, name, email, oldId, whatsapp, passwordChanged = false }) {
  const [done, setDone] = useState(false);
  // v165: "Send on WhatsApp" opens the chat with this teacher (their WhatsApp from the Teachers List)
  const portal = usePortalMaybe();
  const phone = waNumber(whatsapp) || waNumber(portal?.db?.teachers?.find((t) => t.id === teacherId || (oldId && t.id === oldId))?.whatsapp);
  const site = `${window.location.origin}/teacher`;
  const msg = [
    `Assalamu alaikum${name ? ` ${name}` : ''},`,
    '',
    oldId ? `Your QIT Teacher ID has changed from ${oldId} to ${teacherId}.` : passwordChanged ? 'Your QIT Teacher Dashboard password has changed.' : 'Your QIT Teacher Dashboard account is ready.',
    `Teacher ID: ${teacherId}`,
    password ? `Password: ${password}` : 'Password: the same as before',
    '',
    `Sign in at ${site} with Continue with Google${email ? ` (${email})` : ''}. The first time, Google is enough; after that, enter this Teacher ID and password too. Please keep your password private.`,
  ].join('\n');
  return (
    <div className="rounded-2xl border-2 border-[#034751] bg-[#e8f2f2] p-4" data-testid="id-result">
      <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
        <div><div className="text-xs font-bold text-gray-600">Teacher ID</div><div className="font-mono text-2xl font-extrabold text-[#034751]" data-testid="result-id">{teacherId}</div></div>
        <div><div className="text-xs font-bold text-gray-600">Password</div><div className="font-mono text-2xl font-extrabold text-[#034751]" data-testid="result-pw">{password || 'unchanged'}</div></div>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={async () => { await copyText(msg); setDone(true); setTimeout(() => setDone(false), 1800); }}>
          {done ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />} {done ? 'Copied' : 'Copy message'}
        </button>
        <a className="btn-outline-sm inline-flex items-center gap-1" href={`https://wa.me/${phone}?text=${encodeURIComponent(msg)}`} target="_blank" rel="noreferrer" data-testid="result-wa" title={phone ? `Open the WhatsApp chat with +${phone}` : 'No WhatsApp number saved for this teacher — choose the chat in WhatsApp'}><ArrowRightLeft className="h-3.5 w-3.5" /> {phone ? 'Send on WhatsApp' : 'Send on WhatsApp (choose chat)'}</a>
      </div>
      <p className="mt-2 text-xs text-gray-600">The password is also shown on the teacher’s dashboard until someone changes it.</p>
    </div>
  );
}
