import { useEffect, useState } from 'react';
import { usePortal } from '../PortalContext';
import { EditStudentModal, EditTeacherModal } from '../panels/common';
import { TeacherWorkspace } from '../panels/SalaryDirectory';
import { previousMonthOf } from '../lib/constants';

/**
 * v154: tap a student's or teacher's name anywhere in the portal to open
 * their profile. Any element with data-profile="student:QIT-S001" or
 * data-profile="teacher:QIT-R001" works, in every panel.
 */
export const profileAttr = (kind, id) => (id ? { 'data-profile': `${kind}:${id}`, role: 'link', tabIndex: 0, title: 'Open profile' } : {});

export default function ProfileOpener() {
  const { db, status, isSuper } = usePortal();
  const [open, setOpen] = useState(null);
  useEffect(() => {
    const pick = (e) => {
      const el = e.target.closest?.('[data-profile]');
      if (!el) return;
      // a button or field INSIDE the name keeps its own action; a name inside a button (e.g. a teacher row) opens the profile
      const inner = e.target.closest('button:not([data-profile]), a:not([data-profile]), input, select, textarea');
      if (inner && el.contains(inner)) return;
      if (e.type === 'keydown' && e.key !== 'Enter') return;
      const [kind, id] = el.dataset.profile.split(':');
      e.preventDefault();
      e.stopPropagation();
      setOpen({ kind, id });
    };
    document.addEventListener('click', pick, true);
    document.addEventListener('keydown', pick, true);
    return () => { document.removeEventListener('click', pick, true); document.removeEventListener('keydown', pick, true); };
  }, []);
  if (!open || status !== 'ready') return null;
  const close = () => setOpen(null);
  if (open.kind === 'student') {
    const s = db.students.find((x) => x.id === open.id);
    return s ? <EditStudentModal key={s.id} student={s} onClose={close} details /> : null;
  }
  const t = db.teachers.find((x) => x.id === open.id);
  if (!t) return null;
  // Executives: the full teacher profile, as in the Salary Directory (students, salary, dues, history)
  if (isSuper) { const p = previousMonthOf(); return <TeacherWorkspace key={t.id} teacherId={t.id} initialMonth={p.month} initialYear={String(p.year)} onClose={close} />; }
  return <EditTeacherModal teacher={t} onClose={close} onDeleted={close} />;
}
