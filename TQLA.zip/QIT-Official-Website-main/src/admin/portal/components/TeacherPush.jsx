import { useEffect, useMemo, useState } from 'react';
import { BellRing, Search, Send, X } from 'lucide-react';
import { PortalModal } from '../panels/common';
import { usePortalMaybe } from '../PortalContext';
import { byTeacherOrder, teacherCategory } from '../lib/constants';
import { messageTeachers, pushOverview } from '../../../lib/teacherData';
import { matchSearch } from '../../../lib/search';
import { useToast } from '../../../components/ui/Toast';

/**
 * v179: send a notification to teachers. It shows in their dashboard
 * (bell) and on every phone where they turned notifications on.
 * `audience`: 'teachers' | 'residential' | 'online' | 'staff' (from Notice Maker)
 */
const GROUPS = [
  { key: 'all', label: 'All teachers' },
  { key: 'Residential', label: 'Residential' },
  { key: 'Non-Residential Male', label: 'Non-Res. Male' },
  { key: 'Non-Residential Female', label: 'Non-Res. Female' },
  { key: 'online', label: 'All Non-Residential' },
  { key: 'pick', label: 'Choose teachers' },
];
const fromAudience = (a) => (a === 'residential' ? 'Residential' : a === 'online' ? 'online' : 'all');

export default function TeacherPush({ onClose, title: t0 = '', body: b0 = '', audience }) {
  const portal = usePortalMaybe();
  const toast = useToast();
  const teachers = useMemo(() => [...(portal?.db?.teachers || [])].filter((t) => t.status !== 'Inactive').sort(byTeacherOrder), [portal?.db?.teachers]);
  const [group, setGroup] = useState(fromAudience(audience));
  const [picked, setPicked] = useState(() => new Set());
  const [q, setQ] = useState('');
  const [title, setTitle] = useState(t0);
  const [body, setBody] = useState(b0);
  const [busy, setBusy] = useState(false);
  const [phones, setPhones] = useState(null);

  useEffect(() => {
    pushOverview().then((rows) => setPhones(new Map((rows || []).map((r) => [r.teacher_id, r.devices])))).catch(() => setPhones(new Map()));
  }, []);

  const ids = useMemo(() => {
    if (group === 'all') return null;
    if (group === 'pick') return [...picked];
    if (group === 'online') return teachers.filter((t) => teacherCategory(t) !== 'Residential').map((t) => t.id);
    return teachers.filter((t) => teacherCategory(t) === group).map((t) => t.id);
  }, [group, picked, teachers]);
  const count = ids ? ids.length : teachers.length;
  const onPhone = phones ? (ids || teachers.map((t) => t.id)).filter((id) => phones.get(id)).length : null;
  const shown = teachers.filter((t) => !q.trim() || matchSearch(`${t.name} ${t.id}`, q));

  const send = async () => {
    if (title.trim().length < 2) { toast('Write a title.', 'error'); return; }
    if (ids && !ids.length) { toast('Choose at least one teacher.', 'error'); return; }
    setBusy(true);
    try {
      const n = await messageTeachers(ids, title.trim(), body.trim());
      toast(`Sent to ${n} teacher${n === 1 ? '' : 's'}.`);
      onClose();
    } catch (e) {
      toast(e.message || 'Could not send. Please try again.', 'error');
    } finally {
      setBusy(false);
    }
  };

  return (
    <PortalModal onClose={onClose} labelledBy="tp-title">
      <div className="mb-4 flex items-start justify-between gap-3">
        <h2 id="tp-title" className="card-title inline-flex items-center gap-2"><BellRing className="h-5 w-5" /> Notify teachers</h2>
        <button type="button" className="btn-icon-edit" onClick={onClose} aria-label="Close"><X className="h-4 w-4" /></button>
      </div>
      <p className="mb-3 text-sm" style={{ color: 'var(--text-muted)' }}>
        Shows in each teacher’s dashboard (the bell) and as a notification on every phone where they turned notifications on.
      </p>
      <div className="mb-3 flex flex-wrap gap-2" role="radiogroup" aria-label="Send to">
        {GROUPS.map((g) => (
          <button key={g.key} type="button" role="radio" aria-checked={group === g.key} className={group === g.key ? 'btn-teal' : 'btn-outline-sm'} onClick={() => setGroup(g.key)} data-testid={`tp-group-${g.key}`}>
            {g.label}
          </button>
        ))}
      </div>
      {group === 'pick' && (
        <div className="mb-3 rounded-lg border p-2" style={{ borderColor: 'var(--c-box-border)' }}>
          <label className="relative block">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 opacity-50" aria-hidden="true" />
            <input className="m-input" style={{ paddingLeft: 32 }} value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search a teacher" />
          </label>
          <ul className="mt-2 max-h-52 overflow-y-auto">
            {shown.map((t) => (
              <li key={t.id}>
                <label className="flex cursor-pointer items-center gap-2 rounded px-1 py-1 text-sm hover:bg-black/5">
                  <input type="checkbox" checked={picked.has(t.id)} onChange={() => setPicked((s) => { const n = new Set(s); n.has(t.id) ? n.delete(t.id) : n.add(t.id); return n; })} data-testid={`tp-pick-${t.id}`} />
                  <span className="font-semibold">{t.name}</span> <span className="text-xs opacity-70">{t.id}</span>
                  {phones?.get(t.id) ? <span className="ml-auto text-[11px] font-bold text-emerald-700">📱 on</span> : null}
                </label>
              </li>
            ))}
          </ul>
        </div>
      )}
      <div className="form-group">
        <label htmlFor="tp-t">Title <span className="text-red-700">*</span></label>
        <input id="tp-t" className="m-input" maxLength={140} value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. মিটিং on Friday at 8 PM" data-testid="tp-title-input" />
      </div>
      <div className="form-group">
        <label htmlFor="tp-b">Message</label>
        <textarea id="tp-b" className="m-input" rows={6} value={body} onChange={(e) => setBody(e.target.value)} placeholder="Write the notice. The phone shows the first lines; the full text is in the dashboard." data-testid="tp-body" />
      </div>
      <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
        <p className="text-xs font-semibold" style={{ color: 'var(--text-muted)' }} data-testid="tp-count">
          {count} teacher{count === 1 ? '' : 's'}{onPhone != null ? ` · ${onPhone} with phone notifications on` : ''}
        </p>
        <button type="button" className="btn-teal" onClick={send} disabled={busy} data-testid="tp-send">
          <Send className="h-4 w-4" /> {busy ? 'Sending…' : 'Send'}
        </button>
      </div>
    </PortalModal>
  );
}
