import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Eye, EyeOff, KeyRound } from 'lucide-react';

/**
 * Executives: a teacher's Teacher ID sign-in.
 *   onSave(null)      → password back to the automatic one (R 1010…, M 2020…, F 3030…)
 *   onSave('xxxx')    → a password the office chooses
 *   onDisable()       → sign-in switched off (e.g. the teacher left)
 * All return promises; the teacher is signed out on every device.
 */
export default function PasswordDialog({ teacher, login, onSave, onDisable, onClose }) {
  const auto = login?.autoPassword || '';
  const isDefault = Boolean(login?.defaultPassword);
  const [pw, setPw] = useState('');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const box = useRef(null);
  const input = useRef(null);

  useEffect(() => {
    input.current?.focus();
    const onKey = (e) => {
      if (e.key === 'Escape' && !busy) {
        e.preventDefault();
        e.stopPropagation();
        onClose();
      }
      if (e.key === 'Tab' && box.current) {
        const items = [...box.current.querySelectorAll('input, button:not([disabled])')];
        const first = items[0];
        const last = items[items.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener('keydown', onKey, true);
    return () => document.removeEventListener('keydown', onKey, true);
  }, [onClose, busy]);

  const save = async (value, disable = false) => {
    if (!disable && value !== null && (value.trim().length < 4 || value.trim().length > 64)) return setError('Use 4 to 64 characters.');
    setBusy(true);
    setError('');
    try {
      if (disable) await onDisable();
      else await onSave(value === null ? null : value.trim());
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  return createPortal(
    <div className="fixed inset-0 z-[80] flex items-end justify-center p-4 sm:items-center" role="presentation">
      <div className="qit-fade-in absolute inset-0 bg-pine-950/55 backdrop-blur-[2px]" onClick={() => !busy && onClose()} aria-hidden="true" />
      <form
        ref={box}
        role="dialog"
        aria-modal="true"
        aria-labelledby="pw-title"
        onSubmit={(e) => {
          e.preventDefault();
          save(pw);
        }}
        className="qit-pop-in relative w-full max-w-md rounded-2xl border border-gray-200 bg-white p-6 text-gray-900 shadow-2xl"
      >
        <div className="flex gap-4">
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-teal-50 text-[#034751]"><KeyRound className="h-5 w-5" aria-hidden="true" /></span>
          <div className="min-w-0">
            <h2 id="pw-title" className="text-lg font-bold leading-snug text-[#034751]">Teacher ID sign-in</h2>
            <p className="mt-1 text-sm text-gray-700">
              {teacher.name} <span className="id-tag">{teacher.id}</span>
            </p>
            <p className="mt-1 text-sm text-gray-700" data-testid="pw-state">
              {!login?.active
                ? <>Sign-in is <strong>off</strong>. Resetting or setting a password here switches it back on.</>
                : isDefault
                  ? <>Password: <strong>{auto}</strong> (the automatic starting password).</>
                  : <>Password: <strong data-testid="pw-current">{login.currentPassword || 'set by the office'}</strong>{login.changedBy ? ` (set by ${login.changedBy})` : ''}.</>}
            </p>
          </div>
        </div>
        <label htmlFor="pw-new" className="mt-5 block text-sm font-bold">Choose a password (optional)</label>
        <div className="relative mt-1">
          <input
            ref={input}
            id="pw-new"
            type={show ? 'text' : 'password'}
            autoComplete="new-password"
            className="m-input pr-11"
            value={pw}
            onChange={(e) => {
              setPw(e.target.value);
              setError('');
            }}
            aria-invalid={Boolean(error) || undefined}
            aria-describedby="pw-hint"
          />
          <button type="button" onClick={() => setShow((v) => !v)} aria-label={show ? 'Hide password' : 'Show password'} aria-pressed={show} className="absolute inset-y-0 right-0 flex w-11 items-center justify-center text-[#005359]">
            {show ? <EyeOff className="h-4 w-4" aria-hidden="true" /> : <Eye className="h-4 w-4" aria-hidden="true" />}
          </button>
        </div>
        <p id="pw-hint" className="mt-1 text-xs text-gray-600">4 to 64 characters. The teacher's old password opens the dashboard one last time; then they see the new one there (always shown on their dashboard).</p>
        {error && <p role="alert" className="mt-2 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-800">{error}</p>}
        <div className="mt-6 grid gap-2 sm:grid-cols-2">
          <button type="button" disabled={busy} onClick={() => save(null)} className="rounded-xl border border-gray-300 px-4 py-2.5 text-sm font-semibold text-[#034751] transition hover:bg-teal-50 disabled:opacity-50">
            Reset to {auto}
          </button>
          <button type="submit" disabled={busy || !pw.trim()} className="rounded-xl bg-[#034751] px-4 py-2.5 text-sm font-semibold text-white shadow transition hover:bg-[#005359] disabled:opacity-50">
            {busy ? 'Saving…' : 'Save my password'}
          </button>
        </div>
        <div className="mt-3 flex flex-col-reverse gap-2 border-t border-gray-200 pt-3 sm:flex-row sm:justify-between">
          <button type="button" disabled={busy} onClick={onClose} className="rounded-xl border border-gray-300 px-4 py-2.5 text-sm font-semibold transition hover:bg-gray-50">Close</button>
          {login?.active && (
            <button type="button" disabled={busy} onClick={() => save(null, true)} className="rounded-xl border border-red-200 px-4 py-2.5 text-sm font-semibold text-red-700 transition hover:bg-red-50 disabled:opacity-50">
              Switch sign-in off
            </button>
          )}
        </div>
      </form>
    </div>,
    document.body,
  );
}
