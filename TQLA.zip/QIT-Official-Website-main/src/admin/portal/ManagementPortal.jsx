import { matchSearch } from '../../lib/search';
import { lazy, Suspense, useEffect, useMemo, useState, useTransition } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { BookUser, CalendarCheck, Menu, Search, ClipboardCheck, DatabaseZap, FileText, LayoutDashboard, LayoutGrid, LifeBuoy, HeartHandshake, Lock, LockKeyhole, Megaphone, PenLine, RefreshCw, SlidersHorizontal, ShieldCheck, Trophy, UserPlus, Users, Wallet, ContactRound } from 'lucide-react';
import { PANELS, PortalProvider, usePortal } from './PortalContext';
import { SQL_VERSION } from '../../version';
// Charts (Chart.js) load only when a Super Admin opens the Dashboard tab
const Dashboard = lazy(() => import('./panels/Dashboard'));
import SalaryDirectory from './panels/SalaryDirectory';
import StudentRoster from './panels/StudentRoster';
import ProgressReports from './panels/ProgressReports';
import EnrollTeachers from './panels/EnrollTeachers';
import TeacherList from './panels/TeacherList';
import EnrollStudents from './panels/EnrollStudents';
// Text editor for reports and certificates, loaded when opened
const PortalContents = lazy(() => import('./panels/PortalContents'));
import ReportsReview from '../staff/ReportsReview';
import TeacherTracker from '../staff/TeacherTracker';
import TeamRoles from './panels/TeamRoles';
const Counseling = lazy(() => import('./panels/Counseling'));
import TeacherSupport from './panels/TeacherSupport';
import ImportData from './panels/ImportData';
// Loaded when opened
const TeacherDashboards = lazy(() => import('./panels/TeacherDashboards'));
const PointsSettings = lazy(() => import('./panels/PointsSettings'));
const DashboardEditor = lazy(() => import('./panels/DashboardEditor'));
const NoticeMaker = lazy(() => import('./panels/NoticeMaker'));
const AttendanceLog = lazy(() => import('./panels/AttendanceLog'));
const Security = lazy(() => import('./panels/Security'));
import { SETUP_MISSING } from '../../lib/teacherData';
import { createPortal } from 'react-dom';
import ProfileOpener from './components/ProfileOpener';
import './portal.css';

const ICONS = {
  dashboard: LayoutGrid, salary: Wallet, students: Users, reports: FileText, enrollTeacher: UserPlus, teacherList: ContactRound, enrollStudent: BookUser, contents: PenLine,
  teacherReports: ClipboardCheck, support: LifeBuoy, counseling: HeartHandshake, team: ShieldCheck, import: DatabaseZap, teacherDash: LayoutDashboard, points: Trophy, attendance: CalendarCheck, dashEditor: SlidersHorizontal, notices: Megaphone, security: LockKeyhole,
};

// The menu, grouped so each kind of work has its own coloured box
const NAV_GROUPS = [
  // Three colours only (main, accent, neutral), alternating so neighbours differ; they follow the theme
  { key: 'overview', label: 'Overview', Icon: LayoutGrid, color: 'var(--qit-teal)', tint: 'var(--qit-teal-tint)', line: 'var(--qit-teal-line)', keys: ['dashboard', 'counseling'] },
  { key: 'people', label: 'People & salaries', juniorLabel: 'Students & teachers', Icon: Users, color: 'var(--qit-gold)', tint: 'var(--qit-gold-tint)', line: 'var(--qit-gold-line)', keys: ['salary', 'students', 'teacherList', 'enrollTeacher', 'enrollStudent'] },
  // v154: "Reports" became "Attendance"; Progress Reports and Teacher Reports live on the
  // Teachers & Reports page in the left menu
  { key: 'attendanceG', label: 'Attendance & Notices', Icon: CalendarCheck, color: 'var(--qit-teal)', tint: 'var(--qit-teal-tint)', line: 'var(--qit-teal-line)', keys: ['attendance', 'notices'] },
  { key: 'teachers', label: 'Teacher tools', Icon: LayoutDashboard, color: 'var(--qit-gold)', tint: 'var(--qit-gold-tint)', line: 'var(--qit-gold-line)', keys: ['teacherDash', 'dashEditor', 'points', 'support'] },
  { key: 'settings', label: 'Settings & data', Icon: SlidersHorizontal, color: 'var(--qit-slate)', tint: 'var(--qit-slate-tint)', line: 'var(--qit-slate-line)', keys: ['security', 'contents', 'team', 'import'] },
];
// Phones: the sections kept one tap away in the bottom bar
const DOCK_KEYS = { super: ['dashboard', 'students', 'salary', 'attendance'], junior: ['students', 'teacherList', 'enrollStudent'] };
const DOCK_LABEL = { dashboard: 'Home', students: 'Students', salary: 'Salary', reports: 'Reports', teacherList: 'Teachers', attendance: 'Attendance', enrollStudent: 'Enroll' };

// Shown when the Supabase tables have not been created yet
function SetupNeeded({ onRetry }) {
  return (
    <div className="box-card">
      <div className="setup-box">
        <h2 className="mb-2 text-lg font-extrabold">One-time setup needed</h2>
        <ol className="list-decimal space-y-1 pl-5 text-sm font-semibold">
          <li>Open <strong>supabase.com</strong> → your QIT project → <strong>SQL Editor</strong> → <strong>New query</strong>.</li>
          <li>Paste everything from <code>supabase/teacher-dashboard.sql</code> (in the website files) and press <strong>Run</strong>.</li>
          <li>Come back here and press <strong>Try again</strong>, then use <strong>Import Data</strong> to bring in your teachers and students.</li>
        </ol>
        <button type="button" className="btn-teal mt-4" onClick={onRetry}>Try again</button>
      </div>
    </div>
  );
}

// Executives: teachers' submitted reports + the submission tracker
function TeacherReportsPanel({ onUse }) {
  const [view, setView] = useState('reports');
  return (
    <>
      <div className="rv-counts" role="group" aria-label="View">
        <button type="button" className="rv-count" aria-pressed={view === 'reports'} onClick={() => setView('reports')}>Submitted reports</button>
        <button type="button" className="rv-count" aria-pressed={view === 'tracker'} onClick={() => setView('tracker')}>Who has submitted (teacher list)</button>
      </div>
      {view === 'reports' ? <ReportsReview onUse={onUse} /> : <TeacherTracker />}
    </>
  );
}

function UnlockForm() {
  const { unlock, adminEmail } = usePortal();
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await unlock(password);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="box-card mx-auto max-w-md text-center">
      <div className="logo-badge mx-auto mb-4">QIT</div>
      <h2 className="text-xl font-extrabold">Unlock the Management Portal</h2>
      <p className="mt-1 text-sm" style={{ color: 'var(--text-muted)' }}>
        Signed in as <strong>{adminEmail}</strong>. Enter your admin password to connect to the portal records.
      </p>
      <form onSubmit={submit} className="mt-5 space-y-3 text-left">
        <label className="p-label" htmlFor="portal-pw">Password</label>
        <input id="portal-pw" type="password" className="m-input" value={password} onChange={(e) => setPassword(e.target.value)} autoFocus required />
        {error && <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-800" role="alert">{error}</p>}
        <button className="btn-teal w-full justify-center" disabled={busy || !password}>
          <Lock className="h-4 w-4" /> {busy ? 'Connecting…' : 'Unlock system'}
        </button>
      </form>
    </div>
  );
}

function PortalShell() {
  const { status, error, load, isSuper, canOpen, mode, db } = usePortal();
  // Warn when supabase/teacher-dashboard.sql was not run for this version
  const [sqlOld, setSqlOld] = useState(false);
  useEffect(() => {
    if (status !== 'ready' || mode !== 'supabase') return;
    import('../../lib/teacherData').then(({ sqlVersion }) => sqlVersion()).then((n) => setSqlOld(n < SQL_VERSION)).catch(() => {});
  }, [status, mode]);
  const [params, setParams] = useSearchParams();
  const [tab, setTabState] = useState(() => params.get('tab') || '');
  // sel: the menu highlights at once; the panel follows without a loading flash
  const [sel, setSel] = useState(tab);
  const [waiting, startTransition] = useTransition();
  const focusInquiry = params.get('inquiry') || '';
  // The tab is kept in the address (?tab=support), so links and Back work
  const [menuOpen, setMenuOpen] = useState(false); // phones: the menu folds away
  const setTab = (next) => {
    setSel(next);
    // The panel's code is fetched first (instant once cached), so the old panel
    // stays on screen instead of a loading box
    const show = () => startTransition(() => setTabState(next));
    const fetchPanel = PANEL_CODE[next];
    if (fetchPanel) fetchPanel().then(show, show);
    else show();
    setMenuOpen(false);
    setParams(next ? { tab: next } : {}, { replace: true });
  };
  // A notification link while the portal is already open switches the tab
  useEffect(() => {
    const wanted = params.get('tab');
    if (wanted && wanted !== tab) {
      setSel(wanted);
      setTabState(wanted);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params]);
  // Fetch the other panels in the background, so opening one never waits
  useEffect(() => {
    if (status !== 'ready') return undefined;
    const load = () => {
      import('./panels/Dashboard');
      import('./panels/PortalContents');
      import('./panels/TeacherDashboards');
      import('./panels/PointsSettings');
      import('./panels/DashboardEditor');
      import('./panels/NoticeMaker');
      import('./panels/AttendanceLog');
      import('./panels/Security');
    };
    const id = window.requestIdleCallback ? window.requestIdleCallback(load, { timeout: 3000 }) : setTimeout(load, 1500);
    return () => (window.cancelIdleCallback ? window.cancelIdleCallback(id) : clearTimeout(id));
  }, [status]);
  const [incoming, setIncoming] = useState(() => {
    // sent here from the Teachers & Monthly Reports page
    try {
      const saved = sessionStorage.getItem('qit:incoming-report');
      sessionStorage.removeItem('qit:incoming-report');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  }); // a teacher report sent to the Progress Report engine

  // v154: Progress Reports / Teacher Reports moved to the Teachers & Reports page
  const navigate = useNavigate();
  useEffect(() => {
    if (tab !== 'reports' && tab !== 'teacherReports') return;
    try { if (incoming) sessionStorage.setItem('qit:incoming-report', JSON.stringify(incoming)); } catch { /* the page still opens */ }
    navigate(`/admin/review?tab=${tab === 'reports' ? 'progress' : 'reports'}`, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);
  useEffect(() => {
    if (status !== 'ready' || (tab && canOpen(tab))) return;
    // A fresh cloud database starts on Import Data
    if (mode === 'supabase' && isSuper && !db.teachers.length) setTab('import');
    else setTab(isSuper ? 'dashboard' : 'students');
  }, [status, tab, canOpen, isSuper, mode, db.teachers.length]);

  const visible = PANELS.filter((p) => canOpen(p.key));

  const [find, setFind] = useState('');
  const term = find.trim().toLowerCase();
  const found = term ? visible.filter((p) => p.label.toLowerCase().includes(term)) : visible;
  // v188: the same box also finds people — any teacher or student, whichever section is open
  const people = useMemo(() => {
    if (term.length < 2 || status !== 'ready') return [];
    const t = db.teachers.filter((x) => matchSearch(`${x.name} ${x.id} ${x.whatsapp || ''} ${x.email || ''}`, term)).slice(0, 6).map((x) => ({ kind: 'teacher', id: x.id, name: x.name, sub: x.category || 'Teacher' }));
    const st = db.students.filter((x) => matchSearch(`${x.name} ${x.id} ${x.phone || ''}`, term)).slice(0, 8).map((x) => ({ kind: 'student', id: x.id, name: x.name, sub: `${x.status || 'Active'} · ${db.teachers.find((y) => y.id === x.teacherId)?.name || 'no teacher'}` }));
    return [...t, ...st];
  }, [term, db.teachers, db.students, status]);
  const dock = DOCK_KEYS[isSuper ? 'super' : 'junior'].map((k) => visible.find((p) => p.key === k)).filter(Boolean);
  // v157: unread / waiting counts on the sections (from the admin alerts)
  const [alertCounts, setAlertCounts] = useState(() => (typeof window !== 'undefined' && window.__qitAlerts) || {});
  useEffect(() => {
    const on = () => setAlertCounts({ ...(window.__qitAlerts || {}) });
    window.addEventListener('qit-alerts', on);
    return () => window.removeEventListener('qit-alerts', on);
  }, []);
  const navGroups = (inSheet) => NAV_GROUPS.map((g) => {
    const items = visible.filter((p) => g.keys.includes(p.key) && (inSheet || !term || p.label.toLowerCase().includes(term)));
    if (!items.length) return null;
    const GIcon = g.Icon;
    return (
      <div key={g.key} role="group" aria-label={g.label} className="nav-group" style={{ '--g': g.color, '--g-tint': g.tint, '--g-line': g.line }}>
        <div className="nav-group-title"><span className="nav-group-ico"><GIcon className="h-4 w-4" aria-hidden="true" /></span><span className="nav-group-name">{!isSuper && g.juniorLabel ? g.juniorLabel : g.label}</span></div>
        <div className="nav-group-items">
          {items.map((p) => {
            const Icon = ICONS[p.key] || LayoutGrid;
            const on = sel === p.key;
            return (
              <button key={p.key} type="button" className={`nav-btn ${on ? 'active' : ''}`} onClick={() => { setTab(p.key); setMenuOpen(false); setFind(''); }} aria-current={on ? 'page' : undefined}>
                <span className="nav-ico"><Icon className="h-4 w-4" aria-hidden="true" /></span>
                <span>{p.label}</span>
                {alertCounts[p.key] > 0 && <span className="nav-badge" data-testid={`nav-badge-${p.key}`}>{alertCounts[p.key]}</span>}
              </button>
            );
          })}
        </div>
      </div>
    );
  });

  return (
    <div className="qit-portal">
      <header className="p-header">
        <div className="flex items-center gap-4">
          <div className="logo-badge">QIT</div>
          <div>
            <h1 className="text-xl font-extrabold sm:text-2xl" style={{ color: 'var(--c-teal-dark)' }}>
              Quran International Institute
            </h1>
            <p className="text-sm" style={{ color: 'var(--text-muted)' }}>Unified Management System &amp; Financial Portal</p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {status === 'ready' && (
            <span className="id-tag" style={{ background: isSuper ? 'var(--qit-teal)' : 'var(--qit-gold)' }}>
              {isSuper ? 'Super Admin / Executive' : 'Junior Admin'}
            </span>
          )}
          <span className="id-tag" style={{ background: mode === 'demo' ? '#64748B' : 'var(--c-teal-dark)' }} title={{ supabase: 'Saved in the cloud database (Supabase)', live: 'Connected to Google Sheets', demo: 'Demo data saved in this browser only' }[mode]}>
            {{ supabase: 'Cloud database', live: 'Google Sheets', demo: 'Demo mode' }[mode]}
          </span>
          <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={load}>
            <RefreshCw className="h-3.5 w-3.5" /> Refresh
          </button>
        </div>
      </header>

      {status === 'locked' && <UnlockForm />}
      {status === 'loading' && <div className="box-card text-center">Loading portal records…</div>}
      {status === 'error' && error === SETUP_MISSING && <SetupNeeded onRetry={load} />}
      {status === 'error' && error !== SETUP_MISSING && (
        <div className="box-card text-center">
          <p className="font-bold text-red-700">{error || 'Could not reach the portal server.'}</p>
          <button className="btn-teal mt-4" onClick={load}>Try again</button>
        </div>
      )}

      {status === 'ready' && sqlOld && (
        <div role="alert" className="box-card" style={{ borderLeft: '6px solid #b42318', background: '#fef3f2', color: '#7a271a', marginBottom: 16 }} data-testid="sql-old">
          <strong>The database needs an update, so some changes will not save.</strong>
          <p className="mt-1 text-sm">Open Supabase → SQL Editor, paste everything from <strong>teacher-dashboard-SQL-copy-all.txt</strong> (version {SQL_VERSION}) and press Run. If Supabase shows a red error, send that message to your developer. Then refresh this page.</p>
        </div>
      )}
      {status === 'ready' && (
        <>
          {/* Phones (Executive): one button showing the current section; it opens the full list */}
          {isSuper && (
            <button type="button" className="nav-toggle" aria-expanded={menuOpen} onClick={() => setMenuOpen((o) => !o)} data-testid="nav-toggle">
              <span className="nav-toggle-label">Section</span>
              <span className="nav-toggle-current">{visible.find((p) => p.key === tab)?.label || 'Choose a section'}</span>
              <LayoutGrid className="h-5 w-5" aria-hidden="true" />
            </button>
          )}
          {/* Desktop: every section in one tidy index, one coloured row per kind of work */}
          <nav id="portal-menu" className="main-nav nav-grouped nav-index" aria-label="Management portal">
            <div className="nav-find">
              <Search className="h-4 w-4" aria-hidden="true" />
              <input type="search" value={find} onChange={(e) => setFind(e.target.value)} placeholder="Find a section…" aria-label="Find a section"
                onKeyDown={(e) => { if (e.key === 'Enter' && found.length) { setTab(found[0].key); setFind(''); } }} data-testid="nav-find" />
              {find && <span className="nav-find-count">{found.length} section{found.length === 1 ? '' : 's'}{people.length ? ` · ${people.length} ${people.length === 1 ? 'person' : 'people'}` : ''}{found.length ? ' · Enter opens the first' : ''}</span>}
            </div>
            {people.length > 0 && (
              <div className="nav-people" data-testid="nav-people">
                {people.map((x) => (
                  <button key={`${x.kind}:${x.id}`} type="button" className={`nav-person is-${x.kind}`} data-profile={`${x.kind}:${x.id}`}>
                    <span className="nav-person-kind">{x.kind === 'teacher' ? 'Teacher' : 'Student'}</span>
                    <strong>{x.name}</strong> <span className="id-tag">{x.id}</span>
                    <span className="nav-person-sub">{x.sub}</span>
                  </button>
                ))}
              </div>
            )}
            {navGroups(false)}
          </nav>
          {/* Phones: a bottom bar with the main sections; More opens the full list */}
          {createPortal(
            <div className={`qit-portal qit-mdock-layer ${isSuper ? 'is-exec' : ''}`} data-sfx={isSuper ? 'exec' : 'junior'}>
              {menuOpen && (
                <div className="mdock-sheet-wrap" onClick={() => setMenuOpen(false)}>
                  <div className="mdock-sheet nav-grouped nav-index" role="dialog" aria-label="All sections" onClick={(e) => e.stopPropagation()} data-testid="mdock-sheet">
                    <div className="mdock-grip" aria-hidden="true" />
                    {navGroups(true)}
                  </div>
                </div>
              )}
              {!isSuper && (
              <nav className="mdock" aria-label="Main sections" data-testid="mdock">
                {dock.map((p) => {
                  const Icon = ICONS[p.key] || LayoutGrid;
                  const on = sel === p.key && !menuOpen;
                  return (
                    <button key={p.key} type="button" className={`mdock-btn ${on ? 'active' : ''}`} aria-current={on ? 'page' : undefined} onClick={() => { setMenuOpen(false); setTab(p.key); }} data-testid={`mdock-${p.key}`}>
                      <Icon className="h-5 w-5" aria-hidden="true" /><span>{DOCK_LABEL[p.key] || p.label}</span>
                    </button>
                  );
                })}
                <button type="button" className={`mdock-btn ${menuOpen || !dock.some((p) => p.key === sel) ? 'active' : ''}`} aria-expanded={menuOpen} onClick={() => setMenuOpen((o) => !o)} data-testid="mdock-more">
                  <Menu className="h-5 w-5" aria-hidden="true" /><span>More</span>
                </button>
              </nav>
              )}
            </div>,
            document.body,
          )}
          <Suspense fallback={<div className="qit-panel-skeleton" data-testid="panel-fallback" aria-busy="true" />}>
          <div key={tab} className={`qit-panel-in ${waiting ? 'qit-panel-wait' : ''}`} data-testid="portal-panel">
          {tab === 'dashboard' && canOpen('dashboard') && (
            <>
              <Dashboard />
            </>
          )}
          {tab === 'salary' && canOpen('salary') && <SalaryDirectory />}
          {tab === 'students' && <StudentRoster onEnroll={() => setTab('enrollStudent')} />}
          {tab === 'reports' && <ProgressReports incoming={incoming} onIncomingDone={() => setIncoming(null)} />}
          {tab === 'teacherReports' && canOpen('teacherReports') && (
            <TeacherReportsPanel onUse={(r) => { setIncoming(r); setTab('reports'); }} />
          )}
          {tab === 'support' && canOpen('support') && <TeacherSupport focusId={focusInquiry} />}
          {tab === 'team' && canOpen('team') && <TeamRoles />}
          {tab === 'counseling' && canOpen('counseling') && <Counseling />}
          {tab === 'import' && canOpen('import') && <ImportData />}
          {(tab === 'teacherDash' || tab === 'points' || tab === 'attendance' || tab === 'dashEditor' || tab === 'notices' || tab === 'security') && (
            <>
              {tab === 'attendance' && canOpen('attendance') && <AttendanceLog />}
              {tab === 'teacherDash' && canOpen('teacherDash') && <TeacherDashboards />}
              {tab === 'points' && canOpen('points') && <PointsSettings />}
              {tab === 'dashEditor' && canOpen('dashEditor') && <DashboardEditor />}
              {tab === 'notices' && canOpen('notices') && <NoticeMaker />}
              {tab === 'security' && canOpen('security') && <Security />}
            </>
          )}
          {tab === 'teacherList' && canOpen('teacherList') && <TeacherList />}
          {tab === 'enrollTeacher' && <EnrollTeachers />}
          {tab === 'enrollStudent' && <EnrollStudents />}
          {tab === 'contents' && canOpen('contents') && (
            <>
              <PortalContents />
            </>
          )}
          </div>
          </Suspense>
        </>
      )}
    </div>
  );
}

// Bangla text uses Noto Sans Bengali from /fonts (see src/index.css), so no
// extra web font is loaded here.
function useBanglaFont() {
  useEffect(() => {
    // Start downloading the Bangla font as soon as the portal opens (reports are Bangla)
    if (document.getElementById('aikya-admin-font')) return;
    const link = document.createElement('link');
    link.id = 'aikya-admin-font';
    link.rel = 'preload';
    link.as = 'font';
    link.type = 'font/woff2';
    link.crossOrigin = 'anonymous';
    link.href = '/fonts/Aikya.woff2';
    document.head.appendChild(link);
  }, []);
}

const PANEL_CODE = {
  dashboard: () => import('./panels/Dashboard'),
  contents: () => import('./panels/PortalContents'),
  teacherDash: () => import('./panels/TeacherDashboards'),
  points: () => import('./panels/PointsSettings'),
  dashEditor: () => import('./panels/DashboardEditor'),
  notices: () => import('./panels/NoticeMaker'),
  attendance: () => import('./panels/AttendanceLog'),
  security: () => import('./panels/Security'),
};

export default function ManagementPortal() {
  useBanglaFont();
  return (
    <PortalProvider>
      <PortalShell />
      <ProfileOpener />
    </PortalProvider>
  );
}
