import { useEffect, useState, Suspense } from 'react';
import SoundToggle from '../components/ui/SoundToggle';
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { BookOpen, Briefcase, ClipboardCheck, Cloud, ExternalLink, HardDrive, Inbox, Languages, LayoutDashboard, LogOut, Menu, SquarePen, Users, X, Globe2, Send } from 'lucide-react';
import useAdminRole from '../hooks/useAdminRole';
import { SITE_VERSION } from '../version';
import { portalLogout } from './portal/lib/api';
import { useSiteData } from '../context/SiteDataContext';
import { BRAND_NAME } from '../data/defaultContent';
import { signOut } from '../lib/auth';
import LogoMark from '../components/shared/LogoMark';
import InquiryNotifier from './InquiryNotifier';
import ThemePicker from './ThemePicker';
import ScrollTools from '../components/ui/ScrollTools';
import { watchAdminTables } from './tableLabels';
import { AlertsInvite, AlertsToggle, useStaffAlerts } from './StaffAlerts';
import AiAssistant from './AiAssistant';
import { applyAdminTheme, clearAdminTheme, getAdminTheme } from './themes';
import { isSupabaseEnabled } from '../lib/supabaseClient';

export default function AdminLayout() {
  const { content, inquiries, storageMode, refreshInquiries } = useSiteData();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const newCount = inquiries.filter((i) => i.status === 'new').length;

  const { email, isSuper } = useAdminRole();
  useEffect(() => {
    if (isSuper) refreshInquiries().catch(() => {}); // juniors never see inquiries
  }, [refreshInquiries, isSuper]);
  useEffect(() => setOpen(false), [pathname]);
  useEffect(() => {
    document.title = `Admin | ${content.site.brand.name}`;
  }, [pathname, content.site.brand.name]);

  const alerts = useStaffAlerts({ exec: isSuper, inquiries });
  const portalBadge = isSuper ? alerts.counts.support + alerts.counts.approvals + alerts.counts.deletes : 0;
  const allNav = [
    { to: '/admin/portal', label: 'Management Portal', Icon: Briefcase, group: 'manage', badge: portalBadge },
    { to: '/admin/review', label: 'Teachers & Reports', Icon: ClipboardCheck, group: 'manage', badge: alerts.counts.reports },
    { to: '/admin', label: 'Website dashboard', Icon: LayoutDashboard, end: true, superOnly: true, group: 'site' },
    { to: '/admin/courses', label: 'Courses', Icon: BookOpen, superOnly: true, group: 'site' },
    { to: '/admin/pricing', label: 'Pricing & currency', Icon: Globe2, superOnly: true, group: 'site' },
    { to: '/admin/content', label: 'Site content', Icon: SquarePen, superOnly: true, group: 'site' },
    { to: '/admin/bangla', label: 'Bangla text', Icon: Languages, superOnly: true, group: 'site' },
    { to: '/admin/people', label: 'Board, teachers & reviews', Icon: Users, superOnly: true, group: 'site' },
    { to: '/admin/inquiries', label: 'Inquiries', Icon: Inbox, badge: newCount, superOnly: true, group: 'messages' },
    { to: '/admin/assign', label: 'Assignment message', Icon: Send, superOnly: true, group: 'messages' },
  ];
  const nav = allNav.filter((n) => !n.superOnly || isSuper);
  // v163: phones — a dot on "More" while reports, requests or messages are waiting
  const waiting = nav.some((n) => n.badge > 0);
  const NAV_GROUPS = [
    // Messages & leads sits above Website, so Inquiries and its new-count are always in view
    { key: 'manage', label: 'Management' },
    { key: 'messages', label: 'Messages & leads' },
    { key: 'site', label: 'Website' },
  ];

  const handleSignOut = async () => {
    await portalLogout();
    await signOut();
    navigate('/admin/login', { replace: true });
  };

  const sidebar = (
    <div className="flex h-full flex-col">
      <Link to="/admin/portal" className="flex items-center gap-3 py-4 pl-5 pr-14">
        <LogoMark variant="white" className="h-10 w-8" />
        <span className="min-w-0 font-display leading-tight text-white">
          {BRAND_NAME}
          <span className="block text-xs text-pine-100/60">{isSuper ? 'Super Admin' : email ? 'Junior Admin' : 'Admin panel'}</span>
        </span>
      </Link>
      <nav className="side-nav min-h-0 flex-1 space-y-2.5 overflow-y-auto px-3 pb-4 pt-1" aria-label="Admin">
        {NAV_GROUPS.map((g) => {
          const items = nav.filter((n) => n.group === g.key);
          if (!items.length) return null;
          return (
            <div key={g.key} role="group" aria-labelledby={`sg-${g.key}`} className="side-group">
              <p id={`sg-${g.key}`} className="side-group-title">{g.label}</p>
              {items.map(({ to, label, Icon, end, badge }) => (
                <NavLink key={to} to={to} end={end} className={({ isActive }) => `side-link ${isActive ? 'active' : ''}`}>
                  <span className="side-ico"><Icon className="h-4 w-4" aria-hidden="true" /></span>
                  <span className="flex-1">{label}</span>
                  {badge > 0 && (
                    <span className="rounded-full bg-gold-300 px-2 py-0.5 text-xs font-semibold text-pine-950" aria-label={`${badge} new`}>
                      {badge}
                    </span>
                  )}
                </NavLink>
              ))}
            </div>
          );
        })}
      </nav>
      {/* Compact footer, so the menu above (Inquiries and its "new" count) is never hidden behind it */}
      <div className="side-foot border-t border-pine-100/10 px-3 pb-3 pt-3" data-testid="side-foot">
        {/* One row of small buttons, so the footer never covers the menu */}
        <div className="side-foot-grid">
          <a href="/" target="_blank" rel="noreferrer" className="side-foot-btn" title="Open the website"><ExternalLink className="h-4 w-4" aria-hidden="true" /><span>Website</span></a>
          {isSuper && <ThemePicker up className="side-foot-btn" label={<span>Theme</span>} />}
          <AiAssistant className="side-foot-btn" label={<span>AI</span>} />
          <SoundToggle className="side-foot-btn" />
          <AlertsToggle className="side-foot-btn" />
          <button type="button" onClick={(e) => { e.currentTarget.classList.add('is-leaving'); handleSignOut(); }} onPointerDown={(e) => e.currentTarget.classList.add('is-pressing')} onPointerUp={(e) => e.currentTarget.classList.remove('is-pressing')} onPointerLeave={(e) => e.currentTarget.classList.remove('is-pressing')} className="side-foot-btn side-signout" title="Sign out" data-testid="admin-signout"><LogOut className="h-4 w-4" aria-hidden="true" /><span>Sign out</span></button>
        </div>
        <p className="mt-1 flex items-center justify-center gap-1.5 text-[10.5px] text-pine-100/50">
          {storageMode === 'supabase' ? <Cloud className="h-3 w-3" /> : <HardDrive className="h-3 w-3" />}
          {storageMode === 'supabase' ? 'Live, synced to the cloud' : 'Cloud not connected yet'} · v{SITE_VERSION}
        </p>
      </div>
    </div>
  );

  // Executives choose a colour theme; it applies while the admin panel is open
  useEffect(() => {
    if (!isSuper) return undefined;
    applyAdminTheme(getAdminTheme());
    return clearAdminTheme;
  }, [isSuper]);
  // Bangla text in the admin uses Noto Sans Bengali / Noto Serif Bengali (see src/index.css)
  useEffect(() => watchAdminTables(), []);
  useEffect(() => {
    document.documentElement.classList.add('admin-ui');
    return () => document.documentElement.classList.remove('admin-ui');
  }, []);

  return (
    <div className="min-h-screen bg-paper lg:grid lg:grid-cols-[16rem_1fr]" data-sfx={isSuper ? 'exec' : 'junior'}>
      <aside className="dot-grid sticky top-0 hidden h-screen bg-pine-950 lg:block">{sidebar}</aside>

      <div className="admin-topbar sticky top-0 z-40 flex items-center justify-between border-b border-pine-900/10 bg-white/95 px-4 py-3 backdrop-blur lg:hidden">
        <Link to="/admin/portal" className="flex items-center gap-2 font-display text-pine-900">
          <LogoMark className="h-8 w-8" />
          Admin
        </Link>
        <button className="icon-btn" onClick={() => setOpen(true)} aria-label="Open admin menu">
          <Menu className="h-5 w-5" />
        </button>
      </div>
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-pine-950/60" onClick={() => setOpen(false)} aria-hidden="true" />
          <aside className="dot-grid relative h-full w-72 bg-pine-950">
            <button className="absolute right-3 top-4 rounded-full p-2 text-pine-100/80 hover:text-white" onClick={() => setOpen(false)} aria-label="Close admin menu">
              <X className="h-5 w-5" />
            </button>
            {sidebar}
          </aside>
        </div>
      )}

      <main className="min-w-0 px-4 pb-28 pt-6 sm:px-8 lg:px-10 lg:py-10">
        <div className="mx-auto max-w-6xl">
          {/* The sidebar stays while a page loads; each page fades in softly */}
          <Suspense fallback={<div className="qit-panel-skeleton" aria-busy="true" />}>
            <div key={pathname} className="qit-panel-in">
              <Outlet />
            </div>
          </Suspense>
        </div>
      </main>
      {/* Phones: the main admin pages one tap away; everything else is under More */}
      {isSuper && (
        <nav className="admin-mdock lg:hidden" aria-label="Main admin pages" data-testid="admin-mdock">
          {[['/admin/portal', 'Portal', Briefcase], ['/admin/assign', 'Assign', Send], ['/admin/inquiries', 'Inquiries', Inbox], ['/admin/review', 'Teachers', ClipboardCheck]].map(([to, label, Icon]) => (
            <NavLink key={to} to={to} end={to === '/admin'} className={({ isActive }) => `admin-mdock-btn ${isActive ? 'active' : ''}`}>
              <span className="relative"><Icon className="h-5 w-5" aria-hidden="true" />{(() => { const n = nav.find((x) => x.to === to)?.badge || 0; return n > 0 ? <i className="admin-mdock-badge">{n}</i> : null; })()}</span>
              <span>{label}</span>
            </NavLink>
          ))}
          <button type="button" className={`admin-mdock-btn ${open ? 'active' : ''}`} onClick={() => setOpen(true)} aria-label={waiting ? 'Open the full admin menu — new reports or messages' : 'Open the full admin menu'} data-testid="mdock-more"><span className="relative"><Menu className="h-5 w-5" aria-hidden="true" />{waiting && <i className="admin-mdock-dot" data-testid="mdock-dot" aria-hidden="true" />}</span><span>More</span></button>
        </nav>
      )}
      <ScrollTools className={isSuper ? 'above-dock' : 'above-dock'} />
      {/* Teacher support / leave requests stay on screen until handled */}
      {isSuper && isSupabaseEnabled && <InquiryNotifier />}
      {/* v188: phones are invited to turn office notifications on */}
      {isSupabaseEnabled && <AlertsInvite />}
    </div>
  );
}
