import { memo, useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BellRing, CalendarOff, ChevronDown, ChevronUp, CircleDollarSign, LifeBuoy, MessageCircleQuestion, TriangleAlert, X } from 'lucide-react';
import { dismissInquiry, listPendingInquiries, watchInquiries } from '../lib/teacherData';
import { useToast } from '../components/ui/Toast';

const ICONS = { leave: CalendarOff, issue: TriangleAlert, salary: CircleDollarSign, general: MessageCircleQuestion, other: LifeBuoy };
const LABEL = { leave: 'Leave request', issue: 'Problem', salary: 'Salary', general: 'Question', other: 'Other' };

const ago = (iso) => {
  const mins = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins} min ago`;
  const h = Math.round(mins / 60);
  if (h < 24) return `${h} h ago`;
  return `${Math.round(h / 24)} d ago`;
};

/**
 * Floating reminder in the admin panel for teacher support / leave requests.
 * It updates live (Supabase Realtime, with a 60-second fallback) and stays
 * until each request is resolved in Teacher Support or dismissed here.
 */
function InquiryNotifier() {
  const navigate = useNavigate();
  const toast = useToast();
  const [items, setItems] = useState([]);
  const [open, setOpen] = useState(true);

  const load = useCallback(async () => {
    try {
      const list = await listPendingInquiries();
      setItems((prev) => {
        const fresh = (list || []).filter((x) => !prev.some((p) => p.id === x.id));
        if (prev.length && fresh.length) setOpen(true); // a new request re-opens the panel
        return list || [];
      });
    } catch {
      /* tables not set up yet, or offline: stay quiet */
    }
  }, []);

  useEffect(() => {
    load();
    let stop = () => {};
    watchInquiries(load).then((fn) => (stop = fn)).catch(() => {});
    const timer = setInterval(load, 60_000);
    return () => {
      stop();
      clearInterval(timer);
    };
  }, [load]);

  const dismiss = async (item) => {
    setItems((list) => list.filter((x) => x.id !== item.id));
    try {
      await dismissInquiry(item.id);
    } catch (e) {
      toast(e.message, 'error');
      load();
    }
  };

  const openItem = (item) => navigate(`/admin/portal?tab=support&inquiry=${item.id}`);

  if (!items.length) return null;

  return (
    <aside
      className="qit-pop-in fixed bottom-4 left-4 z-[70] w-[min(22rem,calc(100vw-2rem))] overflow-hidden rounded-2xl border border-gold-300/70 bg-white text-pine-950 shadow-2xl dark:bg-[#12302e] dark:text-pine-50"
      aria-label="Teacher requests waiting"
      role="region"
    >
      <button type="button" onClick={() => setOpen((o) => !o)} className="flex w-full items-center gap-2.5 bg-gold-100 px-4 py-3 text-left dark:bg-gold-700/30" aria-expanded={open}>
        <span className="relative flex h-8 w-8 items-center justify-center rounded-full bg-gold-400 text-pine-950">
          <BellRing className="h-4 w-4" aria-hidden="true" />
          <span className="absolute -right-1 -top-1 min-w-[1.25rem] rounded-full bg-red-600 px-1 text-center text-[11px] font-bold leading-5 text-white">{items.length}</span>
        </span>
        <span className="flex-1 text-sm font-bold">
          {items.length === 1 ? '1 teacher request waiting' : `${items.length} teacher requests waiting`}
        </span>
        {open ? <ChevronDown className="h-4 w-4" aria-hidden="true" /> : <ChevronUp className="h-4 w-4" aria-hidden="true" />}
      </button>
      {open && (
        <ul className="max-h-[50vh] divide-y divide-pine-950/10 overflow-y-auto dark:divide-white/10">
          {items.map((item) => {
            const Icon = ICONS[item.category] || LifeBuoy;
            return (
              <li key={item.id} className="flex gap-3 px-4 py-3">
                <Icon className="mt-0.5 h-4 w-4 shrink-0 text-gold-700 dark:text-gold-300" aria-hidden="true" />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold">{item.subject}</p>
                  <p className="truncate text-xs opacity-70">
                    {LABEL[item.category] || 'Request'} · {item.teacher_name || item.teacher_id} · {ago(item.created_at)}
                    {item.status === 'in_progress' ? ' · in progress' : ''}
                  </p>
                  <div className="mt-2 flex gap-2">
                    <button type="button" onClick={() => openItem(item)} className="rounded-lg bg-pine-800 px-3 py-1 text-xs font-semibold text-white hover:bg-pine-900">
                      Open
                    </button>
                    <button type="button" onClick={() => dismiss(item)} className="rounded-lg border border-pine-950/15 px-3 py-1 text-xs font-semibold hover:bg-pine-50 dark:border-white/20 dark:hover:bg-white/10">
                      Dismiss
                    </button>
                  </div>
                </div>
                <button type="button" onClick={() => dismiss(item)} className="self-start rounded p-1 opacity-50 hover:opacity-100" aria-label={`Dismiss ${item.subject}`}>
                  <X className="h-3.5 w-3.5" />
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </aside>
  );
}

export default memo(InquiryNotifier);
