// v160: admin tables never scroll sideways. On narrow screens every table row
// becomes a box with its fields stacked; each cell shows its column name,
// taken from the table header (data-label). Runs for every admin page.
function labelTable(table) {
  const heads = [...table.querySelectorAll(':scope > thead > tr:last-child > th')].map((th) => th.textContent.trim());
  if (!heads.length) return;
  table.querySelectorAll(':scope > tbody > tr').forEach((tr) => {
    let i = 0;
    [...tr.children].forEach((td) => {
      const span = Number(td.getAttribute('colspan')) || 1;
      const label = span > 1 ? '' : heads[i] || '';
      if (td.getAttribute('data-label') !== label) td.setAttribute('data-label', label);
      i += span;
    });
  });
}

export function watchAdminTables() {
  if (typeof document === 'undefined') return () => {};
  let raf = 0;
  const run = () => {
    raf = 0;
    document.querySelectorAll('html.admin-ui table').forEach(labelTable);
  };
  const schedule = () => { if (!raf) raf = requestAnimationFrame(run); };
  const mo = new MutationObserver(schedule);
  mo.observe(document.body, { childList: true, subtree: true });
  schedule();
  return () => { mo.disconnect(); if (raf) cancelAnimationFrame(raf); };
}
