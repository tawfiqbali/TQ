import { Navigate } from 'react-router-dom';
import useAdminRole from '../hooks/useAdminRole';
import FullPageLoader from '../components/ui/FullPageLoader';

// Lets Executives (Super Admins) through; Junior Admins go to the Management
// Portal (where they only see their own panels). allowJunior lets them in here.
export default function RoleRoute({ children, allowJunior = false }) {
  const { email, isSuper } = useAdminRole();
  if (email === null) return <FullPageLoader label="Checking your access" />;
  if (!isSuper && !allowJunior) return <Navigate to="/admin/portal" replace />;
  return children;
}
