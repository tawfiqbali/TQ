import { counselorSetPassword, unlockCounselor, unlockJunior } from '../lib/auth';
import { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { AlertTriangle, Eye, EyeOff, Lock } from 'lucide-react';
import { executivePinLength } from '../lib/teacherData';
import { authMode, getMyAccess, hasSession, ROLES, signIn, signInWithGoogle, signOut, unlockAdmin, usingDefaultPassword } from '../lib/auth';
import { hasStoredSession } from '../lib/supabaseClient';
import GoogleMark from '../components/shared/GoogleMark';
import { GlassCode, GlassStage, glassPause } from '../components/ui/GlassAuth';
import { portalLogin } from './portal/lib/api';
import { useSiteData } from '../context/SiteDataContext';

const MAX_ATTEMPTS = 5;
const LOCK_MS = 60_000;
const LOCK_KEY = 'qii:login-lock'; // survives a page reload

const TABS = [
  { role: ROLES.SUPER, label: 'Executive', hint: 'Only the approved Executive Gmails. First time on a device: Continue with Google, then the Executive password. After that, just the password.' },
  { role: ROLES.JUNIOR, label: 'Junior Admin', hint: 'Only the Gmails an Executive added under Security. Sign in with Google. Opens the teacher list and the teachers’ monthly reports.' },
  { role: ROLES.COUNSELOR, label: 'Academic Counselor', hint: 'Only the Gmails an Executive added as Academic Counselor. Continue with Google, then your own password.' },
];

export default function AdminLogin() {
  const navigate = useNavigate();
  const location = useLocation();
  const { content } = useSiteData();
  const [role, setRole] = useState(ROLES.SUPER);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [attempts, setAttempts] = useState(0);
  const [lockedUntil, setLockedUntilState] = useState(() => Number(localStorage.getItem(LOCK_KEY)) || 0);
  const setLockedUntil = (t) => {
    localStorage.setItem(LOCK_KEY, String(t));
    setLockedUntilState(t);
  };
  const [now, setNow] = useState(Date.now());
  const [params] = useSearchParams();
  const nextPath = (() => {
    const n = params.get('next') || location.state?.from || '/admin/portal';
    // signing in always lands on the Management Portal dashboard, unless a deeper page was asked for
    return n.startsWith('/admin/') && !n.startsWith('/admin/login') ? n : '/admin/portal';
  })();
  // Signed in with an Executive Gmail through Google: the password step
  const [execEmail, setExecEmail] = useState('');
  // This device is already connected with Google: wait for the check instead of
  // flashing the "Continue with Google" step, then bring the password panel in.
  const [checking, setChecking] = useState(() => authMode === 'supabase' && hasStoredSession());
  // the entrance motion plays once when the password panel appears (not again while typing)
  const [arriving, setArriving] = useState(true);
  // A Junior Admin Gmail on this device: the PIN step ({ hasPin: false } = choose one now)
  const [junior, setJunior] = useState(null);
  const [firstPin, setFirstPin] = useState('');
  // v188: an Academic Counselor Gmail: 'unlock' (own password) or 'change' (choose your own password)
  const [couns, setCouns] = useState(null);
  const [newPw, setNewPw] = useState({ a: '', b: '' });
  useEffect(() => {
    if (checking || !execEmail) return undefined;
    setArriving(true);
    const t = setTimeout(() => setArriving(false), 2000);
    return () => clearTimeout(t);
  }, [checking, execEmail]);
  // glossy password boxes: idle | error | success
  const [phase, setPhase] = useState('idle');
  const opened = phase === 'success';
  // The Executive password is a PIN of this many digits (0 = a text password)
  const [pin, setPin] = useState(0);
  useEffect(() => {
    if (!execEmail || junior || couns) return undefined;
    let alive = true;
    executivePinLength().then((n) => alive && setPin(n || 0)).catch(() => {});
    return () => {
      alive = false;
    };
  }, [execEmail, junior]);

  useEffect(() => {
    document.title = `Admin sign-in | ${content.site.brand.name}`;
    hasSession().then(async (ok) => {
      if (ok) return navigate(nextPath, { replace: true });
      if (authMode === 'supabase' && hasStoredSession()) {
        const a = await getMyAccess({ fresh: true }).catch(() => null);
        if (a?.role === 'exec_locked') {
          // know the PIN length before the boxes are drawn, so they do not change
          setPin((await executivePinLength().catch(() => 0)) || 0);
          setExecEmail(a.email || 'your Gmail');
        } else if (a?.role === 'counselor_locked') {
          setCouns('unlock');
          setPin(0);
          setExecEmail(a.email || 'your Gmail');
        } else if (a?.role === 'counselor') {
          if (!a.mustChange) return navigate('/counselor', { replace: true });
          setCouns('change');
          setPin(0);
          setExecEmail(a.email || 'your Gmail');
        } else if (a?.role === 'junior_locked') {
          setJunior({ hasPin: Boolean(a.hasPin), shared: Boolean(a.shared) });
          setPin(a.shared ? Number(a.pinLength) || 0 : 6);
          setExecEmail(a.email || 'your Gmail');
        }
      }
      return setChecking(false);
    }).catch(() => setChecking(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [navigate, content.site.brand.name]);

  const unlock = async (e, typed) => {
    e?.preventDefault();
    if (busy || locked) return;
    setBusy(true);
    setError('');
    try {
      const value = typed ?? password;
      // Junior Admin, first time: the PIN is typed twice before it is saved
      if (junior && !junior.hasPin) {
        if (!firstPin) { setFirstPin(value); setPassword(''); setBusy(false); return; }
        if (firstPin !== value) { setFirstPin(''); setPassword(''); setPhase('error'); setError('The two PINs were not the same. Choose your PIN again.'); setBusy(false); return; }
      }
      const r = couns ? await unlockCounselor(value) : junior ? await unlockJunior(value) : await unlockAdmin(value);
      if (r.ok && couns && r.mustChange) {
        // the first password came from the Executive: choose your own now
        setPassword('');
        setCouns('change');
        setBusy(false);
        return;
      }
      if (r.ok) {
        setPhase('success');
        await glassPause();
        setPassword('');
        navigate(couns ? '/counselor' : junior ? '/admin/portal' : nextPath, { replace: true });
        return;
      }
      setPhase('error');
      setFirstPin('');
      if (typed) setPassword(''); // a wrong PIN clears, ready for another try
      if (r.error === 'wrong') setError(r.left > 0 ? `That ${pin ? 'PIN' : 'password'} is not correct. ${r.left} tries left.` : `That ${pin ? 'PIN' : 'password'} is not correct.`);
      else if (r.error === 'too_many') setError(`Too many wrong tries. Please wait ${r.minutes || 15} minutes.`);
      else if (r.error === 'not_executive') setError('This Gmail does not have Executive access.');
      else if (r.error === 'not_junior') setError('This Gmail is no longer a Junior Admin.');
      else if (r.error === 'not_counselor') setError('This Gmail is no longer an Academic Counselor.');
      else if (r.error === 'bad_pin') setError('The PIN must be exactly 6 digits.');
      else setError('Please sign out and sign in again.');
    } catch (err) {
      setError(err.message);
    }
    setBusy(false);
  };
  const saveOwn = async (e) => {
    e?.preventDefault();
    if (busy) return;
    if (newPw.a.length < 6) { setError('Use at least 6 characters.'); return; }
    if (newPw.a !== newPw.b) { setError('The two passwords are not the same.'); return; }
    setBusy(true);
    setError('');
    try {
      await counselorSetPassword(newPw.a);
      setPhase('success');
      await glassPause();
      navigate('/counselor', { replace: true });
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  };
  const otherGmail = async () => {
    await signOut({ full: true });
    setJunior(null);
    setCouns(null);
    setNewPw({ a: '', b: '' });
    setFirstPin('');
    setExecEmail('');
    setPassword('');
    setError('');
  };

  useEffect(() => {
    if (lockedUntil <= Date.now()) return undefined;
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [lockedUntil]);

  const locked = lockedUntil > now;

  const submit = async (e) => {
    e.preventDefault();
    if (locked || busy) return;
    setBusy(true);
    setError('');
    try {
      const signedInAs = await signIn({ email: email.trim(), password, role });
      // Also open the Management Portal session (Google Sheets back end).
      // If that server is unreachable the portal asks again when opened.
      await portalLogin(email.trim(), password, signedInAs).catch(() => {});
      const from = location.state?.from;
      const home = signedInAs === ROLES.SUPER && from && from.startsWith('/admin/') ? from : '/admin/portal';
      navigate(home, { replace: true });
    } catch (err) {
      const n = attempts + 1;
      if (n >= MAX_ATTEMPTS) {
        setAttempts(0);
        setLockedUntil(Date.now() + LOCK_MS);
        setNow(Date.now());
        setError('Too many attempts. Sign-in is paused for 60 seconds.');
      } else {
        setAttempts(n);
        setError(err.message);
      }
    } finally {
      setBusy(false);
    }
  };

  const google = async () => {
    setBusy(true);
    setError('');
    try {
      await signInWithGoogle({ next: role === ROLES.SUPER ? nextPath : role === ROLES.COUNSELOR ? '/counselor' : '/admin/portal', intent: 'admin' });
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  };

  return (
    <GlassStage variant="office" success={opened} testId="admin-signin" below={!opened && (
      <Link to="/" className="mt-6 block text-center text-sm text-white/60 transition hover:text-white">Back to the website</Link>
    )}>
      <span className="glass-brand"><img src="/brand/logo-full.png" alt="QIT" /></span>
      <p className="glass-eyebrow mt-4">Management office · staff only</p>
      <h1 className="glass-title" aria-live="polite">{opened ? 'Welcome back' : 'Admin sign-in'}</h1>

      {checking ? (
        <div className="glass-checking" role="status" aria-label="Checking this device" data-testid="exec-checking-device">
          <span /><span /><span />
        </div>
      ) : execEmail && couns === 'change' ? (
        <form onSubmit={saveOwn} noValidate data-testid="counselor-change-step">
          {opened ? <p className="glass-sub">Opening your dashboard…</p> : (
            <>
              <p className="glass-sub">Signed in as <strong>{execEmail}</strong>. Choose your own password (6 or more characters). The first password from the office stops working.</p>
              <label htmlFor="cn-pw1" className="glass-label">New password</label>
              <input id="cn-pw1" type={showPassword ? 'text' : 'password'} autoComplete="new-password" className="glass-input" value={newPw.a} onChange={(e) => setNewPw((x) => ({ ...x, a: e.target.value }))} data-testid="cn-new1" autoFocus />
              <label htmlFor="cn-pw2" className="glass-label">Type it again</label>
              <input id="cn-pw2" type={showPassword ? 'text' : 'password'} autoComplete="new-password" className="glass-input" value={newPw.b} onChange={(e) => setNewPw((x) => ({ ...x, b: e.target.value }))} data-testid="cn-new2" />
              <button type="button" className="glass-link" style={{ marginTop: 10, fontSize: '0.78rem' }} onClick={() => setShowPassword((v) => !v)}>{showPassword ? 'Hide password' : 'Show password'}</button>
              {error && <p role="alert" className="glass-error" data-testid="exec-error">{error}</p>}
              <button type="submit" className="glass-btn" disabled={busy || !newPw.a || !newPw.b} data-testid="cn-save">
                <Lock className="h-4 w-4" aria-hidden="true" /> {busy ? 'Saving…' : 'Save and open my dashboard'}
              </button>
              <button type="button" onClick={otherGmail} className="glass-link">Use another Gmail</button>
            </>
          )}
        </form>
      ) : execEmail ? (
        <form onSubmit={unlock} noValidate data-testid="exec-password-step" className={arriving ? 'glass-reveal' : ''}>
          {opened ? <p className="glass-sub">Opening the admin panel…</p> : (
            <p className="glass-sub" data-testid="lock-text">Signed in with Google as <strong>{execEmail}</strong>. {couns ? 'Enter your Academic Counselor password.' : junior ? (junior.shared ? `Enter the Junior Admin ${pin ? 'PIN' : 'password'}.` : junior.hasPin ? 'Enter your Junior Admin PIN.' : firstPin ? 'Type the same PIN once more to confirm it.' : 'Choose a 6-digit PIN. From now on only this PIN is asked on this device.') : `Enter the Executive ${pin ? 'PIN' : 'password'} to open the admin panel on this device.`}{pin && !(junior && !junior.hasPin) ? ' It is checked as soon as you finish typing.' : ''}</p>
          )}
          <GlassCode id="exec-password" value={password} show={showPassword} state={phase} autoFocus minBoxes={pin || 6} pin={pin}
            inputMode={pin ? 'numeric' : undefined} ariaLabel={couns ? 'Academic Counselor password' : junior ? (pin ? 'Junior Admin PIN' : 'Junior Admin password') : pin ? 'Executive PIN' : 'Executive password'}
            onChange={(x) => {
              setPassword(x);
              if (phase === 'error') setPhase('idle');
              // a PIN is checked as soon as the last digit is typed
              if (pin && x.length === pin) unlock(null, x);
            }} />
          {!opened && (
            <>
              <button type="button" className="glass-link" style={{ marginTop: 12, fontSize: '0.78rem' }} onClick={() => setShowPassword((v) => !v)} aria-pressed={showPassword}>
                {showPassword ? <EyeOff className="mr-1 inline h-3.5 w-3.5" aria-hidden="true" /> : <Eye className="mr-1 inline h-3.5 w-3.5" aria-hidden="true" />}
                {showPassword ? (pin ? 'Hide PIN' : 'Hide password') : pin ? 'Show PIN' : 'Show password'}
              </button>
              {error && <p role="alert" className="glass-error" data-testid="exec-error">{error}</p>}
              {pin ? (busy && <p className="glass-sub" data-testid="exec-checking">Checking…</p>) : (
                <button type="submit" className="glass-btn" disabled={busy || !password}>
                  <Lock className="h-4 w-4" aria-hidden="true" /> {busy ? 'Checking…' : couns ? 'Open my dashboard' : 'Open admin panel'}
                </button>
              )}
              <button type="button" onClick={otherGmail} className="glass-link">Use another Gmail</button>
            </>
          )}
        </form>
      ) : (
        <div className="glass-rise" data-testid="admin-google-step">
          <div role="tablist" aria-label="Sign in as" className="glass-tabs">
            {TABS.map((t) => (
              <button key={t.role} type="button" role="tab" aria-selected={role === t.role} onClick={() => { setRole(t.role); setError(''); }}>{t.label}</button>
            ))}
          </div>
          <p className="glass-sub" style={{ fontSize: '0.78rem' }}>{TABS.find((t) => t.role === role).hint}</p>

          {role !== ROLES.SUPER || authMode === 'supabase' ? (
            <>
              <button type="button" onClick={google} disabled={busy} className="glass-btn is-plain">
                <GoogleMark />
                {busy ? 'Opening Google…' : 'Continue with Google'}
              </button>
              {error && <p role="alert" className="glass-error">{error}</p>}
              <p className="glass-sub" style={{ fontSize: '0.78rem', marginTop: 16 }}>
                Teacher? <Link to="/teacher/login" className="font-semibold text-white underline">Open the Teacher Dashboard</Link>
              </p>
            </>
          ) : (
            <form onSubmit={submit} noValidate>
              <label htmlFor="admin-email" className="glass-label">Email</label>
              <input id="admin-email" type="email" autoComplete="username" className="glass-input" value={email} onChange={(e) => setEmail(e.target.value)} required />
              <label htmlFor="admin-password" className="glass-label">Password</label>
              <input id="admin-password" type={showPassword ? 'text' : 'password'} autoComplete="current-password" className="glass-input" value={password} onChange={(e) => setPassword(e.target.value)} required />
              <button type="button" className="glass-link" style={{ marginTop: 10, fontSize: '0.78rem' }} onClick={() => setShowPassword((v) => !v)}>{showPassword ? 'Hide password' : 'Show password'}</button>
              {error && (
                <p role="alert" className="glass-error">
                  {locked ? `Too many attempts. Try again in ${Math.ceil((lockedUntil - now) / 1000)} seconds.` : error}
                </p>
              )}
              <button type="submit" className="glass-btn" disabled={busy || locked || !password || !email}>
                <Lock className="h-4 w-4" aria-hidden="true" /> {busy ? 'Signing in…' : 'Sign in'}
              </button>
            </form>
          )}
        </div>
      )}
      {usingDefaultPassword && !opened && (
        <p className="glass-note"><AlertTriangle className="mr-1 inline h-4 w-4" aria-hidden="true" /> The default password is active. Set VITE_ADMIN_PASSWORD_HASH before publishing the site.</p>
      )}
    </GlassStage>
  );
}
