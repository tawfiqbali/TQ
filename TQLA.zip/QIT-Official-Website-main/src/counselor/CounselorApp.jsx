import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  BookOpenCheck, Briefcase, CalendarClock, ClipboardList, GraduationCap, Inbox, LayoutGrid, LogOut, MessageSquarePlus, Plus, Search, Trash2, Users, X,
} from 'lucide-react';
import { getMyAccess, signOut } from '../lib/auth';
import {
  RECORD_KINDS, STATUSES, addRecord, deleteRecord, kindLabel, listRecords, loadCounselorData, onRecordsChange, statusLabel, studentReports, updateRecord,
} from '../lib/counselorData';
import { matchSearch } from '../lib/search';
import PhoneLinks from '../components/ui/PhoneLinks';
import FullPageLoader from '../components/ui/FullPageLoader';
import { PortalModal } from '../admin/portal/panels/common';
import { useConfirm } from '../components/ui/Confirm';
import { useToast } from '../components/ui/Toast';
import '../admin/portal/portal.css';
import './counselor.css';

/**
 * v188: the Academic Counselor's dashboard. Each counselor signs in with their
 * own Gmail + own password and sees the same screens with their own work:
 *  - students and teachers of their side (female counselors: the female
 *    teachers' students), never any fee, share, salary or bank detail
 *  - a file per student: details, the teacher's monthly reports and the
 *    shared counseling notes (every counselor and the office see them)
 *  - records: talks with students / guardians, exam results, problems,
 *    feedback, teacher contacts; "Send to the office" alerts the Executives
 */
const TABS = [
  { key: 'overview', label: 'Overview', Icon: LayoutGrid },
  { key: 'students', label: 'Students', Icon: GraduationCap },
  { key: 'teachers', label: 'Teachers', Icon: Users },
  { key: 'work', label: 'My work', Icon: Briefcase },
  { key: 'office', label: 'Office cases', Icon: Inbox },
];
const today = () => new Date().toISOString().slice(0, 10);
const when = (v) => (v ? new Date(v).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '');
const dueNow = (r) => r.follow_up && r.follow_up <= today() && r.status !== 'solved';

function StatusPill({ s }) {
  return <span className={`cn-pill cn-${s}`}>{statusLabel(s)}</span>;
}
function StatusDot({ s }) {
  return <span className={`cn-st cn-st-${String(s).toLowerCase()}`}>{s}</span>;
}

export default function CounselorApp() {
  const navigate = useNavigate();
  const [state, setState] = useState('checking');
  const [me, setMe] = useState(null);
  const [data, setData] = useState(null);
  const [records, setRecords] = useState([]);
  const [error, setError] = useState('');
  const [tab, setTab] = useState('overview');
  const [openStudent, setOpenStudent] = useState(null);
  const [form, setForm] = useState(null); // { record?, studentId? }

  useEffect(() => {
    document.documentElement.classList.add('admin-ui');
    document.title = 'Academic Counselor | QIT';
    return () => document.documentElement.classList.remove('admin-ui');
  }, []);

  const loadAll = useCallback(async () => {
    try {
      const [d, r] = await Promise.all([loadCounselorData(), listRecords()]);
      setData(d);
      setMe(d.me);
      setRecords(r);
      setError('');
    } catch (e) {
      setError(e.message);
    }
  }, []);

  useEffect(() => {
    let alive = true;
    (async () => {
      const a = await getMyAccess({ fresh: true }).catch(() => ({ role: 'none' }));
      if (!alive) return;
      if (a.role === 'counselor' && !a.mustChange) {
        setState('ready');
        loadAll();
      } else navigate(`/admin/login?next=${encodeURIComponent('/counselor')}`, { replace: true });
    })();
    return () => { alive = false; };
  }, [navigate, loadAll]);

  // other counselors' notes and the office's replies arrive by themselves
  useEffect(() => {
    if (state !== 'ready') return undefined;
    let stop = () => {};
    let t;
    onRecordsChange(() => {
      clearTimeout(t);
      t = setTimeout(() => listRecords().then(setRecords).catch(() => {}), 300);
    }).then((s) => { stop = s; }).catch(() => {});
    return () => { clearTimeout(t); stop(); };
  }, [state]);

  const teacherById = useMemo(() => Object.fromEntries((data?.teachers || []).map((t) => [t.id, t])), [data]);
  const studentById = useMemo(() => Object.fromEntries((data?.students || []).map((s) => [s.id, s])), [data]);
  const mine = useMemo(() => records.filter((r) => r.counselor_email === me?.email), [records, me]);

  const out = async () => {
    await signOut();
    navigate('/admin/login', { replace: true });
  };
  const saved = (r) => setRecords((list) => [r, ...list.filter((x) => x.id !== r.id)]);
  const removed = (id) => setRecords((list) => list.filter((x) => x.id !== id));

  if (state !== 'ready') return <FullPageLoader label="Opening your dashboard…" />;

  return (
    <div className="cn-page">
      <div className="qit-portal cn-wrap">
        <header className="p-header cn-head">
          <div className="flex min-w-0 items-center gap-3">
            <span className="logo-badge">QIT</span>
            <div className="min-w-0">
              <p className="cn-eyebrow">Academic Counselor</p>
              <h1 className="cn-name" data-testid="cn-name">{me?.name || me?.email || '…'}</h1>
              <p className="cn-sub">{me?.email}{me ? ` · ${me.gender === 'female' ? 'Female teachers’ students' : 'Male & residential teachers’ students'}` : ''}</p>
            </div>
          </div>
          <button type="button" className="btn-outline-sm inline-flex items-center gap-1" onClick={out} data-testid="cn-signout"><LogOut className="h-4 w-4" /> Sign out</button>
        </header>

        <nav className="main-nav" aria-label="Counselor menu">
          {TABS.map(({ key, label, Icon }) => (
            <button key={key} type="button" className={`nav-btn ${tab === key ? 'active' : ''}`} onClick={() => setTab(key)} aria-current={tab === key ? 'page' : undefined} data-testid={`cn-tab-${key}`}>
              <Icon className="h-4 w-4" aria-hidden="true" /> {label}
              {key === 'office' && mine.some((r) => r.office_reply && r.status === 'office') ? <span className="cn-dot" aria-label="new reply" /> : null}
            </button>
          ))}
        </nav>

        {error && <div className="box-card cn-error" role="alert">{error} <button type="button" className="btn-outline-sm ml-2" onClick={loadAll}>Try again</button></div>}
        {!data && !error && <div className="box-card">Loading…</div>}

        {data && tab === 'overview' && (
          <Overview data={data} mine={mine} records={records} studentById={studentById} onOpen={setOpenStudent} onEdit={(r) => setForm({ record: r })} onNew={() => setForm({})} />
        )}
        {data && tab === 'students' && <Students data={data} records={records} teacherById={teacherById} onOpen={setOpenStudent} />}
        {data && tab === 'teachers' && <Teachers data={data} onOpen={setOpenStudent} />}
        {data && tab === 'work' && <RecordList title="My work" list={mine} studentById={studentById} teacherById={teacherById} onEdit={(r) => setForm({ record: r })} onOpen={setOpenStudent} onNew={() => setForm({})} withFilter />}
        {data && tab === 'office' && (
          <RecordList title="Cases at the office" list={mine.filter((r) => r.status === 'office' || r.office_reply)} studentById={studentById} teacherById={teacherById}
            onEdit={(r) => setForm({ record: r })} onOpen={setOpenStudent}
            empty="Nothing sent to the office yet. Open a record and choose “Send to the office” when the office must act." />
        )}
      </div>

      {openStudent && studentById[openStudent] && (
        <StudentFile student={studentById[openStudent]} teacher={teacherById[studentById[openStudent].teacherId]} records={records.filter((r) => r.student_id === openStudent)}
          me={me} onClose={() => setOpenStudent(null)} onAdd={() => setForm({ studentId: openStudent })} onEdit={(r) => setForm({ record: r })} />
      )}
      {form && (
        <RecordForm initial={form.record} studentId={form.studentId} data={data} me={me} onClose={() => setForm(null)} onSaved={(r) => { saved(r); setForm(null); }} onRemoved={(id) => { removed(id); setForm(null); }} />
      )}
    </div>
  );
}

function Overview({ data, mine, records, studentById, onOpen, onEdit, onNew }) {
  const active = data.students.filter((s) => s.status === 'Active').length;
  const open = mine.filter((r) => r.status === 'open' || r.status === 'in_progress');
  const due = mine.filter(dueNow);
  const office = mine.filter((r) => r.status === 'office');
  const tiles = [
    ['Active students', active, GraduationCap],
    ['Teachers', data.teachers.filter((t) => t.status !== 'Inactive').length, Users],
    ['My open cases', open.length, ClipboardList],
    ['Follow-ups due', due.length, CalendarClock],
    ['At the office', office.length, Inbox],
  ];
  return (
    <>
      <div className="cn-tiles" data-testid="cn-overview">
        {tiles.map(([label, n, Icon]) => (
          <div key={label} className="tile cn-tile">
            <div className="tile-label inline-flex items-center gap-1"><Icon className="h-3.5 w-3.5" aria-hidden="true" /> {label}</div>
            <div className="tile-value">{n}</div>
          </div>
        ))}
      </div>
      <div className="box-card">
        <div className="card-header-bar">
          <h2 className="card-title">Follow-ups due</h2>
          <button type="button" className="btn-teal" onClick={onNew} data-testid="cn-new"><MessageSquarePlus className="h-4 w-4" /> New record</button>
        </div>
        {!due.length ? <p className="cn-empty">Nothing due today.</p> : due.map((r) => <RecordRow key={r.id} r={r} student={studentById[r.student_id]} onEdit={onEdit} onOpen={onOpen} />)}
      </div>
      <div className="box-card">
        <div className="card-header-bar"><h2 className="card-title">Latest notes from all counselors</h2></div>
        {!records.length ? <p className="cn-empty">No notes yet.</p> : records.slice(0, 10).map((r) => <RecordRow key={r.id} r={r} student={studentById[r.student_id]} onEdit={onEdit} onOpen={onOpen} showAuthor />)}
      </div>
    </>
  );
}

function Students({ data, records, teacherById, onOpen }) {
  const [q, setQ] = useState('');
  const [st, setSt] = useState('Active');
  const counts = useMemo(() => {
    const m = new Map();
    records.forEach((r) => r.student_id && r.status !== 'solved' && m.set(r.student_id, (m.get(r.student_id) || 0) + 1));
    return m;
  }, [records]);
  // typing a name searches every status
  const list = data.students.filter((s) => (q.trim() ? true : st === 'All' || s.status === st)
    && matchSearch(`${s.name} ${s.id} ${s.phone} ${teacherById[s.teacherId]?.name || ''}`, q));
  return (
    <div className="box-card">
      <div className="card-header-bar">
        <h2 className="card-title">Students ({list.length})</h2>
        <div className="flex flex-wrap gap-2">
          {['Active', 'Hold', 'Inactive', 'All'].map((k) => (
            <button key={k} type="button" className={`dir-tab ${st === k && !q.trim() ? 'active' : ''}`} onClick={() => setSt(k)}>{k}</button>
          ))}
        </div>
      </div>
      <label className="cn-search">
        <Search className="h-4 w-4" aria-hidden="true" />
        <input className="m-input" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name, ID, phone or teacher" data-testid="cn-search" />
      </label>
      <ul className="cn-list">
        {list.map((s) => (
          <li key={s.id}>
            <button type="button" className="cn-row" onClick={() => onOpen(s.id)} data-testid={`cn-student-${s.id}`}>
              <span className="min-w-0">
                <span className="cn-row-title">{s.name} <StatusDot s={s.status} /></span>
                <span className="cn-row-sub">{s.id} · {teacherById[s.teacherId]?.name || 'No teacher'}{s.classTime ? ` · ${s.classTime}` : ''}</span>
              </span>
              {counts.get(s.id) ? <span className="cn-pill cn-open">{counts.get(s.id)} open</span> : null}
            </button>
          </li>
        ))}
        {!list.length && <li className="cn-empty">No student found.</li>}
      </ul>
    </div>
  );
}

function Teachers({ data, onOpen }) {
  const [q, setQ] = useState('');
  const [pick, setPick] = useState(null);
  const list = data.teachers.filter((t) => matchSearch(`${t.name} ${t.id} ${t.whatsapp}`, q));
  return (
    <div className="box-card">
      <div className="card-header-bar"><h2 className="card-title">Teachers ({list.length})</h2></div>
      <label className="cn-search">
        <Search className="h-4 w-4" aria-hidden="true" />
        <input className="m-input" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search a teacher" />
      </label>
      <ul className="cn-list">
        {list.map((t) => (
          <li key={t.id} className="cn-trow">
            <div className="min-w-0">
              <div className="cn-row-title">{t.name} <span className="id-tag">{t.id}</span>{t.status === 'Inactive' ? <StatusDot s="Inactive" /> : null}</div>
              <div className="cn-row-sub">{t.category}{t.department ? ` · ${t.department}` : ''} · {t.students} active student{t.students === 1 ? '' : 's'}</div>
              <div className="cn-row-sub">WhatsApp <PhoneLinks value={t.whatsapp} /></div>
            </div>
            <button type="button" className="btn-outline-sm" onClick={() => setPick(pick === t.id ? null : t.id)} aria-expanded={pick === t.id}>Students</button>
            {pick === t.id && (
              <ul className="cn-sublist">
                {data.students.filter((s) => s.teacherId === t.id).map((s) => (
                  <li key={s.id}><button type="button" className="cn-link" onClick={() => onOpen(s.id)}>{s.name}</button> <StatusDot s={s.status} /></li>
                ))}
              </ul>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

function RecordRow({ r, student, onEdit, onOpen, showAuthor }) {
  return (
    <div className="cn-rec" data-testid={`cn-rec-${r.id}`}>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <span className="cn-kind">{kindLabel(r.kind)}</span>
          <strong className="cn-rec-title">{r.title}</strong>
          <StatusPill s={r.status} />
          {dueNow(r) && <span className="cn-pill cn-due">Follow-up {when(r.follow_up)}</span>}
        </div>
        <div className="cn-row-sub">
          {student ? <button type="button" className="cn-link" onClick={() => onOpen(student.id)}>{student.name}</button> : 'General'}
          {' · '}{when(r.created_at)}{showAuthor ? ` · ${r.counselor_name || r.counselor_email}` : ''}
        </div>
        {r.office_reply && <div className="cn-reply"><strong>Office:</strong> {r.office_reply}</div>}
      </div>
      <button type="button" className="btn-outline-sm" onClick={() => onEdit(r)}>Open</button>
    </div>
  );
}

function RecordList({ title, list, studentById, onEdit, onOpen, onNew, withFilter, empty = 'Nothing here yet.' }) {
  const [f, setF] = useState('active');
  const shown = withFilter ? list.filter((r) => (f === 'all' ? true : f === 'active' ? r.status !== 'solved' : r.status === f)) : list;
  return (
    <div className="box-card">
      <div className="card-header-bar">
        <h2 className="card-title">{title} ({shown.length})</h2>
        {onNew && <button type="button" className="btn-teal" onClick={onNew}><Plus className="h-4 w-4" /> New record</button>}
      </div>
      {withFilter && (
        <div className="mb-3 flex flex-wrap gap-2">
          {[['active', 'Not solved'], ...STATUSES.map((s) => [s.key, s.label]), ['all', 'All']].map(([k, l]) => (
            <button key={k} type="button" className={`dir-tab ${f === k ? 'active' : ''}`} onClick={() => setF(k)}>{l}</button>
          ))}
        </div>
      )}
      {!shown.length ? <p className="cn-empty">{empty}</p> : shown.map((r) => <RecordRow key={r.id} r={r} student={studentById[r.student_id]} onEdit={onEdit} onOpen={onOpen} />)}
    </div>
  );
}

function StudentFile({ student: s, teacher, records, me, onClose, onAdd, onEdit }) {
  const [reports, setReports] = useState(null);
  useEffect(() => {
    studentReports(s.id).then(setReports).catch(() => setReports([]));
  }, [s.id]);
  const exams = records.filter((r) => r.kind === 'exam');
  return (
    <PortalModal onClose={onClose} className="wide" labelledBy="cn-file-title">
      <div className="mb-3 flex items-start justify-between gap-3">
        <div>
          <h2 id="cn-file-title" className="card-title">{s.name}</h2>
          <p className="cn-row-sub mt-1"><span className="id-tag">{s.id}</span> <StatusDot s={s.status} /></p>
        </div>
        <button type="button" className="btn-icon-edit" onClick={onClose} aria-label="Close"><X className="h-4 w-4" /></button>
      </div>
      <div className="cn-grid">
        <div className="tile">
          <div className="tile-label">Student</div>
          <dl className="cn-dl">
            <dt>Phone / WhatsApp</dt><dd><PhoneLinks value={s.phone} /></dd>
            <dt>Class time</dt><dd>{s.classTime || '—'}{s.scheduleType === 'flexible' ? ' (flexible)' : ''}</dd>
            <dt>Medium</dt><dd>{s.medium || '—'}</dd>
            {s.course ? <><dt>Course</dt><dd>{s.course}</dd></> : null}
            {s.country ? <><dt>Country</dt><dd>{s.country}</dd></> : null}
            <dt>With the teacher since</dt><dd>{s.assignDate ? when(s.assignDate) : '—'}</dd>
          </dl>
        </div>
        <div className="tile">
          <div className="tile-label">Teacher</div>
          {teacher ? (
            <dl className="cn-dl">
              <dt>Name</dt><dd>{teacher.name} <span className="id-tag">{teacher.id}</span></dd>
              <dt>WhatsApp</dt><dd><PhoneLinks value={teacher.whatsapp} /></dd>
              <dt>Group</dt><dd>{teacher.category || '—'}</dd>
            </dl>
          ) : <p className="cn-empty">No teacher assigned.</p>}
        </div>
      </div>

      <div className="card-header-bar mt-5">
        <h3 className="card-title">Counseling notes ({records.length})</h3>
        <button type="button" className="btn-teal" onClick={onAdd} data-testid="cn-add-record"><MessageSquarePlus className="h-4 w-4" /> Add record</button>
      </div>
      {!records.length ? <p className="cn-empty">No notes yet. Every counselor and the office see the notes written here.</p> : records.map((r) => (
        <div key={r.id} className="cn-rec">
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2"><span className="cn-kind">{kindLabel(r.kind)}</span><strong>{r.title}</strong><StatusPill s={r.status} /></div>
            {r.kind === 'exam' && r.data?.exam ? <div className="cn-row-sub">{r.data.exam}{r.data.date ? ` · ${when(r.data.date)}` : ''} · {r.data.marks ?? '—'}{r.data.total ? ` / ${r.data.total}` : ''}{r.data.grade ? ` · ${r.data.grade}` : ''}</div> : null}
            {r.details && <p className="cn-details">{r.details}</p>}
            <div className="cn-row-sub">{r.counselor_name || r.counselor_email} · {when(r.created_at)}</div>
            {r.office_reply && <div className="cn-reply"><strong>Office:</strong> {r.office_reply}</div>}
          </div>
          {r.counselor_email === me?.email && <button type="button" className="btn-outline-sm" onClick={() => onEdit(r)}>Edit</button>}
        </div>
      ))}

      {exams.length > 0 && (
        <>
          <div className="card-header-bar mt-5"><h3 className="card-title">Exam results</h3></div>
          <div className="table-wrap"><table className="cn-table"><thead><tr><th>Exam</th><th>Date</th><th>Marks</th><th>Grade</th></tr></thead><tbody>
            {exams.map((r) => <tr key={r.id}><td>{r.data?.exam || r.title}</td><td>{r.data?.date ? when(r.data.date) : '—'}</td><td>{r.data?.marks ?? '—'}{r.data?.total ? ` / ${r.data.total}` : ''}</td><td>{r.data?.grade || '—'}</td></tr>)}
          </tbody></table></div>
        </>
      )}

      <div className="card-header-bar mt-5"><h3 className="card-title inline-flex items-center gap-2"><BookOpenCheck className="h-4 w-4" /> Teacher’s monthly reports</h3></div>
      {reports === null ? <p className="cn-empty">Loading…</p> : !reports.length ? <p className="cn-empty">No monthly report yet.</p> : reports.map((r) => (
        <details key={r.id} className="cn-report">
          <summary><strong>{r.month} {r.year}</strong> · {r.level || '—'} · present {r.present ?? '—'}/{r.total ?? '—'}</summary>
          <dl className="cn-dl">
            {r.lesson ? <><dt>Current lesson</dt><dd>{r.lesson}</dd></> : null}
            {r.taught ? <><dt>Taught</dt><dd>{r.taught}</dd></> : null}
            {r.next ? <><dt>Next target</dt><dd>{r.next}</dd></> : null}
            {r.absenceReason ? <><dt>Absence reason</dt><dd>{r.absenceReason}</dd></> : null}
            {r.remarks ? <><dt>Remarks</dt><dd>{r.remarks}</dd></> : null}
            <dt>Teacher</dt><dd>{r.teacher || '—'}</dd>
          </dl>
        </details>
      ))}
    </PortalModal>
  );
}

function RecordForm({ initial, studentId, data, me, onClose, onSaved, onRemoved }) {
  const toast = useToast();
  const confirm = useConfirm();
  const own = !initial || initial.counselor_email === me?.email;
  const [v, setV] = useState(() => ({
    student_id: initial?.student_id || studentId || '',
    kind: initial?.kind || 'consult_student',
    title: initial?.title || '',
    details: initial?.details || '',
    status: initial?.status || 'open',
    follow_up: initial?.follow_up || '',
    data: { ...(initial?.data || {}) },
  }));
  const [busy, setBusy] = useState(false);
  const [q, setQ] = useState('');
  const set = (k) => (e) => setV((x) => ({ ...x, [k]: e.target.value }));
  const setD = (k) => (e) => setV((x) => ({ ...x, data: { ...x.data, [k]: e.target.value } }));
  const student = data.students.find((s) => s.id === v.student_id);
  const options = data.students.filter((s) => matchSearch(`${s.name} ${s.id}`, q)).slice(0, 40);

  const save = async (status = v.status) => {
    if (v.title.trim().length < 2) { toast('Write a short title.', 'error'); return; }
    setBusy(true);
    try {
      const payload = { ...v, status, teacher_id: student?.teacherId || null };
      const r = initial ? await updateRecord(initial.id, {
        student_id: payload.student_id || null, kind: payload.kind, title: payload.title.trim(), details: payload.details.trim() || null,
        status, follow_up: payload.follow_up || null, data: payload.data, teacher_id: payload.teacher_id,
      }) : await addRecord(payload);
      toast(status === 'office' ? 'Sent to the office.' : 'Saved.');
      onSaved(r);
    } catch (e) {
      toast(e.message, 'error');
      setBusy(false);
    }
  };
  const remove = async () => {
    if (!(await confirm({ title: 'Delete this record?', message: 'It is removed for every counselor and the office.', confirmText: 'Delete', tone: 'danger' }))) return;
    try {
      await deleteRecord(initial.id);
      onRemoved(initial.id);
    } catch (e) {
      toast(e.message, 'error');
    }
  };

  return (
    <PortalModal onClose={onClose} labelledBy="cn-form-title">
      <div className="mb-3 flex items-start justify-between gap-3">
        <h2 id="cn-form-title" className="card-title">{initial ? (own ? 'Edit record' : 'Record') : 'New record'}</h2>
        <button type="button" className="btn-icon-edit" onClick={onClose} aria-label="Close"><X className="h-4 w-4" /></button>
      </div>
      <fieldset disabled={!own || busy} className="cn-form">
        <div className="form-group">
          <label htmlFor="cn-student">Student</label>
          {student ? (
            <div className="flex items-center gap-2"><strong>{student.name}</strong> <span className="id-tag">{student.id}</span>
              {own && <button type="button" className="btn-outline-sm" onClick={() => setV((x) => ({ ...x, student_id: '' }))}>Change</button>}</div>
          ) : (
            <>
              <input id="cn-student" className="m-input" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search the student (leave empty for a general note)" data-testid="cn-form-student" />
              {q.trim() && (
                <ul className="cn-pick">
                  {options.map((s) => <li key={s.id}><button type="button" onClick={() => { setV((x) => ({ ...x, student_id: s.id })); setQ(''); }}>{s.name} <small>{s.id}</small></button></li>)}
                  {!options.length && <li className="cn-empty">No student found.</li>}
                </ul>
              )}
            </>
          )}
        </div>
        <div className="form-group">
          <label htmlFor="cn-kind">What happened</label>
          <select id="cn-kind" className="m-select" value={v.kind} onChange={set('kind')} data-testid="cn-form-kind">
            {RECORD_KINDS.map((k) => <option key={k.key} value={k.key}>{k.label}</option>)}
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="cn-title">Title <span className="text-red-700">*</span></label>
          <input id="cn-title" className="m-input" maxLength={200} value={v.title} onChange={set('title')} placeholder="e.g. Guardian worried about missed classes" data-testid="cn-form-title" />
        </div>
        {v.kind === 'exam' && (
          <div className="cn-exam">
            <div className="form-group"><label htmlFor="cn-ex">Exam</label><input id="cn-ex" className="m-input" value={v.data.exam || ''} onChange={setD('exam')} placeholder="e.g. Monthly test" data-testid="cn-exam-name" /></div>
            <div className="form-group"><label htmlFor="cn-exd">Date</label><input id="cn-exd" type="date" className="m-input" value={v.data.date || ''} onChange={setD('date')} /></div>
            <div className="form-group"><label htmlFor="cn-exm">Marks</label><input id="cn-exm" inputMode="decimal" className="m-input" value={v.data.marks || ''} onChange={setD('marks')} data-testid="cn-exam-marks" /></div>
            <div className="form-group"><label htmlFor="cn-ext">Out of</label><input id="cn-ext" inputMode="decimal" className="m-input" value={v.data.total || ''} onChange={setD('total')} /></div>
            <div className="form-group"><label htmlFor="cn-exg">Grade</label><input id="cn-exg" className="m-input" value={v.data.grade || ''} onChange={setD('grade')} /></div>
          </div>
        )}
        <div className="form-group">
          <label htmlFor="cn-details">Details</label>
          <textarea id="cn-details" className="m-input" rows={5} maxLength={5000} value={v.details} onChange={set('details')} placeholder="What was said, what was agreed, what comes next" data-testid="cn-form-details" />
        </div>
        <div className="cn-two">
          <div className="form-group">
            <label htmlFor="cn-status">Status</label>
            <select id="cn-status" className="m-select" value={v.status} onChange={set('status')} data-testid="cn-form-status">
              {STATUSES.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="cn-fu">Follow up on</label>
            <input id="cn-fu" type="date" className="m-input" value={v.follow_up || ''} onChange={set('follow_up')} />
          </div>
        </div>
      </fieldset>
      {initial?.office_reply && <div className="cn-reply mt-2"><strong>Office reply:</strong> {initial.office_reply}</div>}
      {own && (
        <div className="mt-4 flex flex-wrap items-center justify-between gap-2">
          {initial ? <button type="button" className="btn-danger inline-flex items-center gap-1" onClick={remove}><Trash2 className="h-4 w-4" /> Delete</button> : <span />}
          <div className="flex flex-wrap gap-2">
            {v.status !== 'office' && <button type="button" className="btn-outline-sm" onClick={() => save('office')} disabled={busy} data-testid="cn-send-office">Send to the office</button>}
            <button type="button" className="btn-teal" onClick={() => save()} disabled={busy} data-testid="cn-save-record">{busy ? 'Saving…' : 'Save'}</button>
          </div>
        </div>
      )}
    </PortalModal>
  );
}
