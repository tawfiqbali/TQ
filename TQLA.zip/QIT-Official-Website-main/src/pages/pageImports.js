// Inner pages load on demand and are prefetched while the browser is idle
// (see PublicLayout), so the home page's first download stays small.
export const pageImports = {
  courses: () => import('./CoursesPage'),
  about: () => import('./AboutPage'),
  instructors: () => import('./InstructorsPage'),
  contact: () => import('./ContactPage'),
  notFound: () => import('./NotFound'),
  privacy: () => import('./PrivacyPage'),
  terms: () => import('./TermsPage'),
};
