import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import FullPageLoader from '../components/ui/FullPageLoader';
import { getSupabase } from '../lib/supabaseClient';
import { clearAccessCache, getMyAccess } from '../lib/auth';
import { useT, useTeacherDocument } from '../teacher/i18n';

// Only same-site paths may be used as the page to continue to
const safeNext = (v) => (typeof v === 'string' && v.startsWith('/') && !v.startsWith('//') ? v : '');

/**
 * Google sends people back here after "Continue with Google". The Supabase
 * client swaps the one-time code for a session, then we continue to the page
 * they came from, or to the home page for their role.
 */
export default function AuthCallback() {
  const navigate = useNavigate();
  const [error, setError] = useState('');
  const { t, err, lang } = useT();
  useTeacherDocument(t('cb.signing'));

  useEffect(() => {
    let alive = true;
    (async () => {
      const params = new URLSearchParams(window.location.search);
      const hash = new URLSearchParams(window.location.hash.slice(1));
      const failed = params.get('error_description') || hash.get('error_description');
      if (failed) return setError(failed);
      try {
        const sb = await getSupabase();
        let { data } = await sb.auth.getSession();
        const code = params.get('code');
        if (!data.session && code) {
          const res = await sb.auth.exchangeCodeForSession(code);
          if (res.error) throw res.error;
          data = res.data;
        }
        if (!data.session) throw new Error('Google sign-in did not finish. Please try again.');
        clearAccessCache();
        const access = await getMyAccess({ fresh: true });
        if (!alive) return;
        const next = safeNext(params.get('next'));
        const intent = params.get('intent') || (next.startsWith('/admin') ? 'admin' : '');
        // Executive Gmail: the Executive password comes next, on the admin sign-in page
        // (a Junior Admin Gmail: the PIN comes next, on the same page)
        if (access.role === 'exec_locked' || access.role === 'junior_locked' || access.role === 'counselor_locked'
          || (access.role === 'counselor' && access.mustChange)) {
          // v188: an Academic Counselor's password step is on the same page
          const to = access.role.startsWith('counselor') ? '/counselor' : next.startsWith('/admin/') ? next : '/admin/portal';
          navigate(`/admin/login?next=${encodeURIComponent(to)}`, { replace: true });
          return;
        }
        const isAdmin = access.role === 'super' || access.role === 'junior' || access.role === 'counselor';
        // Admin sign-in with a Gmail that is not on the admin lists: refused
        // (never sent to the teacher sign-up)
        if (intent === 'admin' && !isAdmin) {
          setError(access.setupMissing
            ? 'The security settings are not set up in the cloud database yet. Please ask the QIT office.'
            : t('cb.noAdmin', { email: access.email || 'This account' }));
          await sb.auth.signOut();
          return;
        }
        if (access.role === 'counselor') { navigate('/counselor', { replace: true }); return; }
        const home = { super: '/admin/portal', junior: '/admin/portal', teacher: '/teacher', locked: '/teacher', pending: '/teacher', new: '/teacher/onboarding' }[access.role];
        if (access.role === 'none' || !home) {
          setError(
            access.setupMissing
              ? 'The teacher system is not set up in the cloud database yet. Please ask the QIT office.'
              : access.reason === 'google_required'
                ? t('cb.google')
                : lang === 'bn'
                  ? `${access.email || 'এই অ্যাকাউন্টটি'} Gmail অ্যাকাউন্ট নয়। শিক্ষক ও জুনিয়র অ্যাডমিনদের Gmail দিয়ে সাইন-ইন করতে হবে।`
                  : `${access.email || 'This account'} is not a Gmail account. Teachers and Junior Admins must sign in with Gmail.`,
          );
          await sb.auth.signOut();
          return;
        }
        // A teacher link (e.g. /teacher/report) is kept; admins go to their own area
        const teacherSide = !isAdmin;
        const allowed = next && (teacherSide ? next.startsWith('/teacher') : next.startsWith('/admin/'));
        navigate(access.role === 'new' ? `/teacher/onboarding${next ? `?next=${encodeURIComponent(next)}` : ''}` : allowed ? next : home, { replace: true });
      } catch (e) {
        if (alive) setError(e.message || 'Sign-in failed. Please try again.');
      }
    })();
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [navigate]);

  if (!error) return <FullPageLoader label={t('cb.signing')} />;
  return (
    <main className="flex min-h-screen items-center justify-center bg-paper px-4">
      <div className="max-w-md rounded-3xl bg-surface p-8 text-center shadow-2xl" role="alert">
        <h1 className="text-xl text-heading">{t('cb.failed')}</h1>
        <p className="mt-3 text-sm text-ink/70">{err(error)}</p>
        <div className="mt-6 flex justify-center gap-3">
          <Link to="/teacher/login" className="btn-primary">{t('cb.teacher')}</Link>
          <Link to="/admin/login" className="btn-ghost">{t('cb.admin')}</Link>
        </div>
      </div>
    </main>
  );
}
