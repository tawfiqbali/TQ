import usePageTitle from '../hooks/usePageTitle';
import { useSiteData } from '../context/SiteDataContext';
import { LegalPage } from './PrivacyPage';

export default function TermsPage() {
  usePageTitle('Terms of Service');
  const { content } = useSiteData();
  const email = content?.site?.contact?.email || 'qitoffice.info@gmail.com';
  const name = content?.site?.brand?.name || 'Quran International Institute';
  return (
    <LegalPage title="Terms of Service" updated="27 September 2026">
      <p>These terms apply to the {name} (“QIT”) website, its online classes and the Teacher Dashboard.</p>

      <h2>Classes and fees</h2>
      <p>
        Course details, schedules and fees are shown on this website or agreed with our office. Fees are paid monthly in advance
        unless agreed otherwise. The free trial class lets you try a class before enrolling.
      </p>

      <h2>Teacher Dashboard</h2>
      <ul>
        <li>The Teacher Dashboard is for QIT teachers only. Sign in with your own Gmail account and keep it secure.</li>
        <li>Monthly reports, attendance and schedules you submit must be accurate; salaries are calculated from them.</li>
        <li>Student information you see is confidential and may only be used for teaching at QIT.</li>
        <li>QIT may suspend access if the dashboard is misused or when a teacher leaves.</li>
      </ul>

      <h2>Conduct</h2>
      <p>Students, guardians and teachers are expected to behave respectfully in classes and communications.</p>

      <h2>Changes and availability</h2>
      <p>We work to keep the website and dashboard available but cannot guarantee uninterrupted service. We may update these terms; the date above shows the latest version.</p>

      <h2>Privacy</h2>
      <p>How we handle personal information is explained in our <a className="text-brand underline" href="/privacy">Privacy Policy</a>.</p>

      <h2>Contact</h2>
      <p>Questions? Email <a className="text-brand underline" href={`mailto:${email}`}>{email}</a> or WhatsApp +880 1928-616108.</p>
    </LegalPage>
  );
}
