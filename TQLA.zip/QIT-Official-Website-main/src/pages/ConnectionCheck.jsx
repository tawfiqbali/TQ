import { useEffect, useState } from 'react';
import { supabaseAnonKey, supabaseUrl, usingProxy } from '../lib/supabaseClient';

// v157: /check — a teacher (e.g. in Egypt) opens this page and sends the
// office a screenshot: which part of the connection works on their network.
const TESTS = [
  ['site', 'This website (Netlify)'],
  ['direct', 'Database, direct (supabase.co)'],
  ['proxy', 'Database through this website'],
  ['google', 'Google sign-in (accounts.google.com)'],
];

async function timed(fn, ms = 8000) {
  const t0 = performance.now();
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), ms);
  try {
    const r = await fn(ctrl.signal);
    return { ok: r !== false, ms: Math.round(performance.now() - t0) };
  } catch (e) {
    return { ok: false, ms: Math.round(performance.now() - t0), error: e.name === 'AbortError' ? 'no answer (timed out)' : e.message };
  } finally {
    clearTimeout(timer);
  }
}

export default function ConnectionCheck() {
  const [res, setRes] = useState({});
  const [done, setDone] = useState(false);
  useEffect(() => {
    document.title = 'Connection check | QIT';
    const h = { apikey: supabaseAnonKey };
    const run = {
      site: () => timed((signal) => fetch(`/manifest.webmanifest?t=${Date.now()}`, { signal }).then((r) => r.ok)),
      direct: () => timed((signal) => fetch(`${supabaseUrl}/auth/v1/health`, { headers: h, signal }).then((r) => r.status < 500)),
      proxy: () => timed((signal) => fetch(`/sbapi/auth/v1/health`, { headers: h, signal }).then((r) => r.status < 500)),
      google: () => timed((signal) => fetch('https://accounts.google.com/gsi/client', { mode: 'no-cors', signal }).then(() => true)),
    };
    Promise.all(TESTS.map(async ([k]) => { const r = await run[k](); setRes((x) => ({ ...x, [k]: r })); })).then(() => setDone(true));
  }, []);
  const summary = TESTS.map(([k, label]) => `${label}: ${res[k] ? (res[k].ok ? `OK (${res[k].ms} ms)` : `FAILED${res[k].error ? ` – ${res[k].error}` : ''}`) : '…'}`).join('\n');
  const verdict = !done ? 'Checking…'
    : res.direct?.ok ? 'Everything the Teacher Dashboard needs is reachable.'
      : res.proxy?.ok ? 'Your network blocks the database address, but the website route works: the dashboard switches to it by itself.'
        : 'The database cannot be reached from this network. Please send this screen to the QIT office.';
  return (
    <main style={{ minHeight: '100vh', background: '#f4f8f8', padding: '32px 16px', fontFamily: 'inherit' }}>
      <div style={{ maxWidth: 560, margin: '0 auto', background: '#fff', borderRadius: 20, padding: 24, boxShadow: '0 18px 40px -24px rgba(0,40,40,.5)' }}>
        <h1 style={{ fontSize: '1.4rem', fontWeight: 800, color: '#05535b' }}>Connection check</h1>
        <p style={{ marginTop: 4, color: '#4b6466', fontSize: '.9rem' }}>Send a screenshot of this page to the QIT office if the Teacher Dashboard does not open.</p>
        <ul style={{ marginTop: 18, display: 'grid', gap: 10 }} data-testid="check-list">
          {TESTS.map(([k, label]) => (
            <li key={k} style={{ display: 'flex', justifyContent: 'space-between', gap: 12, padding: '10px 14px', borderRadius: 12, background: '#f3f8f8', border: '1px solid #d6e6e4' }}>
              <span style={{ fontWeight: 700 }}>{label}</span>
              <span data-testid={`check-${k}`} style={{ fontWeight: 800, color: !res[k] ? '#64748b' : res[k].ok ? '#05603a' : '#b42318', whiteSpace: 'nowrap' }}>
                {!res[k] ? '…' : res[k].ok ? `OK · ${res[k].ms} ms` : 'Failed'}
              </span>
            </li>
          ))}
        </ul>
        <p style={{ marginTop: 16, fontWeight: 700 }} data-testid="check-verdict">{verdict}</p>
        <p style={{ marginTop: 6, fontSize: '.8rem', color: '#64748b' }}>Route in use on this browser: {usingProxy() ? 'through this website' : 'direct'} · {navigator.userAgent.slice(0, 80)}</p>
        <button type="button" onClick={() => navigator.clipboard?.writeText(`QIT connection check\n${summary}\n${navigator.userAgent}`)} style={{ marginTop: 14, padding: '10px 16px', borderRadius: 12, background: '#05535b', color: '#fff', fontWeight: 800 }}>Copy results</button>
      </div>
    </main>
  );
}
