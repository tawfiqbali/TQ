import usePageTitle from '../hooks/usePageTitle';
import { useSiteData } from '../context/SiteDataContext';

// Privacy policy (also the link Google's sign-in consent screen points to)
export function LegalPage({ title, updated, children }) {
  return (
    <section className="container-page py-16 sm:py-20">
      <div className="mx-auto max-w-3xl">
        <p className="eyebrow">Legal</p>
        <h1 className="mt-2 text-3xl sm:text-4xl">{title}</h1>
        <p className="mt-2 text-sm text-ink/60">Last updated: {updated}</p>
        <div className="legal mt-8 space-y-6 text-[15px] leading-relaxed text-ink/80 [&_h2]:mt-10 [&_h2]:text-xl [&_h2]:text-heading [&_li]:ml-5 [&_li]:list-disc [&_ul]:space-y-1.5">
          {children}
        </div>
      </div>
    </section>
  );
}

export default function PrivacyPage() {
  usePageTitle('Privacy Policy');
  const { content } = useSiteData();
  const email = content?.site?.contact?.email || 'qitoffice.info@gmail.com';
  const name = content?.site?.brand?.name || 'Quran International Institute';
  return (
    <LegalPage title="Privacy Policy" updated="27 September 2026">
      <p>
        This policy explains what information {name} (“QIT”, “we”) collects through this website
        (quraninternational.academy) and its Teacher Dashboard, and how we use it.
      </p>

      <h2>Information we collect</h2>
      <ul>
        <li><strong>Enquiries and trial bookings:</strong> the name, email, phone/WhatsApp number, course interest, preferred time and message you type into our forms.</li>
        <li><strong>Teachers and staff who sign in with Google:</strong> your name, Gmail address and Google account ID, provided by Google when you choose “Continue with Google”, and the full name and WhatsApp number you enter to receive your Teacher ID.</li>
        <li><strong>Teaching records:</strong> class schedules, monthly progress reports, attendance, and support or leave requests that teachers submit, and the salary records our office keeps for each teacher.</li>
        <li><strong>Your preferences in this browser:</strong> such as the chosen language and theme, saved only on your own device.</li>
      </ul>
      <p>We do not use advertising trackers and we do not sell or rent personal information.</p>

      <h2>How we use it</h2>
      <ul>
        <li>To reply to enquiries, arrange trial classes and run our courses.</li>
        <li>To let teachers see their own students, schedules, reports and salary history, and to let our office review monthly reports and pay salaries.</li>
        <li>To prepare progress reports for students and their guardians.</li>
        <li>To keep the website and accounts secure.</li>
      </ul>

      <h2>Google sign-in</h2>
      <p>
        We only request your basic Google profile (name, email address and account ID) to sign you in. We do not access your
        Gmail messages, contacts, Drive or any other Google data. Our use of information received from Google follows the
        Google API Services User Data Policy, including its Limited Use requirements.
      </p>

      <h2>Where it is stored and who can see it</h2>
      <p>
        Information is stored securely with our database provider (Supabase) and our website host (Netlify). Access is limited by
        role: a teacher sees only their own records; Junior Admins see the teacher list and monthly reports; only QIT executives
        see salary and payment details. We share information only when needed to provide our services or when required by law.
      </p>

      <h2>How long we keep it</h2>
      <p>We keep records for as long as you study or teach with us and as needed for our accounts, then delete or anonymise them.</p>

      <h2>Your choices</h2>
      <p>
        You can ask us to see, correct or delete your information, or to remove your Teacher Dashboard account, by emailing{' '}
        <a className="text-brand underline" href={`mailto:${email}`}>{email}</a>. You can also remove QIT’s access to your Google account at any time in
        your Google Account settings (Security → Third-party apps).
      </p>

      <h2>Children</h2>
      <p>Enquiries for students under 18 should be made by a parent or guardian, who controls the student’s information.</p>

      <h2>Contact</h2>
      <p>
        {name}, 9/15, Junayed Complex, Delta Mor, Rajashon Road, Savar-1340, Dhaka, Bangladesh.<br />
        Email: <a className="text-brand underline" href={`mailto:${email}`}>{email}</a> · Phone/WhatsApp: +880 1928-616108
      </p>
      <p>We may update this policy; the date above shows the latest version.</p>
    </LegalPage>
  );
}
