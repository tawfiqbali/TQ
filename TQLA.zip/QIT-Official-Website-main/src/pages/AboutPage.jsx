import { Check } from 'lucide-react';
import usePageTitle from '../hooks/usePageTitle';
import { useContent, useLanguage } from '../i18n/LanguageContext';
import PageHeader from '../components/shared/PageHeader';
import Features from '../components/home/Features';
import CtaBand from '../components/home/CtaBand';

export default function AboutPage() {
  usePageTitle('pages.aboutTitle');
  const content = useContent();
  const { t } = useLanguage();
  const { about, brand } = content.site;
  const paragraphs = (about.body || '').split(/\n\s*\n/).filter(Boolean);

  return (
    <>
      <PageHeader title={about.heading} />
      <section className="py-10 md:py-14">
        <div className="container-page grid gap-14 lg:grid-cols-[1.2fr_0.8fr] lg:gap-20">
          <div className="space-y-5 text-base leading-relaxed text-ink/75">
            {paragraphs.map((p, i) => (
              <p key={i}>{p}</p>
            ))}
            {about.values?.length > 0 && (
              <div className="pt-6">
                <h2 className="text-2xl">{t('pages.aboutValues')}</h2>
                <ul className="mt-5 space-y-3 text-base">
                  {about.values.map((v) => (
                    <li key={v} className="flex gap-3">
                      <Check className="mt-1 h-5 w-5 shrink-0 text-pine-500" aria-hidden="true" />
                      {v}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
          {about.mission && (
            <aside className="rounded-[2rem] dot-grid flex aspect-[4/5] max-w-sm flex-col items-center justify-center self-start bg-pine-900 px-10 pt-10 text-center">
              <h2 className="text-lg text-gold-300">{t('pages.aboutMission')}</h2>
              <p className="mt-4 font-display text-2xl leading-snug text-white">{about.mission}</p>
              <p className="mt-6 text-xs text-pine-100/70">{brand.name}</p>
            </aside>
          )}
        </div>
      </section>
      <Features />
      <CtaBand />
    </>
  );
}
