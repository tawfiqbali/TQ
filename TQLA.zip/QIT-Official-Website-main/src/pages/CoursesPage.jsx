import usePageTitle from '../hooks/usePageTitle';
import CoursesSection from '../components/home/CoursesSection';
import CtaBand from '../components/home/CtaBand';

export default function CoursesPage() {
  usePageTitle('pages.coursesTitle');
  return (
    <>
      <CoursesSection onlyFeatured={false} />
      <CtaBand />
    </>
  );
}
