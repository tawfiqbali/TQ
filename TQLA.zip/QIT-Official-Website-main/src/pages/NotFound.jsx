import { useLanguage } from '../i18n/LanguageContext';
import { Link } from 'react-router-dom';
import usePageTitle from '../hooks/usePageTitle';

export default function NotFound() {
  usePageTitle('common.notFoundTitle');
  const { t } = useLanguage();
  return (
    <section className="container-page py-28 text-center">
      <h1 className="text-4xl">{t('pages.notFoundHeading')}</h1>
      <p className="mt-4 text-ink/70">{t('pages.notFoundText')}</p>
      <Link to="/" className="btn-primary mt-8">
        {t('pages.notFoundHome')}
      </Link>
    </section>
  );
}
