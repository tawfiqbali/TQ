import { useSearchParams } from 'react-router-dom';
import { Clock, Mail, MapPin, Phone } from 'lucide-react';
import { WhatsAppIcon } from '../components/shared/BrandIcons';
import usePageTitle from '../hooks/usePageTitle';
import { useSiteData } from '../context/SiteDataContext';
import { useContent, useLanguage } from '../i18n/LanguageContext';
import { whatsappLink, mapsLink, gmailLink } from '../lib/utils';
import PageHeader from '../components/shared/PageHeader';
import InquiryForm from '../components/shared/InquiryForm';
import TrialForm from '../components/shared/TrialForm';

export default function ContactPage() {
  usePageTitle('pages.contactTitle');
  const content = useContent();
  const raw = useSiteData().content; // untranslated address for the Maps link
  const { t } = useLanguage();
  const { contact } = content.site;
  const [params, setParams] = useSearchParams();
  const type = params.get('type') === 'trial' ? 'trial' : 'contact';
  const wa = whatsappLink(contact.whatsapp);

  const rows = [
    contact.email && { Icon: Mail, label: t('pages.contactEmail'), value: contact.email, href: gmailLink(contact.email) },
    contact.phone && { Icon: Phone, label: contact.phoneNote ? t('pages.contactPhoneWithNote', { note: contact.phoneNote }) : t('pages.contactPhone'), value: contact.phone, href: `tel:${contact.phone.replace(/[^\d+]/g, '')}` },
    wa && { Icon: WhatsAppIcon, label: t('pages.contactWhatsapp'), value: contact.whatsapp, href: wa },
    contact.address && { Icon: MapPin, label: t('pages.contactOffice'), value: contact.address, href: mapsLink(raw.site.contact.address || contact.address) },
    contact.hours && { Icon: Clock, label: t('pages.contactHours'), value: contact.hours },
  ].filter(Boolean);

  return (
    <>
      <PageHeader title={t('pages.contactHeading')} intro={t('pages.contactIntro')} />
      <section className="py-10 md:py-14">
        <div className="container-page grid gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:gap-16">
          <dl className="space-y-6">
            {rows.map(({ Icon, label, value, href }) => (
              <div key={label} className="flex gap-4">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-tint text-brand">
                  <Icon className="h-5 w-5" aria-hidden="true" />
                </span>
                <div>
                  <dt className="text-sm text-ink/60">{label}</dt>
                  <dd className="mt-0.5 font-medium text-ink">
                    {href ? (
                      <a href={href} className="break-words hover:text-brand hover:underline" {...(href.startsWith('http') ? { target: '_blank', rel: 'noreferrer' } : {})}>
                        {value}
                      </a>
                    ) : (
                      value
                    )}
                  </dd>
                </div>
              </div>
            ))}
          </dl>

          <div className="card-3d card-teal p-6 hover:translate-y-0 sm:p-8">
            <div role="tablist" aria-label={t('pages.chooseForm')} className="mb-6 inline-flex rounded-full border border-ink/15 p-1">
              {[
                ['trial', t('pages.tabTrial')],
                ['contact', t('pages.tabMessage')],
              ].map(([key, label]) => (
                <button
                  key={key}
                  role="tab"
                  aria-selected={type === key}
                  onClick={() => setParams(key === 'trial' ? { type: 'trial' } : {}, { replace: true })}
                  className={`rounded-full px-4 py-2 text-sm font-medium ${type === key ? 'bg-pine-900 text-white' : 'text-ink/65 hover:text-brand'}`}
                >
                  {label}
                </button>
              ))}
            </div>
            {type === 'trial' ? (
              <div className="-mx-6 -mb-6 sm:-mx-8 sm:-mb-8">
                <TrialForm key="trial" />
              </div>
            ) : (
              <InquiryForm key="contact" />
            )}
          </div>
        </div>
      </section>
    </>
  );
}
