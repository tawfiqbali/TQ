import usePageTitle from '../hooks/usePageTitle';
import Hero from '../components/home/Hero';
import FacultyTicker from '../components/home/FacultyTicker';
import CoursesSection from '../components/home/CoursesSection';
import HowItWorks from '../components/home/HowItWorks';
import Features from '../components/home/Features';
import Testimonials from '../components/home/Testimonials';
import FeaturedPhoto from '../components/home/FeaturedPhoto';
import Faq from '../components/home/Faq';
import BoardSection from '../components/home/BoardSection';
import CtaBand from '../components/home/CtaBand';

export default function Home() {
  usePageTitle('');
  return (
    <>
      <FacultyTicker />
      <Hero />
      <CoursesSection />
      <HowItWorks />
      <Features />
      <FeaturedPhoto />
      <Testimonials />
      <Faq />
      <BoardSection />
      <CtaBand />
    </>
  );
}
