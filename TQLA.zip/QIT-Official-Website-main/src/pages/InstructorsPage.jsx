import usePageTitle from '../hooks/usePageTitle';
import { useContent, useLanguage } from '../i18n/LanguageContext';
import PageHeader from '../components/shared/PageHeader';
import InstructorCard from '../components/shared/InstructorCard';
import CtaBand from '../components/home/CtaBand';

export default function InstructorsPage() {
  usePageTitle('pages.instructorsTitle');
  const content = useContent();
  const { t } = useLanguage();
  return (
    <>
      <PageHeader
        title={t('pages.instructorsHeading')}
        intro={t('pages.instructorsIntro')}
      />
      <section className="py-10 md:py-14">
        <div className="container-page grid gap-12 sm:grid-cols-2 lg:grid-cols-4">
          {content.instructors.map((i) => (
            <InstructorCard key={i.id} instructor={i} />
          ))}
        </div>
      </section>
      <CtaBand />
    </>
  );
}
